// Licensed to 76561198147781703
	
local PANEL = {}

function PANEL:Init()
	self.panel_id = nil
	self.item_cell = nil
	self.cur_cell_items_tbl = nil
	self.lang = 1
	
	self.items = {}
end

function PANEL:Paint(w, h)
	--draw.RoundedBox(0, 0, 0, w, h , Color(100, 100, 200))
	adv_daily_login:OutlinedBox( 0, 0, w, h, 1, Color(53, 79, 115 , 200) )
	--daytitle
	--dayid

	if self.items.daytitle then

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Big_font" )
		surface.SetTextColor( Color(255,255,255) )
		surface.SetTextPos( 6 , ( self:GetTall() / 2 ) - (select(2, surface.GetTextSize( self.items.daytitle )) / 2) )
		surface.DrawText( self.items.daytitle )

	end
end

function PANEL:SetPanelID(_id, _cell, _cur_cell_items_tbl)
	self.panel_id = _id
	self.item_cell = _cell
	self.cur_cell_items_tbl = _cur_cell_items_tbl
end

function PANEL:OnCursorEntered()
	surface.PlaySound( adv_daily_login.sound.item_hover_sound )
	-- print(PrintTable(self.items))
	--self.hover = true
end

function PANEL:OnCursorExited()
	--self.hover = false
end

function PANEL:SetData(item_data)
	self.items = {}
	--PrintTable(item_data)
	if istable(item_data) then
		-- PrintTable(item_data)
		self.items = item_data
	end
	
	-- self.item_name_color = item_data.item_color
	-- self.item_name = item_data.item_name
	-- self.item_type = item_data.item_type
	-- self.item_count = item_data.item_count
	-- self.item_id = item_data.item_id
end

function PANEL:GetCellID()
	return self.items.dayid
end

function PANEL:GetLang()
	return self.lang
end

function PANEL:SetupLang(lng_index)
	if (lng_index) == 0 then return end
	self.lang = lng_index
end

function PANEL:CreateStuff()
	-- self.open_editor = vgui.Create( "AdvDailyLogin_Button", self )
	-- self.open_editor:SetText('X')
	-- self.open_editor:MakePop(self.pnl)
	-- self.open_editor:SetSize( 12, 12 )
	-- self.open_editor:SetPos( self:GetWide() - 12 - 12 - 5, (self:GetTall() / 2) - (self.open_editor:GetTall() / 2)  )
	-- -- print(self.open_editor)

	-- self.open_editor.DoClick = function()	
	-- 	--adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
	-- end

	self.open_editor = vgui.Create( "AdvDailyLogin_Button", self )
	self.open_editor:SetSize( 16, 16 )
	self.open_editor:SetPos( self:GetWide() - 16 - 14 - 10, (self:GetTall() / 2) - (self.open_editor:GetTall() / 2)  )
	self.open_editor:SetAnim(true)
	self.open_editor:MakePop(ImageFrame)
	self.open_editor:SetImg( "advdailylogin/settings.png" )
	self.open_editor:SetImageColor(Color(200, 200, 200, 200))
	self.open_editor.DoClick = function() 
		-- PrintTable(self.items)
		local main_pnl = ( self:GetParent():GetParent():GetParent():GetParent():GetParent():GetParent():GetParent() )
		local itemsetup_pnl = ( self:GetParent():GetParent():GetParent():GetParent():GetParent():GetParent() )
		local img_pnl = self.items.parent
		-- PrintTable(main_pnl)
		-- img_pnl.Paint = function(s,w,h)
		-- 	draw.RoundedBox(0, 0, 0, w, h, Color(255,0,0))
		-- end

		if itemsetup_pnl.alert_showed then return end
		if img_pnl.editor_enable then return end
		

		local editor = vgui.Create('AdvDailyLogin_Editor', main_pnl)
		editor:SetSize(435,main_pnl:GetTall() - 20 - 15)
		editor:SetPos(main_pnl:GetWide() / 2 - editor:GetWide() / 2 , 10+15)
		editor:SetItems(self.items.items)
		editor:CreateStuff(img_pnl)
		editor.OnRemove = function()
			img_pnl.editor_enable = false
		end

	end


	self.remove = vgui.Create( "AdvDailyLogin_Button", self )
	self.remove:SetText('X')
	self.remove:SetupLang(self:GetLang())
	self.remove:SetSize( 12, 12 )
	self.remove:EnableBackground()
	self.remove:SetPos( self:GetWide() - 14 - 3, (self:GetTall() / 2) - (self.remove:GetTall() / 2) )
	self.remove:ShowAlert(string.format(adv_daily_login.lang[self.lang].alert_remove_msg..' "%s"', string.lower(self.items.daytitle)))
	self.remove.DoClick = function()
		adv_daily_login:FadeFunc('remove', self, 0, .3, 0, function(onfinish)
			if onfinish == true then
				-- print(self.panel_id)
				--PrintTable(self.cur_cell_items_tbl)
				table.remove( self.cur_cell_items_tbl, self.panel_id )
				-- self:GetParent():GetParent():RefreshItemsPanel('remove',self.cur_cell_items_tbl, 'Call from AdvDailyLogin_Button')
				-- print(self:GetCellID())
				net.Start('adv_daily_login_cell_remove')
					net.WriteInt(self:GetCellID(),6)
				net.SendToServer()
			end
		end)
	end	
end


vgui.Register( "AdvDailyLogin_SetupItemsItem", PANEL)