// Licensed to 76561198147781703
local PANEL = {}

function PANEL:Init()
	self.rounded = 0
	self.tickness = 2
	self.pnl = nil
	self.panelid = nil
	self._items = {}
	self._temp_items = nil
	self.lang = nil
end

function PANEL:Paint(w, h)
	draw.RoundedBox( self.rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
	draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) ) -- 76561198147781959
end

function PANEL:GetLang()
	return self.lang
end

function PANEL:SetItems(items)
	self._items = items
	self._temp_items = table.Copy(items)
end

function PANEL:CreateStuff(mainpnl)
	local space = 5
	local space2 = 5
	local hinth = 20
	local TXTcolor = Color(255,255,255,255)
	local _tempitem, oldvalue = nil
	local itemlist
	local advpnltbledit1, advpnltblcombobox1, advpnltbledit2, advpnltbledit3, advpnltbledit4, advpnltblcolorbox1, button1, ColorMixer = nil
	local edit1, edit2, edit3, edit_gui = nil
	self.panelid = mainpnl:GetCellID()
	self.lang = mainpnl:GetLang()

	local _self = self

	local HeadPnl = vgui.Create('DPanel',self)
	HeadPnl:SetPos(10, 10)
	HeadPnl:SetSize(self:GetWide() - 20,50)
	HeadPnl.Paint = function()
		surface.SetFont("AdvDailyLogin_Editor_font")
		if self.lang then
			local x , y = surface.GetTextSize(adv_daily_login.lang[self.lang].cur_edit_item..self.panelid)
			local mh , mw = HeadPnl:GetWide() , HeadPnl:GetTall()
			surface.SetTextPos( (10), 10)
			surface.SetTextColor(Color(255,255,255))
			surface.DrawText(adv_daily_login.lang[self.lang].cur_edit_item..self.panelid)
		end	
	end

	local BodyPnl = vgui.Create('DPanel',self)
	BodyPnl:SetPos(10, 12+ HeadPnl:GetTall() )
	BodyPnl:SetSize(self:GetWide() - 20, self:GetTall() - 12 - HeadPnl:GetTall() - 40)
	BodyPnl.Paint = function(s,w,h)
	end

	local LeftPnl = vgui.Create('DPanel',self)
	LeftPnl:SetPos(10, 12+ HeadPnl:GetTall() + 49 )
	LeftPnl:SetSize(self:GetWide() / 2, self:GetTall() - 12 - HeadPnl:GetTall() - 40)
	LeftPnl.Paint = function(s,w,h)
		--draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 0, 200))
	end
	local DScroll = vgui.Create ( "DScrollPanel", LeftPnl )
	DScroll:Dock( FILL )
	local sbar = DScroll:GetVBar()

	function DScroll.VBar:PerformLayout()
		local Wide = self:GetWide()
		local BtnHeight = Wide
		if ( self:GetHideButtons() ) then BtnHeight = 0 end
		local Scroll = self:GetScroll() / self.CanvasSize
		local BarSize = math.max( self:BarScale() * ( self:GetTall() - ( 5 ) ), 0 )
		local Track = self:GetTall() - ( BtnHeight ) - BarSize
		Track = Track + 1

		Scroll = Scroll * Track

		self.btnGrip:SetPos( 0, Scroll )
		self.btnGrip:SetSize( Wide, BarSize+BtnHeight )

		if ( BtnHeight > 0 ) then
			self.btnUp:SetVisible( false )
			self.btnDown:SetVisible( false )
		else
			self.btnUp:SetVisible( false )
			self.btnDown:SetVisible( false )
			self.btnDown:SetSize( Wide, BtnHeight )
			self.btnUp:SetSize( Wide, BtnHeight )
		end
	end

	function sbar:Paint( w, h )		end

	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 5, 0, 0, w-5, h, Color( 45,71,106 ) )
	end	


	local RightPnl = vgui.Create('DPanel',self)
	RightPnl:SetPos(self:GetWide() / 2, 12+ BodyPnl:GetTall() )
	RightPnl:SetSize(self:GetWide() - self:GetWide() / 2 - 10, self:GetTall() - 12 - HeadPnl:GetTall() - 40)
	RightPnl.Paint = function(s,w,h)
		--draw.RoundedBox(0,0,0,w,h,Color(255,0,0,200))
	end

	// Gui path
	adv_daily_login:CreateEdit		(BodyPnl, 1, mainpnl:GetLink(),  adv_daily_login.lang[self.lang].enterlink , BodyPnl:GetWide(), 27, 0, space, adv_daily_login.lang[self.lang].linktoimg, TXTcolor, hinth, self.pnl, 
		function(callback, _edit_gui)
			--DScrollPanel:AddItem(callback)
			advpnltbledit1 = callback
			edit_gui = _edit_gui
			_tempgui = _edit_gui:GetValue()
			advpnltbledit1.OnSizeChanged = function( w, h )
				BodyPnl:SetTall(advpnltbledit1:GetTall()+5)
				LeftPnl:SetPos(10, 12 + BodyPnl:GetTall() + 52 )
				RightPnl:SetPos(self:GetWide() / 2, 12 + BodyPnl:GetTall() + 47 )
				LeftPnl:SetSize(self:GetWide() / 2, self:GetTall() - 12 - HeadPnl:GetTall() - BodyPnl:GetTall() - 12 - 35)
				RightPnl:SetSize(self:GetWide() - self:GetWide() / 2 - 10, self:GetTall() - 12 - HeadPnl:GetTall() - BodyPnl:GetTall() - 12 - 35)				
			end
	end)

	// Item type
	adv_daily_login:CreateComboBox2	(LeftPnl, adv_daily_login._items_table, nil, 205 - 20, 205, 21,  0, 0, adv_daily_login.lang[self.lang].add_item , TXTcolor, hinth, self.pnl, 
		function(s, i, v)
		 	_tempitem = v

		 	if oldvalue != v then
				if advpnltbledit2:IsVisible() then
					edit1:SetValue('')
				end

				if advpnltbledit3:IsVisible() then
					edit2:SetValue('')
				end
		 		oldvalue = v
		 	end

		 	if !s.firstchange then
			 	adv_daily_login:FadeFunc('show', advpnltbledit2, 255, .3, 0)
			 	s.firstchange = true
		 	end
			if advpnltbledit3 and edit2 then
				text1 = adv_daily_login.lang[self.lang].item_type_text1
				texthitn2 = adv_daily_login.lang[self.lang].item_hitn1

				advpnltbledit3:SetupText(text1)
				edit2:SetHint_(texthitn2)
			end

			if advpnltbledit4 and edit3 then
				text3 = adv_daily_login.lang[self.lang].item_type_text2
				texthitn4 = adv_daily_login.lang[self.lang].item_hitn2

				advpnltbledit4:SetupText(text3)
				edit3:SetHint_(texthitn4)
			end

		end,
		function(callback)
			DScroll:AddItem(callback)
			advpnltblcombobox1 = callback
		end,
		function(callback2)
			if callback2 then
				if IsValid(edit1) then
					edit1:KillFocus()
				end
				if IsValid(edit2) then
					edit2:KillFocus()
				end
			end
	end)
	
	// Item name
	adv_daily_login:CreateEdit (LeftPnl, self.lang, '', adv_daily_login.lang[self.lang].item_name_hint, 205, 21,  0, space2*2+advpnltblcombobox1:GetTall() + space, adv_daily_login.lang[self.lang].item_disp_name, TXTcolor, hinth, self.pnl, 	
		function(callback, _edit1)
			DScroll:AddItem(callback)
			callback:Hide()
			callback:SetAlpha(0)
			advpnltbledit2 = callback
			edit1 = _edit1
		end,
		function(val)
			if val == true then

				if advpnltbledit3 then
					if !advpnltbledit3:IsVisible() then
						adv_daily_login:FadeFunc('show', advpnltbledit3, 255, .3, 0)
					end
				end

				if advpnltbledit4 then
					if !advpnltbledit4:IsVisible() then
						adv_daily_login:FadeFunc('show', advpnltbledit4, 255, .3, 0)
					end
				end

				if edit2:GetValue() != '' then
					adv_daily_login:FadeFunc('show', advpnltblcolorbox1, 255, .3, 0)
					adv_daily_login:FadeFunc('show', button1, 255, .3, 0)
				end
			else
				if advpnltbledit2:IsVisible() then 
					adv_daily_login:FadeFunc('hide', advpnltbledit3, 0, .3, 0)
				end

				if advpnltbledit2:IsVisible() then 
					adv_daily_login:FadeFunc('hide', advpnltbledit4, 0, .3, 0)
				end

				if advpnltblcolorbox1:IsVisible() then
					adv_daily_login:FadeFunc('hide', advpnltblcolorbox1, 0, .3, 0)
				end

				if button1:IsVisible() then
					adv_daily_login:FadeFunc('hide', button1, 0, .3, 0)
				end

			end
	end)
	
	// Item id
	adv_daily_login:CreateEdit(LeftPnl, 1, '', adv_daily_login.lang[self.lang].item_type_text1, 205, 21,  0, space2*3+advpnltblcombobox1:GetTall()+advpnltbledit2:GetTall() + space, 'text', TXTcolor, hinth, self.pnl, 
		function(callback, _edit2)
			DScroll:AddItem(callback)
			callback:Hide()
			callback:SetAlpha(0)
			advpnltbledit3 = callback
			edit2 = _edit2
		end,
		function(val)
			if val == true then
				if advpnltblcolorbox1:IsVisible() then return end

				adv_daily_login:FadeFunc('show', advpnltblcolorbox1, 255, .3, 0)
				adv_daily_login:FadeFunc('show', button1, 255, .3, 0)
			else
				if !advpnltblcolorbox1:IsVisible() then return end

				adv_daily_login:FadeFunc('hide', advpnltblcolorbox1, 0, .3, 0)
				adv_daily_login:FadeFunc('hide', button1, 0, .3, 0)
			end
	end)

	// Item count
	adv_daily_login:CreateEdit(LeftPnl, 1, '', adv_daily_login.lang[self.lang].item_type_text2, 205, 21,  0, space2*4+advpnltblcombobox1:GetTall()+advpnltbledit2:GetTall()+advpnltbledit3:GetTall() + space , 'item_type_text2', TXTcolor, 20 , self.pnl, 
		function(callback, _edit3)
			DScroll:AddItem(callback)
			callback:Hide()
			callback:SetAlpha(0)
			advpnltbledit4 = callback
			edit3 = _edit3			
		end,
		function(val)
			if val == true then
				if advpnltblcolorbox1:IsVisible() then return end

				adv_daily_login:FadeFunc('show', advpnltblcolorbox1, 255, .3, 0)
				adv_daily_login:FadeFunc('show', button1, 255, .3, 0)
			else
				if !advpnltblcolorbox1:IsVisible() then return end

				adv_daily_login:FadeFunc('hide', advpnltblcolorbox1, 0, .3, 0)
				adv_daily_login:FadeFunc('hide', button1, 0, .3, 0)
			end
	end)

	// Color box
	adv_daily_login:CreateColorBox	(LeftPnl, 1, 205, 141+4, 0, space2*5+advpnltblcombobox1:GetTall()+advpnltbledit2:GetTall()+advpnltbledit3:GetTall()+advpnltbledit4:GetTall()+ space, 	adv_daily_login.lang[self.lang].item_col, TXTcolor, hinth, popup, 
		function(callback, mixer)
			DScroll:AddItem(callback)
			advpnltblcolorbox1 = callback
			advpnltblcolorbox1:Hide()
			ColorMixer = mixer
	end)

	-- add item
	adv_daily_login:CreateButton2	(LeftPnl, adv_daily_login.lang[self.lang].btn_add_item, 205, 26, 0, space2*6+advpnltblcolorbox1:GetTall()+advpnltblcombobox1:GetTall()+advpnltbledit2:GetTall()+advpnltbledit3:GetTall()+advpnltbledit4:GetTall()+ space, 10 , self.pnl, function()

		local _item_name = edit1:GetValue()
		local _item_id = edit2:GetValue()
		local _item_count = tonumber(edit3:GetValue())
		local _item_type = _tempitem
		local _item_color = ColorMixer:GetColor()

	 	if _item_count == nil then
	 		adv_daily_login:AddTextToChat('Error #1: Item count field required only number value!')
	 		edit3:ColorErrorValue()
	 		return
	 	end

	 	chat.AddText(Color(52, 152, 219),'[ ',adv_daily_login.tag,' ] ',Color(46, 204, 113), adv_daily_login.lang[self.lang].btn_add_item_msg)
		table.insert(self._items, {item_color=_item_color, item_name = _item_name, item_type = _item_type, item_count = _item_count, item_id = _item_id} )

		if ValidPanel(itemlist) then
			itemlist:RefreshItemsPanel('create')
		end

		end,
		function(callback)
			DScroll:AddItem(callback)
			button1 = callback
			button1:Hide()
			button1:SetAlpha(0)
	end)
	-- PrintTable(self._items)
	adv_daily_login:CreateItemList (RightPnl, 1, 205, RightPnl:GetTall() - (space2) , RightPnl:GetWide() - 205, space2, adv_daily_login.lang[self.lang].reward_list, TXTcolor, hinth, popup, self._items, mainpnl:GetCellID() , 
		function(callback)
			--print('Callback called!')
			itemlist = callback
	end)

	-- Update btn
	adv_daily_login:CreateButton 	(self, adv_daily_login.lang[self.lang].btn_upd_item, 90, 30, 0, self:GetTall() - 40, 0, nil,nil,nil, self.pnl, function()
		chat.AddText(Color(52, 152, 219),'[ ',adv_daily_login.tag,' ] ',Color(46, 204, 113), adv_daily_login.lang[self.lang].btn_upd_item_msg)
		local _item_gui = ''
		--print(edit_gui:GetValue())
		--print(_tempgui)

		if edit_gui:GetValue() != _tempgui then
			mainpnl:SetImg(edit_gui:GetValue())
			_item_gui = edit_gui:GetValue()
		end

		--PrintTable(self._items)

		local editdata = {item_gui = _item_gui, items = self._items }

		--PrintTable(editdata)
		
		net.Start('adv_daily_login_edititem')
			net.WriteInt(mainpnl:GetCellID(),8)
			net.WriteTable(editdata)
			--net.WriteBool(items_edited_bool)
		net.SendToServer()

		adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
		end,
		function(pnl, btn)
			local w, h = btn:GetSize()
			btn:SetPos(self:GetWide() / 2 - w /2 , 0)
	end)

	self.closeBtn = vgui.Create( "AdvDailyLogin_Button", self )
	self.closeBtn:SetPos( self:GetWide() - (25 + 8), 0 + (6) )
	self.closeBtn:SetText('X')
	self.closeBtn:MakePop(self.pnl)
	self.closeBtn:SetSize( 25, 25 )
	self.closeBtn.DoClick = function()
		mainpnl:SetupItems(self._temp_items)
		adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
	end
end

vgui.Register( "AdvDailyLogin_Editor", PANEL)