// Licensed to 76561198147781703
local PANEL = {}
function PANEL:Init()
	self.rounded = 1
	self.tickness = 1
	self.width = 150

	self.item_name_color = nil
	self.item_name = nil
	self.item_type = nil
	self.item_count = nil
	self.panel_id = nil
	self.item_cell = nil
	self.cur_cell_items_tbl = nil
	self.hover = false
	self.lang = self:GetParent():GetParent():GetParent():GetParent():GetParent():GetParent().lang
end

local space = 2
local space2 = 3
local space3 = 2

function PANEL:Paint(w, h)
	
	draw.RoundedBox( self.rounded + 1, 3, 0, w - 15-1, h, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
	draw.RoundedBox( self.rounded, 3+self.tickness , 0 + self.tickness, w - self.tickness * 2 - 15-1, h - self.tickness * 2, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) ) -- 76561198147781959

	local tw1,th1,tw2,th2,tw3,th3 = nil
	local mw1,mh1,mw2,mh2 = nil

	local _ = nil
	local th1, th2, th3, th4, th5 = nil
	local mh1, mh2, mh3, mh4 = nil
	local tw5 = nil
	local function DrawItemText(txt)
				
	end

	if self.item_name then

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Big_font" )
		if self.lang then
			_ , th1 = surface.GetTextSize( adv_daily_login.lang[self.lang].item_name )
			surface.SetTextColor( Color(255,255,255) )
			surface.SetTextPos( 5+space2 , space )
			surface.DrawText( adv_daily_login.lang[self.lang].item_name )
		end

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Small_font" )
		_ , mh1 = surface.GetTextSize( self.item_name )
		surface.SetTextColor( Color(255,255,255) )
		surface.SetTextPos( 5+space2 , space+mh1+space3)
		surface.DrawText( self.item_name )

	end

	if self.item_type then

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Big_font" )
		if self.lang then
			_ , th2 = surface.GetTextSize( adv_daily_login.lang[self.lang].item_type )
			surface.SetTextColor( Color(255,255,255) )
			surface.SetTextPos( 5+space2 , (th1+mh1)+space3 )
			surface.DrawText( adv_daily_login.lang[self.lang].item_type )	
		end

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Small_font" )
		_ , mh2 = surface.GetTextSize( self.item_type )
		surface.SetTextColor( Color(255,255,255) )
		surface.SetTextPos(5+space2 , space+(th1+mh1)+(mh2)+space3 )
		surface.DrawText( self.item_type )

	end

	if self.item_count then
		surface.SetFont( "AdvDailyLogin_Editor_Reward_Big_font" )
		if self.lang then
			_ , th3 = surface.GetTextSize( adv_daily_login.lang[self.lang].item_count )
			surface.SetTextColor( Color(255,255,255) )
			surface.SetTextPos( 5+space2 ,(th1+mh1)+(th2+mh2)+space3 )
			surface.DrawText( adv_daily_login.lang[self.lang].item_count )
		end

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Small_font" )
		_ , mh3 = surface.GetTextSize( self.item_count )
		surface.SetTextColor( Color(255,255,255) )
		surface.SetTextPos(5+space2 ,space+(th1+mh1)+(th2+mh2)+(mh3)+space3 )
		surface.DrawText( self.item_count )
	end

	if self.item_id then
		surface.SetFont( "AdvDailyLogin_Editor_Reward_Big_font" )
		if self.lang then
			_ , th4 = surface.GetTextSize( adv_daily_login.lang[self.lang].item_type_text1 )
			surface.SetTextColor( Color(255,255,255) )
			surface.SetTextPos( 5+space2 ,(th1+mh1)+(th2+mh2)+(th3+mh3)+space3 )
			surface.DrawText( adv_daily_login.lang[self.lang].item_type_text1 )
		end

		surface.SetFont( "AdvDailyLogin_Editor_Reward_Small_font" )
		_ , mh4 = surface.GetTextSize( adv_daily_login.lang[self.lang].item_type_text1 )
		surface.SetTextColor( Color(255,255,255) )
		surface.SetTextPos(5+space2 ,space+(th1+mh1)+(th2+mh2)+(th3+mh3)+(mh4)+space3 )
		surface.DrawText( self.item_id )
	end
	if self.item_id == nil then
		th4 = 0
		mh4 = 0
	end
	if self.item_name_color then
		surface.SetFont( "AdvDailyLogin_Editor_Reward_Big_font" )
		if self.lang then
			tw5 , th5 = surface.GetTextSize( adv_daily_login.lang[self.lang].item_col )		
			surface.SetTextColor( Color(255,255,255) )
			surface.SetTextPos(5+space2 , (th1+mh1)+(th2+mh2)+(th3+mh3)+(th4+mh4)+space3 )
			surface.DrawText( adv_daily_login.lang[self.lang].item_col  )
		end
		draw.RoundedBoxEx(5, 5+space2, space+(th1+mh1)+(th2+mh2)+(th3+mh3)+(th4+mh4)+space3+th5 ,tw5,10,self.item_name_color,true,true,true,true)
	end
end


function PANEL:SetPanelID(_id, _cell, _cur_cell_items_tbl)
	self.panel_id = _id
	self.item_cell = _cell
	self.cur_cell_items_tbl = _cur_cell_items_tbl
end

function PANEL:OnCursorEntered()
	surface.PlaySound( adv_daily_login.sound.item_hover_sound )
	--self.hover = true
end

function PANEL:OnCursorExited()
	--self.hover = false
end

function PANEL:SetData(item_data)
	-- PrintTable(item_data)
	self.item_name_color = item_data.item_color
	self.item_name = item_data.item_name
	self.item_type = item_data.item_type
	self.item_count = item_data.item_count
	self.item_id = item_data.item_id
end

function PANEL:OnMousePressed(key)
	if adv_daily_login:CheckPermission(LocalPlayer()) then return end
	if key == MOUSE_RIGHT then
		local menu = DermaMenu()
		menu:AddOption( "Remove Item", function()
			adv_daily_login:FadeFunc('remove', self, 0, 0.2, 0, function(onfinish)
				if onfinish == true then
					table.remove( self.cur_cell_items_tbl, self.panel_id )
					self:GetParent():GetParent():RefreshItemsPanel('remove')
				end
			end)
		end )
		menu:Open()
	end
end

vgui.Register( "AdvDailyLogin_ItemPnl", PANEL)

