// Licensed to 76561198147781703
		
local PANEL = {}

function PANEL:Init()
	self.rounded = 2
	self.tickness = 2
	self.pnl = nil
	self.lang = 1

	self.additional_text = ''
end

function PANEL:Paint(w, h)
	draw.RoundedBox( self.rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
	draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) ) -- 76561198147781959
	
	local mw , mh = self:GetWide() , self:GetTall()

	if self.lang then

		surface.SetFont("AdvDailyLogin_MainFrame")
		local wt1 , ht1 = surface.GetTextSize(adv_daily_login.lang[self.lang].Alert_message)
		surface.SetTextPos( (mw / 2) - (wt1 / 2), 5)
		surface.SetTextColor(Color(255,255,255))
		surface.DrawText(adv_daily_login.lang[self.lang].Alert_message)

		if self.additional_text then
			surface.SetFont("AdvDailyLogin_Editor_Reward_Big_font")
			local wt2 , ht2 = surface.GetTextSize(self.additional_text)
			surface.SetTextPos( (mw / 2) - (wt2 / 2), ht1 + 10 )
			surface.SetTextColor(Color(255,255,255))
			surface.DrawText(self.additional_text)
		end

	end
	
end

function PANEL:SetupLang(lng_index)
	if (lng_index) == 0 then return end
	self.lang = lng_index
end

function PANEL:SetText(text)
	self.additional_text = text
end

-- function PANEL:OnFocusChanged( bool )
-- 	-- print('focus ',bool)
-- 	-- self:FocusPrevious()
-- end

function PANEL:Think()
	self:MakePopup() // TO-DO
end

function PANEL:CreateStuff()
	local btn1_pnl , btn2_pnl

	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].Alert_confirm , 90, 27, 4, self:GetTall() - 27 - 4 , left_space ,"", "", "",  self, 
		function()
			// To-do send to server data remove , and seva day.
			adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
			self:ButtonConfirm()
		end,
		function(_pnl,_)
			btn1_pnl = _pnl
		end)

	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].Alerd_deny , 90, 27, self:GetWide() - 90 - 8, self:GetTall() - 27 - 4 , left_space ,"", "", "",  self, 
		function()
			adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
			self:ButtonCancel()
		end,
		function(_pnl,_)
			btn2_pnl = _pnl
		end)	
end

vgui.Register( "AdvDailyLogin_AlertPanel", PANEL)