// Licensed to 76561198147781703

surface.CreateFont( "DailyLoginButton_font", {
	font = 'Roboto',
	extended = true,
	size = 15,
	weight = 600,
} )

local PANEL = {}

function PANEL:Init()
	self.text = ''
	self.tickness = 1
	self.rounded = 3
	self.pnl = nil
	self.mat = nil
	self.disab = false
	self.disabmsg = 'Test'
	self.tsizew = 0
	self.tsizeh	= 0
	self.sizetocontent = false
	self.lang = 1

	self.anim = false
	self.anim_type = ''

	self.imageclr = Color(255,255,255,255)
	self.minwidth = 0
	self.minheight = 0
	self._time = 0
	self.color = nil

	self.showalert = false
	self.alerttext = ''
	self.DrawBackGround = true
end

function PANEL:SetAnim(val, type)
	self.anim = val
	self.anim_type = type or 'rotate'
end

function PANEL:SetImageColor(clr)
	self.imageclr = clr
end

function PANEL:SetDisab(val, msg)
	self.disab = val
	self.disabmsg = msg
end

function PANEL:GetDisabmsg()
	if self.disabmsg != '' then
		return self.disabmsg
	end
end

function PANEL:SetupLang(lng_index)
	if (lng_index) == 0 then return end
	self.lang = lng_index
end

function PANEL:SizeToContent(width, height)
	if width and height then
		self.minwidth = width
		self.minheight = height
	end
	self.sizetocontent = true
	self:SetValSizeToContent()
end

function PANEL:SetValSizeToContent()
	if self.sizetocontent == true then
		surface.SetFont( "AdvDailyLogin_Button_Text" )
		local ww , hh = surface.GetTextSize(self:GetText())
		if self.minwidth then
			if ww < self.minwidth then _ww = self.minwidth else _ww = ww + 20 end
		else
			if ww < 90 then _ww = 90 else _ww = ww + 20 end
		end
		self:SetSize( _ww , self.minheight )
	end
end

function PANEL:GetValSizeToContent()
	if self.sizetocontent == true then
		return self:GetSize()
	end
end

function PANEL:OnMousePressed(key)
	surface.PlaySound(adv_daily_login.sound.button_click)
		if key == 107 then
			if self.showalert then
				local itemsetup_pnl = self:GetParent():GetParent():GetParent():GetParent():GetParent():GetParent():GetParent()

				if itemsetup_pnl.alert_showed then return end
				-- Best way to detect parent.
				-- itemsetup_pnl.Paint = function(s,w,h)
				-- 	draw.RoundedBox(0, 0, 0, w, h, Color(255,0,0))
				-- end
				-- if false then return end
				itemsetup_pnl.alert_showed = true

				itemsetup_pnl.pnl = vgui.Create('AdvDailyLogin_AlertPanel', itemsetup_pnl)
				itemsetup_pnl.pnl:SetSize(200, 100)
				itemsetup_pnl.pnl:SetPos(ScrW() / 2 - itemsetup_pnl.pnl:GetWide() / 2, ScrH() / 2 - itemsetup_pnl.pnl:GetTall() / 2)
				itemsetup_pnl.pnl:SetupLang(self.lang)
				itemsetup_pnl.pnl:CreateStuff()

				itemsetup_pnl.pnl:MakePopup()
				-- itemsetup_pnl.pnl:SetFocusTopLevel( true )
				
				-- main_pnl.pnl:RequestFocus()
				itemsetup_pnl.pnl:SetText(self.alerttext)
				-- print(self.alerttext)
				itemsetup_pnl.pnl.ButtonConfirm = function()

						itemsetup_pnl.alert_showed = false
						return self.DoClick(self)

				end
				itemsetup_pnl.pnl.ButtonCancel = function()

						itemsetup_pnl.alert_showed = false
						
				end
			else			
				self.down = true
			  	return self.DoClick(self)
		  	end
	  	else
	  		self.down = true
	  	end
	
end

function PANEL:OnMouseReleased()
	self.down = false
end

function PANEL:OnCursorExited()
	if self.down then
		self.down = false
	end
end

function PANEL:SetText(text)
	self.text = text
end

function PANEL:GetText()
	return self.text
end

function PANEL:GetDisab()
	return self.disab
end

function PANEL:GetTopText()
	return self.text
end

function PANEL:IsDown()
	return self.down
end

function PANEL:MakePop(pnl)
	-- print(pnl)
	if !IsValid(pnl) then return end
	self.pnl = pnl
end

function PANEL:SetImg(mat)
	if !mat then return end
	self.mat = Material(mat,"smooth")
end

function draw.RotatedBox( x, y, w, h, ang, mat, col ) // Credits to gmod wiki
	surface.SetDrawColor( col )
	surface.SetMaterial( mat )
	surface.DrawTexturedRectRotated( x, y, w, h, ang )
end

function PANEL:ShowAlert(text)
	self.showalert = true
	self.alerttext = tostring(text)
end

function PANEL:EnableBackground()
	self.DrawBackGround = false
end

function PANEL:Paint( w, h )

	--self:SetValSizeToContent()
	if self.mat then

		if self.anim then
			if self.anim_type == 'rotate' then
				if self:IsHovered() then
					local x , y = w / 2 , h / 2
					draw.RotatedBox( x, y, w, h, CurTime() * 180, self.mat, self.imageclr )
				else
					surface.SetDrawColor( self.imageclr )
					surface.SetMaterial( self.mat )
					surface.DrawTexturedRect(0,0,w,h)
				end				
			elseif (self.anim_type == 'size') then
				if self:IsHovered() then
					local x , y = w / 2 , h / 2
					local anim_speed = 1
					local size_min, size_max = 12,32
					--local x , y = 85, 74
					-- local st = math.abs ( math.sin( CurTime() * anim_speed ) )
					-- print(st)
					local var = math.abs( math.sin( CurTime() * 3 ) )
					local hudsize = math.Approach( size_min, size_max, var * 20 )
					local max_x = math.Clamp(hudsize, size_min, size_max)
					local max_y = math.Clamp(hudsize, size_min-(size_max - size_min), size_max)

					surface.SetDrawColor( self.imageclr )
					surface.SetMaterial( self.mat )
					surface.DrawTexturedRect(x - (max_x / 2), (h - y) - (max_y / 2), max_x, max_y)
					
				else
					surface.SetDrawColor( self.imageclr )
					surface.SetMaterial( self.mat )
					surface.DrawTexturedRect(0,0,w,h)
				end					
			end

		else
			local sizew , sizeh = self:GetSize()
			surface.SetDrawColor( self.imageclr )
			surface.SetMaterial( self.mat )
			surface.DrawTexturedRect(0,0,sizew,sizeh)			
		end
	end

	if self.mat then return end
	if self.DrawBackGround then
		if !(self:GetDisab())  and self:IsHovered() and self:IsDown()   then
		--print('Downed!')
		draw.RoundedBox( self.rounded + 1, 0, 0, w, h, Color(39, 174, 96 )) -- Color(39, 174, 96, 255) -- adv_daily_login:LerpColor(self, 2 ,true, adv_daily_login.colors.button)
		draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, adv_daily_login.colors.button )
		else
			if (self:GetDisab())  and self:IsHovered() and self:IsDown()  then
			draw.RoundedBox( self.rounded + 1, 0, 0, w, h, Color(231, 76, 60,255) )
			draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, adv_daily_login.colors.button_hover )
			else
				if self:IsHovered() then // Hovered
				--self.color = adv_daily_login:LerpColor(self, 5 ,false, adv_daily_login.colors.button_border, adv_daily_login.colors.button_hover_border )
				draw.RoundedBox( self.rounded + 1, 0, 0, w, h, adv_daily_login.colors.button_hover_border )
				draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, adv_daily_login.colors.button_hover )
				else // End hovered
					--adv_daily_login:LerpColor(pnl, speed ,hover, color_from, color_to )
				--self.color = adv_daily_login:LerpColor(self, 5 ,false, adv_daily_login.colors.button_hover_border, adv_daily_login.colors.button_border )
				draw.RoundedBox( self.rounded + 1, 0, 0, w, h, adv_daily_login.colors.button_border ) -- 76561198147781959
				draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, adv_daily_login.colors.button )
				end
				--draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, self.color )
			end
		end
	end
	local psizew, psizeh = self:GetSize()
	surface.SetTextColor( 255, 255, 255 )
	surface.SetFont( "AdvDailyLogin_Button_Text" )
	self.tsizew, self.tsizeh = surface.GetTextSize(self:GetText())
	surface.SetTextPos( (psizew / 2) - (self.tsizew / 2 ) , (psizeh / 2) -  (self.tsizeh / 2))
	surface.DrawText( self:GetText())
end

function PANEL:OnCursorEntered()
	surface.PlaySound(adv_daily_login.sound.item_hover_sound)
end

vgui.Register( "AdvDailyLogin_Button", PANEL)