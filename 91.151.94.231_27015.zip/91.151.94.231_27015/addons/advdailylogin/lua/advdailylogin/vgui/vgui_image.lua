// Licensed to 76561198147781703

surface.CreateFont( "AdvDailyLogin_NameFont", {
	font = 'Roboto',
	size = 24,
	weight = 600,
} )

surface.CreateFont( "AdvDailyLogin_ItemsFont", {
	font = 'Roboto',
	size = 15,
	weight = 600,
} )

surface.CreateFont( "AdvDailyLogin_RewardFont", {
	font = 'Roboto',
	size = 18,
	weight = 500,
} )

surface.CreateFont( "AdvDailyLogin_ItemCountFont", {
	font = 'Roboto',
	size = 15,
	weight = 700,
} )

local mat_white = Material("vgui/white")

local sizex, sizey = 10 , 50
local sizew, sizeh = 100, 100

local function CreateLabelItem(name, parent ,posy, col)
	local translate
	local color
	local items = string.Explode(":",name)

	local text = vgui.Create("DLabel",parent)
	translate = translate or "Error"
	if col then color = col 
	else color = color or Color( 255, 255, 255 ) end
	text:SetText(items[2])
	text:SetColor( color )
	text:SetFont( "AdvDailyLogin_ItemCountFont" )
	text:SetPos(10 , posy)
	text:SizeToContents()
end

local PANEL = {}

function PANEL:Init()
	self.items = {}
	self.model = false
	self.image = false
	self.mat = nil
	self.webmat = nil
	self.mdl = nil
	self.name = "Not Found!"
	self.hovered = false
	self.usemodel = false

	self.pnl = nil
	self.pnl2 = nil

	self.lang = 1
	self.cell = nil
	self.link = ''
	self.editor_enable = false

	self.gui_pnl = nil
	self.gui_prewiev_pnl = nil

	self._time = 0
	self._time2 = 0

	DermaPanel = nil

	self.disabled = true

	-- self.debug = false
end

function PANEL:GetStatus()
	return self.disabled
end

function PANEL:SetupLang(lng_index)
	if (lng_index) == 0 then return end
	self.lang = lng_index
end

function PANEL:GetLang()
	return self.lang
end

-- local DermaPanel
local tickness = 2
local rounded = 3

local wave1 = Material( "advdailylogin/BorderTop.png", 'smooth'  ) 
local wave2 = Material( "advdailylogin/BorderDown.png", 'smooth'  )
local wave3 = Material( "advdailylogin/BorderCenter.png", 'smooth' )
-- "bordertop.png"
local CurLerp = 0
local time = 0

local function FadeColor(pnl, hover ,...)

	local speed, color_from = nil
	local args = {...}  -- speed , colorfrom , colorto

	if !pnl then return end
	if args[1] != nil and isnumber(args[1]) then speed = args[1] else speed = 2 end
	if args[2] != nil and istable (args[2]) then color_from = args[2] else color_from = Color(255,255,255) end
	--if args[3] != nil and isbool  (args[2]) then hover = args[3] end

	if hover then
		pnl._time = pnl._time + speed + 0.9
		pnl._time = math.Clamp( pnl._time, 0, 255 )
	else
		pnl._time = pnl._time - speed - 0.5
		pnl._time = math.Clamp( pnl._time, 0, 255 )
	end

	local col = Color(
		Lerp(0,color_from.r,color_from.r),
		Lerp(0,color_from.g,color_from.g),
		Lerp(0,color_from.b,color_from.b),
		math.Clamp( pnl._time , 0, 255 )
	)
	return col
end


local canedit = Material( "advdailylogin/edit.png", 'smooth'  )

function PANEL:Paint( w, h )

	if !self.gui_pnl then 
		if !adv_daily_login:CheckPermission(LocalPlayer()) then
			draw.RoundedBox(5,self:GetWide() / 2 - 42 / 2, self:GetTall() / 2 - 40 / 2 ,40,40,Color(231,236,239))
			draw.RoundedBox(5,self:GetWide() / 2 - 40 / 2, self:GetTall() / 2 - 38 / 2 ,38,38,Color(52,152,219))

			surface.SetDrawColor( Color(255,255,255,255) )
			surface.SetMaterial( canedit ) 
			surface.DrawTexturedRect( self:GetWide() / 2 - 34 / 2, self:GetTall() / 2 - 34 / 2, 34 , 34  )
		end
		return
	end
	-- if !self.debug then
		draw.RoundedBox( rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.item_box_border.r, adv_daily_login.colors.item_box_border.g, adv_daily_login.colors.item_box_border.b, adv_daily_login.colors.item_box_border.a or 255) )
		draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.item_box.r, adv_daily_login.colors.item_box.g, adv_daily_login.colors.item_box.b, adv_daily_login.colors.item_box.a or 255) )
	-- end

	if self.hovered then -- w - 49 , h - 49
		
		surface.SetDrawColor( FadeColor(self ,true, 2, adv_daily_login.colors.item_box_hover_border_from) )
		surface.SetMaterial( wave1 ) 
		surface.DrawTexturedRect( 0, 0, w, h )

		surface.SetDrawColor( FadeColor(self ,true, 2, adv_daily_login.colors.item_box_hover_border_center) )
		surface.SetMaterial( wave3 )
		surface.DrawTexturedRect( 0, 0, w, h )

		surface.SetDrawColor( FadeColor(self ,true, 2, adv_daily_login.colors.item_box_hover_border_to) )
		surface.SetMaterial( wave2 )
		surface.DrawTexturedRect( 0, 0, w, h )
	else
		surface.SetDrawColor( FadeColor(self ,false, 2 ,adv_daily_login.colors.item_box_hover_border_from) )
		surface.SetMaterial( wave1 ) 
		surface.DrawTexturedRect( 0, 0, w, h )

		surface.SetDrawColor( FadeColor(self ,false, 2 ,adv_daily_login.colors.item_box_hover_border_center) )
		surface.SetMaterial( wave3 )
		surface.DrawTexturedRect( 0, 0, w, h )

		surface.SetDrawColor( FadeColor(self ,false, 2 ,adv_daily_login.colors.item_box_hover_border_to) )
		surface.SetMaterial( wave2 )
		surface.DrawTexturedRect( 0, 0, w, h )		
	end
end

function PANEL:SetCellID(id)
	self.cell = id
end

function PANEL:GetCellID()
	return self.cell
end

function PANEL:GetLink()
	return self.link
end

function PANEL:SetName(name)
	self.name = name or "Nothing"
end
 
function PANEL:SetImg(link)
		-- print(link)
		--if self.debug then return end

		if isstring(link) then
			self.link = link
		else
			self.link = ''
		end

		local temp_link, temp_model, temp_mat
		local _self = self

		if IsValid(self.gui_pnl) then
			self.gui_pnl:Remove()
			self.model = false
			self.image = false
			self.webmat	= false	 	
		end

		if type(link) == "string" and string.match(link,"^http") then
			self.webmat = adv_daily_login:WebMaterial(self.link , 'smooth')
			self.webmat:CheckMaterial(
			function(status)
				if status == 'exist' then
					local w , h = self:GetSize()
					if IsValid(self.gui_pnl) then
						self.gui_pnl:SetMaterial(self.webmat:GetMaterial() , 'smooth')
						return
					end
					self.gui_pnl = vgui.Create( "DImage" , self)
					self.gui_pnl:SetMaterial(self.webmat:GetMaterial() , 'smooth')
					self.gui_pnl:SetPos( 3, 3)
					self.gui_pnl:SetSize( w - 6 , h - 6 )
				else
				end
			end,
			function(success)
				if success == true then
					local w , h = self:GetSize()
					if IsValid(self.gui_pnl) then 
						self.gui_pnl:SetMaterial(self.webmat:GetMaterial() , 'smooth')
						return
					end
					self.gui_pnl = vgui.Create( "DImage" , self)
					self.gui_pnl:SetMaterial(self.webmat:GetMaterial() , 'smooth')
					self.gui_pnl:SetPos( 3, 3)
					self.gui_pnl:SetSize( w - 6 , h - 6 )					
				end
			end)
		else
		    if type(link) == "IMaterial" then
		    	if (link) != nil then
		    		self.image = true
		    		self.mat = link
					local w , h = self:GetSize()
					self.gui_pnl = vgui.Create( "DImage" , self)
					self.gui_pnl:SetMaterial(link , 'smooth')
					self.gui_pnl:SetPos( 3, 3)
					self.gui_pnl:SetSize( w - 6 , h - 6 )

				else

					local w , h = self:GetSize()
					self.gui_pnl = vgui.Create( "DImage" , self)
					self.gui_pnl:SetImage("Debug/debugempty")
					self.gui_pnl:SetPos( 3, 3)
					self.gui_pnl:SetSize( w - 6 , h - 6 )

				end
		    elseif isstring(link) then 

		    	if string.sub( link, #link -3 , #link ) == ".vmt" then

		    		self.image = true
		    		self.mat = link

		    		local w , h = self:GetSize()
					self.gui_pnl = vgui.Create( "DImage", self  )
					self.gui_pnl:SetMaterial(self.mat)
					self.gui_pnl:SetSize(w - 6 , h - 6)
					self.gui_pnl:SetPos(3, 3)

				elseif string.sub( link, #link -3 , #link ) == ".mdl" then

					self.model = true
					self.mdl = link

					if !self.usemodel then
						local w , h = self:GetSize()
						self.gui_pnl = vgui.Create("ModelImage", self)
						self.gui_pnl:SetSize(w - 6 , h - 6)
						self.gui_pnl:SetPos(3, 3)
						self.gui_pnl:SetModel(self.mdl, 0, "0")
					else
						local w , h = self:GetSize()
						self.gui_pnl = vgui.Create("DModelPanel", self)
						self.gui_pnl:SetSize(w - 6 , h - 6)
						self.gui_pnl:SetPos(3, 3)
						self.gui_pnl:SetModel(self.mdl, 0, "0")	
						local PrevMins, PrevMaxs = self.gui_pnl.Entity:GetRenderBounds()
						self.gui_pnl:SetCamPos(PrevMins:Distance(PrevMaxs) * Vector(0.5, 0.5, 0.5))
						self.gui_pnl:SetLookAt((PrevMaxs + PrevMins) / 2)
						function self.gui_pnl:LayoutEntity( Entity ) return end
					end

				else

					self.image = true
					self.mat = Material('materials/advdailylogin/nothing.png','smooth')
					local w , h = self:GetSize()
					self.gui_pnl = vgui.Create( "DImage", self  )
					-- if !self.debug then
					self.gui_pnl:SetMaterial(Material('materials/advdailylogin/nothing.png','smooth'))
					-- end
					self.gui_pnl:SetSize(w - 6 , h - 6)
					self.gui_pnl:SetPos(3, 3)

				end

	 		end
 		end

		local HiddenPanel = vgui.Create( "DPanel", _self )
		HiddenPanel:SetPos( 0, 0 )
		HiddenPanel:SetSize( _self:GetWide(), _self:GetTall() )
		HiddenPanel.Paint = function() end

		function HiddenPanel:OnCursorExited()
			_self.hovered = false
			if IsValid(DermaPanel) then
				adv_daily_login:FadeFunc('remove', DermaPanel, 0, .1, 0)
			end			
		end

		function HiddenPanel:OnCursorEntered()
			surface.PlaySound( adv_daily_login.sound.item_hover_sound )
			_self.hovered = true
			if !adv_daily_login.settings.showhoverbox then return end
			_self:HoverPanel()
		end

		function HiddenPanel:OnMousePressed(keyCode)

			if IsValid(_self.pnl2) then
				_self.pnl2:MakePopup()
			end

		    if adv_daily_login:CheckPermission(LocalPlayer()) then return end

			if keyCode == MOUSE_RIGHT then

				local menu = DermaMenu()
				
				if #_self.items ~= 0 or (_self.gui_pnl) then
					menu:AddOption( adv_daily_login.lang[_self.lang].right_click_edit, function()
						local main_pnl = ((_self:GetParent()):GetParent())
						if main_pnl.editor_enable then return end
						main_pnl.editor_enable = true
						local editor = vgui.Create('AdvDailyLogin_Editor', main_pnl)
						editor:SetSize(435,main_pnl:GetTall() - 20 - 15)
						editor:SetPos(main_pnl:GetWide() / 2 - editor:GetWide() / 2 , 10+15)
						editor:SetItems(_self.items)
						editor:CreateStuff(_self)
						editor.OnRemove = function()
							main_pnl.editor_enable = false
						end
					end )
					menu:AddOption( adv_daily_login.lang[_self.lang].right_click_remove , function()
						net.Start('adv_daily_login_cell_remove')
							net.WriteInt(_self:GetCellID(),6)
						net.SendToServer()
					end )
				else
					menu:AddOption( adv_daily_login.lang[_self.lang].right_click_create, function()
						local main_pnl = ((_self:GetParent()):GetParent())
						if main_pnl.editor_enable then return end
						main_pnl.editor_enable = true
						local editor = vgui.Create('AdvDailyLogin_Editor', main_pnl)
						editor:SetSize(435,main_pnl:GetTall() - 20 - 15)
						editor:SetPos(main_pnl:GetWide() / 2 - editor:GetWide() / 2 , 10+15)
						editor:SetItems(_self.items)
						editor:CreateStuff(_self)
						editor.OnRemove = function()
							main_pnl.editor_enable = false
						end
					end )					
				end
				menu:Open()

				menu:MakePopup()

				function menu:OnRemove()
					if IsValid(self) then
						_self.hovered = false
					end
				end
			end		    
		end
end

function PANEL:UseModel(var)
	if var == true then
		self.usemodel = true
	else
		self.usemodel = false
	end
end

function PANEL:SetupItems(additems)
	table.Empty(self.items)
	local item,item_type
	if additems == nil then return end

	self.disabled = false

	for k , v in pairs(additems) do
		if istable(v) then
		
			if v.item_id then
				_item_id = v.item_id
			else
				_item_id = nil
			end

			if v.item_count then
				_item_count = v.item_count
			end

			item = v.item_type or "Not found!"

			if v.item_name then
				name = v.item_name
			else
				name = tostring(v.item_id) or 'Not found!'
			end
			if v.item_color then
				col = Color(v.item_color.r,v.item_color.g,v.item_color.b,v.item_color.a)
			else
				col = nil
			end
			table.insert(self.items, {item_type = item, item_name = name, item_color = col, item_count = _item_count, item_id = _item_id})
		end
	end

end

function PANEL:OnMousePressed(keyCode)
	if IsValid(self.pnl2) then
		self.pnl2:MakePopup()
	end

    if adv_daily_login:CheckPermission(LocalPlayer()) then return end
	if keyCode == MOUSE_RIGHT then
		--print(self.gui_pnl)
		local menu = DermaMenu()
		if #self.items ~= 0 or self.gui_pnl then 
			menu:AddOption( adv_daily_login.lang[self.lang].right_click_edit , function()
				local main_pnl = ((self:GetParent()):GetParent())
				if main_pnl.editor_enable then return end
				main_pnl.editor_enable = true
				local editor = vgui.Create('AdvDailyLogin_Editor', main_pnl)
				editor:SetSize(435,main_pnl:GetTall() - 20)
				editor:SetPos(main_pnl:GetWide() / 2 - editor:GetWide() / 2 , 10)
				editor:SetItems(self.items)
				editor:CreateStuff(self)
				editor.OnRemove = function()
					main_pnl.editor_enable = false
				end

			end )
			menu:AddOption( adv_daily_login.lang[self.lang].right_click_remove, function()
				net.Start('adv_daily_login_cell_remove')
					net.WriteInt(self:GetCellID(),6)
				net.SendToServer()
			end )
		else
			menu:AddOption( adv_daily_login.lang[self.lang].right_click_create , function()
				local main_pnl = ((self:GetParent()):GetParent())
				if main_pnl.editor_enable then return end
				main_pnl.editor_enable = true
				local editor = vgui.Create('AdvDailyLogin_Editor', main_pnl)
				editor:SetSize(435,main_pnl:GetTall() - 20)
				editor:SetPos(main_pnl:GetWide() / 2 - editor:GetWide() / 2 , 10)
				editor:SetItems(self.items)
				editor:CreateStuff(self)
				editor.OnRemove = function()
					main_pnl.editor_enable = false
				end

			end )
		end
		menu:Open()
		function menu:OnRemove()
			if IsValid(self) then
				self.hovered = false
			end
		end
	end		    
end

function PANEL:MakePop(pnl)
	if !IsValid(pnl) then return end
	self.pnl = pnl
end

function PANEL:GetModel()
	return self.model
end

function PANEL:HoverPanel()

	local itemsbox
	local pos = 5
	-- print(500,y)
	local x, y = self:LocalToScreen( 0, y )
	-- print(x,y)
	if IsValid(DermaPanel) or IsValid(self.pnl2) then return end
	DermaPanel = vgui.Create( "DFrame" )
	DermaPanel:SetSize( 300, 200 )
	DermaPanel:SetPos(x , y - DermaPanel:GetTall() - 5 )
	DermaPanel:SetTitle("" )
	DermaPanel:SetDraggable( true )
	DermaPanel:MakePopup()
	DermaPanel:ShowCloseButton(false)
	self.pnl2 = DermaPanel

	DermaPanel:Hide()
	DermaPanel:SetAlpha(0)

	
	adv_daily_login:FadeFunc('show', DermaPanel, 255, .1, 0)

	local DLabel = vgui.Create( "DLabel", DermaPanel )
	DLabel:SetText(adv_daily_login.lang[self.lang].ItemInfo)
	DLabel:SetFont("AdvDailyLogin_RewardFont")
	DLabel.Think = function()
		surface.SetFont( "AdvDailyLogin_RewardFont" )
		if self.lang then
			local dw, dh = surface.GetTextSize( adv_daily_login.lang[self.lang].ItemInfo)
			DLabel:SetPos((9+102+9+85) - dw/2  , 50)
			DLabel:SizeToContents()
		end													
	end

	local name = self.name
	local sizex, sizey = 10 , DermaPanel:GetTall() - DermaPanel:GetTall() + 50
	local sizew,sizeh = 100,100
	local tickness = 2
	local rounded = 2
	local calc = 0
	DermaPanel.Paint = function(self, w, h )
		draw.RoundedBox( rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.hover_box_border.r, adv_daily_login.colors.hover_box_border.g, adv_daily_login.colors.hover_box_border.b, adv_daily_login.colors.hover_box_border.a or 255) )
		draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.hover_box.r, adv_daily_login.colors.hover_box.g, adv_daily_login.colors.hover_box.b, adv_daily_login.colors.hover_box.a or 255) ) -- {{user_id}}

		surface.SetFont( "AdvDailyLogin_NameFont" )
		surface.SetTextColor( 255, 255, 255 )
		local height = select( 1, surface.GetTextSize( name ) )
		surface.SetTextPos( w / 2 - height / 2, 5 )
		surface.DrawText( name)

		draw.RoundedBox( 1, sizex, sizey, sizew, sizeh, Color(adv_daily_login.colors.hover_box_border.r, adv_daily_login.colors.hover_box_border.g, adv_daily_login.colors.hover_box_border.b, adv_daily_login.colors.hover_box_border.a or 255) )
		adv_daily_login:OutlinedBox( sizex - 1, sizey - 1, sizew+ 2, sizeh + 2, 1, Color( 255, 255, 255 , 127.5 ) )

		if calc > self:GetTall() then
			local _temp = calc - self:GetTall() 
			self:SetSize(self:GetWide(), self:GetTall() + _temp + 15 )
			self:SetPos(x , y - self:GetTall() - 5 )
		end
	end

	itemsbox = vgui.Create("DPanel", DermaPanel)
	itemsbox:SetSize(170, DermaPanel:GetTall() - 81)	
	itemsbox:SetPos(120, 70)
	function itemsbox:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(adv_daily_login.colors.hover_box_border.r, adv_daily_login.colors.hover_box_border.g, adv_daily_login.colors.hover_box_border.b, adv_daily_login.colors.hover_box_border.a or 255) )
		adv_daily_login:OutlinedBox( 0, 0, w, h, 1, Color( 255, 255, 255 , 127.5 ) )
	end

	local posx, posy = 10 , 10
	local space = 15

	function itemsbox:Think()
		if pos > 81 then
			self:SetSize(170, pos + 5)
		else
			self:SetSize(170, 81)
		end
	end

	for k, v in pairs(self.items) do
		CreateLabelItem(v.item_type..": "..v.item_name, itemsbox ,pos, v.item_color)
		pos = pos + 15
	end
	local w, h = itemsbox:GetSize()
	
	calc = (70 + pos)

	if IsValid(self.gui_prewiev_pnl) then
		self.gui_prewiev_pnl:Remove()
	end

	if !self.model and !self.image and !self.webmat then

		self.gui_prewiev_pnl = vgui.Create( "DImage", DermaPanel  )
		self.gui_prewiev_pnl:SetImage("Debug/debugempty")
		self.gui_prewiev_pnl:SetSize(sizew, sizeh)
		self.gui_prewiev_pnl:SetPos(sizex, sizey)

	else
		if self.image then

				self.gui_prewiev_pnl = vgui.Create( "DImage", DermaPanel  )
				self.gui_prewiev_pnl:SetMaterial(self.mat)
				self.gui_prewiev_pnl:SetSize(sizew, sizeh)
				self.gui_prewiev_pnl:SetPos(sizex, sizey)

		elseif self.webmat then

				local w , h = self:GetSize()
				self.gui_prewiev_pnl = vgui.Create( "DImage" , DermaPanel)
				self.gui_prewiev_pnl:SetMaterial(self.webmat:GetMaterial() , 'smooth')
				self.gui_prewiev_pnl:SetPos( 10, DermaPanel:GetTall() - DermaPanel:GetTall() + 50)
				self.gui_prewiev_pnl:SetSize( 100 , 100 )

		elseif self.model then

			if !self.usemodel then

				local w , h = self:GetSize()
				self.gui_prewiev_pnl = vgui.Create("ModelImage", DermaPanel)
				self.gui_prewiev_pnl:SetSize(100, 100)
				self.gui_prewiev_pnl:SetPos(10, DermaPanel:GetTall() - DermaPanel:GetTall() + 50)
				self.gui_prewiev_pnl:SetModel(self.mdl, 0, "0")
			else

				local w , h = self:GetSize()
				self.gui_prewiev_pnl = vgui.Create("DModelPanel", DermaPanel)
				self.gui_prewiev_pnl:SetSize(100, 100)
				self.gui_prewiev_pnl:SetPos(10, DermaPanel:GetTall() - DermaPanel:GetTall() + 50)
				self.gui_prewiev_pnl:SetModel(self.mdl, 0, "0")	
				local PrevMins, PrevMaxs = self.gui_prewiev_pnl.Entity:GetRenderBounds()
				self.gui_prewiev_pnl:SetCamPos(PrevMins:Distance(PrevMaxs) * Vector(0.5, 0.5, 0.5))
				self.gui_prewiev_pnl:SetLookAt((PrevMaxs + PrevMins) / 2)
				function self.gui_prewiev_pnl:LayoutEntity( Entity ) return end

			end

		end
	end
end

function PANEL:OnRemove()
	-- print(self,'Removed!')
	if IsValid(DermaPanel) then
		-- print(DermaPanel,'Removed 1!')
		DermaPanel:Remove()
	end
	if IsValid(self.pnl2) then
		-- print(self.pnl2,'Removed 2!')
		self.pnl2:Remove()
	end
end

vgui.Register( "AdvDailyLogin_Cell", PANEL, "Panel" )