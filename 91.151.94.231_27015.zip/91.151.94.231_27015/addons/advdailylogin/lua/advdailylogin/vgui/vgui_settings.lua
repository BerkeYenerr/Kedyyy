// Licensed to 76561198147781703

local PANEL = {}

function PANEL:Init()
	self.rounded = 2
	self.tickness = 2
	self.pnl = nil
	self.lang = 1
end

function PANEL:SetupLang(lng_index)
	if (lng_index) == 0 then return end
	self.lang = lng_index
end

function PANEL:MakePop(pnl)
	if !IsValid(pnl) then return end
	self.pnl = pnl
end

function PANEL:Paint(w, h)
	draw.RoundedBox( self.rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
	draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) ) -- 76561198147781959
	surface.SetFont("AdvDailyLogin_MainFrame")
	local x , y = surface.GetTextSize(adv_daily_login.lang[self.lang].settings)
	local mh , mw = self:GetWide() , self:GetTall()
	surface.SetTextPos( mh / 2 - x / 2, 5)
	surface.SetTextColor(Color(255,255,255))
	surface.DrawText(adv_daily_login.lang[self.lang].settings)
end

function PANEL:CreateStuff()
	-- 76561198147781959
	local _self = self
	local temp_lang = _self.lang
	local edit_gui, _tempgui = nil
	local HintColor = Color(255,255,255)
	local hinth = 20
	local left_space = 10
	local space, start_space = 7, 34

	local edit_pnl,btn2_pnl,btn3_pnl,btn4_pnl,btn5_pnl,combo1_pnl = nil
	-- item gui
	adv_daily_login:CreateEdit	(self, lang, cfg.bglink, adv_daily_login.lang[self.lang].enterlink,  self:GetWide(), 20 , 0, start_space, adv_daily_login.lang[self.lang].linktobg, Color(255,255,255), 20, nil, 
		function(_pnl,_edit)
			edit_pnl = _pnl
			edit_gui = _edit
			_tempgui = _edit:GetValue()
		end)
	
	-- start dl
	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].setup_date, 90, 27, 0, edit_pnl:GetTall() + space + start_space , left_space ,adv_daily_login.lang[self.lang].setup_date_hint, HintColor, hinth,  self.pnl, 
		function()
			if (adv_daily_login.settings.reset_when_complete) then self:SetDisab(true) chat.AddText(Color(52, 152, 219),'[',adv_daily_login.tag,'] ',Color(46, 204, 113),adv_daily_login.lang[cfg.lang_index].setup_date_error) return end
			chat.AddText(Color(52, 152, 219),'[',adv_daily_login.tag,'] ',Color(46, 204, 113),adv_daily_login.lang[cfg.lang_index].setup_date_success)
			net.Start('adv_daily_login_startdailylogin')
			net.SendToServer()
		end,
		function(_pnl,_)
			btn2_pnl = _pnl
		end)

	-- reset data
 	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].reset_data, 90, 27, 0, btn2_pnl:GetTall() + edit_pnl:GetTall() + space*2 + start_space, left_space ,adv_daily_login.lang[self.lang].reset_data_hint, HintColor, hinth, self.pnl, 
 		function()
			chat.AddText(Color(52, 152, 219),'[',adv_daily_login.tag,'] ',Color(46, 204, 113),adv_daily_login.lang[cfg.lang_index].reset_data_success)
			net.Start('adv_daily_login_resetalldata')
			net.SendToServer()
		end,
		function(_pnl,_)
			btn3_pnl = _pnl
		end) 

 	-- pl stats
	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].btn_plstats, 90, 27, 0, btn3_pnl:GetTall() + btn2_pnl:GetTall() + edit_pnl:GetTall() + space*3 + start_space, left_space ,adv_daily_login.lang[self.lang].btn_plstats_hint, HintColor, hinth, self.pnl, 
		function()
			adv_daily_login:FadeFunc('hide', self, 0, .3, 0)
			net.Start('adv_daily_login_getplayerstats')
			net.SendToServer()
		end,
		function(_pnl,_)
			btn4_pnl = _pnl
		end)
	
	-- lang
	adv_daily_login:CreateComboBox2	(self, adv_daily_login.lang, self.lang, 130 - 20 ,self:GetWide(), 20, 0, btn4_pnl:GetTall() + btn3_pnl:GetTall() + btn2_pnl:GetTall() + edit_pnl:GetTall() + space*4 + start_space , adv_daily_login.lang[self.lang].lang_hint, Color(255,255,255), 20, self.pnl, 
		function(s, i, v)
			temp_lang = i
		end,
		function(_pnl)
			combo1_pnl = _pnl
		end)

	local _cfgtbl = {}
	
	-- print(adv_daily_login.lang[self.lang].mysql_btn)
	for k , v in pairs(adv_daily_login.lang[1]) do
		-- print(k , v)
	end
	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].mysql_btn, 90, 27, 0, combo1_pnl:GetTall() + btn4_pnl:GetTall() + btn3_pnl:GetTall() + btn2_pnl:GetTall() + edit_pnl:GetTall() + space*5 + start_space, left_space ,adv_daily_login.lang[self.lang].mysql_btn_hint, HintColor, hinth, self.pnl, 
	function()
		net.Start('adv_daily_login_migratedb')
		net.SendToServer()
	end,
	function(_pnl,_)
		btn5_pnl = _pnl
	end)

	-- save btn
	adv_daily_login:CreateButton(self, adv_daily_login.lang[self.lang].save_data, 0, 30, 0, self:GetTall() - 35, left_space , nil,nil,nil, self.pnl, 
		function()
		chat.AddText(Color(52, 152, 219),'[ ',adv_daily_login.tag,' ] ',Color(46, 204, 113), adv_daily_login.lang[self.lang].save_msg)

		if temp_lang != _self.lang then
			table.insert(_cfgtbl,{lang_index = temp_lang})
		end

		local _item_gui = ''

		if edit_gui:GetValue() != _tempgui and edit_gui:GetValue() != nil and edit_gui:GetValue() != '' then
			self:GetParent():UpdateHtml(edit_gui:GetValue())
			local _img = edit_gui:GetValue()
			table.insert(_cfgtbl,{bglink = _img})
		end

		net.Start('adv_daily_login_updatesettings',true)
			net.WriteTable(_cfgtbl)
		net.SendToServer()

		adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
		end,
		function(pnl,btn)
			local w, h = btn:GetSize()
			btn:SetPos(self:GetWide() / 2 - w /2 , 0)
		end)

	self.closeBtn = vgui.Create( "AdvDailyLogin_Button", self )
	self.closeBtn:SetPos( self:GetWide() - (25 + 8), 0 + (6) )
	self.closeBtn:SetText('X')
	self.closeBtn:MakePop(self.pnl)
	self.closeBtn:SetSize( 25, 25 )
	self.closeBtn.DoClick = function()	
		adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
	end
end

vgui.Register( "AdvDailyLogin_Settings", PANEL )