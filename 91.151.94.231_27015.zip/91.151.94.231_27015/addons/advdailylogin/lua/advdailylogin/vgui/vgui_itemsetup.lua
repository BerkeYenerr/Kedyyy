// Licensed to 76561198147781703

local PANEL = {}

function PANEL:Init()
	self.rounded = 2
	self.tickness = 2
	self.parent_pnl = nil
	self.lang = 1

	self.alert_showed = false
end

function PANEL:Paint(w, h)
	draw.RoundedBox( self.rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
	draw.RoundedBox( self.rounded, 0+self.tickness , 0 + self.tickness, w - self.tickness * 2, h - self.tickness * 2, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) ) -- 76561198147781959
	
	if self.lang then
		surface.SetFont("AdvDailyLogin_MainFrame")
		local x , y = surface.GetTextSize( adv_daily_login.lang[self.lang].celleditor ) 
		local mh , mw = self:GetWide() , self:GetTall()
		surface.SetTextPos( mh / 2 - x / 2, 5)
		surface.SetTextColor(Color(255,255,255))
		surface.DrawText( adv_daily_login.lang[self.lang].celleditor )
	end

end

function PANEL:SetupLang(lng_index)
	if (lng_index) == 0 then return end
	self.lang = lng_index
end

function PANEL:UpdateData(items, Box)
	--print('PANEL:UpdateData(items, Box)')
	local itemstbl = items
	local new_itemss = {}
	--PrintTable(Box)
	for k , v in ipairs(items) do
		if istable(v) then
			table.insert(new_itemss, { daytitle='Day '..k, dayid=k , items = v.items, parent = Box[k] })
		end
	end
	--PrintTable(new_items)
	self.itemlist:RefreshItemsPanel('create', new_itemss, 'Call from AdvDailyLogin_SetupItems')
end

function PANEL:CreateStuff(items, Box)
	
	local itemstbl = items
	local new_items = {}
	-- PrintTable(items)
	-- for k , v in pairs(Box) do
	-- 	if v:GetStatus() == false then
	-- 		print(k,v)
	-- 	end
	-- end
	-- PrintTable(itemstbl)
	local day = adv_daily_login.lang[self.lang].DayName
	for k , v in ipairs(items) do
		if istable(v) then
			table.insert(new_items, { daytitle=day..' '..k, dayid=k , items = v.items, parent = Box[k] })
		end
	end
	-- PrintTable(new_items)

	local MainPnl = vgui.Create('DPanel',self)
	MainPnl:SetPos( 10, 42 )
	MainPnl:SetSize( self:GetWide() - MainPnl.x  - 10, self:GetTall() - MainPnl.y - 10 )
	MainPnl.Paint = function(s,w,h)
		adv_daily_login:OutlinedBox( 0, 0, w, h, 2, Color(53, 79, 115 , 200) )
	end
	// To-do
	//local tmp_days = { { daytitle='Day 1', dayid=1 },{ daytitle='Day 2', dayid=2 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 },{ daytitle='Day 3', dayid=3 } }
	_self = self
								 //(parent, lang, sizew, sizeh, posx, posy, SetHint, HintColor, hinth, popup, _items, item_cell, callback)
	adv_daily_login:CreateDaysList ( MainPnl , self.lang , MainPnl:GetWide() - 3 , MainPnl:GetTall() - 8 , 4 , 4 , nil, nil, nil, nil, new_items, nil, 
		function(callback)
			_self.itemlist = callback
	end)

	self.closeBtn = vgui.Create( "AdvDailyLogin_Button", self )
	self.closeBtn:SetPos( self:GetWide() - (25 + 8), 0 + (6) )
	self.closeBtn:SetText('X')
	self.closeBtn:MakePop(self.pnl)
	self.closeBtn:SetSize( 25, 25 )
	self.closeBtn.DoClick = function()
		adv_daily_login:FadeFunc('remove', self, 0, .3, 0)
	end
end

vgui.Register( "AdvDailyLogin_SetupItems", PANEL)