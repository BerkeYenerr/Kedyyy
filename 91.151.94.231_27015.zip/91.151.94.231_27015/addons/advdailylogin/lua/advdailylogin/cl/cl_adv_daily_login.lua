// Licensed to 76561198147781703

surface.CreateFont( "AdvDailyLogin_Edit_font", {
	font = 'Roboto',
	extended = true,
	size = 12,
	weight = 400,
} )

surface.CreateFont( "AdvDailyLogin_Editor_font", {
	font = 'Roboto',
	extended = true,
	size = 27,
	weight = 1400,
} )

surface.CreateFont( "AdvDailyLogin_Editor_Options_font", {
	font = 'Roboto',
	extended = true,
	size = 17,
	weight = 1200,
} )

surface.CreateFont( "AdvDailyLogin_Editor_Reward_Big_font", {
	font = 'Roboto',
	extended = true,
	size = 18,
	weight = 1600,
} )

surface.CreateFont( "AdvDailyLogin_Editor_Reward_Small_font", {
	font = 'Roboto',
	extended = true,
	size = 13,
	weight = 1600,
} )

surface.CreateFont( "AdvDailyLogin_Button_Text", {
	font = 'Roboto',
	extended = true,
	size = 14,
	weight = 1600,
} )

surface.CreateFont( "AdvDailyLogin_Text_font", {
	font = 'Roboto',
	extended = true,
	size = 15,
	weight = 600,
} )

surface.CreateFont( "AdvDailyLogin_TimeFrame", {
	font = 'Roboto',
	extended = true,
	size = 15,
	weight = 500,
} )

surface.CreateFont( "AdvDailyLogin_MainFrame", {
	font = 'Roboto',
	extended = true,
	size = 25,
	weight = 500,
} )

surface.CreateFont( "AdvDailyLogin_StatsText", {
	font = 'Roboto',
	extended = true,
	size = 15,
	weight = 400,
} )

local function adv_daily_login_convertdate(v)
	local date = os.date(adv_daily_login.settings.dateformat,v)
	return date
end

local function ConverTime(t)
	local s_day, s_hour, s_min = 86400, 3600, 60
	local day = math.floor(t / s_day)
	local hour = math.floor((t - day * s_day) / s_hour) 
	local min = math.floor((t - day * s_day - hour * s_hour) / s_min) 
	local sec = math.floor(t - day * s_day - hour * s_hour - min * s_min) 

	return hour, min, sec
end

local advbtntbl = {}

local data, pldata, Box, Received, data_items, border_box = {},{},{},{},{},{}
local ostime, GetBtn, daily_login_settingsframe, PlayerListFrame, AdvDailyLoginFrame, AppList, daily_login_setupitemsframe

-- hook.Add('Think','RemoveMainFrame2',function() 
-- 	if input.IsKeyDown( KEY_F2 ) then
-- 		if IsValid(AdvDailyLoginFrame) then AdvDailyLoginFrame:Remove() end 
-- 	end
-- end)

local function AdvDailyLogin()

	if IsValid(AdvDailyLoginFrame) then
		AdvDailyLoginFrame:MakePopup()
		return
	end

	local _debug_space = 15

	AdvDailyLoginFrame = vgui.Create( "DFrame" )
	--AdvDailyLoginFrame:SetSize( math.Clamp( 771, 0, ScrW() * 0.7 ), math.Clamp( 518+_debug_space, 0, ScrH() ))
	AdvDailyLoginFrame:SetSize( ScrW() - ((ScrW() / 100 ) * 50), ScrH() * 0.5)
	AdvDailyLoginFrame:SetTitle( "" )
	AdvDailyLoginFrame:SetPos((ScrW() / 2) - (AdvDailyLoginFrame:GetWide() / 2)  , (ScrH() / 2) - (AdvDailyLoginFrame:GetTall() / 2) - 14)
	AdvDailyLoginFrame:SetDraggable( false )
	AdvDailyLoginFrame:MakePopup()
	AdvDailyLoginFrame:ShowCloseButton(false)

	adv_daily_login:FadeFunc('show',AdvDailyLoginFrame, 255 ,.3, .2)

	local tickness = 2
	local rounded = 2

	AdvDailyLoginFrame.UpdateHtml = function()

	end

	function AdvDailyLoginFrame:Paint( w, h )


		draw.RoundedBox( rounded + 1, 0, 0 + _debug_space, w, h - _debug_space, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
		draw.RoundedBox( rounded, 0+tickness , 0 + tickness + _debug_space, w - tickness * 2, h - tickness * 2 - _debug_space, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) )
		surface.SetFont("AdvDailyLogin_MainFrame")
		local x , y = surface.GetTextSize(adv_daily_login.lang[cfg.lang_index].head_text)
		local mh , mw = AdvDailyLoginFrame:GetWide() , AdvDailyLoginFrame:GetTall()
		surface.SetTextPos( (52+17), 5+_debug_space)
		surface.SetTextColor(Color(255,255,255))
		surface.DrawText(adv_daily_login.lang[cfg.lang_index].head_text)

		local ourMat = Material( "advdailylogin/calendar.png" )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( ourMat	)
		surface.DrawTexturedRect( 10, 0, 42, 42 )
	end

	function AdvDailyLoginFrame:OnClose()
		timer.Destroy('adv_daily_login_refresh')

		-- print('closed!')

		if (IsValid(ImageFrame)) then
			ImageFrame:Remove()
		end
	end

	function AdvDailyLoginFrame:OnRemove()
		-- print('removed!')

		timer.Destroy('adv_daily_login_refresh')

		if (IsValid(ImageFrame)) then
			ImageFrame:Remove()
		end
	end

	local html = vgui.Create( "DHTML" , AdvDailyLoginFrame )
	html:SetPos( (AdvDailyLoginFrame:GetTall() - AdvDailyLoginFrame:GetTall()) + 11, 36 + _debug_space ) 
	html:SetSize( AdvDailyLoginFrame:GetWide() - 22 , AdvDailyLoginFrame:GetTall() - 49 - _debug_space  )
	html:SetPopupStayAtBack(true)
	html:SetHTML( [[
		<style>
		html, body {
			width:100%;
			height:100%;
			margin:0;
			padding:0;
			overflow:hidden;
			background-size:cover;
		}
		#mainbg {
			width:100%;
			height:100%;
			background-image: url("]]..cfg.bglink..[[");
			background-size: cover;
			background-repeat: no-repeat;
			background-position: top;

			opacity:1;
			-webkit-transition: opacity 3s;
			-moz-transition: opacity 3s;     
			transition: opacity 3s; 		
		}​

		#mainbg.fade {
			opacity:0;
		}

		</style>

		<div id="mainbg"></div>​

		]] )

	function html:Paint( w, h )
		adv_daily_login:OutlinedBox( 0, 0, w, h, 1, Color( 0, 0, 0 , 127.5 ) )
	end

	AdvDailyLoginFrame.UpdateHtml = function( s, link )
		html:SetHTML( [[
		<style>
		html, body {
			width:100%;
			height:100%;
			margin:0;
			padding:0;
			overflow:hidden;
			background-size:cover;
		}
		#mainbg {
			width:100%;
			height:100%;
			background-image: url("]]..link..[[");
			background-size: cover;
			background-repeat: no-repeat;
			background-position: top;

			opacity:1;
			-webkit-transition: opacity 3s;
			-moz-transition: opacity 3s;     
			transition: opacity 3s; 		
		}​

		#mainbg.fade {
			opacity:0;
		}
		</style>

		<div id="mainbg"></div>​
		]] )
	end

	local CrossPanel = vgui.Create( "DPanel"  , AdvDailyLoginFrame)
	CrossPanel:SetPos( 10, 35+_debug_space )
	CrossPanel:SetSize( AdvDailyLoginFrame:GetWide() - 20 , AdvDailyLoginFrame:GetTall() - 47 - _debug_space)
	CrossPanel:SetBackgroundColor( Color( 0, 0, 0, 0 ) )
	CrossPanel.Paint = function(s,w,h)
		--surface.DrawRect(0,0,w,h)
		--surface.SetDrawColor(255,0,0)
	end

	-- Temporarily unavailable
	local dailyclbg

	local dailyclshadow = vgui.Create( "DPanel"  , AdvDailyLoginFrame)
	dailyclshadow:SetSize( AdvDailyLoginFrame:GetWide(), AdvDailyLoginFrame:GetTall() - 189 )
	dailyclshadow:SetPos( 0	, 120 )

	local shadowleft = Material( "advdailylogin/shadowleft.png",'smooth' )
	local shadowtop = Material( "advdailylogin/shadowtop.png",'smooth' )
	local shadowright = Material( "advdailylogin/shadowright.png",'smooth' )
	local shadowbottom = Material( "advdailylogin/shadowbottom.png",'smooth' )

	local cornerlefttop = Material( "advdailylogin/cornerlefttop.png",'smooth' )
	local cornerleftbottom = Material( "advdailylogin/cornerleftbottom.png",'smooth' )
	local cornerrightbottom = Material( "advdailylogin/cornerrightbottom.png",'smooth' )
	local cornerrighttop = Material( "advdailylogin/cornerrighttop.png",'smooth' )

	local posbgx , posbgy = dailyclshadow:GetPos()
	dailyclshadow.Paint = function(self, ww, hh )

		--draw.RoundedBox(0,0,0,ww,hh,Color(100,0,0))

		local size1, size2 = 20,20

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( shadowleft	)
		surface.DrawTexturedRect(0, dailyclbg.x + 1 ,  29 , dailyclbg:GetTall()  )

			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( cornerlefttop )
			surface.DrawTexturedRect(dailyclbg.x - size1 , 30 - size1 ,  size1 , size2 )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( shadowtop )
		surface.DrawTexturedRect(dailyclbg.x , 0 ,  dailyclbg:GetWide() , 30 )

			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( cornerleftbottom )
			surface.DrawTexturedRect(dailyclbg.x - size1 , dailyclbg:GetTall() + 30 ,  size1 , size2 )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( shadowright )
		surface.DrawTexturedRect(dailyclbg:GetWide() + 29, dailyclbg.x + 1 ,  30 , dailyclbg:GetTall() )

			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( cornerrightbottom )
			surface.DrawTexturedRect(dailyclbg:GetWide() + 29 , dailyclbg:GetTall() + 30 ,  size1 , size2 )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( shadowbottom )
		surface.DrawTexturedRect(dailyclbg.x, dailyclbg:GetTall() + 30 ,  dailyclbg:GetWide() , 30 )

			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( cornerrighttop )
			surface.DrawTexturedRect(dailyclbg:GetWide() + 29 , 30 - size1 ,  size1 , size2 )		

	end

	function dailyclshadow:OnMousePressed( gained )
		if !ImageFrame then return end
		ImageFrame:MakePopup()
	end

	dailyclbg = vgui.Create( "DPanel"  , AdvDailyLoginFrame)
	dailyclbg:SetSize( AdvDailyLoginFrame:GetWide() - 58, AdvDailyLoginFrame:GetTall() - 213 - _debug_space )
	dailyclbg:SetPos( 29, 135 + _debug_space )
	
	AdvDailyLoginFrame.OnSizeChanged = function(s, w, h )
		--print(w, h)
		html:SetSize( AdvDailyLoginFrame:GetWide() - 22 , AdvDailyLoginFrame:GetTall() - 49 - _debug_space  )
		dailyclbg:SetSize( w - 58, h - 213 - _debug_space )
		dailyclshadow:SetSize( AdvDailyLoginFrame:GetWide(), AdvDailyLoginFrame:GetTall() - 105 - 15 - 30 - 18 )
		CrossPanel:SetSize( AdvDailyLoginFrame:GetWide() - 20 , AdvDailyLoginFrame:GetTall() - 47 - _debug_space)
		AdvDailyLoginFrame:SetPos((ScrW() / 2) - (AdvDailyLoginFrame:GetWide() / 2)  , (ScrH() / 2) - (AdvDailyLoginFrame:GetTall() / 2) - 14)
	end

	function dailyclbg:Paint( w, h )
		draw.RoundedBox( 0, 0, 0, w, h, adv_daily_login.colors.cells_bg )
		adv_daily_login:OutlinedBox( 0, 0, w, h, 1, Color(0,0,0,255) )
	end

	local function Refresh_img_pnl()
		if #Box != 0 then
			for k , v in pairs(Box) do
				Box[k]:Remove()
			end
		end
		-- Box = {}
	end

	local function adv_daily_login_items()
		local space = 0
		local space2 = 0
		if !(data_items) then return end

		Refresh_img_pnl()

		local _size, border_posx, border_posy

		if dailyclbg:GetWide() < 771 then
			_size = border_box[1]:GetWide() * 0.6
			_space = dailyclbg:GetWide() / 7 + 1
		elseif dailyclbg:GetWide() > 771 then
			_size = border_box[1]:GetWide() * 0.6
			_space = math.floor(dailyclbg:GetWide() / 7) //+ 1
		end

		for k , v in ipairs(data_items) do

			border_posx , border_posy = border_box[k]:GetPos()
			Box[k] = vgui.Create( "AdvDailyLogin_Cell"  , dailyclbg)
			Box[k]:SetSize( _size , _size )
			Box[k]:SetPos( border_posx + ((border_box[k]:GetWide() / 2)) - ((Box[k]:GetWide() / 2)), border_posy + ((border_box[k]:GetTall() / 2)) - ((Box[k]:GetTall() / 2))  )

			Box[k]:SetCellID(k)
			Box[k]:UseModel(adv_daily_login.settings.use_models)
			Box[k]:SetName(adv_daily_login.lang[cfg.lang_index].DayName..": "..k)
			Box[k]:MakePop(ImageFrame)
			Box[k]:SetupLang(cfg.lang_index)

			if v != 0 then // Fixed - One item not showing
				Box[k]:SetupItems(v.items)
				if (table.Count(v.items) > 1) then
					if !(v.item_gui) || (v.item_gui == " ") then Box[k]:SetImg(Material('materials/advdailylogin/nothing.png','smooth')) end
					if v.item_gui != " " then Box[k]:SetImg(v.item_gui) end
				else
					if (v.item_gui == " ") then
						if v.items[1].item_type == 'pointshop1_points' || v.items[1].item_type == 'pointshop2_points' || v.items[1].item_type == 'pointshop2_prem_points' then
							Box[k]:SetImg(Material('materials/advdailylogin/points.png','smooth'))
						elseif v.items[1].item_type == 'darkrp_cash' then
							Box[k]:SetImg(Material('materials/advdailylogin/money.png','smooth')) 
						end
					else
						Box[k]:SetImg(v.item_gui)
					end
				end
			end

			space = space + _space
			if k == 7 or  k == 14 then
				space = 0
				space2 = space2 + _space
			end		
		end
	end

	local function adv_daily_login_generateimg()
		-- print('Generate img')
		for k , v in ipairs(data_items) do
			--if istable(v) then
				Received[k] = vgui.Create( "DImage"  , dailyclbg)
				Received[k]:SetMaterial(Material('advdailylogin/received.png','smooth'))
				local x , y = Box[k]:GetPos()
				Received[k]:SetSize( 200 , 200 )
				Received[k]:SetPos( x + ((Box[k]:GetWide() / 2)) - ((Received[k]:GetWide() / 2)), y + ((Box[k]:GetTall() / 2)) - ((Received[k]:GetTall() / 2))  )
				Received[k]:Hide()
			--end
		end
	end

	local function adv_daily_login_refreshimg()
		if !data then return end
		local numdata = (data.dailystay)

		--for k , v in pairs(data_items) do
		--	if istable(v) then
				if numdata > 0 then 
					for i=1, numdata do
						if !(Box[i]) then continue end
						local x , y = Box[i]:GetPos()
						--local 
						Received[i]:SetSize( Box[i]:GetWide() * 0.8 , Box[i]:GetWide() * 0.8 )
						Received[i]:SetPos( x + ((Box[i]:GetWide() / 2)) - ((Received[i]:GetWide() / 2)), y + ((Box[i]:GetTall() / 2)) - ((Received[i]:GetTall() / 2)) )
						Received[i]:Show()
					end
				else
					for i=1, #Box do
						Received[i]:Hide()
					end		
				end
		--	end
		--end		
	end

	local function adv_daily_login_refresh_img()
		for i=1, #Box do
			Received[i]:Remove()
		end
		--adv_daily_login_refreshimg()
	end	

	function adv_daily_login_getitemsfx()
		-- print('SFX!')
		if !(data) then return end
		local numdata = (data.dailystay)
		-- local days_confirmed = (data.days_confirmed)

		-- for k , v in pairs(days_confirmed) do
		-- 	print(k , v)
		-- end

		if data.dailystay < 1 then
			for i=1, #Box do
				local x , y = Box[i]:GetPos()
				Received[i]:SetSize( 100 , 100 )
				Received[i]:SetPos( x + ((Box[i]:GetWide() / 2)) - ((Received[i]:GetWide() / 2)), y + ((Box[i]:GetTall() / 2)) - ((Received[i]:GetTall() / 2)) )
				Received[i]:Hide()		
			end
		else
			if numdata < 1 then return end
			if !(Box[numdata]) then return end
			local x , y = Box[numdata]:GetPos()
			Received[numdata]:Show()
			Received[numdata]:SizeTo( Box[numdata]:GetWide() * 0.8, Box[numdata]:GetWide() * 0.8, .1, 0, -1)
			Received[numdata]:MoveTo( x + ((Box[numdata]:GetWide() / 2)) - (((Box[numdata]:GetWide() * 0.8) / 2)), y + ((Box[numdata]:GetTall() / 2)) - (((Box[numdata]:GetWide() * 0.8) / 2)) , .1, 0, -1)
		end
	end

	local function adv_daily_login_drawborder()
		local textsp,textsp2, space2 , space  = 0,0,0,0

		local _size

		if dailyclbg:GetWide() > 771 then
			_size = dailyclbg:GetTall() / 3
			_tempsize = (_size * 7)
			AdvDailyLoginFrame:SetWide(_tempsize+60 + 4)
			AdvDailyLoginFrame:SetTall( AdvDailyLoginFrame:GetTall() + 2)
			--print('More than 771')
		elseif	dailyclbg:GetWide() < 771 then
			--print('Small than 771')
			_size = math.floor(dailyclbg:GetWide() / 7 ) -- размер одной коробки
			AdvDailyLoginFrame:SetWide( AdvDailyLoginFrame:GetWide() + 5 ) -- 135 + 5 + _tempsize
			_tempsize = math.floor(_size * 3)
			AdvDailyLoginFrame:SetTall( (_tempsize) + _debug_space + 213 + 2) -- 135 + 5 + _tempsize
		end

		local count = 1
	 	for b = 1 , 3 do
			for i = 1 , 7 do
				border_box[count] = vgui.Create( "DPanel"  , dailyclbg)
				border_box[count]:SetPos( 0 + space , 0 + space2)
				border_box[count]:SetSize( _size , _size )
				border_box[count].Paint = function(s, w, h )
					draw.RoundedBox( 0, 0, 0, w, h, adv_daily_login.colors.cells_bg )
					adv_daily_login:OutlinedBox( 0, 0, w, h, adv_daily_login.colors.cells_border_size, adv_daily_login.colors.cells_border )
				end
				local x, y = border_box[count]:GetPos()
				local DLabel = vgui.Create( "DLabel", dailyclbg )
				DLabel:SetPos( x+8 , y+2 )
				DLabel:SetText( count )
				DLabel:SetColor(adv_daily_login.colors.cells_text)

				space = space + border_box[count]:GetWide() + 1 
				textsp = textsp + border_box[count]:GetWide() + 1 
				if i % 7 == 0 then
					textsp = 0
					space = 0
					space2 = space2 + border_box[count]:GetWide() + 1 
					textsp2 = textsp2 + border_box[count]:GetWide() 
				end
				count = count + 1
			end
		end
	end

	if IsValid(AdvDailyLoginFrame) then
		adv_daily_login_drawborder()
		timer.Create('adv_daily_login_refresh',0.1,1,function()
			adv_daily_login_items()
			adv_daily_login_generateimg()
			adv_daily_login_refreshimg()
		end)
	end

	net.Receive('adv_daily_login_refresh_',function ()
		-- TO DO save player complete days
		if IsValid(AdvDailyLoginFrame) then

			-- print('Refresh called')
			
			-- PrintTable(data_items)
			data_items = net.ReadTable()
			-- PrintTable(data_items)

			adv_daily_login_items()

			if IsValid(daily_login_setupitemsframe) then
				daily_login_setupitemsframe:UpdateData(data_items, Box)
			end
			
			adv_daily_login_generateimg()
			adv_daily_login_refreshimg()

		end
	end)

	local function adv_daily_login_statsframe(pldata)
		if adv_daily_login:CheckPermission(LocalPlayer()) then return end			
		if !IsValid(PlayerListFrame) then

			PlayerListFrame = vgui.Create( "DFrame", AdvDailyLoginFrame )

			PlayerListFrame:SetSize( AdvDailyLoginFrame:GetWide() / 2 + daily_login_settingsframe:GetWide() / 2, 350)
			PlayerListFrame:SetPos( ScrW() / 2 - PlayerListFrame:GetWide() / 2 , ScrH() / 2 - PlayerListFrame:GetTall()/2)
			PlayerListFrame:SetTitle( "" )
			PlayerListFrame:SetDraggable( false )
			PlayerListFrame:MakePopup()
			PlayerListFrame:ShowCloseButton(false)

			PlayerListFrame:SetVisible(false)
			PlayerListFrame:SetAlpha(0)

			PlayerListFrame:SetVisible(true)
			PlayerListFrame:AlphaTo(255, .2, 0)

			PlayerListFrame.Paint = function(self, w, h)
				draw.RoundedBox( rounded + 1, 0, 0, w, h, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
				draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255) )
				surface.SetFont("AdvDailyLogin_MainFrame")
				local x , y = surface.GetTextSize(adv_daily_login.lang[cfg.lang_index].btn_plstats)
				surface.SetTextPos( self:GetWide() / 2 - x / 2, 5)
				surface.SetTextColor(Color(255,255,255))
				surface.DrawText(adv_daily_login.lang[cfg.lang_index].btn_plstats)
			end

			local LeftArrow = vgui.Create( "AdvDailyLogin_Button", PlayerListFrame )
			LeftArrow:SetPos( 8, 8 )
			LeftArrow:SetSize( 25, 25 )
			LeftArrow:MakePop(ImageFrame)
			LeftArrow:SetImg( "advdailylogin/left.png" )
			LeftArrow:SetImageColor(Color(200, 200, 200, 200))
			LeftArrow.DoClick = function() adv_daily_login:FadeFunc('remove', PlayerListFrame, 0, .3, 0) adv_daily_login:FadeFunc('show',daily_login_settingsframe, 255, .3, 0) end

			local CloseBtn2 = vgui.Create( "AdvDailyLogin_Button", PlayerListFrame )
			CloseBtn2:SetPos( PlayerListFrame:GetWide() - (25 + 8), 0 + (6) )
			CloseBtn2:SetText('X')
			CloseBtn2:MakePop(ImageFrame)
			CloseBtn2:SetSize( 25, 25 )
			CloseBtn2.DoClick = function() 
				adv_daily_login:FadeFunc('remove',PlayerListFrame, 0, .3, 0)
				adv_daily_login:FadeFunc('remove',daily_login_settingsframe, 0, .3, 0)
			end
		end

		local function CreateDataList(pldata)
			if !IsValid(AppList) then

				AppList = vgui.Create( "DListView", PlayerListFrame )
				AppList:SetSize(PlayerListFrame:GetWide() - 10-10 ,PlayerListFrame:GetTall() - 10 - 45)
				AppList:SetPos(10 ,45)
				AppList:SetMultiSelect( false )
				AppList.m_bHideHeaders = false
				AppList:AddColumn( adv_daily_login.lang[cfg.lang_index].column_ply_name )
				AppList:AddColumn( adv_daily_login.lang[cfg.lang_index].column_cur_daily )
				AppList:AddColumn( adv_daily_login.lang[cfg.lang_index].column_next_date )
				AppList:AddColumn( adv_daily_login.lang[cfg.lang_index].column_cur_cooldown )

				AppList.Paint = function(self, w,h)
					draw.RoundedBox( 0, 0, 0, w+2, h+2,Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, 255)  ) // 
					draw.RoundedBox( 0, 0+tickness , 0 + tickness, w-tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
				end

				for k, v in pairs(AppList.Columns) do 

					v.Header:SetFont( 'AdvDailyLogin_StatsText' )
					v.Header:SetTextColor( adv_daily_login.colors.stats_header_text_color )

					function v.Header:Paint(w, h) 
						draw.RoundedBox( 0, 0, 0, w, h,Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, 255)  ) // 
						draw.RoundedBox( 0, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
					end
				end
			end

			local function DataUpdate()
				net.Start('adv_daily_login_getplayerstats')
				net.SendToServer()
				AppList:Clear()
			end

			function AppList:OnRowRightClick( number, line )
				local m = DermaMenu()

				m:AddOption( adv_daily_login.lang[cfg.lang_index].edit_daily, function()
					Derma_StringRequest(
						adv_daily_login.lang[cfg.lang_index].setdailystay_for..line:GetValue( 1 ),
						adv_daily_login.lang[cfg.lang_index].setdailystay_to,
						"",
						function(str)
							if not str or not tonumber(str) then return end
							net.Start('adv_daily_login_setplayerdailystay')
								net.WriteInt(tonumber(str), 32)
								net.WriteString(line.steamid)
							net.SendToServer()
							DataUpdate()
						end)					
				 end)

				m:AddSpacer()
				m:AddOption( adv_daily_login.lang[cfg.lang_index].reset_data_ply, function()
					net.Start('adv_daily_login_resetplayerstats')
					net.WriteString(line.steamid)
					net.SendToServer()
					DataUpdate()
				end)

				m:AddSpacer()
				m:AddOption( adv_daily_login.lang[cfg.lang_index].reset_cooldown, function()
					net.Start('adv_daily_login_resetplayercooldown')
					net.WriteString(line.steamid)
					net.SendToServer()
					DataUpdate()
				end)

				m:AddSpacer()
				m:AddOption( adv_daily_login.lang[cfg.lang_index].open_profile, function()
					gui.OpenURL( string.format('https://steamcommunity.com/profiles/%s/', line.steamid ) )
				end)

				m:Open()
			end

		    function AppList.VBar:Paint( w, h )
				draw.RoundedBox( rounded + 1, AppList.VBar:GetWide() / 2 - 8 / 2 , 0+16, 8, h - 16 - 16,Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, 255)  ) // 
		    end
		    function AppList.VBar.btnUp:Paint( w, h )
				draw.RoundedBox( rounded + 1, 0, 0, w, h,Color(255,255,255,100) )
				draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
		    end
		    function AppList.VBar.btnDown:Paint( w, h )
				draw.RoundedBox( rounded + 1, 0, 0, w, h,Color(255,255,255,100) ) // 
				draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
		    end
		    function AppList.VBar.btnGrip:Paint( w, h )
				draw.RoundedBox( rounded + 1, 0, 0, w, h,Color(adv_daily_login.colors.main_box.r, adv_daily_login.colors.main_box.g, adv_daily_login.colors.main_box.b, adv_daily_login.colors.main_box.a or 255)  ) // 
				draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, Color(adv_daily_login.colors.main_box_border.r, adv_daily_login.colors.main_box_border.g, adv_daily_login.colors.main_box_border.b, adv_daily_login.colors.main_box_border.a or 255) )
		    end

			for k,v in pairs(pldata) do
				-- print(k,v.steamid)
				-- PrintTable(pldata)
				
				local calc = tonumber(ostime - os.time())
				local val = os.time() + calc
				local _t = ((v.nextdate) - val )
				if _t < 0 then _t = 0 end
				local h,m,s = ConverTime(_t)
				AppList:AddLine( v.name, v.dailystay, adv_daily_login_convertdate(v.nextdate), string.format(' %02d h : %02d m : %02d s ', h, m, s) ).steamid = v.steamid

			end

			for _, line in pairs( AppList:GetLines() ) do

			    function line:Paint( w, h )
			        if ( self:IsHovered() ) then
			        	draw.RoundedBox(0,0 + 1,0,self:GetWide(),self:GetTall(),adv_daily_login.colors.stats_lines_hover_color)
			        elseif ( self:IsSelected() ) then
			            draw.RoundedBox(0,0 + 1,0,self:GetWide(),self:GetTall(),adv_daily_login.colors.stats_lines_select_color)
			        end
			    end

			    for _, column in pairs( line["Columns"] ) do
					column:SetFont( 'AdvDailyLogin_StatsText' )
					column:SetTextColor( adv_daily_login.colors.stats_lines_text_color )

			    end

			end

		end

		CreateDataList(pldata)
	end

	net.Receive('adv_daily_login_sendplayerstats',function ()
		local pldata = net.ReadTable()
		ostime = net.ReadString()
		adv_daily_login_statsframe(pldata)
	end)

	local function adv_daily_login_settingsframe()
		if adv_daily_login:CheckPermission(LocalPlayer()) then return end

		if IsValid(PlayerListFrame) then PlayerListFrame:MakePopup() return	end
		if IsValid(daily_login_settingsframe) then return end
		if IsValid(daily_login_setupitemsframe) then return end

		daily_login_settingsframe = vgui.Create('AdvDailyLogin_Settings', AdvDailyLoginFrame)
		daily_login_settingsframe:SetSize( AdvDailyLoginFrame:GetWide() / 2, 380)
		daily_login_settingsframe:SetPos( AdvDailyLoginFrame:GetWide() / 2 - daily_login_settingsframe:GetWide() / 2 , AdvDailyLoginFrame:GetTall() / 2 - daily_login_settingsframe:GetTall() / 2 )
		daily_login_settingsframe:MakePop(ImageFrame)
		daily_login_settingsframe:SetupLang(cfg.lang_index)
		daily_login_settingsframe:CreateStuff()
	end

	local function adv_daily_login_setupitemsframe()
		if adv_daily_login:CheckPermission(LocalPlayer()) then return end

		//if IsValid(PlayerListFrame) then PlayerListFrame:MakePopup() return	end
		if IsValid(daily_login_setupitemsframe) then return end
		if IsValid(daily_login_settingsframe) then return end

		daily_login_setupitemsframe = vgui.Create('AdvDailyLogin_SetupItems', AdvDailyLoginFrame)
		daily_login_setupitemsframe:SetSize( AdvDailyLoginFrame:GetWide() / 2, 380)
		daily_login_setupitemsframe:SetPos( AdvDailyLoginFrame:GetWide() / 2 - daily_login_setupitemsframe:GetWide() / 2 , AdvDailyLoginFrame:GetTall() / 2 - daily_login_setupitemsframe:GetTall() / 2 )
		daily_login_setupitemsframe:SetupLang(cfg.lang_index)
		daily_login_setupitemsframe:CreateStuff(data_items, Box)
		-- daily_login_setupitemsframe:UpdateData(data_items)
	end

	local DatePanel = vgui.Create( "DPanel", AdvDailyLoginFrame )
	DatePanel:SetPos( 30, 95+_debug_space )
	DatePanel:SetSize( 200,35 )
	function DatePanel:Paint(w, h)
		local th = DatePanel:GetTall()
		if adv_daily_login.settings.reset_when_complete then return end
		if !adv_daily_login.colors.timebox_date_outlite then
			draw.SimpleText(adv_daily_login_convertdate(cfg.startdate)..' - '..adv_daily_login_convertdate(cfg.enddate),'AdvDailyLogin_TimeFrame', w / 2,th - th + 10,adv_daily_login.colors.timebox_date_color,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		else
			draw.SimpleTextOutlined(adv_daily_login_convertdate(cfg.startdate)..' - '..adv_daily_login_convertdate(cfg.enddate),'AdvDailyLogin_TimeFrame', w / 2, th - th + 10, adv_daily_login.colors.timebox_date_color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0))
		end
	end	

	local TimePanel = vgui.Create( "DPanel", AdvDailyLoginFrame )
	TimePanel:SetPos( 30, 55+_debug_space )
	TimePanel:SetSize( 200,35 )
	local nextUseString
	
	local calc = tonumber(ostime - os.time())
	function TimePanel:Paint(w, h)

		local val = os.time() + calc
		local _t = ((data.nextdate) - val )

		draw.RoundedBox( rounded + 1, 0, 0, w, h, adv_daily_login.colors.timebox_border )
		draw.RoundedBox( rounded, 0+tickness , 0 + tickness, w - tickness * 2, h - tickness * 2, adv_daily_login.colors.timebox_color )
		local w = select(1,TimePanel:GetSize())
		if _t > 0 then
			local th = TimePanel:GetTall()
			draw.SimpleText(adv_daily_login.lang[cfg.lang_index].NextUseText,"AdvDailyLogin_TimeFrame",w / 2, th - th / 2 - 8 ,adv_daily_login.colors.timebox_text_color,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
	end

	local Cooldown = vgui.Create( "DLabel", TimePanel )

	local function CalcTimeInfelicityn(t)
		local hr, ml, sc = 0,0,0
		local _t = os.time()
		local val = tonumber(t)
		local cal = val - _t

		if cal < 0 then return hr, ml, sc end
		local s_day, s_hour, s_min = 86400, 3600, 60
		local day =  math.floor(cal / s_day)
		local hour = math.floor((cal - day * s_day) / s_hour) 
		local min =  math.floor((cal - day * s_day - hour * s_hour) / s_min) 
		local sec =  math.floor(cal - day * s_day - hour * s_hour - min * s_min)

		return hour, min, sec
	end

	local calc = tonumber(ostime - os.time())

	function Cooldown:Think()
		if !data then return end

		local val = os.time() + calc
		local _t = ((data.nextdate) - val )

		local h,m,s = ConverTime(_t)

		local ww,hh = TimePanel:GetSize()
		local www,hhh = self:GetSize()

		if _t <= 0 then
			nextUseString = adv_daily_login.lang[cfg.lang_index].AlreadyGet
			self:SetPos( (ww / 2 ) - (www / 2), hh / 2 - hhh / 2)
			GetBtn:SetVisible(true)
			GetBtn:SetEnabled( true )
		else
			nextUseString = string.format(' %02d h : %02d m : %02d s ', h, m, s)

			self:SetPos( (ww / 2 )- (www / 2), 18 )
			GetBtn:SetVisible(false)
			GetBtn:SetEnabled( false )
		end
		self:SetText(nextUseString)
		self:SetColor(adv_daily_login.colors.timebox_text_color)
		self:SizeToContents()
	end

	Cooldown:SetColor(adv_daily_login.colors.timebox_text_color)
	Cooldown:SetFont("AdvDailyLogin_TimeFrame")

	GetBtn = vgui.Create( "AdvDailyLogin_Button", AdvDailyLoginFrame )
	GetBtn:SetText( adv_daily_login.lang[cfg.lang_index].btn_get  )
	GetBtn:SizeToContent(129, 44)
	-- GetBtn:SetSize( 129, 44 )
	GetBtn:SetPos( AdvDailyLoginFrame:GetWide() / 2 - GetBtn:GetWide() / 2, AdvDailyLoginFrame:GetTall() - 67  )
	GetBtn:MakePop(ImageFrame)
	GetBtn.DoClick = function(self)
		if !data then return end
		net.Start("adv_daily_login_getitem")
		net.SendToServer()
	end

	local sizew = 25
	local sizeh = 25
	local CloseBtn = vgui.Create( "AdvDailyLogin_Button", AdvDailyLoginFrame )
	CloseBtn:SetPos( AdvDailyLoginFrame:GetWide() - (sizew + 8), sizeh - sizeh + (6) + _debug_space )
	CloseBtn:SetText('X')
	CloseBtn:MakePop(ImageFrame)
	CloseBtn:SetSize( sizew, sizeh )
	CloseBtn.DoClick = function()
		AdvDailyLoginFrame:Remove()
		--ImageFrame:Remove()
	end

	if IsValid(LocalPlayer()) then
		if adv_daily_login:CheckPermission(LocalPlayer()) then return end

		local SettingsBtn = vgui.Create( "AdvDailyLogin_Button", AdvDailyLoginFrame )
		SettingsBtn:SetPos( (AdvDailyLoginFrame:GetWide() - 10)-42, 45 + _debug_space )
		SettingsBtn:SetSize( 32, 32 )
		SettingsBtn:SetAnim(true)
		SettingsBtn:MakePop(ImageFrame)
		SettingsBtn:SetImg( "advdailylogin/settings.png" )
		SettingsBtn:SetImageColor(Color(200, 200, 200, 200))

		SettingsBtn.DoClick = function()  adv_daily_login_settingsframe() end

		local SetupItemsBtn = vgui.Create( "AdvDailyLogin_Button", AdvDailyLoginFrame )
		SetupItemsBtn:SetPos( (AdvDailyLoginFrame:GetWide() - 10)-42 - 32 - 6, 45 + _debug_space )
		SetupItemsBtn:SetSize( 32, 32 )
		SetupItemsBtn:SetAnim(true, 'size')
		SetupItemsBtn:MakePop(ImageFrame)
		SetupItemsBtn:SetImg( "advdailylogin/edit.png" )
		SetupItemsBtn:SetImageColor(Color(200, 200, 200, 200))

		SetupItemsBtn.DoClick = function()  adv_daily_login_setupitemsframe() end
	end
end

net.Receive("adv_daily_login_open", function(len)
	data = net.ReadTable()
	cfg = net.ReadTable()
	adv_daily_login.cfg_lang = cfg.lang_index
	-- PrintTable(data)
	ostime = net.ReadString()
	data_items = net.ReadTable()
	AdvDailyLogin()
end)

net.Receive("adv_daily_login_updatedate", function(len,ply)
	data = net.ReadTable()
	ostime = net.ReadString()
	-- PrintTable(data)
	sound.PlayFile( adv_daily_login.sound.item_received, "", function( station )
		if ( IsValid( station ) ) then station:Play() end
	end )
	adv_daily_login_getitemsfx()
end)

net.Receive("adv_daily_login_updatedate_items", function(len,ply)
	data = net.ReadTable()

end)