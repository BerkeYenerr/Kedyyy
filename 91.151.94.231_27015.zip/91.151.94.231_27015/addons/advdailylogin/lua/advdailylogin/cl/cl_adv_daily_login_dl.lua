// Licensed to 76561198147781703
// Credits to Kogitsune

local AdvDailyLoginDL = {}
AdvDailyLoginDL.__index = AdvDailyLoginDL

local root = 'advdailylogin'

if not file.IsDir(root, "DATA") then
	file.CreateDir(root)
end

function AdvDailyLoginDL:Download(status)
	if self:IsDownloading() or self:IsReady() then return end
	local uid = util.CRC(self.Path) .. '.png'
	self.UID = uid

	http.Fetch(self.Path, function(body)
		file.Write(root.. "/" .. self.UID, body)
		self.Downloading = false
		self.Ready = true
		status(true)
	end, function(err)
		print("Error fetching url '" .. self.Path .. "': " .. err .. "\n")
	end)
end

function AdvDailyLoginDL:IsReady()
	return self.Ready
end

function AdvDailyLoginDL:IsDownloading()
	return self.Downloading
end

function AdvDailyLoginDL:GetMaterial()
	if self:IsDownloading() or not self:IsReady() then return end
	local x = Material("../data/"..root.."/" .. self.UID, self.Flags)
	return x
end

function AdvDailyLoginDL:CheckMaterial(status, ondownloaded)
	local uid = util.CRC(self.Path) .. '.png'
	if file.Exists( root.. "/" .. uid, 'DATA' ) then
		self.UID = uid
		self.Ready = true
		local x = Material("../data/"..root.."/" .. uid, self.Flags)
		if status then
			status('exist', x)
		end
		return x
	else
		if status then
			status('download')
		end
		self:Download(function(status)
			if status == true then
				ondownloaded(true)
			end
		end)
	end
end

function adv_daily_login:WebMaterial(path, flags)
	return setmetatable({
		Path = path,
		Flags = flags,
		Ready = false,
		Downloading = false
	}, AdvDailyLoginDL)
end