adv_daily_login.advpnltbl = adv_daily_login.advpnltbl or {}
table.Empty(adv_daily_login.advpnltbl)

local debug = false

function adv_daily_login:OutlinedBox		( x, y, w, h, thickness, clr ) // Credits to gmod wiki
	surface.SetDrawColor( clr )
	for i=0, thickness - 1 do
		surface.DrawOutlinedRect( x + i, y + i, w - i * 2, h - i * 2 )
	end
end

function adv_daily_login:CreateButton 		(parent, text, sizew, sizeh, posx, posy, leftspace, SetHint, HintColor, hinth, popup ,click, callback)
	local count = #adv_daily_login.advpnltbl + 1

	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetPos(posx,posy)

	adv_daily_login.advpnltbl[count]:SetSize(parent:GetWide(),sizeh)
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100)) end
	end
	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end	
	end

	local mw , mh = adv_daily_login.advpnltbl[count]:GetWide() , adv_daily_login.advpnltbl[count]:GetTall()

	local btn = vgui.Create( "AdvDailyLogin_Button", adv_daily_login.advpnltbl[count] )
	btn:SetText( text )
	btn:SetPos( leftspace, 0 )
	btn:SizeToContent(btn:GetWide() + 30, sizeh)

	if callback then
		callback = callback(adv_daily_login.advpnltbl[count], btn)
	end

	btn:MakePop(ImageFrame)
	btn.DoClick = click

	if isstring(SetHint) then
		surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
		local tw , th = surface.GetTextSize(SetHint)

		local toptextpanel = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
		toptextpanel:SetPos(leftspace, 0)
		toptextpanel:SetSize (tw + 10, hinth)
		adv_daily_login.advpnltbl[count]:SetSize(adv_daily_login.advpnltbl[count]:GetWide(), sizeh + toptextpanel:GetTall())
		btn:SetPos( leftspace , toptextpanel:GetTall() )

		function toptextpanel:Paint( w, h )
			if debug then draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100)) end
			surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
			local tw , th = surface.GetTextSize(SetHint)

			surface.SetTextColor( HintColor )
			surface.SetTextPos( 0 , toptextpanel:GetTall() / 2 - th / 2 )
			surface.DrawText( SetHint )
		end
	end
end

function adv_daily_login:FadeFunc			(case, parent, alpha, dur, delay, onfinish)
	if !IsValid(parent) then return end
	local actions = {
	  	['remove'] = function ()
	  		if parent:GetAlpha() == 0 then
	  			parent:SetAlpha(0)
	  		else
	  			parent:SetAlpha(255)
	  		end	  		
	  		parent:SetVisible(true)
			parent:AlphaTo(alpha, dur, delay, function()
				parent:Remove()
				if onfinish then
					onfinish(true)
				end
				
			end)	  		
	  	end,
	  	['show'] = function ()
	  		parent:SetVisible(true)
	  		parent:SetAlpha(0)
	  		parent:AlphaTo(alpha, dur, delay)
	  	end,
	  	['hide'] = function ()
	  		if parent:GetAlpha() == 0 then
	  			parent:SetAlpha(0)
	  		else
	  			parent:SetAlpha(255)
	  		end	  		
	  		parent:SetVisible(true)
	  		parent:AlphaTo(alpha, dur, delay, function()
	  			parent:Hide()
				if onfinish then
					onfinish(true)
				end
	  		end)
	  	end,
	  	['close'] = function ()
	  		if parent:GetAlpha() == 0 then
	  			parent:SetAlpha(0)
	  		else
	  			parent:SetAlpha(255)
	  		end
	  		parent:SetVisible(true)
			parent:AlphaTo(alpha, dur, delay, function()
				parent:Close()
				if onfinish then
					onfinish(true)
				end
			end)	  		
	  	end,
	}
	return actions[case]()
end

function adv_daily_login:CreateColorBox		(parent, lang, sizew, sizeh, posx, posy, SetHint, HintColor, hinth, popup, callback)
	local count = #adv_daily_login.advpnltbl + 1

	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetSize(sizew,sizeh)
	adv_daily_login.advpnltbl[count]:SetPos(posx, posy )
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100))  end
	end
	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end	
	end

	local Mixer = vgui.Create( "DColorMixer", adv_daily_login.advpnltbl[count] )
	Mixer:SetSize(adv_daily_login.advpnltbl[count]:GetWide() - 20, sizeh) 
	Mixer:SetPos(10,adv_daily_login.advpnltbl[count]:GetTall() - Mixer:GetTall() - 10)
	Mixer:SetPalette( false )
	Mixer:SetAlphaBar( false )
	Mixer:SetWangs( true )
	Mixer:SetColor( Color( 30, 100, 160 ) )	

	if callback then
		callback(adv_daily_login.advpnltbl[count], Mixer)
	end

	if isstring(SetHint) then
		adv_daily_login.advpnltbl[count]:SetSize(sizew,sizeh+ 20)
		adv_daily_login.advpnltbl[count]:SetPos(posx,posy )
		local toptextpanel = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
		toptextpanel:SetPos(10, 0)
		toptextpanel:SetSize (adv_daily_login.advpnltbl[count]:GetWide() - 20, hinth)
		Mixer:SetPos( 10, toptextpanel:GetTall() )
		toptextpanel.OnMousePressed = function(self, key)
			if popup then
				popup:MakePopup()
			end	
		end

		function toptextpanel:Paint( w, h )
			if debug then draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100)) end
			surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
			local tw , th = surface.GetTextSize( SetHint )

			surface.SetTextColor( HintColor )
			surface.SetTextPos(0 , toptextpanel:GetTall() / 2 - th / 2 )
			surface.DrawText( SetHint )
		end
	end
end

function adv_daily_login:CreateEdit			(parent, lang, editval, edithint, sizew, sizeh, posx, posy, MainText, HintColor, hinth, popup, callback, onvaluechanged)
	local count = #adv_daily_login.advpnltbl + 1
	local edit_hint = edithint
	local Big_Hint = MainText
	local editting_border_color = (adv_daily_login.colors.main_box_border)

	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetSize(sizew,sizeh)
	adv_daily_login.advpnltbl[count]:SetPos(posx,posy)
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100))  end
	end

	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end	
	end

	adv_daily_login.advpnltbl[count].SetupText = function(s, v)
		Big_Hint = v
	end

	local mw , mh = adv_daily_login.advpnltbl[count]:GetWide() , adv_daily_login.advpnltbl[count]:GetTall()

	local edit = vgui.Create("DTextEntry", adv_daily_login.advpnltbl[count])
	edit:SetPaintBackground(false)
	edit:SetPos( 10, adv_daily_login.advpnltbl[count]:GetTall() - 10 )
	edit:SetSize( adv_daily_login.advpnltbl[count]:GetWide() - 20 , sizeh )
	edit:SetValue(editval)
	edit._color = editting_border_color
	edit.Paint = function(s, w, h)

		draw.RoundedBox( 2 + 1, 0, 0, w, h, edit._color )
		draw.RoundedBox( 3, 0+ 2 , 0 + 2, w - 2 * 2, h - 2 * 2, adv_daily_login.colors.main_box )

		if s:IsEditing() then
			s._color = Color(41, 12, 185)
		else
			s._color = editting_border_color
		end

		if isstring(edit_hint) then
			surface.SetFont( "AdvDailyLogin_Edit_font" )
			local tw , th = surface.GetTextSize(edit_hint)

			if s:GetText() == "" and not s:IsEditing() then
					draw.SimpleText(edit_hint, "AdvDailyLogin_Edit_font", 10, (h/2)  , Color(149, 152, 154),  0, 1)
			end
		end
		if s:IsHovered() or s:IsEditing() or s:GetText() ~= "" then
			s:DrawTextEntryText(Color(255, 255, 255), Color(53, 79, 115 , 200), Color(255, 255, 255))
		end
	end

	EaseOut = function(power) 
	return function(t) 
			return 1 - math.abs(math.pow(t-1, power)) 
		end 
	end

	local anim_speed = 0.5 // anim speed
	local anim_duration = 2 // anim frames - 5

	local start_anim = 0
	local anim_count = start_anim + anim_duration
	local def_color = Color(53, 79, 115 )
	local err_color = Color(231, 76, 60 )

	local function LerpColor(frac,from,to)
		local _speed = ( frac )
		-- print(_speed ,frac, anim_count, anim_speed)
		local col = Color(
			Lerp(_speed,from.r,to.r),
			Lerp(_speed,from.g,to.g),
			Lerp(_speed,from.b,to.b),
			Lerp(_speed,from.a,to.a)
		)
		--print(col)
		return col
	end

	--local time = RealFrameTime()
	

	local function ColorErrorValue()
		start_anim = ( start_anim + .1 )
	
		if anim_count > start_anim then 
			local num = (EaseOut(anim_count)(start_anim))
			editting_border_color = LerpColor(num, def_color, err_color )
		else
			hook.Remove('Think','testfunc')
			start_anim = 0
		end
	end

	function edit:ColorErrorValue()
		editting_border_color = err_color
		hook.Add('Think','testfunc', ColorErrorValue)
	end
	
	--hook.Call('string eventName',table gamemodeTable,vararg args)


	function edit:SetHint_(value)
		edit_hint = value
	end

	if callback then
		callback = callback(adv_daily_login.advpnltbl[count], edit)
	end

	edit.OnValueChange = function(self) -- Passes a single argument, the text entry object.
		if self:GetValue() != '' then
			if onvaluechanged then
				onvaluechanged(true)
			end			
		else
			if onvaluechanged then
				onvaluechanged(false)
			end			
		end
	end

	edit.OnTextChanged = function(self) -- Passes a single argument, the text entry object.
		if self:GetValue() != '' then
			if onvaluechanged then
				onvaluechanged(true)
			end			
		else
			if onvaluechanged then
				onvaluechanged(false)
			end			
		end

	end

	-- print(Big_Hint)
	if isstring(Big_Hint) then
		local toptextpanel = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
		toptextpanel:SetPos(10, 0)
		toptextpanel:SetSize (adv_daily_login.advpnltbl[count]:GetWide() - 20, hinth)
		adv_daily_login.advpnltbl[count]:SetSize(sizew, sizeh + toptextpanel:GetTall())
		edit:SetPos( 10 , toptextpanel:GetTall() )

		function toptextpanel:Paint( w, h )
			if debug then draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100)) end
			surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
			local tw , th = surface.GetTextSize(Big_Hint)

			surface.SetTextColor( HintColor )
			surface.SetTextPos( 0 , toptextpanel:GetTall() / 2 - th / 2 )
			surface.DrawText( Big_Hint )
		end
	end
end

function adv_daily_login:CreateComboBox2	(parent, data ,set_def_data, cboxwide, sizew, sizeh, posx, posy, SetHint, HintColor, hinth, popup, onselect, callback, callback2)
	local count = #adv_daily_login.advpnltbl + 1

	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetSize(sizew,sizeh)
	adv_daily_login.advpnltbl[count]:SetPos(posx,posy)
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100))  end
	end
	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end	
	end

	if callback then
		callback = callback(adv_daily_login.advpnltbl[count])
	end

	local cbox = vgui.Create( "DComboBox", adv_daily_login.advpnltbl[count] )
	cbox:SetSize( cboxwide , sizeh )
	cbox:SetPos( 10, adv_daily_login.advpnltbl[count]:GetTall() - 10 )
	cbox:SetSortItems( false )
	cbox:SetTextColor( Color( 255, 255, 255 ) )
	cbox:SetFont("AdvDailyLogin_Edit_font")
	cbox.firstchange = false

	cbox.OnMousePressed = function(self, key)
		if cbox:IsMenuOpen() then
			--print('Menu is opened!')
			cbox:CloseMenu()
		else
			cbox:OpenMenu()
		end
		if callback2 then
			callback2(true)
		end

		if popup then
			popup:MakePopup()
		end
		
		local hovered_color = Color(230,235,238)
		local stand_color = Color(255,255,255)
		local corner = 7
		local text_color = Color(0,70,108)
		local posx , posy = cbox:GetPos()
		local locposx, locposy = cbox:LocalToScreen(posx , posy)
		cbox.Menu:SetPos(locposx - 10,locposy + 5)
		function cbox.Menu:Paint(w, h)
		end
	 	for k,v in pairs( cbox.Menu:GetCanvas():GetChildren() ) do
	 		v:RequestFocus()
	 		v:SetTextColor(text_color)
			function v:Paint(w, h)
				if (k == 1) and (#cbox.Menu:GetCanvas():GetChildren() == 1) then
					draw.RoundedBoxEx(corner,0,0,w,h,stand_color,true,true,true,true)
				elseif (k == 1) then
					draw.RoundedBoxEx(corner,0,0,w,h,stand_color,true,true,false,false)
					surface.SetDrawColor(hovered_color)
					surface.DrawLine(0, h-1, w, h-1)
				elseif (k == #cbox.Menu:GetCanvas():GetChildren()) then
					draw.RoundedBoxEx(corner,0,0,w,h,stand_color,false,false,true,true)
				else
					draw.RoundedBoxEx(corner,0,0,w,h,stand_color,false,false,false,false)
					surface.SetDrawColor(hovered_color)
					surface.DrawLine(0, h-1, w, h-1)
				end

				if v:IsHovered() then
					if (k == 1) and (#cbox.Menu:GetCanvas():GetChildren() == 1) then
						draw.RoundedBoxEx(corner,0,0,w,h-1,hovered_color,true,true,true,true)
					elseif (k == 1) then
						draw.RoundedBoxEx(corner,0,0,w,h-1,hovered_color,true,true,false,false)
					elseif (k == #cbox.Menu:GetCanvas():GetChildren()) then
						draw.RoundedBoxEx(corner,0,0,w,h,hovered_color,false,false,true,true)
					else
						draw.RoundedBoxEx(corner,0,0,w,h-1,hovered_color,false,false,false,false)
					end
				end
			end
		end
	end

	for k , v in ipairs( data ) do
		if istable(v) then
			cbox:AddChoice( v.Name )
		else
			cbox:AddChoice( v )
		end
	end

	if set_def_data then
		cbox:SetValue( cbox:GetOptionText( set_def_data ) )
	end
	
	cbox.OnSelect = onselect

	cbox.Paint = function( _, w, h )
		draw.RoundedBox( 2 + 1, 0, 0, w, h, Color(adv_daily_login.colors.button_border.r, adv_daily_login.colors.button_border.g, adv_daily_login.colors.button_border.b, adv_daily_login.colors.button_border.a or 255) ) -- 76561198147781703
		draw.RoundedBox( 2, 0+2 , 0 + 2, w - 2 * 2, h - 2 * 2, Color(adv_daily_login.colors.button.r, adv_daily_login.colors.button.g, adv_daily_login.colors.button.b, adv_daily_login.colors.button.a or 255) )
	end
	

	if isstring(SetHint) then
		local toptextpanel = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
		toptextpanel:SetPos(10, 0)
		toptextpanel:SetSize (adv_daily_login.advpnltbl[count]:GetWide() - 20, hinth)
		adv_daily_login.advpnltbl[count]:SetSize( sizew, sizeh + toptextpanel:GetTall() )

		cbox:SetPos( 10 , toptextpanel:GetTall() )
		toptextpanel.OnMousePressed = function(self, key)
			if popup then
				popup:MakePopup()
			end	
		end

		function toptextpanel:Paint( w, h )
			if debug then draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100)) end
			surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
			local tw , th = surface.GetTextSize( SetHint )

			surface.SetTextColor( HintColor )
			surface.SetTextPos(0 , toptextpanel:GetTall() / 2 - th / 2 )
			surface.DrawText( SetHint )
		end
	end
end

function adv_daily_login:CreateItemList		(parent, lang, sizew, sizeh, posx, posy, SetHint, HintColor, hinth, popup, _items, item_cell, callback)
	local count = #adv_daily_login.advpnltbl + 1
    --PrintTable(_items)
	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetSize(sizew,sizeh)
	adv_daily_login.advpnltbl[count]:SetPos(parent:GetWide() - adv_daily_login.advpnltbl[count]:GetWide() - 10 , posy)
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100)) end
	end
	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end
	end

	local ItemsPnl = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
	ItemsPnl:SetSize(sizew , sizeh)
	ItemsPnl:SetPos(0 , 0 )
	ItemsPnl.Paint = function(self, w , h)
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,255))end 
		if ItemsPnl:IsHovered() then
			--print('ItemsPnl hovered!')
		end
	end
	ItemsPnl.OnCursorEntered = function(self, keycode)
		--print('cursore! 1')			
	end

	local DScroll

	local function CreateItemsPanel (parent, tbl , cell, callback1)

		DScroll = vgui.Create( "DScrollPanel", parent )
		DScroll.OnCursorEntered = function(self, keycode)
		end

		DScroll:Dock( FILL )

		local sbar = DScroll:GetVBar()

		function DScroll.VBar:PerformLayout()
			local Wide = self:GetWide()
			local BtnHeight = Wide
			if ( self:GetHideButtons() ) then BtnHeight = 0 end
			local Scroll = self:GetScroll() / self.CanvasSize
			local BarSize = math.max( self:BarScale() * ( self:GetTall() - ( 5 ) ), 0 )
			local Track = self:GetTall() - ( BtnHeight ) - BarSize
			Track = Track + 1

			Scroll = Scroll * Track

			self.btnGrip:SetPos( 0, Scroll )
			self.btnGrip:SetSize( Wide, BarSize+BtnHeight )

			if ( BtnHeight > 0 ) then
				self.btnUp:SetVisible( false )
				self.btnDown:SetVisible( false )
			else
				self.btnUp:SetVisible( false )
				self.btnDown:SetVisible( false )
				self.btnDown:SetSize( Wide, BtnHeight )
				self.btnUp:SetSize( Wide, BtnHeight )
			end
		end

		function sbar:Paint( w, h )	end

		function sbar.btnGrip:Paint( w, h )
			draw.RoundedBox( 5, 0, 0, w-5, h, Color( 200,71,106 ) )
		end	
		local item_id_bool = false
		local item_number = {}
		local pos = 0
		local size = 0	

		for k , v in ipairs(tbl) do
			-- PrintTable(v)
			if v.item_id != nil then
				size = 159
			else
				size = 131
			end
			local Item = DScroll:Add( "AdvDailyLogin_ItemPnl" )
			Item:SetPanelID(k, cell, tbl)
			Item:SetData(v)
			Item:SetSize(200,size)
			Item:SetPos(0,pos)

			pos = pos + Item:GetTall() + 5
		end

		function DScroll:RefreshItemsPanel(_type)
			--print('RefreshItemsPanel')
			if _type == 'create' then

				local newpos1 = 0
				-- self:Clear()
				for k , v in ipairs(tbl) do

					if v.item_id != nil then
						size = 159
					else
						size = 131
					end

					local Item = DScroll:Add( "AdvDailyLogin_ItemPnl" )
					Item:SetPanelID(k, cell, tbl)
					Item:SetData(v)
					Item:SetSize(200,size)
					Item:SetPos(0,newpos1)
					newpos1 = newpos1 + Item:GetTall() + 5

					if k == #tbl then
						Item:SetAlpha(0)
						adv_daily_login:FadeFunc('show', Item, 255, 0.3, 0)
					end
				end
			elseif _type == 'remove' then
				local newpos2 = 0
				self:Clear()
				for k , v in ipairs(tbl) do

					if v.item_id != nil then
						size = 159
					else
						size = 131
					end
										
					local Item = self:Add( "AdvDailyLogin_ItemPnl" )
					Item:SetPanelID(k, cell, tbl)
					Item:SetData(v)
					Item:SetSize(200,size)
					Item:SetPos(0,newpos2)
					newpos2 = newpos2 + Item:GetTall() + 5
				end				
			end
		end

		if callback1 then
			callback1(DScroll)
		end

	end

	CreateItemsPanel(ItemsPnl, _items, item_cell, function(callback1)
		if callback1 then
			--print('callback1')
			callback(callback1)
		end
	end)

	if isstring(SetHint) then
		local toptextpanel = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
		toptextpanel:SetPos(10, 0)
		toptextpanel:SetSize (adv_daily_login.advpnltbl[count]:GetWide() - 20, hinth)
		adv_daily_login.advpnltbl[count]:SetSize( sizew, sizeh )
		ItemsPnl:SetSize(sizew - 5 + 3, sizeh - 20)
		ItemsPnl:SetPos(7 , toptextpanel:GetTall() )
		adv_daily_login.advpnltbl[count]:SetPos( posx , posy )

		toptextpanel.OnMousePressed = function(self, key)
			if popup then
				popup:MakePopup()
			end	
		end

		function toptextpanel:Paint( w, h )
			if debug then draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100)) end
			surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
			local tw , th = surface.GetTextSize( SetHint )
	
			surface.SetTextColor( HintColor )
			surface.SetTextPos(0 , toptextpanel:GetTall() / 2 - th / 2 )
			surface.DrawText( SetHint )
		end
	end
end

function adv_daily_login:CreateDaysList		(parent, lang, sizew, sizeh, posx, posy, SetHint, HintColor, hinth, popup, _items, item_cell, callback)
	local count = #adv_daily_login.advpnltbl + 1
	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetSize(sizew, sizeh)
	adv_daily_login.advpnltbl[count]:SetPos(posx, posy)
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100)) end
	end
	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end
	end

	local ItemsPnl = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
	ItemsPnl:SetSize(sizew , sizeh)
	ItemsPnl:SetPos(0 , 0 )
	ItemsPnl.Paint = function(self, w , h)
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,255))end 
		if ItemsPnl:IsHovered() then end
	end
	ItemsPnl.OnCursorEntered = function(self, keycode)
	end

	local function CreateItemsPanel (parent, tbl , cell)

		local DScroll = vgui.Create( "DScrollPanel", parent )
		DScroll.OnCursorEntered = function(self, keycode)
		end

		DScroll:Dock( FILL )

		local sbar = DScroll:GetVBar()
		sbar.scroll = false
		function DScroll.VBar:PerformLayout()
			local Wide = self:GetWide()
			local BtnHeight = Wide
			if ( self:GetHideButtons() ) then BtnHeight = 0 end
			local Scroll = self:GetScroll() / self.CanvasSize
			local BarSize = math.max( self:BarScale() * ( self:GetTall() - ( 5 ) ), 0 )
			local Track = self:GetTall() - ( BtnHeight ) - BarSize
			Track = Track + 1

			

			Scroll = Scroll * Track
			--self.scroll = self:GetWide()
			--print(self.scroll)

			self.btnGrip:SetPos( 0, Scroll )
			self.btnGrip:SetSize( Wide, BarSize+BtnHeight )

			if ( BtnHeight > 0 ) then
				self.scroll = true
				self.btnUp:SetVisible( false )
				self.btnDown:SetVisible( false )
			else
				self.scroll = false
				self.btnUp:SetVisible( false )
				self.btnDown:SetVisible( false )
				self.btnDown:SetSize( Wide, BtnHeight )
				self.btnUp:SetSize( Wide, BtnHeight )
			end
		end

		function sbar:Paint( w, h )	end

		function sbar.btnGrip:Paint( w, h )
			draw.RoundedBox( 5, 0, 0, w - 5, h, Color( 45,71,106 ) )
		end	
		local item_id_bool = false
		local item_number = {}
		local pos = 0
		local size = 26
		local wide = 17
		--local barsize = ( math.max( DScroll.VBar:BarScale() * ( DScroll.VBar:GetTall() - ( 5 ) ), 0 ) + DScroll.VBar:GetWide() )

		-- print( sbar:GetScroll() )

		local hasvalues = {}

		if tbl ~= nil then
			local Item, AddNewDay

			for k , v in ipairs(tbl) do
				
				--table.insert(hasvalues,k)
				local dayid = (v.dayid)
				hasvalues[dayid] = true

				--PrintTable(v)
				Item = DScroll:Add( "AdvDailyLogin_SetupItemsItem" )
				Item:SetPanelID(k, cell, tbl)
				Item:SetData(v)
				Item:SetSize(parent:GetWide() - wide,size)
				Item:SetPos(0,pos)
				Item:SetupLang(lang)
				Item:CreateStuff()
				pos = pos + Item:GetTall() + 2
			end
			
			if #tbl < 21 then
				print(lang)
				AddNewDay = DScroll:Add( "AdvDailyLogin_Button" )	
				AddNewDay:SetText( adv_daily_login.lang[lang].addnewday )
				AddNewDay:SetPos( 0, pos )
				AddNewDay:SetSize( parent:GetWide() - wide, size )
				AddNewDay:SizeToContent(AddNewDay:GetWide(), size)
				AddNewDay.DoClick = function()

					local nextvalue = 0

					for i = 1 , 21 do
						if hasvalues[i] == nil then
							--print(i)
							nextvalue = i
							break 
						end
					end

					local editdata = {item_gui = '', items = {} }
					net.Start('adv_daily_login_edititem')
						net.WriteInt(nextvalue,8)
						net.WriteTable(editdata)
					net.SendToServer()
				end				
			end
		end

		
		function DScroll:RefreshItemsPanel(_type, items_tbl, callfrom)
			sbar:SetScroll( 0 )
			local wide = 17
			hasvalues = {}
			local tbl = items_tbl

			if _type == 'create' then

				local newpos1 = 0
				self:Clear()
				
				for k , v in ipairs(tbl) do

					hasvalues[v.dayid] = true

					local Item = self:Add( "AdvDailyLogin_SetupItemsItem" )
					Item:SetPanelID(k, cell, tbl)
					Item:SetData(v)
					Item:SetSize(parent:GetWide() - wide,size)
					Item:SetPos(0,newpos1)
					Item:SetupLang(lang)
					Item:CreateStuff()
					newpos1 = newpos1 + Item:GetTall() + 5

					if k == #tbl then
						Item:SetAlpha(0)
						adv_daily_login:FadeFunc('show', Item, 255, 0.3, 0)
					end
				end
				if #tbl < 21 then
					
					AddNewDay = DScroll:Add( "AdvDailyLogin_Button" )	
					AddNewDay:SetText( adv_daily_login.lang[lang].addnewday )
					AddNewDay:SetPos( 0, newpos1 )
					AddNewDay:SetSize( parent:GetWide() - wide, size )
					AddNewDay:SizeToContent(AddNewDay:GetWide(), size)
					AddNewDay.DoClick = function()

						local nextvalue = 0
						for i = 1 , 21 do
							if hasvalues[i] == nil then
								nextvalue = i
								break 
							end
						end
						if nextvalue == 0 then return end

						local editdata = {item_gui = '', items = {} }
						net.Start('adv_daily_login_edititem')
							net.WriteInt(nextvalue,8)
							net.WriteTable(editdata)
						net.SendToServer()
					end
				end

			elseif _type == 'remove' then

				local newpos2 = 0
				self:Clear()
				for k , v in ipairs(tbl) do

					hasvalues[v.dayid] = true

					local Item = self:Add( "AdvDailyLogin_SetupItemsItem" )
					Item:SetPanelID(k, cell, tbl)
					Item:SetData(v)
					Item:SetSize(parent:GetWide() - wide,size)
					Item:SetPos(0,newpos2)
					Item:SetupLang(lang)
					Item:CreateStuff()
					newpos2 = newpos2 + Item:GetTall() + 2
				end
				if #tbl < 21 then
					
					AddNewDay = DScroll:Add( "AdvDailyLogin_Button" )	
					AddNewDay:SetText( adv_daily_login.lang[lang].addnewday )
					AddNewDay:SetPos( 0, newpos2 )
					AddNewDay:SetSize( parent:GetWide() - wide, size )
					AddNewDay:SizeToContent(AddNewDay:GetWide(), size)
					AddNewDay.DoClick = function()

						local maxsequense = #hasvalues
						local nextvalue = 0
						if (maxsequense + 1) <= 21 then
							nextvalue = maxsequense + 1
						else
							nextvalue = 0
						end

						if nextvalue == 0 then return end
						
						local editdata = {item_gui = '', items = {} }

						net.Start('adv_daily_login_edititem')
							net.WriteInt(nextvalue,8)
							net.WriteTable(editdata)
						net.SendToServer()
		
					end					
				end

			end

		end

		if callback then
			callback = callback(DScroll)
		end		
	end
	
	CreateItemsPanel(ItemsPnl, _items, item_cell)

	if isstring(SetHint) then
		local toptextpanel = vgui.Create('DPanel', adv_daily_login.advpnltbl[count])
		toptextpanel:SetPos(10, 0)
		toptextpanel:SetSize (adv_daily_login.advpnltbl[count]:GetWide() - 20, hinth)
		adv_daily_login.advpnltbl[count]:SetSize( sizew, sizeh )
		ItemsPnl:SetSize(sizew - 5 + 3, sizeh - 20)
		ItemsPnl:SetPos(7 , toptextpanel:GetTall() )
		adv_daily_login.advpnltbl[count]:SetPos( posx , posy )

		toptextpanel.OnMousePressed = function(self, key)
			if popup then
				popup:MakePopup()
			end	
		end

		function toptextpanel:Paint( w, h )
			if debug then draw.RoundedBox(0,0,0,w,h,Color(0,255,0,100)) end
			surface.SetFont( "AdvDailyLogin_Editor_Options_font" )
			local tw , th = surface.GetTextSize( SetHint )
	
			surface.SetTextColor( HintColor )
			surface.SetTextPos(0 , toptextpanel:GetTall() / 2 - th / 2 )
			surface.DrawText( SetHint )
		end
	end
end

function adv_daily_login:CreateButton2		(parent, text, sizew, sizeh, posx, posy, leftspace, popup, click, callback, callback2)
	local count = #adv_daily_login.advpnltbl + 1

	adv_daily_login.advpnltbl[count] = vgui.Create('DPanel', parent)
	adv_daily_login.advpnltbl[count]:SetPos(0,posy)

	adv_daily_login.advpnltbl[count]:SetSize(sizew,sizeh)
	adv_daily_login.advpnltbl[count].Paint = function(self, w, h) 
		if debug then draw.RoundedBox(0,0,0,w,h,Color(255,0,0,100))  end
	end
	adv_daily_login.advpnltbl[count].OnMousePressed = function(self, key)
		if popup then
			popup:MakePopup()
		end	
	end

	if callback then
		callback(adv_daily_login.advpnltbl[count])
	end

	local mw , mh = adv_daily_login.advpnltbl[count]:GetWide() , adv_daily_login.advpnltbl[count]:GetTall()

	local btn = vgui.Create( "AdvDailyLogin_Button", adv_daily_login.advpnltbl[count] )
	btn:SetText( text )
	btn:SetPos(leftspace,0)
	btn:SetSize( adv_daily_login.advpnltbl[count]:GetWide() - 20, sizeh )
	btn:SizeToContent(btn:GetWide(), sizeh)
	
	if callback2 then
		callback2(btn)
	end

	btn:MakePop(ImageFrame)
	btn.DoClick = click
end

function adv_daily_login:CheckPermission(ply)
	if table.HasValue(adv_daily_login.settings.setting_access_group,ply:GetUserGroup()) or table.HasValue(adv_daily_login.settings.setting_access_steamid,ply:SteamID()) or ply:IsSuperAdmin() then -- 76561198147781703
		return false
	else
		return true
	end
end

function adv_daily_login:AddTextToChat(msg)
	chat.AddText(Color(52, 152, 219),'[ ',adv_daily_login.tag,' ] ',Color(46, 204, 113), msg)
	return
end

-- function adv_daily_login:TableAdd(tbl,index)
-- 	tbl[index] = true
-- end