-- UTIL

adv_daily_login = adv_daily_login or {}
adv_daily_login.lang = adv_daily_login.lang or {}

function adv_daily_login:RegisterLanguage( id , lng )
    for k,v in ipairs(adv_daily_login.lang) do
        if v.Name == lng.Name or v.ID == lng.ID then
            adv_daily_login.lang[k] = lng
            return
        end
    end
    table.insert(adv_daily_login.lang, lng)
end