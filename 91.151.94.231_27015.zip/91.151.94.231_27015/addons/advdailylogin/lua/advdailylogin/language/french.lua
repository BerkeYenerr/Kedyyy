local LANG = {}

LANG.ID 					= 3
LANG.Name					= "French"
			
LANG.head_text				= "Connexion quotidienne avancée"
LANG.get_text				= "Vous avez"
LANG.btn_get				= "Obtenir récompense"
LANG.NextUseText			= "Prochaine utilisation après"
LANG.AlreadyGet				= "Vous pouvez avoir l'item"
LANG.ItemInfo				= "Détails récompense"
LANG.DayName				= "Jour"

--[[-------------------------------------------------------------------------
Settings frame
---------------------------------------------------------------------------]]
LANG.settings				= "Paramétres"
LANG.linktobg				= "Lien vers l'image"
	
LANG.setup_date				= "Début connexion quotidienne"
LANG.setup_date_hint 		= "Paramétrer la date de début et de fin automatiques"
LANG.setup_date_error		= "Désactiver le reset une fois terminé"
LANG.setup_date_success		= "La date est paramétrée automatiquement"
	
LANG.reset_data_hint		= "Reset toutes les données des joueurs"
LANG.reset_data				= "Reset les données"
LANG.reset_data_success 	= "Les données des joueurs ont été reset"
	
LANG.btn_plstats			= "Statistiques joueur"
LANG.btn_plstats_hint		= "Statistiques des joueurs"
	
LANG.lang_hint				= "Changer la langue"
	
LANG.save_data 				= "Sauvegarder"
LANG.save_msg				= "Paramétres sauvegardés"

LANG.mysql_err 				= "Une erreur s'est produite lors de l'exécution de la requête:"
LANG.mysql_btn 				= "Migrer la base de données"
LANG.mysql_btn_hint 		= "Migrer la base de données locale vers la base de données MySQL"
LANG.mysql_migrate_status 	= "Migrer le statut"
LANG.mysql_migrate_start 	= "Démarrer la migration"
LANG.mysql_connect 			= "Connecté à la base de données!"
LANG.mysql_fail 			= "Échec de la connexion à la base de données!"
LANG.mysql_check 			= "Vérification de la table de base de données"
LANG.mysql_tbl 				= "Table créée!"
--[[-------------------------------------------------------------------------
Item editor frame
---------------------------------------------------------------------------]]
LANG.right_click_edit		= 'Editer Item'
LANG.right_click_remove     = 'Remove cell'
LANG.right_click_create     = 'Create cell'

LANG.cur_edit_item          = "Id de l'item actuellement edité: "
                             
LANG.linktoimg              = "Lien vers l'image de l'item"
LANG.enterlink              = "Entrer le chemin de l'image"
                             
LANG.add_item               = "▼ Ajouter item ▼"
LANG.item_type_text1        = "Id de l'item"
LANG.item_type_text2        = "Nombre item"
LANG.item_hitn1             = "Entrer le nom et l'id depuis PS"
LANG.item_hitn2             = "Entrer le nombre d'item"
                             
LANG.item_name_hint         = "Entrer le nom de l'item"
LANG.item_disp_name         = "Nom de l'item affiché"
                             
LANG.item_col               = "Couleur de l'item"
LANG.reward_list            = "Liste récompenses"
                             
LANG.item_name              = "Nom de l'item"
LANG.item_type              = "Type de l'item"
LANG.item_count				= "Nombre de l'items"

LANG.btn_add_item           = "Ajouter cet item"
LANG.btn_add_item_msg       = "Item ajouté!"
LANG.btn_upd_item           = "Mettre à jour l'item"
LANG.btn_upd_item_msg       = "Item mis à jour!"

--[[-------------------------------------------------------------------------
Aler frame
---------------------------------------------------------------------------]]
LANG.Alert_message          = 'Êtes-vous sûr ?  '
LANG.Alert_confirm          = 'Oui'
LANG.Alerd_deny             = 'Annuler'

--[[-------------------------------------------------------------------------
Edit items frame
---------------------------------------------------------------------------]]
LANG.celleditor             = 'Éditeur de cellule'
LANG.addnewday              = 'Ajouter un nouveau jour'
LANG.alert_remove_msg       = 'Va supprimer'

--[[-------------------------------------------------------------------------
Data editor frame
---------------------------------------------------------------------------]]
LANG.setdailystay_for		= "Régler le séjour quotidien pour"
LANG.setdailystay_to		= "Régler le séjour quotidien à..."
LANG.edit_daily				= "Editer le séjour quotidien"
LANG.reset_data_ply			= "Reset la les données"
LANG.reset_cooldown			= "Reset le temps d'attente"
LANG.open_profile			= "Ouvrir le profil steam"
	
LANG.column_ply_name			= "Nom du joueur"
LANG.column_cur_daily			= "Séjour quotidien actuel"
LANG.column_next_date			= "Prochaine date"
LANG.column_cur_cooldown		= "Temps d'attente actuel"

adv_daily_login:RegisterLanguage( LANG.ID , LANG )