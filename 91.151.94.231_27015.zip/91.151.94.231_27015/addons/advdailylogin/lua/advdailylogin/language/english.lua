local LANG = {}

LANG.ID 					= 1
LANG.Name 					= 'English'

LANG.head_text				= "Günlük Ödül"
LANG.get_text				= "You get"
LANG.btn_get 				= "Ödülü Al!"
LANG.NextUseText 			= "Sonraki Hediyen"
LANG.AlreadyGet 			= "You can get the item!"
LANG.ItemInfo				= "Ödül Hakkinda"
LANG.DayName				= "Gün"

--[[-------------------------------------------------------------------------
Settings frame
---------------------------------------------------------------------------]]
LANG.settings 				= "Settings"
LANG.linktobg 				= "Link to background"

LANG.setup_date 			= 'Start Daily Login'
LANG.setup_date_hint 		= 'Setup start and end date automate'
LANG.setup_date_error 		= 'Need disable reset when complete'
LANG.setup_date_success 	= 'Date is set automatically'

LANG.reset_data_hint		= 'Reset all players data'
LANG.reset_data 			= 'Reset data'
LANG.reset_data_success		= 'Players data reseted!'

LANG.btn_plstats			= 'Player stats'
LANG.btn_plstats_hint 		= 'All player statistics'

LANG.lang_hint 				= 'Change language'

LANG.save_data 				= 'Save'
LANG.save_msg 				= 'Settings saved!'

LANG.mysql_err 				= 'An error occured while executing the query:'
LANG.mysql_btn 				= 'Migrate DB'
LANG.mysql_btn_hint 		= 'Migrate local DB to MySQL DB'
LANG.mysql_migrate_status 	= 'Migrate status'
LANG.mysql_migrate_start 	= 'Migrate start'
LANG.mysql_connect 			= 'Connected to DB!'
LANG.mysql_fail 			= 'Failed connect to DB!'
LANG.mysql_check 			= 'Check DB table'
LANG.mysql_tbl 				= 'Table created!'
--[[-------------------------------------------------------------------------
Item editor frame
---------------------------------------------------------------------------]]
LANG.right_click_edit		= 'Edit cell'
LANG.right_click_remove     = 'Remove cell'
LANG.right_click_create     = 'Create cell'

LANG.cur_edit_item 			= 'Current editing item id: '

LANG.linktoimg 				= "Link to item image"
LANG.enterlink 				= 'Enter path to image'

LANG.add_item 				= '▼ Add Item ▼'
LANG.item_type_text1		= 'Item id'
LANG.item_type_text2		= 'Item count'
LANG.item_hitn1 			= 'Enter item name/item id from PS'
LANG.item_hitn2 			= 'Enter item count'

LANG.item_name_hint 		= 'Enter item name'
LANG.item_disp_name 		= 'Displayed item name'

LANG.item_col 				= 'Item color'
LANG.reward_list 			= 'Reward list'

LANG.item_name 				= 'Item name'
LANG.item_type 				= 'Item type'
LANG.item_count				= 'Item count'

LANG.btn_add_item 			= 'Add this item'
LANG.btn_add_item_msg		= 'Item Added!'
LANG.btn_upd_item 			= 'Update item'
LANG.btn_upd_item_msg		= 'Item updated!'

--[[-------------------------------------------------------------------------
Aler frame
---------------------------------------------------------------------------]]
LANG.Alert_message          = 'Are you sure ?'
LANG.Alert_confirm          = 'Yes'
LANG.Alerd_deny             = 'Cancel'

--[[-------------------------------------------------------------------------
Edit items frame
---------------------------------------------------------------------------]]
LANG.celleditor             = 'Cell editor'
LANG.addnewday              = 'Add new day'
LANG.alert_remove_msg       = 'Will remove'

--[[-------------------------------------------------------------------------
Data editor frame
---------------------------------------------------------------------------]]
LANG.setdailystay_for 		= 'Set DailyStay for'
LANG.setdailystay_to 		= 'Set DailyStay to...'
LANG.edit_daily 			= "Edit dailystay"
LANG.reset_data_ply 		= "Reset data"
LANG.reset_cooldown 		= "Reset cooldown"
LANG.open_profile			= "Open Steam Profile"

LANG.column_ply_name 		= "Player name"
LANG.column_cur_daily		= "Cur dailystay"
LANG.column_next_date 		= "Next date"
LANG.column_cur_cooldown	= "Current cooldown"

adv_daily_login:RegisterLanguage( LANG.ID , LANG )