local LANG = {}

LANG.ID  					= 2
LANG.Name 					= 'Russian'

LANG.head_text				= "Advanced Daily Login"
LANG.get_text				= "Вы получите"
LANG.btn_get 				= "Получить награду"
LANG.NextUseText 			= "Следующее использование через"
LANG.AlreadyGet 			= "Вы можете получить итем!"
LANG.ItemInfo				= "Информация"
LANG.DayName				= "День"

--[[-------------------------------------------------------------------------
Settings frame
---------------------------------------------------------------------------]]
LANG.settings 				= "Настройки"
LANG.linktobg 				= "Ссылка на изображение"

LANG.setup_date 			= 'Запустить Daily Login'
LANG.setup_date_hint 		= 'Авто старт и конец даты'
LANG.setup_date_error 		= "Нужно выключить 'сброс при завершении'"
LANG.setup_date_success 	= 'Дата установленна автоматически'

LANG.reset_data_hint		= 'Сброс всей даты игроков'
LANG.reset_data 			= 'Сброс даты'
LANG.reset_data_success		= 'Дата игроков сброшена!'

LANG.btn_plstats			= 'Статистика игроков'
LANG.btn_plstats_hint 		= 'Вся статистика игроков'

LANG.lang_hint 				= 'Изменить язык'

LANG.save_data 				= 'Сохранить'
LANG.save_msg 				= 'Настройки сохранены!'

LANG.mysql_err 				= 'Произошла ошибка при выполнении запроса:'
LANG.mysql_btn 				= 'Перенос Базы'
LANG.mysql_btn_hint 		= 'Перенос локальной базы в MySQL базу'
LANG.mysql_migrate_status 	= 'Перенес базы - статус'
LANG.mysql_migrate_start 	= 'Перенес базы - начало'
LANG.mysql_connect 			= 'Подключение к базе!'
LANG.mysql_fail 			= 'Невозможно подключится к базе!'
LANG.mysql_check 			= 'Проверка таблицы'
LANG.mysql_tbl 				= 'Таблица создана!'
--[[-------------------------------------------------------------------------
Item editor frame
---------------------------------------------------------------------------]]
LANG.right_click_edit		= 'Изменить ячейку'
LANG.right_click_remove     = 'Удалить ячейку'
LANG.right_click_create     = 'Создать ячейку'

LANG.cur_edit_item 			= 'Текущий изменяемый id: '

LANG.linktoimg 				= "Путь на изображение предмета"
LANG.enterlink 				= 'Введите путь к изображению'

LANG.add_item 				= '▼ Добавить предмет ▼'
LANG.item_type_text1		= 'Id предмета в поинтшопе'
LANG.item_type_text2		= 'Колличество элементов'
LANG.item_hitn1 			= 'Введите название предмета/Id предмета из поинтшопа'
LANG.item_hitn2 			= 'Введите количество элементов'

LANG.item_name_hint 		= 'Введите название предмета'
LANG.item_disp_name 		= 'Название'

LANG.item_col 				= 'Цвет предмета'
LANG.reward_list 			= 'Список вознаграждений'

LANG.item_name 				= 'Название'
LANG.item_type 				= 'Тип предмета'
LANG.item_count				= 'Кол-во предметов'

LANG.btn_add_item 			= 'Добавить этот предмет'
LANG.btn_add_item_msg		= 'Предмет добавлен!'
LANG.btn_upd_item 			= 'Обновить предмет'
LANG.btn_upd_item_msg		= 'Предмет обновлён!'

--[[-------------------------------------------------------------------------
Aler frame
---------------------------------------------------------------------------]]
LANG.Alert_message          = 'Вы уверены ?'
LANG.Alert_confirm          = 'Да'
LANG.Alerd_deny             = 'Отмена'

--[[-------------------------------------------------------------------------
Edit items frame
---------------------------------------------------------------------------]]
LANG.celleditor             = 'Редактор ячеек'
LANG.addnewday              = 'Добавить следующий день'
LANG.alert_remove_msg       = 'Будет удалён'

--[[-------------------------------------------------------------------------
Data editor frame
---------------------------------------------------------------------------]]
LANG.setdailystay_for		= 'Установить DailyStay для'
LANG.setdailystay_to 		= 'Установить DailyStay на...'
LANG.edit_daily 			= "Изменить DailyStay"
LANG.reset_data_ply 		= "Сброс даты"
LANG.reset_cooldown 		= "Сброс таймера"
LANG.open_profile			= "Открыть Steam профиль"

LANG.column_ply_name 		= "Имя игрока"
LANG.column_cur_daily		= "Текущий DailyStay"
LANG.column_next_date 		= "Следующая дата"
LANG.column_cur_cooldown	= "Текущий таймер"

adv_daily_login:RegisterLanguage( LANG.ID , LANG )