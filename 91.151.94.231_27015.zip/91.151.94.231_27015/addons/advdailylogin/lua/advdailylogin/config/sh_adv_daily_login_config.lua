MsgC( Color( 255, 222, 102 ), "Config loaded!\n" )

// Licensed to 76561198147781703

adv_daily_login.settings = adv_daily_login.settings or {}
adv_daily_login.colors = adv_daily_login.colors or {}
adv_daily_login.sound = adv_daily_login.sound or {}
adv_daily_login.custom = adv_daily_login.custom or {}
adv_daily_login.cfg_lang = 1
--[[-------------------------------------------------------------------------
Global settings
---------------------------------------------------------------------------]]
adv_daily_login.settings.cooldown = 24*60*60 // in seconds
adv_daily_login.settings.datecooldown = 22 // days for auto setup date.

adv_daily_login.settings.use_models = true // use models or model image.
adv_daily_login.settings.open_when_connect = false

adv_daily_login.settings.open_command = '!czxzxczxccxzzx' // chat command
adv_daily_login.settings.open_key = KEY_F7 // Open Key Command
adv_daily_login.settings.open_cooldown = 5 // Cooldown before open adv_daily_login login

adv_daily_login.settings.dateformat = '%d/%m/%Y' // day , month , year
adv_daily_login.settings.showitemscount = true // show items count ?
adv_daily_login.settings.devmode = false // Recomended enable before setup items , and after disable it.
adv_daily_login.settings.showhoverbox = true // Show hover box ?

// Need reload server after change!
adv_daily_login.settings.db_type = 'file' // file - local storage , mysql - mysql bd

// reset after the user has fully completed daily login
// if true , auto date won't work.
adv_daily_login.settings.reset_when_complete = false

// if true , auto date - automatically resets all player progress when date is up
adv_daily_login.settings.reset_when_date_is_up = false

adv_daily_login.settings.setting_access_group = {
	'superadmin', -- user group
}
adv_daily_login.settings.setting_access_steamid = {
	'', -- steamid // example 'STEAM_0:0:0'
}
--[[-------------------------------------------------------------------------
Color settings
---------------------------------------------------------------------------]]
// Main frame
adv_daily_login.colors.main_box = Color(20, 19, 17 , 250 )
adv_daily_login.colors.main_box_border = Color(48, 45, 40 , 200)

--adv_daily_login.colors.main_box = Color(18, 26, 38  )
--adv_daily_login.colors.main_box_border = Color(53, 79, 115 )

adv_daily_login.colors.hover_box = Color(48, 45, 40, 220)
adv_daily_login.colors.hover_box_border = Color(20, 19, 17, 220)

adv_daily_login.colors.item_box = Color(20, 17, 19, 100 )
adv_daily_login.colors.item_box_border = Color(20, 17, 19)
adv_daily_login.colors.item_box_hover_border_from = Color(200, 218, 237)
adv_daily_login.colors.item_box_hover_border_center = Color(200,194,246)
adv_daily_login.colors.item_box_hover_border_to = Color(200, 169, 255)
adv_daily_login.colors.item_box_hover = Color(200, 26, 38,255)
adv_daily_login.colors.item_hover_border = Color(255, 0, 0)
adv_daily_login.colors.item_hover = Color(108, 26, 38, 255 )

adv_daily_login.colors.button = Color(33, 47, 69, 255 )
adv_daily_login.colors.button_border = Color(18, 26, 38, 255 )
adv_daily_login.colors.button_hover = Color(18, 26, 38, 255 )
adv_daily_login.colors.button_hover_border = Color(33, 47, 69, 255 )
adv_daily_login.colors.button_text = Color(255, 255, 255, 255 )

adv_daily_login.colors.cells_border = Color( 33, 47, 69 , 255 )
adv_daily_login.colors.cells_border_size = 1
adv_daily_login.colors.cells_text = Color( 255, 255, 255 , 127.5 )
adv_daily_login.colors.cells_bg = Color( 20, 19, 17, 255 )

adv_daily_login.colors.itemcount = Color( 0, 255, 255, 255 )

adv_daily_login.colors.timebox_color = Color(0, 0, 0 , 0)
adv_daily_login.colors.timebox_border = Color(0, 0, 5 , 30)

adv_daily_login.colors.timebox_date_color = Color(52, 152, 219)
adv_daily_login.colors.timebox_date_outlite = true

adv_daily_login.colors.timebox_text_color = Color(52, 152, 219)

// Player Stats
adv_daily_login.colors.stats_header_text_color = Color(255,255,255)
adv_daily_login.colors.stats_header_color = Color(255,255,255)

adv_daily_login.colors.stats_lines_hover_color = Color(52, 152, 219)
adv_daily_login.colors.stats_lines_select_color = Color(201, 128, 185)
adv_daily_login.colors.stats_lines_text_color = Color(255,255,255)

--[[-------------------------------------------------------------------------
Sound settings
---------------------------------------------------------------------------]]
adv_daily_login.sound.item_hover_sound 	= Sound("advdailylogin/hover.wav")
adv_daily_login.sound.item_received		= Sound("sound/advdailylogin/gotitem.mp3")
adv_daily_login.sound.button_click 		= Sound("advdailylogin/click.wav")

adv_daily_login.tag = 'AdvDailyLogin'