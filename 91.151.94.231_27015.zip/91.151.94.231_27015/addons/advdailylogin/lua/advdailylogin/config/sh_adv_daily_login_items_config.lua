MsgC( Color( 255, 222, 102 ), "Item config loaded!\n" )

// Licensed to 76561198147781703

adv_daily_login._items_table = {'helix_cash','helix_level','entity_autowander','bombastic','anan','buyukutusu2','buyulukutu'}
