MsgC( Color( 137, 222, 255 ), "Advanced Daily Login loadign\n".."{{script_version_id}}" )

local root = 'advdailylogin'

local function LoadFiles(var, ltype, file_ext)
	local Files, Folders = file.Find( 'advdailylogin/'..var..'/'..'*'..'.lua', "LUA" )
	for k , v in pairs(Files) do
		if ltype == 'sh' then
			MsgC( Color( 137, 222, 255 ), "Advanced Daily Login shared loading\n" )
			if SERVER then
				AddCSLuaFile(root..'/'..var..'/'..v)
				include(root..'/'..var..'/'..v)
			else
				include(root..'/'..var..'/'..v)
			end
		elseif ltype == 'cl' then
			MsgC( Color( 137, 222, 255 ), "Advanced Daily Login clientside loading\n" )
			if SERVER then
				AddCSLuaFile(root..'/'..var..'/'..v)
			else
				include(root..'/'..var..'/'..v)
			end
		elseif ltype == 'sv' then
			MsgC( Color( 137, 222, 255 ), "Advanced Daily Login serverside loading\n" )
			if SERVER then
				if file_ext then
					local str = string.match(v,file_ext)
					if str == file_ext then
						include(root..'/'..var..'/'..v)
						break
					end			
				else
					include(root..'/'..var..'/'..v)
				end
			end
		end
	end
end

LoadFiles('sh', 'sh')
LoadFiles('config', 'sh')
LoadFiles('language', 'sh')
LoadFiles('vgui', 'cl')
LoadFiles('cl', 'cl')
LoadFiles('sv', 'sv')
if adv_daily_login.settings.db_type then
LoadFiles('db', 'sv', adv_daily_login.settings.db_type)	
end


if (SERVER) then
	resource.AddFile( "materials/"..root.."/money.png" )
	resource.AddFile( "materials/"..root.."/calendar.png" )
	resource.AddFile( "materials/"..root.."/nothing.png" )
	resource.AddFile( "materials/"..root.."/settings.png" )
	resource.AddFile( "materials/"..root.."/points.png" )
	resource.AddFile( "materials/"..root.."/left.png" )
	resource.AddFile( "materials/"..root.."/received.png" )
	resource.AddFile( "materials/"..root.."/BorderCenter.png" )
	resource.AddFile( "materials/"..root.."/BorderDown.png" )
	resource.AddFile( "materials/"..root.."/BorderTop.png" )
	// To do upload to workshop new materials , and here replace names
	resource.AddFile( "materials/"..root.."/shadowbottom.png" )
	resource.AddFile( "materials/"..root.."/shadowleft.png" )
	resource.AddFile( "materials/"..root.."/shadowright.png" )
	resource.AddFile( "materials/"..root.."/shadowtop.png" )
	
	resource.AddFile( "materials/"..root.."/cornerlefttop.png" )
	resource.AddFile( "materials/"..root.."/cornerleftbottom.png" )
	resource.AddFile( "materials/"..root.."/cornerrightbottom.png" )
	resource.AddFile( "materials/"..root.."/cornerrighttop.png" )

	resource.AddFile( "sound/"..root.."/hover.wav" )
	resource.AddFile( "sound/"..root.."/gotitem.mp3" )
	resource.AddFile( "sound/"..root.."/click.wav" )
	
	resource.AddWorkshop('1631378658')
end