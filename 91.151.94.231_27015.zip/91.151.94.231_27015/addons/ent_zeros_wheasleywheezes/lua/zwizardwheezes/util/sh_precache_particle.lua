game.AddParticles( "particles/cc_bombtastic_vfx.pcf")
PrecacheParticleSystem( "ccbomb_main" )
PrecacheParticleSystem( "ccbomb_bomb_trail" )

game.AddParticles( "particles/cc_decoydetonator_vfx.pcf")
PrecacheParticleSystem( "cc_decoy_explosion" )
PrecacheParticleSystem( "cc_darknesspowder_explosion" )

game.AddParticles("particles/cc_custom_trails.pcf")
PrecacheParticleSystem("zww_trail_large01")
PrecacheParticleSystem("zww_trail_teacup")
PrecacheParticleSystem("zww_teacup_bite")


game.AddParticles("particles/zpc2_generic.pcf")
//PrecacheParticleSystem("zpc2_cake_burst")
PrecacheParticleSystem("zpc2_fuse")
PrecacheParticleSystem("zpc2_mortarburst_medium")
//PrecacheParticleSystem("zpc2_mortarburst_large")
PrecacheParticleSystem("zpc2_shelltrail")
PrecacheParticleSystem("zpc2_shelltrail_large")


game.AddParticles("particles/zpc2_nautical_explosions.pcf")
PrecacheParticleSystem("zpc2_nautical_pink")

game.AddParticles("particles/zpc2_flame.pcf")
PrecacheParticleSystem("zpc2_flame_special_redgreen")
PrecacheParticleSystem("zpc2_flame_special_yellowgreen")



game.AddParticles("particles/zpc2_cake_explosions.pcf")
PrecacheParticleSystem("zpc2_cake_explosion_blue")
PrecacheParticleSystem("zpc2_cake_explosion_cyan")
PrecacheParticleSystem("zpc2_cake_explosion_green")
PrecacheParticleSystem("zpc2_cake_explosion_orange")
PrecacheParticleSystem("zpc2_cake_explosion_pink")
PrecacheParticleSystem("zpc2_cake_explosion_red")
PrecacheParticleSystem("zpc2_cake_explosion_violett")
PrecacheParticleSystem("zpc2_cake_explosion_white")
PrecacheParticleSystem("zpc2_cake_explosion_yellow")




game.AddParticles("particles/zpc2_burst_green.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_green")
PrecacheParticleSystem("zpc2_burst_medium_green")
PrecacheParticleSystem("zpc2_burst_big_green")

game.AddParticles("particles/zpc2_burst_blue.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_blue")
PrecacheParticleSystem("zpc2_burst_medium_blue")
PrecacheParticleSystem("zpc2_burst_big_blue")

game.AddParticles("particles/zpc2_burst_orange.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_orange")
PrecacheParticleSystem("zpc2_burst_medium_orange")
PrecacheParticleSystem("zpc2_burst_big_orange")

game.AddParticles("particles/zpc2_burst_red.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_red")
PrecacheParticleSystem("zpc2_burst_medium_red")
PrecacheParticleSystem("zpc2_burst_big_red")

game.AddParticles("particles/zpc2_burst_violett.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_violett")
PrecacheParticleSystem("zpc2_burst_medium_violett")
PrecacheParticleSystem("zpc2_burst_big_violett")

game.AddParticles("particles/zpc2_burst_white.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_white")
PrecacheParticleSystem("zpc2_burst_medium_white")
PrecacheParticleSystem("zpc2_burst_big_white")

game.AddParticles("particles/zpc2_burst_pink.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_pink")
PrecacheParticleSystem("zpc2_burst_medium_pink")
PrecacheParticleSystem("zpc2_burst_big_pink")

game.AddParticles("particles/zpc2_burst_cyan.pcf")
PrecacheParticleSystem("zpc2_burst_tiny_cyan")
PrecacheParticleSystem("zpc2_burst_medium_cyan")
PrecacheParticleSystem("zpc2_burst_big_cyan")




game.AddParticles("particles/zpc2_dorn_shots.pcf")
PrecacheParticleSystem("zpc2_dorn_red")

game.AddParticles("particles/zpc2_harinezumi_explosions.pcf")
PrecacheParticleSystem("zpc2_harinezumi_blue")
PrecacheParticleSystem("zpc2_harinezumi_cyan")
PrecacheParticleSystem("zpc2_harinezumi_green")
PrecacheParticleSystem("zpc2_harinezumi_orange")
PrecacheParticleSystem("zpc2_harinezumi_pink")
PrecacheParticleSystem("zpc2_harinezumi_red")
PrecacheParticleSystem("zpc2_harinezumi_violett")
PrecacheParticleSystem("zpc2_harinezumi_yellow")

game.AddParticles("particles/zpc2_shroom_explosions.pcf")
PrecacheParticleSystem("zpc2_shroom_blue")
PrecacheParticleSystem("zpc2_shroom_cyan")
PrecacheParticleSystem("zpc2_shroom_green")
PrecacheParticleSystem("zpc2_shroom_orange")
PrecacheParticleSystem("zpc2_shroom_red")
PrecacheParticleSystem("zpc2_shroom_violett")
PrecacheParticleSystem("zpc2_shroom_yellow")

game.AddParticles("particles/zpc2_nagano_explosions.pcf")
PrecacheParticleSystem("zpc2_nagano_blue")
PrecacheParticleSystem("zpc2_nagano_cyan")
PrecacheParticleSystem("zpc2_nagano_green")
PrecacheParticleSystem("zpc2_nagano_orange")
PrecacheParticleSystem("zpc2_nagano_pink")
PrecacheParticleSystem("zpc2_nagano_red")
PrecacheParticleSystem("zpc2_nagano_violett")
PrecacheParticleSystem("zpc2_nagano_white")
PrecacheParticleSystem("zpc2_nagano_yellow")

game.AddParticles("particles/zpc2_board_letters.pcf")
PrecacheParticleSystem("zpc2_board_letter_w")
PrecacheParticleSystem("zpc2_board_letter_e")
PrecacheParticleSystem("zpc2_board_letter_a")
PrecacheParticleSystem("zpc2_board_letter_s")
PrecacheParticleSystem("zpc2_board_letter_l")
PrecacheParticleSystem("zpc2_board_letter_e")
PrecacheParticleSystem("zpc2_board_letter_y")

game.AddParticles("particles/zpc2_special_explosions.pcf")
PrecacheParticleSystem("zpc2_explo_salute")
PrecacheParticleSystem("zpc2_explo_sparklers")

game.AddParticles("particles/zpc2_twinklefan_explosions.pcf")
PrecacheParticleSystem("zpc2_explo_twinklefan_blue")
PrecacheParticleSystem("zpc2_explo_twinklefan_green")
PrecacheParticleSystem("zpc2_explo_twinklefan_orange")
PrecacheParticleSystem("zpc2_explo_twinklefan_red")
PrecacheParticleSystem("zpc2_explo_twinklefan_violett")


game.AddParticles("particles/zpc2_yonshakudama_explosions.pcf")
PrecacheParticleSystem("zpc2_Yonshakudama_mix")

game.AddParticles("particles/zpc2_spark_explosions.pcf")
PrecacheParticleSystem("zpc2_explospark_blue")
PrecacheParticleSystem("zpc2_explospark_green")
PrecacheParticleSystem("zpc2_explospark_orange")
PrecacheParticleSystem("zpc2_explospark_red")
PrecacheParticleSystem("zpc2_explospark_violett")
PrecacheParticleSystem("zpc2_explospark_white")


/*
game.AddParticles("particles/zpc2_confetty.pcf")
PrecacheParticleSystem("zpc2_confetty")

game.AddParticles("particles/zpc2_cake_shots.pcf")
game.AddParticles("particles/zpc2_basic_explosions.pcf")



game.AddParticles("particles/zpc2_demon_explosions.pcf")
game.AddParticles("particles/zpc2_sparkstar_explosions.pcf")
game.AddParticles("particles/zpc2_colorshift_explosions.pcf")
game.AddParticles("particles/zpc2_star_explosions.pcf")
game.AddParticles("particles/zpc2_planet_explosions.pcf")
game.AddParticles("particles/zpc2_octo_explosions.pcf")


game.AddParticles("particles/zpc2_flower.pcf")
game.AddParticles("particles/zpc2_form_explosions.pcf")
game.AddParticles("particles/zpc2_hw2018.pcf")
game.AddParticles("particles/zpc2_letter_explosions.pcf")
game.AddParticles("particles/zpc_combo01.pcf")
game.AddParticles("particles/zpc_combo02.pcf")
game.AddParticles("particles/zpc_combo03.pcf")
game.AddParticles("particles/zpc2_fountains.pcf")
game.AddParticles("particles/zpc2_longshot.pcf")
game.AddParticles("particles/zpc2_whistler.pcf")
game.AddParticles("particles/zpc2_sparktower.pcf")


game.AddParticles("particles/zpc2_oneshot_basic.pcf")
game.AddParticles("particles/zpc2_sparkcluster.pcf")
game.AddParticles("particles/zpc2_flares.pcf")
game.AddParticles("particles/zpc2_lum_flares.pcf")
game.AddParticles("particles/zpc2_cluster_strobe.pcf")
*/
