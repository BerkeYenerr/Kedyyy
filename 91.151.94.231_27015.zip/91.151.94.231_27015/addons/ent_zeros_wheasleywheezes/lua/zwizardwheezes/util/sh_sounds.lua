sound.Add({
	name = "zww_crackling",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = "zww/crackling.mp3"
})

sound.Add({
	name = "zww_shot_crackling_short",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = {
		"zww/cake_shot_crackling01_short.wav",
		"zww/cake_shot_crackling02_short.wav",
		"zww/cake_shot_crackling03_short.wav",
	}
})

sound.Add({
	name = "zww_rocket_woosh",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = "zww/rocket_woosh.wav"
})


sound.Add({
	name = "zww_firework_explosion01",
	channel = CHAN_STATIC,
	volume = 1,
	level = 80,
	pitch = {100, 100},
	sound = "zww/firework_explosion_1.wav"
})
sound.Add({
	name = "zww_firework_nagano",
	channel = CHAN_STATIC,
	volume = 1,
	level = 80,
	pitch = {100, 100},
	sound = "zww/nagano.wav"
})


sound.Add({
	name = "zww_explo",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = "zww/explo.wav"
})

sound.Add({
	name = "zww_explo_sparkstar",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = "zww/sparkstar.wav"
})

sound.Add({
	name = "zww_rocket_whistle",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = {"zww/cake_whisle01.wav","zww/cake_whisle04.wav"}
})



sound.Add({
	name = "zww_fuse",
	channel = CHAN_STATIC,
	volume = 1,
	level = 45,
	pitch = {100, 100},
	sound = "zww/fuse.wav"
})

sound.Add({
	name = "zww_kubi",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = "zww/kubi.mp3"
})



sound.Add({
	name = "zww_decoy_taunt",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {100, 100},
	sound = "zww/decoy_taunt.wav"
})

sound.Add({
	name = "zww_decoy_run01_loop",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {100, 100},
	sound = "zww/decoy_run01_loop.wav"
})

sound.Add({
	name = "zww_decoy_pre_explode",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {100, 100},
	sound = "zww/decoy_pre_explode.mp3"
})

sound.Add({
	name = "zww_decoy_explode",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = {100, 100},
	sound = {
		"zww/decoy_explode01.wav",
		"zww/decoy_explode02.wav",
		"zww/decoy_explode03.wav",
	}
})

sound.Add({
	name = "zww_decoy_taunt_single",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {95, 105},
	sound = "zww/decoy_taunt01.wav"
})


sound.Add({
	name = "zww_teacup_bite",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {100, 100},
	sound = "zww/teacup_bite.wav"
})

sound.Add({
	name = "zww_teacup_howl",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {95, 105},
	sound = "zww/teacup_howl.wav"
})


sound.Add({
	name = "zww_ouch_male",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {100, 100},
	sound = {"vo/npc/Barney/ba_pain01.wav", "vo/npc/Barney/ba_pain02.wav", "vo/npc/Barney/ba_pain03.wav", "vo/npc/Barney/ba_pain04.wav", "vo/npc/Barney/ba_pain05.wav", "vo/npc/Barney/ba_pain06.wav", "vo/npc/Barney/ba_pain07.wav", "vo/npc/Barney/ba_pain08.wav", "vo/npc/Barney/ba_pain09.wav", "vo/npc/Barney/ba_pain10.wav", "vo/npc/male01/ow01.wav", "vo/npc/male01/ow02.wav", "vo/npc/male01/pain01.wav", "vo/npc/male01/pain02.wav", "vo/npc/male01/pain03.wav", "vo/npc/male01/pain04.wav", "vo/npc/male01/pain05.wav", "vo/npc/male01/pain06.wav", "vo/npc/male01/pain07.wav", "vo/npc/male01/pain08.wav", "vo/npc/male01/pain09.wav"}
})

sound.Add({
	name = "zww_ouch_female",
	channel = CHAN_STATIC,
	volume = 1,
	level = 60,
	pitch = {100, 100},
	sound = {"vo/npc/female01/ow01.wav", "vo/npc/female01/ow02.wav", "vo/npc/female01/pain01.wav", "vo/npc/female01/pain02.wav", "vo/npc/female01/pain03.wav", "vo/npc/female01/pain04.wav", "vo/npc/female01/pain05.wav", "vo/npc/female01/pain06.wav", "vo/npc/female01/pain07.wav", "vo/npc/female01/pain08.wav", "vo/npc/female01/pain09.wav"}
})
