
zclib.NetEvent.AddDefinition("zww_use_base", {
    [1] = {
        type = "entity"
    },
    [2] = {
        type = "entity"
    },
}, function(received)
    local ent = received[1]
    local ply = received[2]

    if IsValid(ent) and ent.OnItemUse then
        ent:OnItemUse(ply)
    end
end)

zclib.NetEvent.AddDefinition("zww_box_base", {
    [1] = {
        type = "entity"
    },
    [2] = {
        type = "entity"
    },
}, function(received)
    local ent = received[1]
    local ply = received[2]

    if IsValid(ent) and ent.OnUnbox then
        ent:OnUnbox(ply)
    end
end)

zclib.NetEvent.AddDefinition("zww_darknesspowder_use", {
    [1] = {
        type = "entity"
    }
}, function(received)
    local ent = received[1]

    if IsValid(ent) and ent.UsePowder then
        ent:UsePowder()
    end
end)

zclib.NetEvent.AddDefinition("zww_firework_trigger", {
    [1] = {
        type = "entity"
    }
}, function(received)
    local ent = received[1]

    if IsValid(ent) and ent.TriggerFirework then
        ent:TriggerFirework()
    end
end)

zclib.NetEvent.AddDefinition("zww_teacup_bite", {
    [1] = {
        type = "entity"
    }
}, function(received)
    local ent = received[1]

    if IsValid(ent) then
        ent:EmitSound("zww_teacup_bite")
        zclib.Effect.ParticleEffect("zww_teacup_bite", ent:GetPos() + Vector(0,0,35), ent:GetAngles(), ent)
        if math.random(10) > 5 then
            ent:EmitSound("zww_ouch_male")
        else
            ent:EmitSound("zww_ouch_female")
        end
    end
end)
