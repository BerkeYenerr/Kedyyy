if SERVER then return end
zww = zww or {}
zww.CEnt = zww.CEnt or {}
zww.CEnt.List = zww.CEnt.List or {}

/*

    A system which creates and cleans up client props

*/

function zww.CEnt.Create(mdl)
    local ent = zclib.ClientModel.AddProp(mdl)
    ent.RemoveTime = CurTime() + 60
    table.insert(zww.CEnt.List, ent)
    local timerid = "zww_cent_cleanup_timer"

    //zclib.Timer.Remove(timerid)
    if timer.Exists(timerid) == false then
        zclib.Timer.Create(timerid, 10, 0, function()
            if zww.CEnt.List == nil then
                zclib.Timer.Remove(timerid)

                return
            end

            if table.Count(zww.CEnt.List) <= 0 then
                zclib.Timer.Remove(timerid)

                return
            end

            for k, v in pairs(zww.CEnt.List) do
                if IsValid(v) and CurTime() > v.RemoveTime then
                    zclib.ClientModel.Remove(v)
                    table.remove(zww.CEnt.List, k)
                end
            end
        end)
    end

    return ent
end
