zww = zww or {}

function zww.Print(msg)
	print("[Zeros Wizard Wheezes] " .. msg)
end
