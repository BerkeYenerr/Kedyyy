if SERVER then return end
zww = zww or {}
zww.NPC = zww.NPC or {}

///////////////////////////////////////////
///////////////////////////////////////////
local NPCVGUI = {}

local function OpenInterface()

    if IsValid(zww_NPC_panel) then
        zww_NPC_panel:Remove()
    end

    zww_NPC_panel = vgui.Create("zww_vgui_NPC")
end

net.Receive("zww_NPC_Open", function(len)

    LocalPlayer().zww_NPC = net.ReadEntity()

    // Open Main interface
    OpenInterface()
end)

function NPCVGUI:Init()
    self:SetSize(600 * zclib.wM, 800 * zclib.hM)
    self:Center()
    self:MakePopup()
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetDraggable(true)
    self:SetSizable(false)

    self:DockMargin(0,0,0,0)
    self:DockPadding(5,5,5,5)

    local TopContainer = vgui.Create("DPanel", self)
    TopContainer:SetAutoDelete(true)
    TopContainer:SetSize(self:GetWide(), 50 * zclib.hM)
    TopContainer.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w - 55 * zclib.wM, h, zherb.colors["yellow01"])
    end
    TopContainer:Dock(TOP)

    local close_btn = zclib.vgui.ImageButton(self:GetWide() - 49 * zclib.wM,0,50 * zclib.wM,50 * zclib.hM,TopContainer,zherb.materials["close"],function()
        self:Close()
    end,function()
        return false
    end)
    close_btn:Dock(RIGHT)
    close_btn.MainColor = zherb.colors["yellow01"]
    close_btn.IconColor = color_white
    close_btn.Paint = function(s, w, h)

		draw.RoundedBox(0, 0, 0, w, h, s.MainColor)

		surface.SetDrawColor(s.IconColor)
		surface.SetMaterial(zherb.materials["close"])
		surface.DrawTexturedRect(0, 0,w, h)

		if s:IsEnabled() == false then
			draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
		else
			if s:IsHovered() then
				draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
			end
		end
	end

    if not LocalPlayer().zww_NPC.PrintName then return end
    local TitleBox = vgui.Create("DLabel", TopContainer)
    TitleBox:SetAutoDelete(true)
    TitleBox:SetSize(200 * zclib.wM, 50 * zclib.hM)
    TitleBox:SetPos(0 * zclib.wM, 0 * zclib.hM)
    TitleBox:Dock(LEFT)
    TitleBox:SetText(LocalPlayer().zww_NPC.PrintName)
    TitleBox:SetTextColor(zherb.colors["white01"])
    TitleBox:SetFont(zclib.GetFont("zherb_vgui_font01"))
    TitleBox:SetContentAlignment(5)
    TitleBox:SizeToContentsX( 15 * zclib.wM )


    local MainScroll = vgui.Create( "DScrollPanel", self )
    MainScroll:Dock(FILL)
    MainScroll:DockMargin(2 * zclib.wM, 5 * zclib.wM, 2  * zclib.wM, 5 * zclib.wM)
    MainScroll.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    local sbar = MainScroll:GetVBar()
    sbar:SetHideButtons( true )
    function sbar:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"]) end
    function sbar.btnUp:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnDown:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnGrip:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    self.ItemList_Scroll = MainScroll

    local MainContainer = vgui.Create("DIconLayout", MainScroll)
    MainContainer:Dock(FILL)
    MainContainer:SetSpaceX(5)
    MainContainer:SetSpaceY(5)
    MainContainer.Paint = function(s, w, h)
        //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    MainScroll:InvalidateLayout(true)
    MainContainer:InvalidateParent(true)

    self.ItemList = {}
    local itemHeight = 100 * zclib.wM

    for k,v in pairs(LocalPlayer().zww_NPC.ShopItems) do
        if isnumber(k) == false then continue end

        if v.canbuy and v.canbuy(LocalPlayer()) ~= true and v.cansell == nil then continue end

        local item = MainContainer:Add("DPanel")
        item:SetSize(self:GetWide() - 40 * zclib.wM, itemHeight)
        item:SetText("")
        item.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["grey02"])
        end
        self.ItemList[k] = item

        local mdl = zclib.vgui.ModelPanel({model = v.model,skin = v.skin,color = v.color,render = {FOV = v.FOV or 25, Angles = v.Angles,Pos = v.Pos}})
        mdl:SetSize(itemHeight,itemHeight)
        mdl:SetParent(item)
        mdl.PreDrawModel = function(ent)
            cam.Start2D()
                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(zherb.materials["item_bg"])
                surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, itemHeight, itemHeight)
            cam.End2D()
        end
        mdl.PostDrawModel = function(ent) end

        if v.desc then
            local desc = vgui.Create("DLabel", item)
            desc:Dock(FILL)
            desc:DockMargin(itemHeight + 10 * zclib.wM, 30 * zclib.hM, 0 * zclib.wM, 0 * zclib.hM)
            desc:SetWrap(true)
            desc:SetContentAlignment(7)
            desc:SetText(v.desc)
            desc:SetFont(zclib.GetFont("zherb_vgui_font03"))
            desc.Paint = function(s, w, h)
                //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["grey02"])
            end
            item.desc = desc
        end

        local button = vgui.Create("DButton", item)
        button:SetText("")
        button:Dock(FILL)
        button:DockMargin(0, 0, 0, 0)
        button.text = "Buy"
        button.text_color = zherb.colors["green01"]
        if v.tur then
            button.money = v.price .. " " .. string.upper(v.tur)
        else
            button.money = zclib.Money.Display(v.price)
        end

        if v.cansell and v.cansell(LocalPlayer()) then
            local _,sell_value = v.cansell(LocalPlayer())
            button.text = "Sell"
            button.text_color = zherb.colors["orange01"]
            button.money = zclib.Money.Display(math.Round(v.price * sell_value))
        end

        if v.canbuy then
            local result,color,txt = v.canbuy(LocalPlayer())
            if result and color and txt then
                button.text = txt
                button.text_color = color
                button.money = ""
            end
        end

        button.Paint = function(s, w, h)
            draw.SimpleText(v.name, zclib.GetFont("zherb_vgui_font02"), itemHeight + 10 * zclib.wM, 5 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            //if v.desc then draw.SimpleText(v.desc, zclib.GetFont("zherb_vgui_font03"), itemHeight + 10 * zclib.wM, 32 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) end
            if s:IsHovered() then
                draw.SimpleText(s.text, zclib.GetFont("zherb_vgui_font01"), itemHeight + 10 * zclib.wM,  h - 50 * zclib.hM, s.text_color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                zclib.util.DrawOutlinedBox(0, 0, w, h, 2, s.text_color)
                draw.SimpleText(s.money, zclib.GetFont("zherb_vgui_font01"), w - 10 * zclib.wM, h - 50 * zclib.hM, s.text_color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                if IsValid(item.desc) then item.desc:SetVisible(false) end
            else
                zclib.util.DrawOutlinedBox(0, 0, w, h, 2, s.text_color)
                draw.SimpleText(s.money, zclib.GetFont("zherb_vgui_font02"), w - 10 * zclib.wM, h - 30 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
                if IsValid(item.desc) then item.desc:SetVisible(true) end
            end
        end
        button.DoClick = function(s)
            zclib.vgui.PlaySound("UI/buttonclick.wav")
            self:BuyItem(k)
        end
    end
end

function NPCVGUI:Paint(w, h)
    surface.SetDrawColor(zherb.colors["white01"])
    surface.SetMaterial(zherb.materials["background"])
    surface.DrawTexturedRect(0, 0,w * 1.3, h)
end

function NPCVGUI:BuyItem(id)
    net.Start("zww_NPC_BuyItem")
    net.WriteEntity(LocalPlayer().zww_NPC)
    net.WriteUInt(id,16)
    net.SendToServer()

    // Rebuild the interface
    timer.Simple(0.25, function()
        OpenInterface()
    end)
end

function NPCVGUI:Close()
    LocalPlayer().zww_NPC = nil
    if IsValid(zww_NPC_panel) then
        zww_NPC_panel:Remove()
    end
end

vgui.Register("zww_vgui_NPC", NPCVGUI, "DFrame")
