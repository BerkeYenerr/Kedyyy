if SERVER then return end
zww = zww or {}
zww.NPC = zww.NPC or {}

function zww.NPC.Initialize(NPC)
    NPC:DrawShadow(false)
end

function zww.NPC.Draw(NPC)
    cam.Start3D2D(NPC:GetPos() + Vector(0, 0, NPC.UI_Y), Angle(0, LocalPlayer():EyeAngles().y - 90, 90), 0.05)
        draw.RoundedBox(16, -200, -40, 400, 80, zherb.colors["black02"])
        draw.SimpleText(NPC.PrintName, zclib.GetFont("zherb_font03"), 0, 0, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end
