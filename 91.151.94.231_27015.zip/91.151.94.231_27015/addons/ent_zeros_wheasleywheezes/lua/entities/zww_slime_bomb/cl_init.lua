include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end


local SlimeLifeTime = 10
local use_sounds = {"ambient/levels/canals/toxic_slime_gurgle2.wav", "ambient/levels/canals/toxic_slime_gurgle3.wav", "ambient/levels/canals/toxic_slime_gurgle4.wav", "ambient/levels/canals/toxic_slime_gurgle5.wav", "ambient/levels/canals/toxic_slime_gurgle6.wav", "ambient/levels/canals/toxic_slime_gurgle7.wav", "ambient/levels/canals/toxic_slime_gurgle8.wav"}

local SlimeCache = {}

local function AddSlime(ply)
	if SlimeCache[ply:SteamID64()] == nil then
		SlimeCache[ply:SteamID64()] = {}
	end

	table.insert(SlimeCache[ply:SteamID64()], {
		time = CurTime() + SlimeLifeTime
	})
end

zclib.CacheModel("models/bettybean/bettybean.mdl")

local function CreateSlime(ply)
    local cs = zww.CEnt.Create()
    if IsValid(cs) then
        cs.slime_OwnerID = ply:SteamID()
        cs.slime_Owner = ply
        cs:SetModel("models/bettybean/bettybean.mdl")
        cs:SetNoDraw(true)
        cs:SetPredictable(false)
        cs:DrawShadow(false)
        cs:DestroyShadow()
        cs:SetMoveType(MOVETYPE_NONE)
        cs:Spawn()
        cs:SetMaterial("models/props_foliage/tree_deciduous_01a_trunk")
        cs:SetColor(Color(0,255,0))

        cs.rnd_scale = math.Rand(0.8,1.7)

        return cs
    end
end

local function DrawSlime(ply)

    if zclib.util.InDistance(LocalPlayer():GetPos(), ply:GetPos(), 500) == false then
        for k,v in pairs(SlimeCache[ply:SteamID64()]) do
            if IsValid(v.ent) then
                zclib.ClientModel.Remove(v.ent)
                v.ent = nil
            end
        end
        return
    end
    for k,v in pairs(SlimeCache[ply:SteamID64()]) do

        if CurTime() > v.time then
            if IsValid(v.ent) then
                zclib.ClientModel.Remove(v.ent)
                v.ent = nil
            end
            SlimeCache[ply:SteamID64()][k] = nil
        end

        if not IsValid(v.ent) then
            v.ent = CreateSlime(ply)
            local boneid = math.random(ply:GetBoneCount())
            v.boneid = boneid
            continue
        end

        local mat = ply:GetBoneMatrix(v.boneid)
        if not mat then continue end
        local pos, ang = mat:GetTranslation(), mat:GetAngles()

        local scale = (v.ent.rnd_scale / SlimeLifeTime) * (math.Clamp(v.time - CurTime(),0,SlimeLifeTime))
        v.ent:SetModelScale(scale)

        render.SetColorModulation(0, 1, 0, 1)
        render.Model({
            model = "models/bettybean/bettybean.mdl",
            pos = pos,
            angle = ang
        }, v.ent)
        render.SetColorModulation(1, 1, 1, 1)
    end
end

zclib.Hook.Add("PostPlayerDraw", "zww_slimesuprise_drawslime", function(ply)
    if IsValid(ply) and ply:Alive() and SlimeCache[ply:SteamID64()] then
        DrawSlime(ply)
    end
end)

gameevent.Listen("player_disconnect")
hook.Add("player_disconnect", "zww_player_disconnect_slimesuprise_slime", function(data)
    for k, v in pairs(ents.GetAll()) do
        if IsValid(v) and v.slime_OwnerID and v.slime_OwnerID == data.networkid then
            SafeRemoveEntity(v)
        end
    end
end)


net.Receive("zww_slimebomb_explo", function(len)
	local slimebomb = net.ReadEntity()

	if IsValid(slimebomb) then
		sound.Play(use_sounds[math.random(#use_sounds)], slimebomb:GetPos(), 65, 255)
		zclib.Effect.ParticleEffect("cc_decoy_explosion", slimebomb:GetPos() + Vector(0, 0, 60), slimebomb:GetAngles(), slimebomb)

		for k, v in pairs(ents.FindInSphere(slimebomb:GetPos(), slimebomb.Effect_Radius)) do
			if not IsValid(v) then continue end
			if v:IsPlayer() == false then continue end
			if v:Alive() == false then continue end

			for i = 1, math.random(25) do
				AddSlime(v)
			end
		end
	end
end)
