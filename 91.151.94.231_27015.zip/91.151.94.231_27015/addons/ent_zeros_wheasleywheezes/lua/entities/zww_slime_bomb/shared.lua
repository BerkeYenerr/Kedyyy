ENT.Type					= "anim"
ENT.Base					= "base_anim"
ENT.RenderGroup             = RENDERGROUP_BOTH
ENT.Spawnable		        =  false
ENT.AdminSpawnable		    =  false

ENT.PrintName		        = "Slime Bomb"
ENT.Author					= "ClemensProduction aka Zerochain"
ENT.Information				= "info"
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.Model                   = nil
ENT.AutomaticFrameAdvance   = true
ENT.DisableDuplicator		= false


ENT.Effect_Radius           = 200
