include("shared.lua")

// Because we rounding the CurTime and use that as a seed for math random each CLIENT will have the exact same random number which should synch the agensts movement
function ENT:GetRandomNumber(min,max)
	math.randomseed(math.Round(CurTime()) + self:EntIndex())
	return math.random(min,max)
end

function ENT:Initialize()

	self:ResetSequence(self:LookupSequence("idle"))

	timer.Simple(self.SpawnOutOfBoxTime, function()
		if IsValid(self) then
			self:ResetSequence(self:LookupSequence("run"))
			self:SetPhysical()
		end
	end)

	self.NextDirChange = CurTime() + 0.5
	self.SpawnTime = CurTime()
	self.ExplotionStart = CurTime() + self:GetWalkTime() + self.SpawnOutOfBoxTime
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:GetNextPos()

	local rndPos = self:GetPos() + Vector(0, 0, self:GetRandomNumber(10,30))

	local randomAngle = self:GetRandomNumber(0,360)
	local circleRadius = 500
	rndPos = rndPos + Vector(math.cos(randomAngle) * circleRadius, math.sin(randomAngle) * circleRadius, 1)

	local c_trace = zclib.util.TraceLine({
		start = rndPos + Vector(0, 0, 50),
		endpos = rndPos - Vector(0, 0, 5000),
		mask = MASK_SOLID_BRUSHONLY
	}, "zww_decoy_runner_nextpos")

	debugoverlay.Line(rndPos + Vector(0, 0, 50), rndPos - Vector(0, 0, 5000), 1, Color(0, 255, 0), false)
	debugoverlay.Line(rndPos + Vector(0, 0, 50), c_trace.HitPos, 1, Color(255, 255, 255), true)

	if c_trace and c_trace.Hit and c_trace.HitPos then
		debugoverlay.Sphere(c_trace.HitPos, 5, 1, Color(255, 0, 0), false)

		return c_trace.HitPos
	end
end

function ENT:SetPhysical()
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	self:PhysWake()

	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:SetMaterial("gmod_silent")
		//phys:SetMaterial("default_silent")
	end
	return phys
end

function ENT:SetMoveable()
	self:MakePhysicsObjectAShadow(true, true)
end


function ENT:IsTouchingGround()
	//if self.LastCheck and CurTime() < self.LastCheck then return end
	//self.LastCheck = CurTime() + 1
	//local min = self:OBBMins()
	local t_start = self:GetPos()
	local t_end = t_start - Vector(0, 0, 5)

	local c_trace = zclib.util.TraceLine({
		start = t_start,
		endpos = t_end,
		mask = MASK_SOLID_BRUSHONLY
	}, "zww_decoy_runner_touchingground")

	debugoverlay.Line(t_start, t_end, 0.01, Color(255, 0, 255), true)

	self.GroundPos = c_trace.HitPos

	return c_trace and c_trace.Hit == true
end

function ENT:Think()
	//self:SetNextClientThink(CurTime())

	if CurTime() > self.ExplotionStart and self.ExplosionInitiated == nil then
		self:StartExplosion()
	end

	if (self.SpawnTime + self.SpawnOutOfBoxTime) > CurTime() then return end

	zclib.util.LoopedSound(self, "zww_decoy_run01_loop", self.ExplosionInitiated ~= true)

	if self.ExplosionIminant then return true end

	//self:SetModelScale(0.6)

	self:HandleMovement()

	//return true
end

function ENT:MakeJump()
	if CurTime() < (self.SpawnTime + 1 + self.SpawnOutOfBoxTime) then return end
	self.IsJumping = true
	//self:EmitSound("zww_decoy_taunt_single")

	local phys = self:SetPhysical()
	if IsValid(phys) then

		if self.LookDirection then
			phys:ApplyForceCenter((self:GetUp() * 300 - self.LookDirection:Forward() * 200) * phys:GetMass())
		else
			phys:ApplyForceCenter((self:GetUp() * 300) * phys:GetMass())
		end

		local val = 50
		local angVel = Vector(self:GetRandomNumber(-val, val),self:GetRandomNumber(-val, val),self:GetRandomNumber(-val, val)) * phys:GetMass()
		phys:AddAngleVelocity(angVel)
	end

	timer.Simple(0.3,function()
		if IsValid(self) then
			self.IsMidAir = true
		end
	end)
end

function ENT:HandleMovement()

	if (self.SpawnTime + 1.5) < CurTime() and self:IsTouchingGround() ~= self.IsGrounded then
		self.IsGrounded = self:IsTouchingGround()

		if self.IsGrounded then
			self:SetMoveable()
			self.SmoothPos = self:GetPos()
		else
			local vel = self:GetVelocity()
			local phys = self:SetPhysical()
			if IsValid(phys) then phys:ApplyForceCenter(vel * phys:GetMass() ) end
		end
	end

	if CurTime() > self.NextDirChange then
		local newPos = self:GetNextPos()

		if newPos then
			debugoverlay.Line(self.NewPos or self:GetPos(), newPos, 1, Color(0, 0, 255), true)
			self.NewPos = newPos
		end

		self.NextDirChange = CurTime() + math.Rand(1, 2)

		if self:GetRandomNumber(0,10) > 5 and self.IsGrounded then self:MakeJump() end
	end

	if self.NewPos == nil then self.NewPos = self:GetPos() end

	self.SmoothPos = LerpVector(FrameTime() * self.WalkSpeed, self.SmoothPos or self:GetPos(), self.NewPos)

	if self.GroundPos and self.GroundPos.z then
		self.SmoothPos = Vector(self.SmoothPos.x,self.SmoothPos.y,self.GroundPos.z)
	end

	if self.IsGrounded ~= true then return end

	local lookDir = (self:GetPos() - self.SmoothPos):Angle()
	self.LookDirection = lookDir

	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:UpdateShadow(self.SmoothPos, Angle(0, lookDir.y, 0), FrameTime() * 25)
	end
end

function ENT:StartExplosion()
	if self.ExplosionInitiated then return end

	self.ExplosionInitiated = true

	self:EmitSound("zww_decoy_pre_explode")

	timer.Simple(2, function()
		if IsValid(self) then

			self.ExplosionIminant = true

			self:ResetSequence(self:LookupSequence("idle"))

			self:EmitSound("zww_decoy_taunt_single")

			// Make it jump
			local phys = self:SetPhysical()
			if IsValid(phys) then

				phys:ApplyForceCenter((self:GetUp() * self:GetRandomNumber(300, 400) + self:GetRight() * self:GetRandomNumber(-250, 250) + self:GetForward() * self:GetRandomNumber(-250, 250)) * phys:GetMass() )

				local val = 50
				local angVel = Vector(self:GetRandomNumber(-val, val),self:GetRandomNumber(-val, val),self:GetRandomNumber(-val, val)) * phys:GetMass()
				phys:AddAngleVelocity(angVel)
			end
		end
	end)

	timer.Simple(2.7, function()
		if IsValid(self) then
			self:SetModelScale(0)
			self:PhysicsInit(SOLID_NONE)

			self:EmitSound("zww_decoy_explode")
			ParticleEffect("cc_decoy_explosion", self:GetPos(), self:GetAngles(), nil)

			self:GibBreakClient(Vector( math.Rand(0,1), math.Rand(0,1), 1) * 100)
		end
	end)
end

function ENT:OnRemove()
	self:StopSound("zww_decoy_run01_loop")
end
