AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Decoy - Box"
ENT.Model = "models/zerochain/props_harrypotter/cc_decoy_box.mdl"

ENT.OnUnbox = function(ent)
    local start_delay = 2
    local count = 25

    ent:DoActionDelayed(start_delay, function()
        local delay = 1

        for i = 1, count do
            timer.Simple(delay, function()
                if IsValid(ent) then
                    local aent = ents.Create("zww_decoy_runner")
                    aent:SetAngles(Angle(0, 0, 0))
                    aent:SetPos(ent:GetPos())
                    aent:Spawn()
                    aent:Activate()
                end
            end)

            delay = delay + 0.025
        end
    end)

    ent:DoActionDelayed(start_delay + 2.5, function()
        ent:SetModelScale(0, 2)
    end)

    ent:DoActionDelayed(start_delay + 5 + 2 + (count * 0.025), function()
        ent:SetNoDraw(true)
    end)

    SafeRemoveEntityDelayed(ent, 15 + start_delay + (count * 0.025))
end
