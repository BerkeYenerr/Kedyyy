AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Harinezumi"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item04.mdl"

function ENT:SpawnFunction(ply, tr)
	if (not tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 1
	local ent = ents.Create(self.ClassName)
	ent:SetAngles(Angle(90,0,90))
	ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()

	return ent
end

ENT.Firework_Duration       = 5

local effects = {
    "zpc2_harinezumi_blue",
    "zpc2_harinezumi_cyan",
    "zpc2_harinezumi_green",
    "zpc2_harinezumi_orange",
    "zpc2_harinezumi_pink",
    "zpc2_harinezumi_red",
    "zpc2_harinezumi_violett",
    "zpc2_harinezumi_yellow",
}

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        ent:PhysicsInit(SOLID_NONE)
    	ent.PhysgunDisabled = true
    end

    if CLIENT then
        ent:SetNoDraw(true)

        ent:TriggerShellDelayed({
            delay = 0,
            shell_mdl = "models/zerochain/props_harrypotter/cc_items/cc_item04.mdl",
            shell_trail = "zpc2_shelltrail",
            shell_dir = Vector(0,-3,0),
            shell_wind = 0.1,
            shell_sound = "zww_rocket_woosh",
            shell_size = 1,
            explo_sound = "zww_firework_explosion01",
            explo_effect = effects[math.random(#effects)],
        })
    end
end
