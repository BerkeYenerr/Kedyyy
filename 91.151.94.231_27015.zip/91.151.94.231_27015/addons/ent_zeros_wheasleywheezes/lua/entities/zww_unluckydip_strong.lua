AddCSLuaFile()
local BaseClass = baseclass.Get("zww_use_base")
ENT.Type = "anim"
ENT.Base = "zww_use_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Unluckdip - Strong"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item11.mdl"

ENT.Duration = 30
ENT.Accuracy = 1

ENT.OnItemUse = function(ent,ply)

    if SERVER and IsValid(ply) and ply:IsPlayer() and not timer.Exists("zww_unlucky" .. ply:SteamID64()) then
        local duration = ent.Duration
        local accuracy = ent.Accuracy
        timer.Create("zww_unlucky" .. ply:SteamID64(), 1, duration, function()
            if not IsValid(ply) then return end

            local swep = ply:GetActiveWeapon()
            if not IsValid(swep) then return end
            if swep:GetClass() ~= "weapon_hpwr_stick" then return end

            swep:HPWDecreaseAccuracy(accuracy)
            //swep.HpwRewrite.Accuracy = accuracy
        end)
    end

    if CLIENT then
        local dlight = DynamicLight(ent:EntIndex( ) )
        if dlight then
            dlight.pos = ent:GetPos( )
            dlight.r = 255
            dlight.g = 235
            dlight.b = 255
            dlight.brightness = 10
            dlight.Decay = 1000
            dlight.Size = 512
            dlight.DieTime = CurTime( ) + 1
        end

        zclib.Sound.EmitFromPosition(ent:GetPos(),"potiontable_explosion")
        zclib.Effect.ParticleEffect("zherb_potion_explosion01", ent:GetPos(), ent:GetAngles(), ent)
    end
end
