AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Goblin"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item09.mdl"


ENT.Firework_Duration       = 5

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        //ent:PhysicsInit(SOLID_NONE)
    	//ent.PhysgunDisabled = true
    end

    if CLIENT then
        //self:SetNoDraw(true)

        local count = 10
        for i = 1, count do
            ent:TriggerEffectDelayed({
                delay = 0.1 * i,
                effect = "zpc2_flame_special_yellowgreen",
                ang = Angle(25,(360 / count) * i,0),
                sound = "zww_crackling",
            })
        end

        local radius = 0.3
        for i = 1, count do
            local x = math.sin((360 / count) * i)
            local y = math.cos((360 / count) * i)
            ent:TriggerShellDelayed({
                delay = 0.1 * i,
                explo_effect = "zpc2_cake_explosion_red",
                explo_sound = "zww_crackling",
                shell_wind = 0,
                shell_size = 0.01,
                shell_dir = Vector(x * radius,y * radius,1)
            })
        end

        //zpc2_cake_explosion_red
        ent:TriggerEffectDelayed({delay = 1,effect = "zpc2_burst_medium_green",sound = "zww_shot_crackling_short"})
        ent:TriggerEffectDelayed({delay = 1,effect = "zpc2_dorn_red",sound = "zww_shot_crackling_short"})
    end
end
