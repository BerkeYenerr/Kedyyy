AddCSLuaFile()
local BaseClass = baseclass.Get("zww_npc_base")
ENT.Type                    = "ai"
ENT.Base                    = "zww_npc_base"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = true
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "Sakacı Charlie"
ENT.UI_Y                    = 80
ENT.Model                   = "models/models/konnie/bioshock/robert_f.mdl"
ENT.ShouldDrawModel         = true

/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end
*/

ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end

AddItem({
    class = "bombastic",
    name = "Bombastic Bomb",

    model = "models/zerochain/props_harrypotter/cc_bombtastic_box.mdl",
price = 40,
    tur = "sc"
})

AddItem({
    class = "zww_box_decoy",
    name = "Tuzak Kutusu",

    model = "models/zerochain/props_harrypotter/cc_decoy_box.mdl",
    price = 75,
    tur = "sc"
})

AddItem({
    class = "zww_earrape",
    name = "Kulak Patlatan",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item38.mdl",
price = 40,
    tur = "sc"
})

AddItem({
    class = "zww_firework_augustu",
    name = "Augustu-Havai Fisek",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item08.mdl",
price = 40,
    tur = "sc"
})

AddItem({
    class = "zww_firework_blaze",
    name = "Blaze-Havai Fisek",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item31.mdl",
price = 60,
tur = "sc"
})

AddItem({
    class = "zww_firework_cracker01",
    name = "Peace Disturber 1",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item27.mdl",
price = 40,
tur = "sc"
})

AddItem({
    class = "zww_firework_cracker02",
    name = "Peace Disturber 2",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item28.mdl",
price = 40,
tur = "sc"
})

AddItem({
    class = "zww_firework_cracker03",
    name = "Peace Disturber 3",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item29.mdl",
price = 60,
tur = "sc"
})

AddItem({
    class = "zww_firework_cracker04",
    name = "Peace Disturber 4",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item30.mdl",
price = 60,
tur = "sc"
})

AddItem({
    class = "zww_firework_cracker05",
    name = "Fanged Flyer",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item13.mdl",
price = 60,
tur = "sc"
})

AddItem({
    class = "zww_firework_goblin",
    name = "Bang Bang Boggart Banger",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item09.mdl",
price = 40,
tur = "sc"
})

AddItem({
    class = "zww_firework_knatter",
    name = "Spectrum Splasher",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item39.mdl",
price = 40,
tur = "sc"
})

AddItem({
    class = "zww_firework_rocket01",
    name = "Whack Trance Whammy Rocket",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item04.mdl",
price = 75,
tur = "sc"
})

AddItem({
    class = "zww_firework_rocket02",
    name = "Thor's Thunder Cracker",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item06.mdl",
price = 75,
tur = "sc"
})

AddItem({
    class = "zww_firework_rocket03",
    name = "Thestral Thrasher small",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item05.mdl",
price = 75,
tur = "sc"
})

AddItem({
    class = "zww_firework_rocket04",
    name = "Isaacs-Havai Fisek",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item37.mdl",
price = 75,
tur = "sc"
})

AddItem({
    class = "zww_firework_weaslybox",
    name = "Weasley Kutusu",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item02.mdl",
price = 60,
tur = "sc"
})

AddItem({
    class = "jinx_off",
    name = "Jinx-Off",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item24.mdl",
price = 40,
tur = "sc"
})

AddItem({
    class = "zww_muglemagic",
    name = "Muggle Magic(Rastgele Büyü)",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item01.mdl",
price = 40,
tur = "sc"
})

AddItem({
    class = "zww_box_shockshake",
    name = "Electric Shock Shake ",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item33.mdl",
price = 75,
tur = "sc"
})

AddItem({
    class = "zww_slimesuprise",
    name = "Slime surprise",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item34.mdl",
    price = 10,
    tur = "sc"
})

AddItem({
    class = "zww_box_teacup",
    name = "Nose-biting Teacup",

    model = "models/kory/meals/teaset.mdl",
    price = 90,
    tur = "sc"
})

AddItem({
    class = "zww_box_thathat",
    name = "Just Like That Hat",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item23.mdl",
    price = 10,
    tur = "sc"
})

AddItem({
    class = "zww_unluckydip_strong",
    name = "Unlucky Dip",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item10.mdl",
    price = 10,
    tur = "sc"
})

AddItem({
    class = "zww_makeover01",
    name = "Makeover Kutusu",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item19.mdl",
    price = 10,
    tur = "sc"
})