AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Shock Smash"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item33.mdl"

ENT.OnUnbox = function(ent)

    if CLIENT then

        timer.Simple(1, function()
            if IsValid(ent) then
                // Create Hulk fist client model
                local cs = zww.CEnt.Create()

                if IsValid(cs) then
                    cs:SetModel("models/zerochain/props_harrypotter/cc_hulksmash.mdl")
                    cs:DrawShadow(false)
                    cs:DestroyShadow()
                    cs:SetMoveType(MOVETYPE_NONE)
                    cs:Spawn()
                    cs:SetSequence(cs:LookupSequence("smash"))
                    cs:SetPos(ent:GetPos())
                    cs.cycle = 0
                    ent.HulkFist = cs
                    ent:EmitSound("zww_teacup_howl")
                end

                timer.Simple(0.4, function()
                    if IsValid(ent) then
                        // Create electric sound and ParticleEffect

                        sound.Play("ambient/energy/weld1.wav", ent:GetPos( ), 75, 100,1)

                        local effectdata = EffectData()
                        effectdata:SetOrigin( ent:GetPos( ) )
                        effectdata:SetMagnitude( 1000 )
                        effectdata:SetScale(100)
                        effectdata:SetRadius( 50 )
                        util.Effect( "cball_bounce", effectdata )


                        zclib.Effect.ParticleEffect("zherb_potion_explosion01", ent:GetPos(), ent:GetAngles(), ent)
                    end
                end)

                timer.Simple(0.75, function()
                    if IsValid(cs) then
                        // Remove Hulk fist
                        zclib.ClientModel.Remove(cs)
                    end
                end)
            end
        end)
    end

    if SERVER then

        ent:DoActionDelayed(1.4, function()

            ent:SetNoDraw(true)

            // Create electric shock damage and push players in radius

            for k,v in pairs(ents.FindInSphere(ent:GetPos(),200)) do
                if not IsValid(v) then continue end

        		local phys = v:GetPhysicsObject()
        		if IsValid(phys) and phys:IsMotionEnabled() == true then
        			local tpos = (v:GetPos() - ent:GetPos()) + Vector(0,0,50)
        			phys:ApplyForceCenter(tpos * phys:GetMass() * 5)
        		end

                local d = DamageInfo()
                if v:IsPlayer() then
                    d:SetDamage(15)

                    if math.random(10) > 5 then
                        v:EmitSound("zww_ouch_male")
                    else
                        v:EmitSound("zww_ouch_female")
                    end
                    local spos = ((v:GetPos() - ent:GetPos()) * 500) + Vector(0,0,700)
                    v:SetVelocity(spos)
                else
                    d:SetDamage(150)
                end
                d:SetAttacker(ent)
                d:SetDamageType(DMG_SHOCK)
                v:TakeDamageInfo(d)


            end
        end)

        SafeRemoveEntityDelayed(ent,2.3)
    end
end

if CLIENT then
    function ENT:Think()
        self:SetNextClientThink(CurTime())

        if IsValid(self.HulkFist) then
            self.HulkFist:SetCycle(self.HulkFist.cycle)
            self.HulkFist.cycle = math.Clamp(self.HulkFist.cycle + 2 * FrameTime(),0,1)
        end

        return true
    end
end
