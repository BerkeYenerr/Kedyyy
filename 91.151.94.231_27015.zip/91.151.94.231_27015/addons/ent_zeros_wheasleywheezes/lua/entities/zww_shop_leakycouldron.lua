AddCSLuaFile()
local BaseClass = baseclass.Get("zww_npc_base")
ENT.Type                    = "ai"
ENT.Base                    = "zww_npc_base"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = true
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "Barmen"
ENT.UI_Y                    = 75
ENT.Model                   = "models/konnie/witcher3/zoltan_f.mdl"
ENT.ShouldDrawModel         = true

/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end
*/

ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end

AddItem({
    class = "ent_kaymakbira",
    name = "Kaymak Birasi",

    model = "models/sbs/hogsmeade/wu/hmm_3b_butterbeer.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "ent_yemekornegi",
    name = "Patates-Tavuk",

    model = "models/kory/meals/fishandchips.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_meatstick",
    name = "Et",

    model = "models/food/meatstick/meat01_dbr_04.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_pie",
    name = "Turta",

    model = "models/food/pie/pie.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_grapes",
    name = "Uzum",

    model = "models/alchemy/grapes01.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_egg",
    name = "Yumurta",

    model = "models/props_phx/misc/egg.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_bloodale",
    name = "Kanlı Gazoz",

    model = "models/food/potion/life_potion.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_bananas",
    name = "Muz",

    model = "models/food/bananas/banana_regime.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_bread",
    name = "Ekmek",

    model = "models/food/bread/bread.mdl",
    price = 20,
    tur = "sc"
})