AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Slime Suprise"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item34.mdl"

function ENT:SpawnFunction(ply, tr)
	if (not tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 1
	local ent = ents.Create(self.ClassName)
	local angle = ply:GetAimVector():Angle()
	angle = Angle(0, angle.yaw, 0)
	angle:RotateAroundAxis(angle:Up(), 180)
	ent:SetAngles(angle)
	ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()

	return ent
end

if CLIENT then
    function ENT:OnRemove()
        self:StopParticles()
    end
end

ENT.OnUnbox = function(ent)

    if CLIENT then
        ent:EmitSound("zww_fuse")
        zclib.Effect.ParticleEffectAttach("zpc2_fuse", PATTACH_POINT_FOLLOW, ent, 0)

    	timer.Simple(1, function()
    		if IsValid(ent) then
    			ent:EmitSound("zww_kubi")
    		end
    	end)
    end

    if SERVER then
        ent:DoActionDelayed(1, function()
            local aent = ents.Create("zww_slime_bomb")
        	aent:SetAngles(ent:GetAngles())
        	aent:SetPos(ent:GetPos() + ent:GetUp() * 10)
        	aent:Spawn()
        	aent:Activate()

        	local phys = aent:GetPhysicsObject()
        	if IsValid(phys) then
        		phys:Wake()
        		phys:EnableMotion(true)
                phys:SetMaterial("gmod_silent")
    			phys:SetMass(10)
    			phys:SetDragCoefficient(7)

        		phys:ApplyForceCenter(ent:GetUp() * phys:GetMass() * 800)
        		local val = 3500
        		local angVel = Vector(math.random(-val, val), math.random(-val, val), math.random(-val, val)) * phys:GetMass()
        		phys:AddAngleVelocity(angVel)
        	end

        	constraint.NoCollide(aent, ent, 0, 0)
        	SafeRemoveEntityDelayed(ent, 1.25)
        end)

        ent:DoActionDelayed(1, function()
            ent:SetModelScale(0,0.25)
        end)

        ent:DoActionDelayed(1.5, function()
            ent:SetNoDraw(true)
        end)

        SafeRemoveEntityDelayed(ent,2)
    end
end
