AddCSLuaFile()
local BaseClass = baseclass.Get("zww_npc_base")
ENT.Type                    = "ai"
ENT.Base                    = "zww_npc_base"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = true
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "Slug & Jigger (Potion seller)"
ENT.UI_Y                    = 77
ENT.Model                   = "models/eli.mdl"
ENT.ShouldDrawModel         = true

/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end
*/

ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end

AddItem({
    potion = "twilightmoonbeams",
    name = "Twilight Moonbeam",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item26.mdl",
    price = 550,
    tur = "sc"
})

AddItem({
    potion = "amortentialovepotion",
    name = "Amortentia: Love potion",

    model = "models/zerochain/props_harrypotter/cc_items/cc_item25.mdl",
    price = 600
})

AddItem({
    potion = "smallinvisiblepotion",
    name = "Small Invisibility Potion",

    model = "models/mixtures_health/mixtures_health_50hp.mdl",
    price = 3000
})

AddItem({
    potion = "mediuminvisiblepotion",
    name = "Medium Invisibility Potion",

    model = "models/mixtures_health/mixtures_health_50hp.mdl",
    price = 4000
})

AddItem({
    potion = "biginvisiblepotion",
    name = "Big Invisibility Potion",

    model = "models/mixtures_health/mixtures_health_50hp.mdl",
    price = 6000
})

AddItem({
    potion = "erumpentpotion",
    name = "Erumpent Potion",

    model = "models/mlp_props/nightmare_night/candy_cart/potion_jar.mdl",
    price = 2000
})

AddItem({
    potion = "strengtheningsolution",
    name = "Strengthening Solution",

    model = "models/alchemylab/potion_purple.mdl",
    price = 1000
})

AddItem({
    potion = "potion_anti_poison",
    name = "Antidote to Common Poisons",

    model = "models/alchemylab/potion_orange.mdl",
    price = 1100
})

AddItem({
    potion = "cheesebasedpotion",
    name = "Cheese-Based Potion",

    model = "models/items/provisions/potions/stone_potion.mdl",
    price = 1900
})
