include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:UsePowder()
	self:EmitSound("zww_decoy_explode")
	ParticleEffect("cc_darknesspowder_explosion", self:GetPos(), self:GetAngles(), nil)
end
