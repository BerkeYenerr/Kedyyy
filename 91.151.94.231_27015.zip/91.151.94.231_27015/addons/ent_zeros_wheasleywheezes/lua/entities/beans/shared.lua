ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Berti Botts Beans Color"
ENT.Author = "Kory"
ENT.Category = "Kory Ents"

ENT.Spawnable = true
ENT.AdminSpawnable = true
