AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Augustus"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item08.mdl"


ENT.Firework_Duration       = 5

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        //ent:PhysicsInit(SOLID_NONE)
    	//ent.PhysgunDisabled = true
    end

    if CLIENT then
        //self:SetNoDraw(true)

        ent:TriggerEffectDelayed({delay = 0.25,effect = "zpc2_flame_special_redgreen",sound = "zww_shot_crackling_short"})
        ent:TriggerShellDelayed({delay = 0.25,explo_effect = "zpc2_cake_explosion_green",shell_wind = 0.5,shell_size = 0.01,})

        ent:TriggerEffectDelayed({delay = 0.5,effect = "zpc2_flame_special_redgreen",sound = "zww_shot_crackling_short"})
        ent:TriggerShellDelayed({delay = 0.5,explo_effect = "zpc2_cake_explosion_white",shell_wind = 0.5,shell_size = 0.01,})

        ent:TriggerEffectDelayed({delay = 1,effect = "zpc2_flame_special_redgreen",sound = "zww_shot_crackling_short"})
        ent:TriggerShellDelayed({delay = 1,explo_effect = "zpc2_cake_explosion_green",shell_wind = 0.5,shell_size = 0.01,})

        ent:TriggerEffectDelayed({delay = 1.25,effect = "zpc2_flame_special_redgreen",sound = "zww_shot_crackling_short"})
        ent:TriggerShellDelayed({delay = 1.25,explo_effect = "zpc2_cake_explosion_white",shell_wind = 0.5,shell_size = 0.01,})

        ent:TriggerEffectDelayed({delay = 1.75,effect = "zpc2_flame_special_redgreen",sound = "zww_shot_crackling_short"})
        ent:TriggerShellDelayed({
            delay = 1.75,
            explo_effect = "zpc2_nautical_pink",
            explo_sound = "zww_crackling",
            shell_wind = 0,
            shell_size = 0.01,
            shell_dir = Vector(0,0,1.5)
        })
    end
end
