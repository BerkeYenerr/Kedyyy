AddCSLuaFile()
local BaseClass = baseclass.Get("zww_use_base")
ENT.Type = "anim"
ENT.Base = "zww_use_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Muggle Magic"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item01.mdl"

ENT.Spells = {"Red Sparks","Green Sparks","Colovaria","Extinguishing Spell"} --editlencek

ENT.OnItemUse = function(ent,ply)
    if SERVER and IsValid(ply) and ply:IsPlayer() then
        local spell = ent.Spells[math.random(#ent.Spells)]
        zclib.Notify(ply, "You learned " .. spell, 0)
        HpwRewrite:PlayerGiveSpell(ply, spell)
    end


    if CLIENT then
        zclib.Sound.EmitFromPosition(ent:GetPos(),"potiontable_explosion")
        zclib.Effect.ParticleEffect("zherb_potion_explosion", ent:GetPos(), ent:GetAngles(), ent)
    end
end
