//ENT.Base                    = "base_anim"
//ENT.Type                    = "anim"
ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = false
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "Joke Shop"
ENT.UI_Y                    = 80
ENT.Model                   = "models/Humans/Group03/male_07.mdl"
ENT.ShouldDrawModel         = true

// This check can be used to prevent the player from interacting with the npc
/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end


ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end


AddItem({
    class = "zww_box_bombastic",
    potion = "48dgnjgsd834",
    swep = "weapon_crowbar",

    name = "Bombastic Bomb",
    model = "models/zerochain/props_harrypotter/cc_bombtastic_box.mdl",
    price = 500
})
*/
