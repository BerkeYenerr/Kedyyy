include("shared.lua")

function ENT:Initialize()
	zww.NPC.Initialize(self)
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Draw()
	if self.ShouldDrawModel then self:DrawModel() end
	zww.NPC.Draw(self)
end
