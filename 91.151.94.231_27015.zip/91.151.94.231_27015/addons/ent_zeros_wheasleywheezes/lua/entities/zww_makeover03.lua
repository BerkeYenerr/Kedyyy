AddCSLuaFile()
local BaseClass = baseclass.Get("zww_use_base")
ENT.Type = "anim"
ENT.Base = "zww_use_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Witches - MakeOver03"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item21.mdl"

ENT.OnItemUse = function(ent,ply)
    local target = ply or ent

    if SERVER and IsValid(target) and target:IsPlayer() then
        // Randomize the player bodygroup
        for k,v in pairs(target:GetBodyGroups()) do
            target:SetBodygroup(k,math.random(#v.submodels))
        end
    end

    if CLIENT then
        zclib.Sound.EmitFromPosition(target:GetPos(),"potiontable_explosion")
        zclib.Effect.ParticleEffect("zherb_potion_explosion", target:GetPos(), target:GetAngles(), target)
    end
end
