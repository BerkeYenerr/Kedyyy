AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "ThatHat - Box"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item23.mdl"

local TestLoot = {
    "mushroom_eat"
}

ENT.LootCount = 5

ENT.OnUnbox = function(ent, ply)
    if SERVER then
        local hat = ents.Create("prop_dynamic")
        hat:SetModel("models/player/items/humans/top_hat.mdl")
        //aent:SetModelScale(0,0)
        hat:SetModelScale(2,0)
        hat:SetAngles(ent:LocalToWorldAngles(Angle(0,0,180)))
        hat:SetPos(ent:LocalToWorld(Vector(0,0,27)))
        hat:Spawn()
        hat:Activate()

        SafeRemoveEntityDelayed(hat,3)

        ent:DoActionDelayed(1, function()
            //aent:SetModelScale(0,2)

            local delay = 0
            for i = 1, ent.LootCount do
                timer.Simple(delay, function()
                    if IsValid(ent) then

                        local x = math.sin(math.random(360))
                        local y = math.cos(math.random(360))
                        local radius = 100

                        local aent = ents.Create(TestLoot[math.random(#TestLoot)])
                        aent:SetAngles(Angle(0, 0, 0))
                        aent:SetPos(ent:GetPos() + Vector(x * radius ,y * radius,15))
                        aent:Spawn()
                        aent:Activate()
                    end
                end)

                delay = delay + 0.1
            end
        end)

        SafeRemoveEntityDelayed(ent,3.1)
    end

    if CLIENT then
        timer.Simple(1.1,function()
            if not IsValid(ent) then return end
            zclib.Sound.EmitFromPosition(ent:GetPos(),"potiontable_explosion")
            zclib.Effect.ParticleEffect("zherb_potion_explosion", ent:GetPos() + Vector(0,0,60), ent:GetAngles(), ply)
        end)
    end
end
