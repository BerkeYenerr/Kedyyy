AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Cracker01"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item27.mdl"


ENT.Firework_Duration       = 28
ENT.Firework_JumpCount      = 50

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        ent:PhysicsInit(SOLID_NONE)
    	ent.PhysgunDisabled = true
    end

    if CLIENT then
        ent:SetNoDraw(true)

        ent:TriggerCracker({

            interval_start = 1,

            cracker_mdl = ent.Model,
            cracker_trail = "zww_trail_large01",
            cracker_sound = "zww_shot_crackling_short",
            cracker_effect = "zpc2_mortarburst_medium",
            //cracker_size = 1,
            explo_sound = "zww_shot_crackling_short",

            final_effect = {"zpc2_explo_twinklefan_blue","zpc2_explo_twinklefan_green"},
            final_count = 6,
            primary_effect = {"zpc2_cake_explosion_blue","zpc2_cake_explosion_cyan","zpc2_cake_explosion_green"},
            secondary_effect = "zpc2_cake_explosion_white",
        })
    end
end
