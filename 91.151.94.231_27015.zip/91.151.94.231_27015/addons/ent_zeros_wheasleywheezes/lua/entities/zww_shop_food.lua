AddCSLuaFile()
local BaseClass = baseclass.Get("zww_npc_base")
ENT.Type                    = "ai"
ENT.Base                    = "zww_npc_base"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = true
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "Sekerlemeci Cathy"
ENT.UI_Y                    = 77
ENT.Model                   = "models/npc/tfa_tw3_ciri_empress.mdl"
ENT.ShouldDrawModel         = true

/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end
*/

ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end


AddItem({
    class = "anan",
    name = "Cikolatali Kurbaga",

    model = "models/zerochain/props_harrypotter/cccrd/cc_frogbox.mdl",
    price = 60,
    tur = "sc"
})

AddItem({
    class = "entity_bean",
    name = "Bertie Bott'un Sekerleri",

    model = "models/zerochain/props_harrypotter/cc_bertiebottsbeans.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_bonbons",
    name = "Bonbon",

    model = "models/sbs/hogsmeade/wu/hmm_hd_bonbons.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_candycorn",
    name = "Sekerli Mısır",

    model = "models/zerochain/props_halloween/candy_candycorn.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "ent_honeydukes",
    name = "Honey Duke Cikolatasi",

    model = "models/kory/meals/honeydukeschocolatebar.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_lolipop",
    name = "Lolipop",

    model = "models/zerochain/props_halloween/candy_lolipop.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_cupcake",
    name = "Balkabagi Keki",

    model = "models/zerochain/props_halloween/candy_cupcake.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "entity_hayvansesi",
    name = "Ses Ureten Sekerleme",

    model = "models/zerochain/props_harrypotter/cc_bertiebottsbeans.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_saffron",
    name = "Tongue tying lemon twister",

    model = "models/props_junk/glassbottle01a.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "ent_balkabagisuyu",
    name = "Balkabagi Suyu",

    model = "models/kory/meals/pumpkinjuice.mdl",
    price = 20,
    tur = "sc"
})

AddItem({
    class = "eoti_food_ciderale",
    name = "Su",

    model = "models/props_junk/garbage_glassbottle003a.mdl",
    price = 20,
    tur = "sc"
})
