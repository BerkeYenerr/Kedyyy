AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Blaze"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item31.mdl"


ENT.Firework_Duration       = 7


local random_effects = {
    "zpc2_burst_tiny_green",
    "zpc2_burst_medium_green",
    "zpc2_burst_big_green",
    "zpc2_burst_tiny_blue",
    "zpc2_burst_medium_blue",
    "zpc2_burst_big_blue",
    "zpc2_burst_tiny_orange",
    "zpc2_burst_medium_orange",
    "zpc2_burst_big_orange",
    "zpc2_burst_tiny_red",
    "zpc2_burst_medium_red",
    "zpc2_burst_big_red",
    "zpc2_burst_tiny_violett",
    "zpc2_burst_medium_violett",
    "zpc2_burst_big_violett",
    "zpc2_burst_tiny_white",
    "zpc2_burst_medium_white",
    "zpc2_burst_big_white",
    "zpc2_burst_tiny_pink",
    "zpc2_burst_medium_pink",
    "zpc2_burst_big_pink",
    "zpc2_burst_tiny_cyan",
    "zpc2_burst_medium_cyan",
    "zpc2_burst_big_cyan",
}

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        ent:PhysicsInit(SOLID_NONE)
    	ent.PhysgunDisabled = true
    end

    if CLIENT then
        //self:SetNoDraw(true)

        local count = 100
        for i = 1, count do
            ent:TriggerEffectDelayed({
                delay = 0.05 * i,
                effect = random_effects[math.random(#random_effects)],
                sound = "zww_shot_crackling_short",
                ang = Angle(math.random(-35,35),math.random(360),0)
            })
        end

        local shellCount = 10
        local radius = 0.3
        for i = 1, shellCount do
            local x = math.sin((360 / shellCount) * i)
            local y = math.cos((360 / shellCount) * i)
            ent:TriggerShellDelayed({
                delay = 0.5 * i,
                explo_effect = "zpc2_explo_sparklers",
                explo_sound = "zww_crackling",
                shell_wind = 0,
                shell_size = 0.01,
                shell_dir = Vector(x * radius,y * radius,math.Rand(1,1.4))
            })
        end
    end
end
