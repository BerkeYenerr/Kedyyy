AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Knatter"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item39.mdl"


ENT.Firework_Duration       = 10

local random_explosioneffects = {
    "zpc2_cake_explosion_blue",
    "zpc2_cake_explosion_cyan",
    "zpc2_cake_explosion_green",
    "zpc2_cake_explosion_orange",
    "zpc2_cake_explosion_pink",
    "zpc2_cake_explosion_red",
    "zpc2_cake_explosion_violett",
    "zpc2_cake_explosion_white",
    "zpc2_cake_explosion_yellow",
}

local cracker_mdls = {
    "models/zerochain/props_harrypotter/cc_items/cc_item16.mdl",
    "models/zerochain/props_harrypotter/cc_items/cc_item17.mdl",
    "models/zerochain/props_harrypotter/cc_items/cc_item18.mdl",
}

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        ent:PhysicsInit(SOLID_NONE)
    	ent.PhysgunDisabled = true
    end

    if CLIENT then


        local timerid = "zww_knatter_timer_" .. ent:EntIndex()
        local rep = 50
        local start_delay = 0.25
        local cur_delay = start_delay
        zclib.Timer.Create(timerid,cur_delay,rep,function()

            if not IsValid(ent) then
                 zclib.Timer.Remove(timerid)
                return
            end

            ent:TriggerEffectDelayed({
                delay = 0,
                effect = "zpc2_mortarburst_medium",
                sound = "zww_crackling",
            })

            local x = math.sin(math.random(360))
            local y = math.cos(math.random(360))
            local radius = math.Rand(0.2,0.5)
            ent:TriggerShellDelayed({
                delay = 0,
                explo_effect = random_explosioneffects[math.random(#random_explosioneffects)],
                //explo_sound = "zww_crackling",
                //shell_sound = "zww_crackling",
                shell_mdl = cracker_mdls[math.random(#cracker_mdls)],
                shell_wind = 0.25,
                shell_size = 0.5,
                shell_dir = Vector(x * radius,y * radius,0.75)
            })


            cur_delay = cur_delay - (start_delay / rep)
            timer.Adjust(timerid,cur_delay)

            if timer.RepsLeft(timerid) <= 0 then
                ent:SetNoDraw(true)

                ent:TriggerShellDelayed({
                    delay = 0,
                    explo_effect = "zpc2_explo_sparklers",
                    explo_sound = "zww_explo",
                    shell_sound = "zww_kubi",
                    shell_mdl = "models/zerochain/props_harrypotter/cc_items/cc_item18.mdl",
                    shell_wind = 0,
                    shell_size = 1.5,
                    shell_dir = Vector(x * radius,y * radius,2)
                })
            end
        end)
    end
end
