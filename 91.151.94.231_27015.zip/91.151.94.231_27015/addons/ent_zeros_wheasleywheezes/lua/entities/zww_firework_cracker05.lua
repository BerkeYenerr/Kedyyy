AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Fanged Flyer"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item13.mdl"


ENT.Firework_Duration       = 15
ENT.Firework_JumpCount      = 30


// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        ent:PhysicsInit(SOLID_NONE)
    	ent.PhysgunDisabled = true
    end

    if CLIENT then
        ent:SetNoDraw(true)

        ent:TriggerCracker({

            interval_start = 0.7,

            cracker_mdl = "models/zerochain/props_harrypotter/cc_items/cc_item40.mdl",
            cracker_trail = "zww_trail_large01",
            cracker_sound = "zww_shot_crackling_short",
            cracker_effect = "zpc2_mortarburst_medium",
            //cracker_size = 1,
            explo_sound = "zww_shot_crackling_short",

            move_size = 300,

            final_effect = {"zpc2_nagano_green"},
            final_count = 5,
            final_sound = "zww_firework_nagano",

            primary_effect = {"zpc2_explospark_green","zpc2_explospark_red"},
            secondary_effect = "zpc2_explospark_white",
        })
    end
end
