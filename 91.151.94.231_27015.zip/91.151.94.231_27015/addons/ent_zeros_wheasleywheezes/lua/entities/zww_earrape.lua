AddCSLuaFile()
local BaseClass = baseclass.Get("zww_use_base")
ENT.Type = "anim"
ENT.Base = "zww_use_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "EarRape"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item38.mdl"

ENT.OnItemUse = function(ent,ply)

    if SERVER and IsValid(ply) and ply:IsPlayer() and not timer.Exists("zww_earrape" .. ply:SteamID64()) then
        local filter = RecipientFilter()
        filter:AddPlayer(ply)

        local snd = CreateSound(ply, "synth/25_pwm_1760.wav", filter)
        snd:Play()

        snd:ChangeVolume(1, 0)
        snd:ChangeVolume(0, 4)

        util.ScreenShake(ply:GetPos(), 64, 128, 3, 40)

        local ang = AngleRand() * 0.2
        ply:ViewPunch(ang)
        ang.r = 0

        ply:SetEyeAngles(ply:EyeAngles() + ang)
        ply:ConCommand("stopsound")

        timer.Create("zww_earrape" .. ply:SteamID64(), 5, 1, function()
            snd:Stop()
        end)
    end

    if CLIENT then

        local target = ply or ent

        local dlight = DynamicLight(target:EntIndex( ) )
        if dlight then
            dlight.pos = target:GetPos( )
            dlight.r = 255
            dlight.g = 235
            dlight.b = 255
            dlight.brightness = 10
            dlight.Decay = 1000
            dlight.Size = 512
            dlight.DieTime = CurTime( ) + 1
        end

        local pos = ply and ply:GetShootPos() or target:GetPos()
    	local dir = ply and ply:GetAimVector() or target:GetForward()
    	for i = 1, 4 do
    		timer.Simple(i * 0.1, function()
    			sound.Play("weapons/physcannon/energy_bounce2.wav", pos + dir * i * 30, 60, math.random(120, 140))
    		end)
    	end

        zclib.Sound.EmitFromPosition(target:GetPos(),"potiontable_explosion")
        zclib.Effect.ParticleEffect("zherb_potion_explosion", target:GetPos() + Vector(0,0,60), target:GetAngles(), target)
    end
end
