AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Bombastic - Box"
ENT.Model = "models/zerochain/props_harrypotter/cc_bombtastic_box.mdl"

ENT.OnUnbox = function(ent)

    if CLIENT then
        ent:EmitSound("zww_fuse")
    	zclib.Animation.Play(ent, "open", 1)

    	timer.Simple(1, function()
    		if IsValid(ent) then
    			ent:SetBodygroup(0, 1)
    			ent:SetBodygroup(1, 1)
    			ent:EmitSound("zww_kubi")
    		end
    	end)
    end

    if SERVER then
        ent:DoActionDelayed(1, function()
            local aent = ents.Create("zww_bombtastic_bomb")
        	aent:SetAngles(ent:GetAngles())
        	aent:SetPos(ent:GetPos() + ent:GetUp() * 10)
        	aent:Spawn()
        	aent:Activate()

        	for k, v in pairs(ent:GetChildren()) do
        		if IsValid(v) and v:GetClass() == "prop_vehicle_prisoner_pod" then
        			v:SetParent(nil)
        			v:SetParent(aent)
        		end
        	end

        	local phys = aent:GetPhysicsObject()

        	if IsValid(phys) then
        		phys:Wake()
        		phys:EnableMotion(true)
        		phys:ApplyForceCenter(ent:GetUp() * phys:GetMass() * 1250 + ent:GetRight() * math.random(-250, 250) + ent:GetForward() * math.random(-250, 250))
        		local val = 3500
        		local angVel = Vector(math.random(-val, val), math.random(-val, val), math.random(-val, val)) * phys:GetMass()
        		phys:AddAngleVelocity(angVel)
        	end

        	constraint.NoCollide(aent, ent, 0, 0)
        	SafeRemoveEntityDelayed(ent, 1.25)
        end)

        ent:DoActionDelayed(2, function()
            ent:SetModelScale(0, 1)
        end)

        ent:DoActionDelayed(3, function()
            ent:SetNoDraw(true)
        end)

        SafeRemoveEntityDelayed(ent,3)
    end
end
