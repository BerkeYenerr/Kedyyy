include("shared.lua")

function ENT:Initialize()
	//self:SetModel("models/kory/meals/teaset.mdl")
	self.SmoothAng = Angle(0, 0, 0)

	timer.Simple(0.2,function()
		if IsValid(self) then
			//self:SetModel("models/kory/meals/teaset.mdl")
			zclib.Effect.ParticleEffectAttach("zww_trail_teacup", PATTACH_POINT_FOLLOW, self, 0)
		end
	end)
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Think()
	self:SetNextClientThink(CurTime())

	local target = self:GetBiteTarget()
	if IsValid(target) then
		local dir = (self:GetPos() - Vector(0, 0, 50) - target:GetPos()):Angle()
		self.SmoothAng = LerpAngle(FrameTime() * 2, self.SmoothAng, dir)
		self:SetRenderAngles(Angle(0, self.SmoothAng.y, 0))
	end

	//self:SetRenderOrigin(self:GetPos())

	return true
end
