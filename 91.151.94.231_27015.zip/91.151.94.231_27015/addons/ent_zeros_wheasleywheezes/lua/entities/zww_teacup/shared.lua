ENT.Type					= "anim"
ENT.Base					= "base_anim"
ENT.RenderGroup             = RENDERGROUP_BOTH
ENT.Spawnable		        =  false
ENT.AdminSpawnable		    =  false

ENT.PrintName		        = "Teacup"
ENT.Author					= "ClemensProduction aka Zerochain"
ENT.Information				= "info"
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.Model                   = "models/kory/meals/teaset.mdl"
ENT.AutomaticFrameAdvance   = true
ENT.DisableDuplicator		= false

function ENT:SetupDataTables()
    self:NetworkVar( "Entity", 0, "BiteTarget" )

	if SERVER then
		self:SetBiteTarget(NULL)
	end
end
