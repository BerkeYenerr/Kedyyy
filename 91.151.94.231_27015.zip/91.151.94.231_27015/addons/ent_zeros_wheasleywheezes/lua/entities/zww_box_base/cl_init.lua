include("shared.lua")

function ENT:Draw()
	self:DrawModel()

	if self:GetIsActivated() then
		self:SetRenderAngles(self:LocalToWorldAngles(Angle(0,CurTime() * 180,0)))
	end
end

function ENT:DrawTranslucent()
	self:Draw()
end
