ENT.Type					= "anim"
ENT.Base					= "base_anim"
ENT.RenderGroup             = RENDERGROUP_BOTH
ENT.Spawnable		        =  false
ENT.AdminSpawnable		    =  false

ENT.PrintName		        = "Use Item"
ENT.Author					= "ClemensProduction aka Zerochain"
ENT.Information				= "info"
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item19.mdl"
ENT.AutomaticFrameAdvance   = true
ENT.DisableDuplicator		= false

/*
ENT.OnItemUse = function(ent,ply)
end
*/
