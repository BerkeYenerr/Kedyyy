AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Weather - Box"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item22.mdl"

ENT.OnUnbox = function(ent, ply)
    local target = ply
    if not IsValid(target) then return end
    if SERVER then
        net.Start("hpwrewrite.atmospheric")
        net.WriteEntity(target)
        net.Broadcast()

        ent:SetNoDraw(true)
        SafeRemoveEntityDelayed(ent,21)
    end

    if CLIENT then
        local _ply = target:GetPos()
        sound.Play("hogwartsrp/other/sfx-other-rain-001.mp3", _ply)

        timer.Simple(2, function()
            sound.Play("hogwartsrp/other/sfx-other-thunder-001.mp3", _ply)
        end)

        timer.Simple(9, function()
            sound.Play("hogwartsrp/other/sfx-other-thunder-002.mp3", _ply)
        end)

        timer.Simple(20, function()
            sound.Play("hogwartsrp/other/sfx-other-thunder-003.mp3", _ply)
        end)
    end

end
