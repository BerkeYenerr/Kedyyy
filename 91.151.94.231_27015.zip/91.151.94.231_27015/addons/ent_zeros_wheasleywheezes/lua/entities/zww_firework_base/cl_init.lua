include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:OnRemove()
	self:StopParticlesNamed("zww_fuse")
end

function ENT:TriggerFirework()
	self:EmitSound("zww_fuse")
	zclib.Effect.ParticleEffectAttach("zpc2_fuse", PATTACH_POINT_FOLLOW, self, 0)

	timer.Simple(1, function()
		if IsValid(self) then
			self:StopParticlesNamed("zpc2_fuse")
			self:Firework_Design(self)
		end
	end)
end

function ENT:TriggerEffectDelayed(data)
	timer.Simple(data.delay or 1,function()
		if IsValid(self) then self:TriggerEffect(data) end
	end)
end

function ENT:TriggerEffect(data)

	local parent = self

	if IsValid(data.parent) then
		parent = data.parent
	end

	if data.sound then parent:EmitSound(data.sound or "zww_kubi") end
	zclib.Effect.ParticleEffect(data.effect or "zpc2_flame_special_redgreen", parent:LocalToWorld(data.pos or Vector(0,0,0)), parent:LocalToWorldAngles(data.ang or Angle(0,0,0)), parent)
end

function ENT:TriggerShellDelayed(data)
	timer.Simple(data.delay or 0,function()
		if IsValid(self) then self:TriggerShell(data) end
	end)
end

function ENT:TriggerShell(data)

	local shell_ent = zww.CEnt.Create(data.shell_mdl or "models/props_junk/PopCan01a.mdl")

	if IsValid(shell_ent) then

		shell_ent:SetPos(self:GetPos() + Vector(0,0,25))
		shell_ent:SetAngles(self:GetAngles())
		shell_ent:PhysicsInit(SOLID_VPHYSICS)
		shell_ent:SetMoveType(MOVETYPE_VPHYSICS)
		shell_ent:SetSolid(SOLID_VPHYSICS)
		shell_ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
		shell_ent:PhysWake()

		zclib.Effect.ParticleEffectAttach(data.shell_trail or "zpc2_shelltrail", PATTACH_POINT_FOLLOW, shell_ent, 0)
		if data.shell_sound then shell_ent:EmitSound(data.shell_sound) end

		shell_ent:SetModelScale(data.shell_size or 1)

		local phys = shell_ent:GetPhysicsObject()
		if IsValid(phys) then
			phys:SetMaterial("gmod_silent")
			phys:SetMass(10)
			phys:SetDragCoefficient(0)

			//local f_dir = (data.shell_dir or Vector(0, 0, 1)) * phys:GetMass() * 500
			local dir = data.shell_dir or Vector(0, 0, 1)

			local f_dir = self:GetUp() * dir.z
			f_dir = f_dir + self:GetRight() * dir.x
			f_dir = f_dir + self:GetForward() * dir.y
			f_dir = f_dir * 500

			local mod_x = math.random(-500, 500) * data.shell_wind
			local mod_z = math.random(-500, 500) * data.shell_wind

			f_dir = f_dir + Vector(mod_x,0,0)
			f_dir = f_dir + Vector(0,mod_z,0)

			phys:ApplyForceCenter(f_dir * phys:GetMass())
		end

		timer.Simple(1, function()
			if IsValid(shell_ent) and IsValid(self) then
				if data.explo_sound then shell_ent:EmitSound(data.explo_sound or "zww_explo") end
				zclib.Effect.ParticleEffect(data.explo_effect, shell_ent:GetPos(), shell_ent:GetAngles(), self)
			end

			if IsValid(shell_ent) then
				zclib.ClientModel.Remove(shell_ent)
			end
		end)
	end
end




function ENT:TriggerCracker(data)

	local cracker = zww.CEnt.Create(data.cracker_mdl or "models/props_junk/PopCan01a.mdl")

	if IsValid(cracker) then

		cracker:SetPos(self:GetPos())
		cracker:SetAngles(self:GetAngles())
		cracker:PhysicsInit(SOLID_VPHYSICS)
		cracker:SetMoveType(MOVETYPE_VPHYSICS)
		cracker:SetSolid(SOLID_VPHYSICS)
		cracker:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
		cracker:PhysWake()

		if data.cracker_trail then zclib.Effect.ParticleEffectAttach(data.cracker_trail, PATTACH_POINT_FOLLOW, cracker, 0) end

		local phys = cracker:GetPhysicsObject()
		if IsValid(phys) then phys:SetMaterial("gmod_silent") end

		if data.cracker_size then cracker:SetModelScale(data.cracker_size or 1) end

		//local starttime = CurTime()

		local effect_switch = true
		local timerid = "zww_cracker_timer_" .. self:EntIndex()
		local rep = self.Firework_JumpCount
		local start_delay = data.interval_start or 1
		local cur_delay = start_delay
		zclib.Timer.Create(timerid,cur_delay,rep,function()

			if not IsValid(self) then
				 zclib.Timer.Remove(timerid)
				return
			end

			if not IsValid(cracker) then
				 zclib.Timer.Remove(timerid)
				return
			end


			self:TriggerEffectDelayed({
				parent = cracker,
				delay = 0,
				effect = data.cracker_effect,
				sound = data.cracker_sound,
			})

			phys = cracker:GetPhysicsObject()
			if IsValid(phys) then
				local val = data.move_size or 125
				local posVel = Vector(self:GetSynchRandomNumber(-val, val),self:GetSynchRandomNumber(-val, val),effect_switch and 700 or 0) * phys:GetMass()
				phys:ApplyForceCenter(phys:GetMass() * posVel)

				val = 50
				local angVel = Vector(self:GetSynchRandomNumber(-val, val),self:GetSynchRandomNumber(-val, val),self:GetSynchRandomNumber(-val, val)) * phys:GetMass()
				phys:AddAngleVelocity(angVel)
			end

			local nextEffect
			if effect_switch then
				if istable(data.primary_effect) then
					nextEffect = data.primary_effect[math.random(#data.primary_effect)]
				else
					nextEffect = data.primary_effect
				end
			else
				if istable(data.secondary_effect) then
					nextEffect = data.secondary_effect[math.random(#data.secondary_effect)]
				else
					nextEffect = data.secondary_effect
				end
			end

			self:TriggerEffectDelayed({
				parent = cracker,
				delay = 0,
				effect = nextEffect,
				sound = data.explo_sound,
			})

			effect_switch = not effect_switch

			cur_delay = cur_delay - (start_delay / rep)
			timer.Adjust(timerid,cur_delay)

			if timer.RepsLeft(timerid) <= 1 then

				for i = 1,data.final_count do

					local fEffect
					if istable(data.final_effect) then
						fEffect = data.final_effect[math.random(#data.final_effect)]
					else
						fEffect = data.final_effect
					end

					self:TriggerEffectDelayed({
						parent = cracker,
						delay = 0,
						effect = fEffect,
						sound = data.final_sound or data.explo_sound,
						ang = Angle((360 / data.final_count) * i,(360 / data.final_count) * i,(360 / data.final_count) * i)
					})
				end

				if IsValid(phys) then
					phys:EnableMotion(false)
				end
				cracker:SetNoDraw(true)

				timer.Simple(2,function()
					cracker:StopParticles()
					zclib.ClientModel.Remove(cracker)
				end)
			end
		end)
	end
end
