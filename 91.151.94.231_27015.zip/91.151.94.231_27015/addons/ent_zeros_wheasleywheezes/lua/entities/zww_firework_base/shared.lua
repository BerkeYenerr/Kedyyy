ENT.Type					= "anim"
ENT.Base					= "base_anim"
ENT.RenderGroup             = RENDERGROUP_BOTH
ENT.Spawnable		        =  false
ENT.AdminSpawnable		    =  false

ENT.PrintName		        = "FireworkName"
ENT.Author					= "ClemensProduction aka Zerochain"
ENT.Information				= "info"
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_decoy_box.mdl"
ENT.AutomaticFrameAdvance   = true
ENT.DisableDuplicator		= false


ENT.Firework_Duration       = 5

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)
    /*

        You can use those functions to create delayed effects

        ent:TriggerEffectDelayed(data)



        ent:TriggerShellDelayed(data)

        // Any undefined value will be set to its default value
        ent:TriggerShellDelayed({
            delay = 0.5,
            shell_mdl = "models/props_junk/PopCan01a.mdl",
            shell_trail = "zpc2_shelltrail",
            shell_dir = Vector(0,0,1),
            shell_wind = 0.5,
            shell_sound = "zww_kubi",
            shell_size = 1,
            explo_sound = "zww_explo",
            explo_effect = "zpc2_cake_explosion_green",
        })

    */
end

// Returns a random number which is synch by the clients
function ENT:GetSynchRandomNumber(min,max)
	math.randomseed(math.Round(CurTime()) + self:EntIndex())
	return math.random(min,max)
end
