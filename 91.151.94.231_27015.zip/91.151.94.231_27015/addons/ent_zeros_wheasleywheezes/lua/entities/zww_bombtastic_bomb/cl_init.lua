include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Initialize()
	ParticleEffectAttach("ccbomb_bomb_trail", PATTACH_POINT_FOLLOW, self, 1)

	timer.Simple(1, function()
		if IsValid(self) then
			self:StopParticles()
			ParticleEffect("ccbomb_main", self:GetPos(), self:GetAngles(), nil)
			self:EmitSound("zww_crackling")
			self:EmitSound("zww_explo")
		end
	end)
end
