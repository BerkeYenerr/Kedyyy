AddCSLuaFile()
local BaseClass = baseclass.Get("zww_use_base")
ENT.Type = "anim"
ENT.Base = "zww_use_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Jinx-Off"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item24.mdl"

ENT.ImmunityDuration = 10

ENT.OnItemUse = function(ent,ply)

    if SERVER and IsValid(ply) and ply:IsPlayer() and not timer.Exists("timer.jinxoff." .. ply:SteamID64()) then

        // Makes the player immune against potion effect from the Zeros Herbology script for 10 seconds
        ply.zherb_potionimunity = CurTime() + ent.ImmunityDuration

        local a = ents.Create("hexshield")
        if IsValid(a) then
            a:SetPos(ply:GetPos() + VectorRand() * 10)
            a:SetAngles(ply:GetAngles())
            a:SetOwner(ply)
            a:SetTargetPlayer(ply)
            a:Spawn()
        end

        timer.Create("timer.jinxoff." .. ply:SteamID64(), ent.ImmunityDuration, 1, function()
            for k, v in pairs(ents.GetAll()) do
                if v:GetClass() == "hexshield" and v:GetOwner() == ply then
                    v:Remove()
                end
            end
        end)

        net.Start("spells.protegototalum.addbuff")
        net.WriteEntity(ply)
        net.Send(ply)
    end

    if CLIENT then
        local dlight = DynamicLight(ent:EntIndex( ) )
        if dlight then
            dlight.pos = ent:GetPos( )
            dlight.r = 255
            dlight.g = 235
            dlight.b = 255
            dlight.brightness = 16
            dlight.Decay = 1000
            dlight.Size = 512
            dlight.DieTime = CurTime( ) + 1
        end

        sound.Play("hpwrewrite/spells/godivillio.mp3", ent:GetPos( ), 65, 255)

        zclib.Sound.EmitFromPosition(ent:GetPos(),"potiontable_explosion")
        zclib.Effect.ParticleEffect("zherb_potion_explosion", ent:GetPos(), ent:GetAngles(), ent)
    end
end
