AddCSLuaFile()
local BaseClass = baseclass.Get("zww_box_base")
ENT.Type = "anim"
ENT.Base = "zww_box_base"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Zero´s Wizard Wheezes"
ENT.PrintName = "Teacup - Box"
ENT.Model = "models/zerochain/props_harrypotter/cc_items/cc_item15.mdl"

ENT.OnUnbox = function(ent)

    if SERVER then
        ent:DoActionDelayed(2, function()
            local aent = ents.Create("zww_teacup")
            aent:SetAngles(Angle(0, 0, 0))
            aent:SetPos(ent:GetPos() + Vector(0,0,25))
            aent:Spawn()
            aent:Activate()
        end)

        ent:DoActionDelayed(2, function()
            ent:SetModelScale(0, 1)
        end)

        ent:DoActionDelayed(3, function()
            ent:SetNoDraw(true)
        end)

        SafeRemoveEntityDelayed(ent,4)
    end
end
