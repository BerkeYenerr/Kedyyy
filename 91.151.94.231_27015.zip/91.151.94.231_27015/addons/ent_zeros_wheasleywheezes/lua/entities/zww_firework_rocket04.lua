AddCSLuaFile()
local BaseClass = baseclass.Get("zww_firework_base")
ENT.Type                    = "anim"
ENT.Base                    = "zww_firework_base"
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  true

ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.PrintName		        = "Firework - Special"
ENT.Model                   = "models/zerochain/props_harrypotter/cc_items/cc_item36.mdl"

function ENT:SpawnFunction(ply, tr)
	if (not tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 1
	local ent = ents.Create(self.ClassName)
	local angle = ply:GetAimVector():Angle()
	angle = Angle(0, angle.yaw, 0)
	angle:RotateAroundAxis(angle:Up(), 180)
	ent:SetAngles(angle)
	ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()

	return ent
end

ENT.Firework_Duration       = 5

// This will be used to create one or multiple effect sequences
ENT.Firework_Design = function(ent)

    if SERVER then
        ent:PhysicsInit(SOLID_NONE)
    	ent.PhysgunDisabled = true
    end

    if CLIENT then
        ent:SetNoDraw(true)

        ent:TriggerShellDelayed({
            delay = 0,
            shell_mdl = "models/zerochain/props_harrypotter/cc_items/cc_item37.mdl",
            shell_trail = "zpc2_shelltrail_large",
            shell_dir = Vector(0,0,15),
            shell_wind = 3,
            shell_sound = "zww_rocket_whistle",
            shell_size = 1,
            explo_sound = "zww_explo_sparkstar",
            explo_effect = "zpc2_Yonshakudama_mix",
        })
    end
end
