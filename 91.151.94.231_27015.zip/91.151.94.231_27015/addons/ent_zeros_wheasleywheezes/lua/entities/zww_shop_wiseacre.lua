AddCSLuaFile()
local BaseClass = baseclass.Get("zww_npc_base")
ENT.Type                    = "ai"
ENT.Base                    = "zww_npc_base"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = true
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Wizard Wheezes"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "IVIR ZIVIR SATICISI"
ENT.UI_Y                    = 85
ENT.Model                   = "models/player/ratedr4ryan/booker_darker_npc.mdl"
ENT.ShouldDrawModel         = true

/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end
*/

ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end

AddItem({
    class = "zherb_pot",
    name = "Saksi",
    desc = "Tohumlarinizi buyutmek icin gerekli olan esya, satin aldiginda envanterine gelecek. ",
    model = "models/zerochain/props_herbology/zherb_pot.mdl",
    price = 30,
    tur = "sc"
})


AddItem({
    class = "gazete",
    name = "Gazete",
    desc = "Guncel haberleri takip etmenizi saglar",
    model = "models/props_junk/garbage_newspaper001a.mdl",
    price = 10,
    tur = "sc"
})

/*
AddItem({
    swep = "sh_accessory_changer",
    name = "Acessory Changer (change anywhere anytime)",

    model = "models/effects/hexshield_b.mdl",
    price = 450
})
*/

AddItem({
    swep = "buu_lantern",
    name = "Fener",

    model = "models/weapons/w_lantern.mdl",
    price = 10,
    tur = "sc"
})

AddItem({
    class = "dirdirci",
    name = "Dirdirci Dergisi",
    desc = "Buyuculuk dunyasindaki olaylari takip etmenize yarar ",
    model = "models/sbs/hogwarts/wu/hwm_quibbler_closed.mdl",
    price = 10,
    tur = "sc"
})

AddItem({
    class = "smallbag",
    name = "Kucuk Canta",
    desc = "Envanterinizin alanını buyultur.",
    model = "models/props_c17/suitcase001a.mdl",
    price = 80,
    tur = "sc"
})

AddItem({
    class = "largebag",
    name = "Buyuk Canta",
    desc = "Envanterinizin alanını buyultur.",
    model = "models/props_c17/suitcase001a.mdl",
    price = 100,
    tur = "sc"
})

AddItem({
    class = "buyukutusu2",
    name = "Buyulu Kutu",
    desc = "Rastgele buyu kazanmanızı saglar.",
    model = "models/zerochain/props_fairground/junkbox.mdl",
    price = 40,
    tur = "sc"
})
