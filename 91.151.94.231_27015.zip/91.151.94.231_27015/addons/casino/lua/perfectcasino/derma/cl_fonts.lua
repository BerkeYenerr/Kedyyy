-- This just creates the font. to keep them organised
surface.CreateFont("pCasino.Header.Static", {
	font = "Roboto",
	size = 35,
})
surface.CreateFont("pCasino.Title.Static", {
	font = "Roboto",
	size = 36,
})
surface.CreateFont("pCasino.Entity.Bid", {
	font = "Roboto",
	size = 40,
})
surface.CreateFont("pCasino.Entity.Arrows", {
	font = "Roboto",
	size = 60,
})
surface.CreateFont("pCasino.SubTitle.Static", {
	font = "Roboto",
	size = 24,
})
surface.CreateFont("pCasino.Main.Static", {
	font = "Roboto",
	size = 28,
})
surface.CreateFont("pCasino.Nav.Static", {
	font = "Roboto",
	size = 25,
})
surface.CreateFont("pCasino.Textbox.Static", {
	font = "Roboto",
	size = 20,
	weight = 500,
})
surface.CreateFont("pCasino.Button.Micro", {
	font = "Roboto",
	size = 15,
	weight = 500,
})