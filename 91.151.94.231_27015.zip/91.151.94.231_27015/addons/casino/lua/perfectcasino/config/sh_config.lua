-----------------------
--      IMPORTANT     -
-----------------------
-- The creation of the entities is done in-game with the toolgun.
-- This allows for you to easily have several of the same machine with different configurations,
-- making the addon easier to use in the process.

-----------------------
-- General Config
-----------------------

-- Chat prefix
PerfectCasino.Config.PrefixColor = Color(175, 0, 0)
PerfectCasino.Config.Prefix = "[pCasino]"

--- The usergroups/SteamIDs that get access to the in-game entity maker
PerfectCasino.Config.AccessGroups = {}
PerfectCasino.Config.AccessGroups["superadmin"] = true

-- Para ekleme ve kontrol işlemleri
function PerfectCasino.Config.AddMoney(ply, amount)
    local character = ply:GetCharacter()
    if character then
        if amount < 0 then
            character:TakeMoney(math.abs(amount)) -- Negatif miktarı çıkar
        else
            character:GiveMoney(amount) -- Pozitif miktarı ekle
        end
    end
end

function PerfectCasino.Config.CanAfford(ply, amount)
    local character = ply:GetCharacter()
    return character and character:HasMoney(amount) or false
end

-- Para formatlama
function PerfectCasino.Config.FormatMoney(amount)
    return ix.currency.Get(amount)
end

-----------------------
-- Rewards Functions
-----------------------

PerfectCasino.Config.RewardsFunctions = {}

-- No reward
PerfectCasino.Config.RewardsFunctions["nothing"] = function(ply, ent, inputValue)
    -- No action required
end

-- Helix currency reward
PerfectCasino.Config.RewardsFunctions["money"] = function(ply, ent, inputValue)
    PerfectCasino.Config.AddMoney(ply, inputValue)
end

-- Jackpot handling
PerfectCasino.Config.RewardsFunctions["jackpot"] = function(ply, ent, inputValue)
    local jackpotAmount = ent:GetCurrentJackpot()

    PerfectCasino.Config.AddMoney(ply, jackpotAmount)
    ent:SetCurrentJackpot(ent.data.jackpot.startValue) -- Reset jackpot

    return "You have hit the jackpot, the payout is " .. PerfectCasino.Config.FormatMoney(jackpotAmount)
end

-- Prize wheel spin
PerfectCasino.Config.RewardsFunctions["prize_wheel"] = function(ply, ent, inputValue)
    PerfectCasino.Core.GiveFreeSpin(ply)
end

-- Weapon reward
PerfectCasino.Config.RewardsFunctions["weapon"] = function(ply, ent, inputValue)
    ply:Give(inputValue)
end

-- Health reward
PerfectCasino.Config.RewardsFunctions["health"] = function(ply, ent, inputValue)
    ply:SetHealth(inputValue)
end

-- Armor reward
PerfectCasino.Config.RewardsFunctions["armor"] = function(ply, ent, inputValue)
    ply:SetArmor(inputValue)
end

-- Kill the player
PerfectCasino.Config.RewardsFunctions["kill"] = function(ply, ent, inputValue)
    ply:Kill()
end

-- Change playermodel
PerfectCasino.Config.RewardsFunctions["setmodel"] = function(ply, ent, inputValue)
    ply:SetModel(inputValue)
end

-- Helix XP reward (Example, needs plugin integration)
PerfectCasino.Config.RewardsFunctions["helix_xp"] = function(ply, ent, inputValue)
    local character = ply:GetCharacter()
    if character and character.GiveExperience then
        character:GiveExperience(inputValue)
    end
end

-- Custom currency (for plugins or other systems)
PerfectCasino.Config.RewardsFunctions["custom_currency"] = function(ply, ent, inputValue)
    -- Example for a custom Helix plugin-based system
    local character = ply:GetCharacter()
    if character and character.AddCurrency then
        character:AddCurrency(inputValue)
    end
end

-----------------------
-- Icons Config
-----------------------

if SERVER then return end

-- Custom icons for prize wheels
PerfectCasino.Core.AddIcon("car", "Car", "https://0wain.xyz/icons/pcasino/car.png")
PerfectCasino.Core.AddIcon("money", "Money", "https://0wain.xyz/icons/pcasino/money.png")
PerfectCasino.Core.AddIcon("weapon", "Weapon", "https://0wain.xyz/icons/pcasino/weapon.png")
