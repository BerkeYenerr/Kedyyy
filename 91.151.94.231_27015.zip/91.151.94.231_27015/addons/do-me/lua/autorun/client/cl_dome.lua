surface.CreateFont( "ftcoolxxl", {
    font = "coolvetica",
    extended = false,
    size = 120,
})

net.Receive("slashmeusd2",function()

    local ply = net.ReadEntity()
    local msg = "✿"..net.ReadString().." ✿"

    if ply:IsValid() then
        for k, v in pairs( player.GetAll() ) do
            if v:IsPlayer() then
                if v == LocalPlayer() then
                    hook.Add("PostDrawOpaqueRenderables", ply:SteamID().."me2", function()
                        if ply:IsValid() then
                            local pos = ply:LocalToWorld(ply:OBBCenter()) + Vector(0, 0, 60)
                            local ang = (pos - EyePos()):Angle()
                            local a = 170 - math.Clamp(ply:GetPos():Distance(EyePos()) * 0.8, 0, 170)
                        
                            cam.Start3D2D(pos, Angle(0, ang.y - 90, -ang.p + 90), 0.05)
                                local v1 = ply:GetPos()
                                local v2 = LocalPlayer():GetPos()
                                
                                if v1:Distance(v2) < 500 then 
                                    local color = Color(255, 255, 255, 255)
                                    surface.SetFont("ftcoolxxl")
                                    draw.RoundedBox(3, -(select(1, surface.GetTextSize(msg))/2)-5,-20, select(1, surface.GetTextSize(msg))+10,select(2, surface.GetTextSize(msg))+40, Color(0,0,0,200),TEXT_ALIGN_CENTER)
        
                                    draw.SimpleText(msg, "ftcoolxxl", 0, 0, color, TEXT_ALIGN_CENTER)
                                end 
                            cam.End3D2D()
                        end
                    end)
                end
            end
        end
    end

end)

net.Receive("kafaustubitir", function()
    local ply = net.ReadEntity()
    hook.Remove("PostDrawOpaqueRenderables", ply:SteamID().."me2")
end)

local meCol = Color(163,0,0) -- Change me color here
local doCol = Color(15,177,189) -- Change do color here

Arrondissement = 16 -- Default : 16
CouleurTexte = Color(3, 207, 252) -- Default : 255, 255, 255
CouleurBox = Color(3,3,3,131) -- Default : 3,3,3,131
local TEXT_ALIGN_CENTER = TEXT_ALIGN_CENTER
local RealTime = RealTime
local FrameTime = FrameTime
local EyeAngles = EyeAngles
local ipairs = ipairs
local Lerp = Lerp
local Color = Color
local draw = draw
local surface = surface
local cam = cam
local draw_GetFontHeight = draw.GetFontHeight
local draw_RoundedBox = draw.RoundedBox
local draw_SimpleText = draw.SimpleText
local surface_SetFont = surface.SetFont
local surface_GetTextSize = surface.GetTextSize
local cam_Start3D2D = cam.Start3D2D
local cam_End3D2D = cam.End3D2D
surface.CreateFont("3DCHAT", {font = "Roboto", size = 256})
local offset = Vector(0, 0, 35)
local colw, colb = CouleurTexte, CouleurBox

hook.Add("PostPlayerDraw", "3DCHAT_PostPlayerDraw", function(ply)
    if (!ply.m_bHas3DMessage) then return end

    local e = ply:EyePos() + offset
    local rt = RealTime()
    local ft = FrameTime() * 2
    local fh = draw_GetFontHeight("3DCHAT")
    local ang = EyeAngles()

    ang:RotateAroundAxis(ang:Forward(), 90)
    ang:RotateAroundAxis(ang:Right(), 90)
    local y = 0
    for i = 0, #ply.m_3DMessages do
        local v = ply.m_3DMessages[#ply.m_3DMessages - i]
        if (!v) then
            continue end
        v.alpha = Lerp(ft, v.alpha, v.endtime > rt and 1 or 0)
        v.y = Lerp(ft, v.y, y)

        if (v.endtime < rt and v.alpha <= 0.01) then
            table.remove(ply.m_3DMessages, _)
            if (table.Count(ply.m_3DMessages) == 0) then
                ply.m_bHas3DMessage = false
            end
            return
        end
        
        colw.a = 10 * v.alpha
        colb.a = 10 * v.alpha
        cam_Start3D2D(e, ang, v.scale)
            draw_RoundedBox(Arrondissement, -v.wi * 0.5, v.y - v.he * 0.1, v.wi, v.he, colb)
            draw_SimpleText(v.msg, "3DCHAT", 0, v.y + v.he * 0.4 , v.colorMsg, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            y = y - fh - 16
        cam_End3D2D()
    end
end)

net.Receive("dome_msg", function()
    local isDo = net.ReadBool()
    local ply = net.ReadEntity()
    local msg = net.ReadString()

    if (!IsValid(ply)) then return end

    if isDo then
        msgCol = doCol
    else
        msgCol = meCol
    end

    surface_SetFont("3DCHAT")
    
    local wi, he = surface_GetTextSize(msg)
    wi = wi + 16
    ply.m_3DMessages = ply.m_3DMessages or {}
    ply.m_bHas3DMessage = true
    
    if (#ply.m_3DMessages >= 5) then
        table.remove(ply.m_3DMessages, 1)
    end
    
    table.insert(ply.m_3DMessages, {
        scale = (100 - msg:len()) / 200 * 0.08,
        msg = msg,
        colorMsg = msgCol,
        start = RealTime(),
        endtime = RealTime() + 6,
        alpha = 0,
        y = 0,
        wi = wi,
        he = he,
    })
end)

net.Receive("zar_msg", function()
    local isChar = net.ReadBool()
    local ply = net.ReadEntity()
    local msg = net.ReadString()

    if (!IsValid(ply)) then return end

    if isChar then
        msgCol = Color(0, 255, 0)
    else
        msgCol = Color(255, 0, 0)
    end

    surface_SetFont("3DCHAT")
    
    local wi, he = surface_GetTextSize(msg)
    wi = wi + 16
    ply.m_3DMessages = ply.m_3DMessages or {}
    ply.m_bHas3DMessage = true
    
    if (#ply.m_3DMessages >= 5) then
        table.remove(ply.m_3DMessages, 1)
    end
    
    table.insert(ply.m_3DMessages, {
        scale = (100 - msg:len()) / 200 * 0.08,
        msg = msg,
        colorMsg = msgCol,
        start = RealTime(),
        endtime = RealTime() + 6,
        alpha = 0,
        y = 0,
        wi = wi,
        he = he,
    })
end)
