if (SERVER) then
	util.AddNetworkString("dome_msg")
	AddCSLuaFile()
	AddCSLuaFile("client/cl_dome.lua")
else
	include("client/cl_dome.lua")
end