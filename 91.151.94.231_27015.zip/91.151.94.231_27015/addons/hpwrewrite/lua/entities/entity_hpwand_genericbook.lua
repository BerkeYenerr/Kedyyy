/*
*   @package        rcore
*   @module         spells
*/

/*
*   standard tables and localization
*/

rcore 					= rcore or { }
local base              = rcore
local helper            = rlib.h
local access            = rlib.a
local storage           = rlib.s

/*
*   module calls
*/

local mod, prefix  		= base:modules_load( 'spells', true )
local cfg          		= base:modules_settings( mod )

/*
*   Localized call func
*
*   @source : lua\autorun\libs\_calls
*   @param  : str t
*   @param  : varg { ... }
*/

local function call( t, ... )
    return rlib:call( t, ... )
end

/*
*	Localized translation func
*/

local function lang( ... )
    return rlib:translate( mod, ... )
end

/*
*	prefix ids
*/

local function pref( str, suffix )
    local state = not suffix and mod or isstring( suffix ) and suffix or false
    return rlib.get:pref( str, state )
end

AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = cfg.spellbook_base or "entity_hpwand_bookbase"
ENT.PrintName = HpwRewrite.CategoryNames.Generic
ENT.Category = "Harry Potter Spell Packs"
ENT.Author = "Wand"
ENT.AdminOnly = true

ENT.Model = "models/hpwrewrite/books/book2.mdl"

ENT.Spawnable =  true

local cat = HpwRewrite.CategoryNames.Generic

function ENT:GiveSpells(activator, caller)
	for k, v in pairs(HpwRewrite:GetSpells()) do
		if istable(v.Category) then
			if table.HasValue(v.Category, cat) then
				HpwRewrite:PlayerGiveLearnableSpell(activator, k, true)
			end
		elseif v.Category == cat then
			HpwRewrite:PlayerGiveLearnableSpell(activator, k, true)
		end
	end

	return true
end
