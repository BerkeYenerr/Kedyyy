local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
Lupin'in kendi asasıdır.
]]

Skin.Year = [[
]]

Skin.Ders = [[
]]


Skin.ViewModel = Model("models/hpwrewrite/c_lupinwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_lupinwand.mdl")

Skin.NodeOffset = Vector(1600, 85, 0)

HpwRewrite:AddSkin("Lupin Wand", Skin)