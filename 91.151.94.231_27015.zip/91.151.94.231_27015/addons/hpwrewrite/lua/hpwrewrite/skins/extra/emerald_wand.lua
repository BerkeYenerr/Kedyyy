local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
	Emerald wand. 
]]

Skin.ViewModel = Model("models/hpwrewrite/c_emeraldwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_emeraldwand.mdl")


Skin.NodeOffset = Vector(113, -293, 0)



HpwRewrite:AddSkin("Emerald Wand", Skin)