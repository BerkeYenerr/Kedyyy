local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
Tonks'un özel asasıdır.
]]

Skin.Year = [[
]]

Skin.Ders = [[
]]



Skin.ViewModel = Model("models/hpwrewrite/c_tonkswand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_tonkswand.mdl")

Skin.NodeOffset = Vector(1000, -40, 0)

HpwRewrite:AddSkin("Tonks Wand", Skin)

----
local Skin = { }

Skin.Description = [[
	Mürver Asa varolan en güçlü 
	asadır ve gerçek efendisi 
	tarafından kullanıldığında 
	o kişi hiçbir düelloda 
	alt edilemez.
	
	Ölüm Yadigarlarının ilki olan 
	Kadim Asadır.
]]

Skin.ViewModel = Model("models/fuzion/hpwrewrite/new9.mdl")
Skin.WorldModel = Model("models/fuzion/hpwrewrite/new9.mdl")
Skin.HoldType = "melee"

Skin.NodeOffset = Vector(757, -440, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("ozel asa 3", Skin)