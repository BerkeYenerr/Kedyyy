local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
	Buz asası.
]]

Skin.ViewModel = Model("models/hpwrewrite/c_frostwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_frostwand.mdl")


Skin.NodeOffset = Vector(303, -153, 0)



HpwRewrite:AddSkin("Frost Wand", Skin)