local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
	Lav asa. 
]]

Skin.ViewModel = Model("models/hpwrewrite/c_lavawand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_lavawand.mdl")


Skin.NodeOffset = Vector(103, -653, 0)



HpwRewrite:AddSkin("Lava Wand", Skin)