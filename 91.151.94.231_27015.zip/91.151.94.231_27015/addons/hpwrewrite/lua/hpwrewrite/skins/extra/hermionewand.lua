local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
Hermione'nin Asasıdır.
]]

Skin.Year = [[
]]

Skin.Ders = [[
]]


Skin.ViewModel = Model("models/konnie/hermionewand/c_hermionenew.mdl")
Skin.WorldModel = Model("models/konnie/hermionewand/w_hermionenew.mdl")

Skin.NodeOffset = Vector(1300, -40, 0)

HpwRewrite:AddSkin("Hermione Wand", Skin)