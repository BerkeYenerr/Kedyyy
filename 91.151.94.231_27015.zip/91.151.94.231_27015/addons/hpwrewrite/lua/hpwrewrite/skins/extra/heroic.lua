local Skin = { }

Skin.Description = [[
	Bilinmeyen bir büyücü
	tarafından yapılmıştır.
]]

Skin.ViewModel = Model("models/hpwrewrite/c_heroicwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_heroicwand.mdl")
Skin.HoldType = "melee"

Skin.NodeOffset = Vector(1273, -593, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("Heroic Wand", Skin)