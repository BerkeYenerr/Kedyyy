local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
	Hagrid'in asasıdır. 
]]

Skin.ViewModel = Model("models/hpwrewrite/c_kedi_semsiyewand.mdl")
Skin.WorldModel = Model("models/hpwrewrite/c_kedi_semsiyewand.mdl")


Skin.NodeOffset = Vector(1273, -793, 0)



HpwRewrite:AddSkin("Hagrid Wand", Skin)