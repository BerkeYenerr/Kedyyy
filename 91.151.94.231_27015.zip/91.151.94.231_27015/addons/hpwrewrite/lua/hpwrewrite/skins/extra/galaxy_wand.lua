local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
	Galaksi asası. 
]]

Skin.ViewModel = Model("models/hpwrewrite/c_galaxywand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_galaxywand.mdl")


Skin.NodeOffset = Vector(1273, -793, 0)



HpwRewrite:AddSkin("Galaxy Wand", Skin)