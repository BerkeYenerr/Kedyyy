local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
	Şeytani asa. 
]]

Skin.ViewModel = Model("models/hpwrewrite/c_satanicwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_satanicwand.mdl")


Skin.NodeOffset = Vector(340, -465, 0)



HpwRewrite:AddSkin("Satanic Wand", Skin)