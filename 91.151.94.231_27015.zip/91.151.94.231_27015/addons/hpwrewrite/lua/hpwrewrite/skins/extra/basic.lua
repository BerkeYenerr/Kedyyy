local Skin = { }

Skin.Description = [[
	Bu asa bilinmeyen
	bir büyücünün
	asasıdır.
]]

Skin.ViewModel = Model("models/hpwrewrite/c_basicwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_basicwand.mdl")
Skin.HoldType = "melee"

Skin.NodeOffset = Vector(1033, -83, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("Basic Wand", Skin)