local Skin = { }

Skin.Base = "Wand"

Skin.Description = [[
Harry Potter'ın Asasıdır.
]]

Skin.Year = [[
]]

Skin.Ders = [[
]]


Skin.ViewModel = Model("models/hpwrewrite/c_kedi_harrywand1.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_kedi_harrywand.mdl")

Skin.NodeOffset = Vector(1300, -40, 0)

HpwRewrite:AddSkin("Harry Wand", Skin)