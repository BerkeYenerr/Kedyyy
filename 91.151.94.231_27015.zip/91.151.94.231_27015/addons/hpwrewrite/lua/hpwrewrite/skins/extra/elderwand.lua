local Skin = { }

Skin.Description = [[
	Mürver Asa varolan en güçlü 
	asadır ve gerçek efendisi 
	tarafından kullanıldığında 
	o kişi hiçbir düelloda 
	alt edilemez.
	
	Ölüm Yadigarlarının ilki olan 
	Kadim Asadır.
]]

Skin.ViewModel = Model("models/hpwrewrite/c_kedi_elderwand1.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_elderwand.mdl")
Skin.HoldType = "melee"

Skin.NodeOffset = Vector(757, -440, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("Elder Wand", Skin)