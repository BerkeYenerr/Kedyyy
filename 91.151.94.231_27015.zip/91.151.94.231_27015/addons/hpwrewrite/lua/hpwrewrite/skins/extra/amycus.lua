local Skin = { }

Skin.Description = [[
	Amycus'un asası.
]]

Skin.ViewModel = Model("models/hpwrewrite/c_amycuswand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_amycuswand.mdl")
Skin.HoldType = "melee"

Skin.NodeOffset = Vector(1273, -453, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("Amycus Wand", Skin)

local Skin = { }

Skin.Description = [[
	Olta Asası.
]]

Skin.ViewModel = Model("models/jason_isaacs/c_oltaasa_kedi.mdl")
Skin.WorldModel = Model("models/jason_isaacs/w_oltaasa_kedi.mdl")
Skin.HoldType = "pistol"

Skin.NodeOffset = Vector(1273, -453, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("Rod Wand", Skin)