local Skin = { }

Skin.Description = [[
	Fenrir'in asası.
]]

Skin.ViewModel = Model("models/hpwrewrite/c_fenrirwand_kedi.mdl")
Skin.WorldModel = Model("models/hpwrewrite/w_fenrirwand.mdl")
Skin.HoldType = "melee"

Skin.NodeOffset = Vector(1073, 60, 0)

function Skin:OnFire(wand)
	-- Epic animations for fights
	local vm = wand.Owner:GetViewModel()
	if not vm then return end

	local anim = vm:GetSequence()
	if anim == 5 or anim == 4 then
		self.Owner:ViewPunch(AngleRand() * 0.006)
	end 
end

HpwRewrite:AddSkin("Fenrir Wand", Skin)