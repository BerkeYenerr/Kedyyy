game.AddDecal("HpwFireball", "hpwrewrite/decals/fireball")
game.AddDecal("HpwDremboom", "hpwrewrite/decals/dremboom")
game.AddDecal("HpwForbefire", "hpwrewrite/decals/forbefire")
game.AddDecal("HpwDragoner", "hpwrewrite/decals/dragoner")
game.AddDecal("HpwDisarmCurse", "hpwrewrite/decals/disarmcurse")

for i = 1, 5 do
	game.AddDecal("HpwDeprimoCrack" .. i, "hpwrewrite/decals/cracks/crack" .. i)
end
