HpwRewrite.Language = HpwRewrite.Language or { }
HpwRewrite.Language.Languages = HpwRewrite.Language.Languages or { }

HpwRewrite.Language.CurrentLanguage = "en"

function HpwRewrite.Language:AddLanguage(codename, name)
	if self.Languages[codename] then return end

	self.Languages[codename] = { }
	self.Languages[codename].Name = name
	self.Languages[codename].Dictonary = { }
end

function HpwRewrite.Language:AddWord(lCodeName, index, word)
	local lang = self.Languages[lCodeName] 
	if not lang then print("[Wand] Language " .. lCodeName .. " not found!") return end

	lang.Dictonary[index] = word
end

function HpwRewrite.Language:GetWord(index, lCodeName)
	lCodeName = lCodeName or self.CurrentLanguage
	local lang = self.Languages[lCodeName]
	if not lang then return end

	local word = lang.Dictonary[index]

	if not word then 
		lang = self.Languages["en"] -- Default one

		if lang then
			word = lang.Dictonary[index]

			if not word then
				return index
			end

			return word
		end
	end

	return word
end

HpwRewrite:IncludeFolder("hpwrewrite/language", true)

-- Defaulting to ENGLISH if your homelang is not found

local cvar = GetConVar("gmod_language")
if cvar then
	if HpwRewrite.Language.Languages[string.lower(cvar:GetString())] then
		HpwRewrite.Language.CurrentLanguage = string.lower(cvar:GetString())
	end
else
 	print("[Wand] Can't find 'gmod_language' variable!")
end

local customlang = HpwRewrite.CVars.Language
if customlang then
	local val = customlang:GetString()
	if val != customlang:GetDefault() and HpwRewrite.Language.Languages[val] then
		HpwRewrite.Language.CurrentLanguage = string.lower(val)
	end
end
