if SERVER then return end
if not HpwRewrite then return end

HpwRewrite.Manuals = HpwRewrite.Manuals or { }
HpwRewrite.Manuals.FAQ = HpwRewrite.Manuals.FAQ or { }

local function AddQA(question, answer)
	table.insert(HpwRewrite.Manuals.FAQ, { Q = question, A = answer })
end

AddQA("Büyü nasıl öğreneceğim?", "İlk önce öğrenmek istediğiniz büyünün dersine girip kitabı alınız\nsonrasında büyüyü asa menüsünden \"öğrenmeye başla\" butonu ile\nöğreniniz.")
AddQA("Bir büyüyü nasıl tuşa atarım?", "Asa menüsünde tuş atama sekmesine girip \"tuş atama oluştur\"\nistediğiniz büyüyü seçip \"giriş\" dediğinizde bir tuş atadığınızda\nişlem bitecektir.")
AddQA("Aradığımı bulamadım?", "Bir yetkiliye danışarak sorunu çözebilirsiniz.")

--AddQA("Where is Favourite spells like in old wand addon?", "Favourite spells replaced with custom RPG styled spellbar and binds.\nTo bind something go to Binding tab, choose tree or create new one, click 'Create bind',\nenter spell, click 'Enter' and press any key you want to bind spell to")

function HpwRewrite.Manuals.PrintFAQ()
	for k, v in pairs(HpwRewrite.Manuals.FAQ) do
		MsgC(HpwRewrite.Colors.Blue, "Q:")
		local question = string.Explode("\n", v.Q)
		for _, str in pairs(question) do
			MsgC(HpwRewrite.Colors.White, "  " .. str .. "\n")
		end

		MsgC(HpwRewrite.Colors.Blue, "A:")
		local answer = string.Explode("\n", v.A)
		for _, str in pairs(answer) do
			MsgC(HpwRewrite.Colors.White, "  " .. str .. "\n")
		end

		MsgC(HpwRewrite.Colors.Blue, string.rep(".", 60) .. "\n")
	end
end


HpwRewrite.Manuals.License = [[
The MIT License (MIT)

Copyright (c) 2017 G-P.R.O Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without
limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons
to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.
]]

HpwRewrite.Manuals.KnownBugs = {
	"Animations are not stable when in multiplayer. Can't be fixed due to Source Engine",
	"In DarkRP gamemode throwing damage doesnt work because of DarkRP's spawn protection",
	"Autofire animations in multiplayer look strange"
}

HpwRewrite.Manuals.Contributors = {
	["ProfessorBear"] = "http://steamcommunity.com/profiles/76561198073333911",
	["calafex"] = "http://steamcommunity.com/profiles/76561198076062109/",
	["EgrOnWire"] = "https://steamcommunity.com/profiles/76561198060367130",
	["battlefield 4 russian"] = "http://steamcommunity.com/profiles/76561197980596537/",
	["CrishNate"] = "http://steamcommunity.com/profiles/76561198039998355/"
}





