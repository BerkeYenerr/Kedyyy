NPCRobSystem.Language = {}

-- If you run into any issues and the addon throws errors at you, contact me through a support ticket, or add me on steam.

/*
===================
The language config
===================
*/

NPCRobSystem.Language.Buy = "Satin Al"
NPCRobSystem.Language.Brought = "You brought %s for ¥%s!"
NPCRobSystem.Language.NoBuyRank = "You do not have permission to buy %s"
NPCRobSystem.Language.NoBuyMoney = "Not enough money to buy %s"

NPCRobSystem.Language.HoldUp = "Hold up the store for\n ¥%s?"
NPCRobSystem.Language.RobStore = "Rob store!"

NPCRobSystem.Language.RobTooFar = "You are too far away to rob the store!"
NPCRobSystem.Language.NoActiveWeapon = "Please equip a weapon before trying to rob the store!"
NPCRobSystem.Language.RobDead = "You are dead!"
NPCRobSystem.Language.RobNotEnGovern = "Not enough government"
NPCRobSystem.Language.RobNotEnPly = "Not enough players"
NPCRobSystem.Language.RobNotJob = "You are not the right job to rob"
NPCRobSystem.Language.RobGlobalNotif = "%s is holding up a General Store for ¥%s, it will be done in %is"
NPCRobSystem.Language.RobGlobalNotifComp = "%s has robbed a General Store for ¥%s"	
NPCRobSystem.Language.RobCoolDown = "This NPC can't be robbed for another %is!"
NPCRobSystem.Language.RobFail = "%s has failed to rob the store for ¥%s"
NPCRobSystem.Language.CopRobTitle = "%s is being robbed!"
NPCRobSystem.Language.CopRobDis = "Distance: %im"

NPCRobSystem.Language.CurrentBeingRobbed = "The store is currently being robbed! This will take %i more seconds"
