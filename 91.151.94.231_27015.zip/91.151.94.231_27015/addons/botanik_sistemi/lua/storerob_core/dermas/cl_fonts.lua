-- This just creates the font. to keep them organised

surface.CreateFont( "npcrob_title", {
    font = "harry p",
    size = 120,
    weight = 100
})
surface.CreateFont( "npcrob120", {
	font = NPCRobSystem.Config.Font,
	size = 120,
	weight = 100
})
surface.CreateFont( "npcrob80", {
	font = NPCRobSystem.Config.Font,
	size = 80,
	weight = 100
})
surface.CreateFont( "npcrob50", {
	font = NPCRobSystem.Config.Font,
	size = 50,
	weight = 100
})
surface.CreateFont( "npcrob44", {
	font = NPCRobSystem.Config.Font,
	size = 44,
	weight = 100
})
surface.CreateFont( "npcrob42", {
	font = NPCRobSystem.Config.Font,
	size = 42,
	weight = 100
})
surface.CreateFont( "npcrob40", {
	font = NPCRobSystem.Config.Font,
	size = 40,
	weight = 100
})
surface.CreateFont( "npcrob35", {
	font = NPCRobSystem.Config.Font,
	size = 35,
	weight = 100
})
surface.CreateFont( "npcrob30", {
	font = NPCRobSystem.Config.Font,
	size = 30,
	weight = 100
})
surface.CreateFont( "npcrob25", {
	font = NPCRobSystem.Config.Font,
	size = 25,
	weight = 100
})
surface.CreateFont( "npcrob20", {
	font = NPCRobSystem.Config.Font,
	size = 20,
	weight = 100
})