ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Model = "models/props/eryk/farmingmod/seedbag.mdl"
ENT.AutomaticFrameAdvance = true
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.PrintName = "Seed"
ENT.Category = "Herbology & Potions"
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:SetupDataTables()
    self:NetworkVar("Int", 1, "SeedID")
    self:NetworkVar("Int", 2, "Amount")
    if (SERVER) then
        self:SetSeedID(0)
        self:SetAmount(0)
    end
end
