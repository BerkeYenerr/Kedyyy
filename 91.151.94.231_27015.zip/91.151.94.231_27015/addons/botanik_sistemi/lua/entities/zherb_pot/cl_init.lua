include("shared.lua")

function ENT:Initialize()
	zherb.Pot.Initialize(self)
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Draw()
	zherb.Pot.Draw(self)
end

function ENT:OnRemove()
	zherb.Pot.OnRemove(self)
end

function ENT:Think()
	zherb.Pot.Think(self)
	self:SetNextClientThink(CurTime())
	return true
end
