ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Model = "models/zerochain/props_herbology/zherb_pot.mdl"
ENT.AutomaticFrameAdvance = true
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.PrintName = "Plant Pot"
ENT.Category = "Herbology & Potions"
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:SetupDataTables()
    self:NetworkVar("Int", 1, "PlantID")
    self:NetworkVar("Int", 3, "Progress")
    self:NetworkVar("Int", 2, "Water")
    self:NetworkVar("Entity", 1, "Plant")

    if (SERVER) then
        self:SetPlantID(-1)
        self:SetProgress(0)
        self:SetWater(0)
        self:SetPlant(NULL)
    end
end
