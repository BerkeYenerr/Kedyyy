include("shared.lua")

function ENT:Initialize()
	zherb.NPC.Initialize(self)
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Draw()
	self:DrawModel()
	zherb.NPC.Draw(self)
end
