include("shared.lua")

function ENT:Initialize()
	zherb.Potiontable.Initialize(self)
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Draw()
	zherb.Potiontable.Draw(self)
end

function ENT:OnRemove()
	zherb.Potiontable.OnRemove(self)
end

function ENT:Think()
	zherb.Potiontable.Think(self)
	self:SetNextClientThink(CurTime())
	return true
end
