ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Model = "models/zerochain/props_herbology/zherb_potiontable.mdl"
ENT.AutomaticFrameAdvance = true
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.PrintName = "Potion Table"
ENT.Category = "Herbology & Potions"
ENT.RenderGroup = RENDERGROUP_BOTH


function ENT:SetupDataTables()
    self:NetworkVar("Int", 1, "PotionID")
    self:NetworkVar("Int", 2, "BrewStart")
    self:NetworkVar("Int", 3, "ErrorStart")

    if (SERVER) then
        self:SetPotionID(0)
        self:SetBrewStart(0)
        self:SetErrorStart(-1)
    end
end

function ENT:OnMiniGame(ply)
    local trace = ply:GetEyeTrace()
    local lp = self:WorldToLocal(trace.HitPos)
    if lp.x > -12 and lp.x < 12 and lp.y < 19 and lp.y > 12.5 and lp.z > 38 and lp.z < 40 then
        return true
    else
        return false
    end
end
