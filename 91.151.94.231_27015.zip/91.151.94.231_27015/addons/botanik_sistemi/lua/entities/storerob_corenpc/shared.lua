ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.PrintName = "NPC Store/Rob"
ENT.Author = "Owain Owjo"
ENT.Category = "Herbology & Potions"
ENT.Spawnable = true
ENT.AdminSpawnable = true
