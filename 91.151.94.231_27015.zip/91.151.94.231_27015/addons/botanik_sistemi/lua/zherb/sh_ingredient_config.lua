zherb = zherb or {}
zherb.config = zherb.config or {}
zherb.config.Ingredients = {}

zherb.config.Ingredient_ListID = {}
local function AddIngredient(data) local id = table.insert(zherb.config.Ingredients,data) zherb.config.Ingredient_ListID[data.uniqueid] = id return id end

ZHERB_ING_WITCHSGANGLION = AddIngredient({

	// This will be used to identify the item later (This needs to be a uniqueid)
	uniqueid = "witchsganglion",

	// Name of the ingredient
	name = "Witch's ganglion",

	// Some info
	desc = "Cadı ganglionu, büyülü özelliklere sahip nadir bir bitkidir. Titreyen belirgin bir kan kırmızısı ampulü vardır.",

	// Model
	model = "models/alchemy/ingredbile.mdl",

	// If defined the model will be colored
	//color = Color(40, 201, 230, 255),

	// If defined the skin will be changed
	//skin = 1,

	// If defined the bodygroup will be changed
	//bodygroup = {1,1},
})

ZHERB_ING_SPIDER = AddIngredient({uniqueid = "spider",name = "Örümcek parçası",desc = "Bir örümceğin başı.",model = "models/food/spider/spidercarcass_head.mdl",})
ZHERB_ING_CHICKEN = AddIngredient({uniqueid = "chicken",name = "Tavuk",desc = "E Tavuk",model = "models/food/chicken/roasted_chicken.mdl",})
ZHERB_ING_CHERRY = AddIngredient({uniqueid = "cherry",name = "Kiraz",desc = "Kediotu bitkisinin kökü.",model = "models/tsbb/fruits/cherry.mdl",})
ZHERB_ING_VALERIANROOT = AddIngredient({uniqueid = "valerianroot",name = "Kediotu kökü",desc = "Kediotu bitkisinin kökü.",model = "models/alchemy/ingredginseng.mdl",})
ZHERB_ING_ACONITE = AddIngredient({uniqueid = "aconite",name = "Akonit",desc = "Sihirli özelliklere sahip sıradan bir bitki.",model = "models/alchemy/ingrednightshade01.mdl", color = Color(0, 127, 127, 255),})
ZHERB_ING_DITTANY = AddIngredient({uniqueid = "dittany",name = "Dittany",desc = "Güçlü bir şifalı bitki ve onarıcı.",model = "models/alchemy/ingredtobacco01.mdl",})
ZHERB_ING_ALIHOTSY = AddIngredient({uniqueid = "alihotsy",name = "Alihotsy",desc = "Bitkinin yaprakları histeriye ve kontrol edilemeyen kahkahalara neden olabilir.",model = "models/alchemy/ingredprimroseleaves.mdl",})
ZHERB_ING_CHEESE = AddIngredient({uniqueid = "cheese",name = "Peynir",desc = "Sütteki proteinlerin kesilmesiyle oluşan bir yiyecek.",model = "models/foodnhouseholditems/cheesewheel1c.mdl",})
ZHERB_ING_SCURVYGRASS = AddIngredient({uniqueid = "scurygrass",name = "İskorbüt Otu",desc = "Sihirli özelliklere sahip sıradan bir bitki.",model = "models/alchemy/ingreddragonstongue.mdl",})
ZHERB_ING_EXPLODINGFLUID = AddIngredient({uniqueid = "explodingfluid",name = "Patlayıcı Sıvı",desc = "Erumpent'in boynuzunda bulundu.",model = "models/sohald_spike/props/potion_1.mdl", skin = 5,})
ZHERB_ING_LOVAGE = AddIngredient({uniqueid = "lovage",name = "Lovage",desc = "Yüzyıllardır bitkisel ilaçlarda özellikle sindirimi kolaylaştırmak için kullanılmıştır.",model = "models/alchemy/ingredladysmantleleaves.mdl",})
ZHERB_ING_NEWTSPLEEN = AddIngredient({uniqueid = "newtspleen",name = "Semender Dalağı",desc = "Semenderin dalağı.",model = "models/alchemy/ingredironwoodnut.mdl",})
ZHERB_ING_GINGER = AddIngredient({uniqueid = "ginger",name = "Zencefil",desc = "Köksapı, zencefil kökü, yemek pişirmede yüksek aromalı bir baharat olarak ve halk hekimliğinde kullanılan çiçekli bir bitki.",model = "models/alchemy/ingredwhiteseedpod.mdl",})
ZHERB_ING_ARMADILLOBILE = AddIngredient({uniqueid = "armadillobile",name = "Armadillo Safrası",desc = "Bir Armadillo safrası.",model = "models/alchemy/ingredratmeat.mdl",})
ZHERB_ING_SHRIVELFIG = AddIngredient({uniqueid = "shrivelfig",name = "Kuru İncir",desc = "İksirlerde güçlü özelliklere sahip büyülü bir bitki.",model = "models/alchemy/ingredpear.mdl", color = Color(29, 0, 255, 255),})
ZHERB_ING_WORMWOOD = AddIngredient({uniqueid = "wormwood",name = "Wormwood",desc = "Eski zamanlardan beri İksir yapımında kullanılan çok acı bir bitki.",model = "models/alchemy/ingredladysmantleleaves.mdl", color = Color(127, 111, 63, 255),})
ZHERB_ING_BILLYWIGSTINGS = AddIngredient({uniqueid = "billywigstings",name = "Billywig stings",desc = "Billywigs'in sokmaları.",model = "models/items/jewels/purses/big_purse.mdl",})
ZHERB_ING_MANDRAKEROOT = AddIngredient({uniqueid = "mandrakeroot",name = "Adamotu Kökü",desc = "Bir Mandrake'in kökü",model = "models/alchemy/ingredmandrake.mdl",})
ZHERB_ING_STANDARDINGREDIENT = AddIngredient({uniqueid = "standardingredient",name = "Standart Bileşen",desc = "Birçok sihirli uygulama ve özelliğe sahip kuru otların karışımı.",model = "models/items/jewels/purses/big_purse.mdl",})
ZHERB_ING_KNOTGRASS = AddIngredient({uniqueid = "knotgrass",name = "Düğüm Otu",desc = "Sihirli özelliklere sahip bir bitki.",model = "models/alchemy/ingredlotusseed.mdl", color = Color(0, 255, 63, 255),})
ZHERB_ING_FLUXWEED = AddIngredient({uniqueid = "fluxweed",name = "Akı Otu",desc = "Sihirli bir bitki ve şifalı özellikleriyle bilinen hardal ailesinin bir üyesi.",model = "models/alchemy/ingredstinkhorncap01.mdl", color = Color(0, 255, 63, 255),})
ZHERB_ING_LACEWINGFLY = AddIngredient({uniqueid = "lacewigfly",name = "Dantel Sineği",desc = "Adını büyük, şeffaf, bağcıklı kanatlarından alan küçük yeşil böcekler.",model = "models/items/jewels/purses/big_purse.mdl",})
ZHERB_ING_BICORNHORN = AddIngredient({uniqueid = "bicornhorn",name = "Bicorn Boynuzu",desc = "Bicorn Boynuzu.",model = "models/alchemy/ingredminotaurhorn.mdl",})
ZHERB_ING_LEECH = AddIngredient({uniqueid = "leech",name = "Sülük",desc = "Suda yaşayan küçük sümüklü böcek benzeri omurgasızlar",model = "models/alchemy/ingredminotaurhorn.mdl", color = Color(36, 36, 36, 255),})
ZHERB_ING_BLOODROOT = AddIngredient({uniqueid = "bloodroot",name = "Kan Kökü",desc = "Çok yıllık çiçekli bir bitki.",model = "models/alchemy/ingredbloodgrass.mdl",})
ZHERB_ING_BOOMSLANG = AddIngredient({uniqueid = "boomslang",name = "Boomslang Derisi",desc = "Boomslangs derisi belirli iksirlerde, özellikle de Polyjuice Potion'da kullanılır.",model = "models/alchemy/ingredfishscale.mdl",})
ZHERB_ING_ALCOHOL = AddIngredient({uniqueid = "alcohol",name = "Alkol",desc = "Renksiz, uçucu ve yanıcı bir sıvı.",model = "models/sohald_spike/props/potion_3.mdl", skin = 5,})
ZHERB_ING_ANGELSTRUMPET = AddIngredient({uniqueid = "angelstrumpet",name = "Angels Trumpet",desc = "Brugmansia, Güney Amerika'ya özgü çiçekli bitkilerin bir cinsidir.",model = "models/items/jewels/purses/big_purse.mdl", color = Color(255, 255, 255, 255),})
ZHERB_ING_ARNICA = AddIngredient({uniqueid = "arnica",name = "Arnika",desc = "Ayçiçeği ile ilgili bir bitki türü cinsi.",model = "models/alchemy/ingrednightshade01.mdl", color = Color(255, 255, 0, 255),})
ZHERB_ING_CHIZPURFLECARAPACE = AddIngredient({uniqueid = "chizpurflecarapace",name = "Chizpurfle Kabuğu",desc = "Sihirli bir parazit olan Chizpurfle'dan çıkarıldı.",model = "models/weapons/w_bugbait.mdl",})
ZHERB_ING_UNICORNHORN = AddIngredient({uniqueid = "unicornhorn",name = "Unicorn Boynuzu",desc = "Sihirli özelliklere sahip bir tek boynuzlu atın boynuzu.",model = "models/alchemy/ingredunicornhorn.mdl",})
ZHERB_ING_FIRESEED = AddIngredient({uniqueid = "fireseed",name = "Ateş Tohumu",desc = "Ateş tohumu çalısından tohumlar.",model = "models/items/jewels/l02_crystalquest01.mdl", color = Color(190, 22, 22, 255),})
ZHERB_ING_LAVENDER = AddIngredient({uniqueid = "levander",name = "Levander",desc = "Güzel rengi ve sakinleştirici kokusuyla dikkat çeken bir çiçek.",model = "models/alchemy/ingredrice01.mdl", color = Color(29, 0, 255, 255),})
ZHERB_ING_FLOBBERWORMMUCUS = AddIngredient({uniqueid = "flobberwormmucus",name = "Solucan Mukusu",desc = "Flobberworm'dan sümüksü yeşil mukus.",model = "models/items/jewels/purses/big_purse.mdl",})
ZHERB_ING_VALERIANSPRINGS = AddIngredient({uniqueid = "valeriansprings",name = "Kediotu Dalları",desc = "Sihirli özelliklere sahip bir bitki.",model = "models/alchemy/ingredredwortflower.mdl", color = Color(0, 255, 63, 255),})
ZHERB_ING_MOONDEW = AddIngredient({uniqueid = "moondew",name = "Ayçiçeği",desc = "Ayçiceği'nin büyülü özellikleri, Orta Çağ'da druidess Cliodna tarafından keşfedildi.",model = "models/alchemy/ingrednightshade01.mdl", color = Color(191, 255, 127, 255),})
ZHERB_ING_SOPOPHOROUSBEANS = AddIngredient({uniqueid = "sopophorusbean",name = "Sopophorous beans",desc = "Kasvetli bataklıklarda yetişen büyülü bir bitkinin fasulyesi.",model = "models/food/potato/potato.mdl", color = Color(17, 133, 0, 255),})
ZHERB_ING_ROOTOFASPHODEL = AddIngredient({uniqueid = "rootofasphodel",name = "Asphodel'in Kökü",desc = "Asphodel bitkisinin toz haline getirilmiş kökü.",model = "models/alchemy/ingredharrada.mdl",})
ZHERB_ING_SLOTHBRAIN = AddIngredient({uniqueid = "slothbrain",name = "Donuk Beyin",desc = "Bir Tembellikten alınan beyin.",model = "models/alchemy/ingredmutton.mdl",})
ZHERB_ING_MOLY = AddIngredient({uniqueid = "moly",name = "Moly",desc = "Büyüleri etkisiz hale getirmek için yenebilen ve aynı zamanda bir iksir maddesi olarak kullanılan güçlü bir bitki.",model = "models/alchemy/ingredvoidsalts.mdl",})
ZHERB_ING_MINT = AddIngredient({uniqueid = "mint",name = "Nane",desc = "İyileştirici ve serinletici özelliklere sahiptir.",model = "models/mosi/fnv/props/coyotetobacco.mdl",})
ZHERB_ING_BOUNCINGBULB = AddIngredient({uniqueid = "bouncingbulb",name = "Zıplayan Ampul",desc = "Kısıtlanmadığı takdirde etrafta zıplayan büyülü bir bitki.",model = "models/alchemy/ingredonion.mdl", color = Color(125, 85, 255, 255),})
ZHERB_ING_FOXGLOVES = AddIngredient({uniqueid = "foxglove",name = "Yüksük eldiveni",desc = "Canlı çiçekli otsu bitki cinsi.",model = "models/alchemy/grapes01.mdl", color = Color(116, 74, 255, 255),})
ZHERB_ING_FLITTERBY = AddIngredient({uniqueid = "flitterby",name = "Flitterby",desc = "Sihirli bir güve türü.",model = "models/items/jewels/purses/big_purse.mdl",})
ZHERB_ING_HORKLUMP = AddIngredient({uniqueid = "horklump",name = "Horklump",desc = "Büyülü, etli, pembe bir mantar.",model = "models/food/mushroom_blue/mushroom_blue.mdl", color = Color(255, 0, 191, 255),})
ZHERB_ING_BOOMBERRY = AddIngredient({uniqueid = "boomberry",name = "Boom Berry",desc = "Sihirli bir meyve. Suyu onarıcı özelliklere sahiptir.",model = "models/alchemy/ingredmilkthistleseeds.mdl", color = Color(133, 96, 255, 255),})
ZHERB_ING_GRIFFINCLAW = AddIngredient({uniqueid = "griffinclaw",name = "Griffin Pençesi",desc = "Griffin pençesi, ön kısmı kartal, arka kısmı aslanın olduğu büyülü bir canavar.",model = "models/gibs/antlion_gib_small_1.mdl",})
ZHERB_ING_SALAMANDERBLOOD = AddIngredient({uniqueid = "salamanderblood",name = "Semender Kanı",desc = "Ateşte yaşayan bir semenderin kanı.",model = "models/alchemylab/potion_red.mdl",})
ZHERB_ING_BURSTINGMUSHROOM = AddIngredient({uniqueid = "burstinmushroom",name = "Patlayan Mantar",desc = "Bir tür büyük sihirli mantar.",model = "models/alchemy/ingredflyamanitacap01.mdl",})
ZHERB_ING_NETTLE = AddIngredient({uniqueid = "nettle",name = "Isırgan",desc = "Isırgan otu (Urtica diocia) veya yanık ela olarak da bilinir.",model = "models/alchemy/ingredginkgoleaf.mdl",})
ZHERB_ING_DIRIGIBLEPLUM = AddIngredient({uniqueid = "dirigibleplum",name = "Zeplin Erik",desc = "Turuncu turp benzeri sihirli bir meyve. Zeplin erikleri küçük çalılarda baş aşağı büyür.",model = "models/props/eryk/farmingmod/orange.mdl",})
ZHERB_ING_SACTELI = AddIngredient({uniqueid = "sacteli",name = "Saç Teli",desc = "Birinin saçının teli, Çok Özlü İksir yapımında kullanılır.",model = "models/props/eryk/farmingmod/orange.mdl",})
