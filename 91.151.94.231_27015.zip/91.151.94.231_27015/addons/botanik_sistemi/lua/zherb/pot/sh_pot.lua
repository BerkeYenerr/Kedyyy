zherb = zherb or {}
zherb.Pot = zherb.Pot or {}

function zherb.Pot.CatchID(uniqueid)
    return zherb.config.Plant_ListID[uniqueid]
end

// Returns all the valid seeds the player has in his itemstore inv
function zherb.Pot.GetSeeds(ply)
    if not ply then return end
    local char = ply:GetCharacter()
    if not char then return end
    local inven = char:GetInventory()
    if not inven then return end
    local inv = inven:GetItems()
    if not inv then return end

    // Lets build a list of all the Ingredients and their amount, the user currently has in his inventory
    local INV_SeedList = {}
    for k,v in pairs(inv) do
        if v and v.class and v.class == "zherb_item_seed" then
            INV_SeedList[v.data.seedid] = (INV_SeedList[v.data.seedid] or 0) + (v.data.amount or 1)
        end
    end
    return INV_SeedList
end

function zherb.Pot.HasSeed(ply,SeedID)
    local seeds = zherb.Pot.GetSeeds(ply)
    return seeds[zherb.config.Plants[SeedID].uniqueid] ~= nil
end
