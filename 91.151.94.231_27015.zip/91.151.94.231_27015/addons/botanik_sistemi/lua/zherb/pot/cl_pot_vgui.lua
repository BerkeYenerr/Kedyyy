if not CLIENT then return end
zherb = zherb or {}
zherb.Pot = zherb.Pot or {}

///////////////////////////////////////////
///////////////////////////////////////////
local PotVGUI = {}

local function OpenInterface()

    if IsValid(zherb_Pot_panel) then
        zherb_Pot_panel:Remove()
    end

    zherb_Pot_panel = vgui.Create("zherb_vgui_Pot")
end

net.Receive("zherb_Pot_Open", function(len)
    zclib.Debug_Net("zherb_Pot_Open",len)

    LocalPlayer().zherb_Pot = net.ReadEntity()

    // Open Main interface
    OpenInterface()
end)

function PotVGUI:Init()
    self:SetSize(500 * zclib.wM, 500 * zclib.hM)
    self:Center()
    self:MakePopup()
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetDraggable(true)
    self:SetSizable(false)

    self:DockMargin(0,0,0,0)
    self:DockPadding(5,5,5,5)

    local TopContainer = vgui.Create("DPanel", self)
    TopContainer:SetAutoDelete(true)
    TopContainer:SetSize(self:GetWide(), 50 * zclib.hM)
    TopContainer.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w - 55 * zclib.wM, h, zherb.colors["yellow01"])
    end
    TopContainer:Dock(TOP)

    local close_btn = zclib.vgui.ImageButton(self:GetWide() - 49 * zclib.wM,0,50 * zclib.wM,50 * zclib.hM,TopContainer,zherb.materials["close"],function()
        self:Close()
    end,function()
        return false
    end)
    close_btn:Dock(RIGHT)
    close_btn.MainColor = zherb.colors["yellow01"]
    close_btn.IconColor = color_white
    close_btn.Paint = function(s, w, h)

        draw.RoundedBox(0, 0, 0, w, h, s.MainColor)

        surface.SetDrawColor(s.IconColor)
        surface.SetMaterial(zherb.materials["close"])
        surface.DrawTexturedRect(0, 0,w, h)

        if s:IsEnabled() == false then
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
        else
            if s:IsHovered() then
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
            end
        end
    end

    local TitleBox = vgui.Create("DLabel", TopContainer)
    TitleBox:SetAutoDelete(true)
    TitleBox:SetSize(200 * zclib.wM, 50 * zclib.hM)
    TitleBox:SetPos(0 * zclib.wM, 0 * zclib.hM)
    TitleBox:Dock(LEFT)
    TitleBox:SetText("SAKSI")
    TitleBox:SetTextColor(zherb.colors["white01"])
    TitleBox:SetFont(zclib.GetFont("zherb_vgui_font01"))
    TitleBox:SetContentAlignment(5)
    TitleBox:SizeToContentsX( 15 * zclib.wM )

    local PlantID = LocalPlayer().zherb_Pot:GetPlantID()

    // Create Button to activate the pot
    if PlantID == -1 then

        local Main = vgui.Create("DPanel", self)
        Main:SetAutoDelete(true)
        Main:SetSize(self:GetWide(), 300 * zclib.hM)
        Main.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
            draw.SimpleText("Dikim icin saksiyi etkinlestirin.", zclib.GetFont("zherb_vgui_font02"), w / 2, h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            surface.SetDrawColor(zherb.colors["white04"])
            surface.SetMaterial(zherb.materials["zherb_hoeing_icon"])
            surface.DrawTexturedRect(w / 2 - h / 2, 0,h,h)
        end
        Main:Dock(FILL)

        local activate_button = vgui.Create("DButton", self)
        activate_button:SetTall(50 * zclib.wM)
        activate_button:SetText("")
        activate_button:Dock(BOTTOM)
        activate_button:DockMargin(0,0,0,0)
        activate_button.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"])
            draw.SimpleText("Etkinlestir", zclib.GetFont("zherb_vgui_font02"), w / 2, h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            if s:IsHovered() then
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
            end
        end
        activate_button.DoClick = function(s)
            zclib.vgui.PlaySound("UI/buttonclick.wav")

            self:ActivatePot(false)
        end

        local activate_all_button = vgui.Create("DButton", self)
        activate_all_button:SetTall(50 * zclib.wM)
        activate_all_button:SetText("")
        activate_all_button:Dock(BOTTOM)
        activate_all_button:DockMargin(0,0,0,5)
        activate_all_button.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"])
            draw.SimpleText("Hepsini Etkinlestir", zclib.GetFont("zherb_vgui_font02"), w / 2, h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            if s:IsHovered() then
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
            end
        end
        activate_all_button.DoClick = function(s)
            zclib.vgui.PlaySound("UI/buttonclick.wav")

            self:ActivatePot(true)
        end
        return
    end

    // Create dropdown list for plants which are currently in the players itemstore inventory
    if PlantID == 0 then

        local DComboBox = vgui.Create( "DComboBox", self )
        DComboBox:SetTall(40 * zclib.wM)
        DComboBox:Dock(TOP)
        DComboBox:DockMargin(0,5,0,5)
        DComboBox:SetValue( "Sahip Oldugun Tohumlar (TIKLA)" )


        local PlantList = zherb.Pot.GetSeeds(ply)
        if not PlantList then return end

        // Change with seed list from your itemstore inv
        for k,v in pairs(PlantList) do
            print(k)
            if k == nil then continue end
            local plantID 
            for key, value in pairs(zherb.config.Plant_ListID) do 
                if value == k then 
                    plantID = value
                end
            end
            if plantID == nil then continue end
            local plantData = zherb.config.Plants[plantID]
            if plantData == nil then continue end

            // Runs a custom check if it exists
            if plantData.CanGrow and plantData.CanGrow(LocalPlayer()) ~= true then continue end

            DComboBox:AddChoice(plantData.name,plantID )
        end
        DComboBox.OnSelect = function( s, index, value )
            local a_value = s:GetOptionData( index )
            self:SelectSeed(a_value)
        end

        if PlantList and table.Count(PlantList) > 0 then
            if LocalPlayer().zherb_Pot_PlantID and PlantList[zherb.config.Plants[LocalPlayer().zherb_Pot_PlantID].uniqueid] then
                self:SelectSeed(LocalPlayer().zherb_Pot_PlantID)
            else

                for k,v in pairs(PlantList) do
                    self:SelectSeed(zherb.config.Plant_ListID[k])
                    break
                end
            end
        end

    end

    // Give the player the option to SELL HARVERST OR REMOVE
    if PlantID > 0 and LocalPlayer().zherb_Pot:GetProgress() >= zherb.config.Plants[PlantID].water then
        local function AddButton(txt,color,ActionID)
            local b = vgui.Create("DButton", self)
            b:SetTall(50 * zclib.wM)
            b:SetText("")
            b:Dock(TOP)
            b:DockMargin(0,5,0,0)
            b.Paint = function(s, w, h)
                draw.RoundedBox(0, 0, 0, w, h, color)
                draw.SimpleText(txt, zclib.GetFont("zherb_vgui_font02"), w / 2, h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

                if s:IsHovered() then
                    draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
                end
            end
            b.DoClick = function(s)
                zclib.vgui.PlaySound("UI/buttonclick.wav")

                net.Start("zherb_Pot_Finalize")
                net.WriteEntity(LocalPlayer().zherb_Pot)
                net.WriteInt(ActionID,4)
                net.SendToServer()

                self:Close()
            end
        end

        --AddButton("Sat",zherb.colors["yellow01"],1)

        AddButton("Hasat (Envantere Al)",zherb.colors["yellow01"],2)

        AddButton("Kaldır",zherb.colors["yellow01"],3)


        self:InvalidateLayout(true)
        self:SizeToChildren(false, true)
    end
end

function PotVGUI:Paint(w, h)
    surface.SetDrawColor(zherb.colors["white01"])
    surface.SetMaterial(zherb.materials["background"])
    surface.DrawTexturedRect(0, 0,w * 1.3, h)
end

function PotVGUI:ActivatePot(ActivateAll)
    net.Start("zherb_Pot_Activate")
    net.WriteEntity(LocalPlayer().zherb_Pot)
    net.WriteBool(ActivateAll)
    net.SendToServer()

    self:Close()
end

function PotVGUI:SelectSeed(id)

    if IsValid(self.SeedInfo) then self.SeedInfo:Remove() end

    local PlantData = zherb.config.Plants[id]
    if PlantData == nil then return end

    LocalPlayer().zherb_Pot_PlantID = id

    local Main = vgui.Create("DPanel", self)
    Main:SetAutoDelete(true)
    Main:SetSize(self:GetWide(), 300 * zclib.hM)
    Main.Paint = function(s, w, h)
        //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    Main:Dock(FILL)
    self.SeedInfo = Main

    Main:InvalidateLayout(true)
    Main:SizeToChildren(false, true)


    local size = Main:GetWide()
    local mdl = zclib.vgui.ModelPanel({model = PlantData.model,color = PlantData.color,skin = PlantData.skin,bodygroup = PlantData.bodygroup,render = {FOV = 25}})
    mdl:SetSize(size,size)
    mdl:SetParent(Main)
    /*
    mdl.PreDrawModel = function(ent)
        cam.Start2D()

            surface.SetDrawColor(zherb.colors["white01"])
            surface.SetMaterial(zherb.materials["item_bg"])
            surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, size, size)
            //draw.RoundedBox(1,0 * zclib.wM, 0 * zclib.hM, 100 * zclib.wM, 100 * zclib.hM, zherb.colors["white01"])
        cam.End2D()
    end
    */
    mdl:Dock(TOP)
    mdl:DockMargin(0,0,0,5)


    local function AddInfo(parent,dock,txt,font,color)
        local pnl = vgui.Create("DLabel", parent)
        pnl:SetAutoDelete(true)
        pnl:SetSize(size, 25 * zclib.hM)
        pnl:Dock(dock)
        pnl:SetText(txt)
        pnl:SetTextColor(color)
        pnl:SetFont(font)
        pnl:SetContentAlignment(4)
        pnl:DockMargin(5,0,0,5)
        pnl:SizeToContentsY(5 * zclib.hM)
        //pnl:SetWrap(true)

        pnl:InvalidateLayout(true)
        pnl:SizeToContents()
        return pnl
    end

    AddInfo(mdl, TOP, PlantData.name, zclib.GetFont("zherb_vgui_font02"), zherb.colors["white01"])
    AddInfo(mdl, TOP, PlantData.desc, zclib.GetFont("zherb_vgui_font03"), zherb.colors["white01"])
    local GrowTime = AddInfo(mdl, TOP, "Grow Time: " .. zclib.util.FormatTime(PlantData.water), zclib.GetFont("zherb_vgui_font03"), zherb.colors["white01"])
    GrowTime:DockMargin(5,20 * zclib.hM,0,5)

    local function AddList(title,items,list)
        local main = vgui.Create("DPanel", mdl)
        //main:Dock(TOP)
        main:SetAutoDelete(true)
        main:SetSize(size, 200 * zclib.hM)
        main:SetPos(0 * zclib.wM,190 * zclib.hM)
        //main:DockMargin(0,20 * zclib.hM,0,5)
        main.Paint = function(s, w, h)
            //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
        end

        local title_pnl = vgui.Create("DLabel", main)
        title_pnl:SetAutoDelete(true)
        title_pnl:SetSize(size, 30 * zclib.hM)
        title_pnl:Dock(TOP)
        title_pnl:SetText(title)
        title_pnl:SetTextColor(zherb.colors["white01"])
        title_pnl:SetFont(zclib.GetFont("zherb_vgui_font02"))
        title_pnl:SetContentAlignment(7)
        title_pnl:DockMargin(5,5,0,0)

        local layout = vgui.Create("DIconLayout", main)
        layout:SetAutoDelete(true)
        layout:SetSize(size, 100 * zclib.hM)
        layout:Dock(TOP)
        layout:SetSpaceX(5)
        layout:SetSpaceY(5)
        layout:DockMargin(5,0,5,5)
        layout.Paint = function(s, w, h)
            //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
        end
        for _id, val in pairs(items) do
            local data = list[_id]
            if data == nil then continue end
            local itm_size = layout:GetTall()
            local itm = zclib.vgui.ModelPanel({model = data.model,color = data.color,skin = data.skin,bodygroup = data.bodygroup,render = {FOV = 25}})
            itm:SetSize(itm_size,itm_size)
            itm:SetTooltip(data.desc)
            itm.PreDrawModel = function(ent)
                cam.Start2D()
                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(zherb.materials["item_bg"])
                    surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, itm_size,itm_size)
                cam.End2D()
            end
            layout:Add(itm)

            local name_pnl = vgui.Create("DLabel", itm)
            name_pnl:SetAutoDelete(true)
            name_pnl:SetSize(itm:GetWide(), 20 * zclib.hM)
            name_pnl:Dock(BOTTOM)
            name_pnl:SetText(data.name)
            name_pnl:SetTextColor(zherb.colors["white01"])
            name_pnl:SetFont(zclib.GetFont("zherb_vgui_font05"))
            name_pnl:SetContentAlignment(5)
            name_pnl.Paint = function(s, w, h)
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
            end

            local amount_pnl = vgui.Create("DLabel", itm)
            amount_pnl:DockMargin(5,5,5,5)
            amount_pnl:SetAutoDelete(true)
            amount_pnl:SetSize(itm:GetWide(), 20 * zclib.hM)
            amount_pnl:Dock(TOP)
            amount_pnl:SetText("x" .. val)
            amount_pnl:SetTextColor(zherb.colors["white01"])
            amount_pnl:SetFont(zclib.GetFont("zherb_vgui_font02"))
            amount_pnl:SetContentAlignment(9)
            amount_pnl.Paint = function(s, w, h)
                //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
            end
        end
        main:InvalidateLayout(true)
        main:SizeToChildren(false, true)
        main:SetTall(main:GetTall() + 5 * zclib.hM)
    end

    AddList("Hasat Edilen Malzemeler:",PlantData.ingredients,zherb.config.Ingredients)

    local plant_button = vgui.Create("DButton", Main)
    plant_button:SetTall(50 * zclib.wM)
    plant_button:SetText("")
    plant_button:Dock(BOTTOM)
    plant_button:DockMargin(0,0,0,0)
    plant_button.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"])
        draw.SimpleText("Tohumu Yerlestir", zclib.GetFont("zherb_vgui_font02"), w / 2, h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if LocalPlayer().zherb_Pot_PlantID == nil then
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
            return
        end

        if s:IsHovered() then
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
        end
    end
    plant_button.DoClick = function(s)
        zclib.vgui.PlaySound("UI/buttonclick.wav")

        self:PlantSeed()
    end
end

function PotVGUI:PlantSeed()
    net.Start("zherb_Pot_PlantSeed")
    net.WriteEntity(LocalPlayer().zherb_Pot)
    net.WriteInt(LocalPlayer().zherb_Pot_PlantID,16)
    net.SendToServer()

    self:Close()
end

// Close the editor
function PotVGUI:Close()

    LocalPlayer().zherb_Pot = nil

    if IsValid(zherb_Pot_panel) then
        zherb_Pot_panel:Remove()
    end
end

vgui.Register("zherb_vgui_Pot", PotVGUI, "DFrame")
