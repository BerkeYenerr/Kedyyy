if not CLIENT then return end
zherb = zherb or {}
zherb.Pot = zherb.Pot or {}

function zherb.Pot.Initialize(Pot)
    Pot.LastProgess = 0
    Pot.LastScale = 0
    Pot.SmoothScale = 0
    Pot.UIPos = Pot:GetPos()
end

function zherb.Pot.Draw(Pot)
    Pot:DrawModel()

    if zclib.util.InDistance(LocalPlayer():GetPos(), Pot:GetPos(), 500) then

        local PlantData = zherb.config.Plants[Pot:GetPlantID()]
        if PlantData then
            // Pot:GetPos() + Vector(0, 0, 40)
            cam.Start3D2D(Pot.UIPos, Angle(0, LocalPlayer():EyeAngles().y - 90, 90), 0.05)
                draw.RoundedBox(20, -300, -200, 600, 100, zherb.colors["black03"])
                draw.SimpleText(PlantData.name, zclib.GetFont("zherb_font01"), 0, -150, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

                if Pot.LastProgess >= (PlantData.water * 10) then
                    draw.RoundedBox(20, -75, -75, 150, 150, zherb.colors["black03"])
                    draw.SimpleText("[E]", zclib.GetFont("zherb_font01"), 0, 0, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                else

                    draw.RoundedBox(0, -190, -45, 380, 35, zherb.colors["black03"])
                    draw.RoundedBox(0, -190, -45, (380 / (PlantData.water * 10)) * Pot.LastProgess, 35, zherb.colors["green01"])

                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(zherb.materials["progress_forground"])
                    surface.DrawTexturedRect(-200, -55, 400, 50)



                    draw.RoundedBox(0, -190, 5, 380, 35, zherb.colors["black03"])
                    draw.RoundedBox(0, -190, 5, (380 / 100) * Pot:GetWater(), 35, zherb.colors["blue01"])

                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(zherb.materials["progress_forground"])
                    surface.DrawTexturedRect(-200, 0, 400, 50)
                end
            cam.End3D2D()
        end
    end
end

function zherb.Pot.OnRemove(Pot)
end

function zherb.Pot.Think(Pot)

    if zclib.util.InDistance(LocalPlayer():GetPos(), Pot:GetPos(), 500) then

        local plant = Pot:GetPlant()
        Pot.LastProgess = Pot:GetProgress()
        if IsValid(plant) then

            local PlantData = zherb.config.Plants[Pot:GetPlantID()]
            if PlantData then

                // Make sure this scale is never bigger then a certain limit, so model is not too big
                local bound_min,bound_max = plant:GetModelBounds()
                local size = bound_max - bound_min
                size = size:Length()
                local scale = 30 / size

                if PlantData.offset and PlantData.offset.scale then scale = scale * PlantData.offset.scale end

                scale = (scale / (PlantData.water * 10)) * Pot.LastProgess
                Pot.LastScale = scale
                //print(scale)
            end

            Pot.SmoothScale = Lerp(1 * FrameTime(),Pot.SmoothScale,Pot.LastScale)

            local _,max = plant:GetModelBounds()

            local mat = Matrix()
            mat:Scale(Vector(Pot.SmoothScale,Pot.SmoothScale,Pot.SmoothScale))
            mat:SetTranslation(Vector(0, 0, (max.z / 2) * Pot.SmoothScale))
            plant:EnableMatrix("RenderMultiply", mat)

            //local _,Potmax = Pot:GetModelBounds()
            Pot.UIPos = plant:GetPos() + plant:GetUp() * 45//math.Clamp(((Potmax.z * 2) * Pot.SmoothScale), max.z / 2, 15) + Vector(0, 0, 5)
        else
            Pot.LastProgess = 0
            Pot.LastScale = 0
            Pot.SmoothScale = 0
        end
    else
        Pot.LastProgess = 0
        Pot.LastScale = 0
        Pot.SmoothScale = 0
    end
end

net.Receive("zherb_Pot_OnPlantAction", function(len)
    zclib.Debug_Net("zherb_Pot_OnPlantAction", len)
    local ActionID = net.ReadInt(6)
    local Pot = net.ReadEntity()
    local PlantID = net.ReadInt(12)

    if not IsValid(Pot) then return end
    if PlantID == nil then return end

    /*
        1 = PLantedSeed
        2 = OnHarvested
        3 = OnDeath
        4 = OnRemove
    */

    zclib.Debug(tostring(Pot) .. " ActionID: " .. ActionID)

    local PlantData = zherb.config.Plants[PlantID]
    if PlantData == nil then return end

    if ActionID == 1 then
        if PlantID <= 0 then return end

        if PlantData.OnSeedPlanted then PlantData.OnSeedPlanted(Pot,Pot:GetPlant(),nil) end
    elseif ActionID == 2 then
        if PlantData.OnHarvested then PlantData.OnHarvested(Pot,nil) end
    elseif ActionID == 3 then
        if PlantData.OnDeath then PlantData.OnDeath(Pot) end
    elseif ActionID == 4 then
        if PlantData.OnRemove then PlantData.OnRemove(Pot) end
    end
end)
