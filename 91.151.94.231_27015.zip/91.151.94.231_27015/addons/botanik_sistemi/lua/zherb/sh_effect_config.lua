zherb = zherb or {}
zherb.config = zherb.config or {}
zherb.config.Effects = {}
local function AddEffect(data) return table.insert(zherb.config.Effects,data) end


//////////////////////////////////////////////////////////////////////////
/////////////////////////////  HOOKS  ////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
zclib.Hook.Add("Move", "HasteEffect", function(ply, mv, usrcmd)
	if ply.zherb_EffectModifiers and ply.zherb_EffectModifiers["Speed"] and CurTime() < ply.zherb_EffectModifiers["Speed"].time then
		local speed = mv:GetMaxSpeed() * ply.zherb_EffectModifiers["Speed"].val
		mv:SetMaxSpeed(speed)
		mv:SetMaxClientSpeed(speed)
	end
end)

zclib.Hook.Add("PlayerDeath", "PoisonEffect", function(victim, inflictor, attacker)

	// Stop any active effects
	if IsValid(victim) and victim.zherb_ActiveEffect then
		for k,v in pairs(victim.zherb_ActiveEffect) do
			zherb.Effect.End(victim,k)
		end
	end
end)

zclib.Hook.Add("EntityTakeDamage", "DamageModifier", function(target, dmginf)
	if dmginf and IsValid(target) and zherb.Potion.IsTarget(target) and target:Alive() then

		// Scales the damage if the attacker has a strengthen effect
		local attacker = dmginf:GetAttacker()
		if IsValid(attacker) and zherb.Potion.IsTarget(attacker) and attacker:Alive() and attacker.zherb_EffectModifiers and attacker.zherb_EffectModifiers["Damage"] and CurTime() < attacker.zherb_EffectModifiers["Damage"].time and attacker.zherb_EffectModifiers["Damage"].type == "STRENGTH" then
			dmginf:ScaleDamage(attacker.zherb_EffectModifiers["Damage"].scale)
		end

		// Scales the damage if the target has a damage modify
		if target.zherb_EffectModifiers and target.zherb_EffectModifiers["Damage"] and CurTime() < target.zherb_EffectModifiers["Damage"].time then
			local dmg_type = target.zherb_EffectModifiers["Damage"].type
			local dmg_scale = target.zherb_EffectModifiers["Damage"].scale

			if dmg_type then
				if dmg_type == dmginf:GetDamageType() then
					dmginf:ScaleDamage(dmg_scale)
				end
			else
				dmginf:ScaleDamage(dmg_scale)
			end
		end
	end
end)

if CLIENT then
	zclib.Hook.Add("CalcView", "PlayerSize", function(ply, origin, angles, fov, znear, zfar)
		if ply:GetNWBool("zherb_ModifyViewByScale",false) == true then

			// Disables the legs for the Glegs Addon
			hook.Add("ShouldDisableLegs","ShouldDisableLegs_PlayerSize",function()
				return true
			end)

			local height = 72
			if ply:Crouching() == true then height = 36 end
			local view = {
				origin = origin - (angles:Up() * (height - (height * ply:GetModelScale()))),
				angles = angles,
				fov = fov,
				drawviewer = false
			}
			return view
		else
			hook.Add("ShouldDisableLegs","ShouldDisableLegs_PlayerSize",function()
				return false
			end)
		end
	end)

	zclib.Hook.Add("CalcViewModelView", "PlayerSize", function(wep, vm, oldPos, odlang)
		if LocalPlayer():GetNWBool("zherb_ModifyViewByScale",false) == true then
			local height = 72
			if LocalPlayer():Crouching() == true then height = 36 end
			oldPos = oldPos - (odlang:Up() * (height - (height * LocalPlayer():GetModelScale())))
			return oldPos,odlang
		end
	end)

	local LastMoveDistortion = -1
	local MoveStrength = 0
	local MoveSwitch = false
	zclib.Hook.Add("StartCommand","MovementModify", function(ply,ucmd)

		if IsValid(ply) and ply:Alive() then

			local mv_fw = ucmd:GetForwardMove()
			local mv_sd = ucmd:GetSideMove()

			local MoveDistortionStrength = ply:GetNWInt("zherb_DistortMovement", -1)
			if MoveDistortionStrength > 0 then
				if LastMoveDistortion < CurTime() then

					local strength = zherb_DistortMovement

					MoveStrength = math.Rand(-strength,strength)
					MoveSwitch = not MoveSwitch
					LastMoveDistortion = CurTime() + math.Rand(5 / strength, 3)
				else

					if MoveSwitch then
						mv_fw = mv_fw + (10000 * MoveStrength)
						mv_sd = mv_sd + (10000 * MoveStrength)
					end
				end
			end

			local MoveInvertionStrength = ply:GetNWInt("zherb_InvertMovement", -1)
			if MoveInvertionStrength > 0 then
				mv_fw = -mv_fw
				mv_sd = -mv_sd
			end

			ucmd:SetForwardMove(mv_fw)
			ucmd:SetSideMove(mv_sd)
		end
	end)
end
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////




// Gives the player a random health amount between min / max
ZHERB_EFFECT_HEALTH = AddEffect({
	// Name of the effect
	name = "İyileştirme Gücü",

	// Some info
	desc = "Oyuncuların sağlığını arttırır!",

	// What icon should be used
	icon = Material( "materials/zerochain/zherb/ui/zherb_health_icon.png", "noclamp smooth" ),

	// Code to execute
	OnStart = function(ply,data)
		ply:SetHealth(math.Clamp(ply:Health() + math.random(data.min,data.max),0,ply:GetMaxHealth()))
	end,
	OnEnd = function(ply,id)
	end,
})
//////////////////////////////////////////////////////////////////////////


// Gives the player a random armor amount between min / max
ZHERB_EFFECT_ARMOR = AddEffect({
	name = "Zırh Gücü",
	desc = "Oyuncuların zırhını arttırır!",
	icon = Material( "materials/zerochain/zherb/ui/zherb_armor_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		ply:SetArmor(math.Clamp(ply:Armor() + math.random(data.min,data.max),0,ply:GetMaxArmor()))
	end,
	OnEnd = function(ply,id)
	end,
})
//////////////////////////////////////////////////////////////////////////


// Increases the player movement speed
ZHERB_EFFECT_HASTE = AddEffect({
	name = "Hız Gücü",
	desc = "Oyuncuların hareket hızını arttırır!",
	icon = Material( "materials/zerochain/zherb/ui/zherb_speed_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id)
		local inc = math.random(data.min,data.max)
		local speed_mul = (1 / 100) * inc
		ply.zherb_EffectModifiers["Speed"] = {val = speed_mul,time = CurTime() + data.duration}
	end,
	OnEnd = function(ply,id)
		ply.zherb_EffectModifiers["Speed"] = nil
	end,
})
//////////////////////////////////////////////////////////////////////////


// Changes the players model
ZHERB_EFFECT_MODELCHANGE  = AddEffect({
	name = "Görünüm Değiştir",
	desc = "Oyuncu modelini değiştirir.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_modelchange_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id)

		// Dont change the model if we currently got a model change active
		if ply.zherb_EffectModifiers and ply.zherb_EffectModifiers["ModelChange"] and ply.zherb_EffectModifiers["ModelChange"].time and CurTime() < ply.zherb_EffectModifiers["ModelChange"].time then return end

		local LastModel = ply:GetModel()

		// Change model
		ply:SetModel(data.mdl)

		ply.zherb_EffectModifiers["ModelChange"] = {time = CurTime() + data.duration,previous_mdl = LastModel}

		local timerid = "zherb_timer_effect_modelchange_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			zherb.Effect.End(ply,id)
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_modelchange_" .. ply:SteamID64())

		// Reset model
		ply:SetModel(ply.zherb_EffectModifiers["ModelChange"].previous_mdl)

		ply.zherb_EffectModifiers["ModelChange"] = nil
	end,
})

//////////////////////////////////////////////////////////////////////////
ZHERB_EFFECT_MODELCHANGE_COKOZLU  = AddEffect({
	name = "ÇOK OZLU IKSIR!",
	desc = "İçerdiği saç telinin sahibinin şekline bürünür.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_modelchange_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id,ent)

		// Dont change the model if we currently got a model change active
		if ply.zherb_EffectModifiers and ply.zherb_EffectModifiers["ModelChange"] and ply.zherb_EffectModifiers["ModelChange"].time and CurTime() < ply.zherb_EffectModifiers["ModelChange"].time then return end

		local LastModel = ply:GetModel()

		// Change model
		ply:SetModel(ent:GetNWEntity("oyuncu"):GetCharacter():GetModel())
		/*ply.bodygrouplari = ply:GetBodyGroups()
		for k,v in pairs(ent:GetNWEntity("oyuncu"):GetBodyGroups()) do 
			ply:SetBodygroup(v.id, v.num)
		end*/

		ply.zherb_EffectModifiers["ModelChange"] = {time = CurTime() + data.duration,previous_mdl = LastModel}

		local timerid = "zherb_timer_effect_modelchange_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			zherb.Effect.End(ply,id)
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_modelchange_" .. ply:SteamID64())

		// Reset model
		ply:SetModel(ply.zherb_EffectModifiers["ModelChange"].previous_mdl)
		/*for k,v in pairs(ply.bodygrouplari) do 
			ply:SetBodygroup(v.id, v.num)
		end*/

		ply.zherb_EffectModifiers["ModelChange"] = nil
	end,
})
//////////////////////////////////////////////////////////////////////////


// Inflicts poison damage over time
ZHERB_EFFECT_POISON  = AddEffect({
	name = "Zehir Hasarı",
	desc = "Zehir hasarı verir.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_poison_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		local timerid = "zherb_timer_effect_poison_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.interval, data.rep, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end

			local dmg = math.random(data.min,data.max)

			// Damage player
			local d = DamageInfo()
			d:SetDamage(dmg)
			d:SetAttacker(Entity(1))
			d:SetDamageType(DMG_NERVEGAS)
			ply:TakeDamageInfo(d)
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_poison_" .. ply:SteamID64())
	end,
})
ZHERB_EFFECT_ANTIPOISON  = AddEffect({
	name = "Panzehir",
	desc = "Birisi zehirlenirse, bu etkiyi durdurur.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_poison_antidode_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		zclib.Timer.Remove("zherb_timer_effect_poison_" .. ply:SteamID64())
	end,
	OnEnd = function(ply,id)

	end,
})
//////////////////////////////////////////////////////////////////////////

ZHERB_EFFECT_KEMIK = AddEffect({
	// Name of the effect
	name = "Kemik Güçlendirme",

	// Some info
	desc = "Kemiklerini tamir eder!",

	// What icon should be used
	icon = Material( "materials/zerochain/zherb/ui/zherb_health_icon.png", "noclamp smooth" ),

	// Code to execute
	OnStart = function(ply,data)
		if legs_players[ply:SteamID64()] then
			ply:SetWalkSpeed( legs_players[ply:SteamID64()][0] )
			ply:SetRunSpeed( legs_players[ply:SteamID64()][1] )
			ply:ChatPrint("Kemiklerin iyileşti!")
		end
	end,
	OnEnd = function(ply,id)
	end,
})





local function custom_ulx_freeze(target, should_unfreeze)

	if target.ULXExclusive == "frozen" then return end

	if target:InVehicle() then
		target:ExitVehicle()
	end

	if not should_unfreeze then
		target:Lock()
	else
		target:UnLock()
	end

	target:DisallowSpawning(not should_unfreeze)
	ulx.setNoDie(target, not should_unfreeze)

	if target.whipped then
		target.whipcount = target.whipamt
	end
end

if SERVER then

	util.AddNetworkString("zherb_sleep_start")
	util.AddNetworkString("zherb_sleep_stop")

	util.AddNetworkString("zherb_screeneffect_start")
	util.AddNetworkString("zherb_screeneffect_stop")

	// Prevent Text Chat
	zclib.Hook.Add("PlayerSay", "SleepEffect", function(ply)
	    if ply:GetNWBool("zherb_effect_sleep",false) then return "" end
	end)

	// Prevent Voicehat
	zclib.Hook.Add("PlayerCanHearPlayersVoice", "SleepEffect", function(  listener,  talker )
	    if talker:GetNWBool("zherb_effect_sleep",false) then return false end
	end)

	// Prevent Job change
	zclib.Hook.Add("canChangeJob", "SleepEffect", function(ply)
	    if talker:GetNWBool("zherb_effect_sleep",false) then return false, "You are sleeping." end
	end)

	// Prevent Jumping
	zclib.Hook.Add("SetupMove", "SleepEffect", function(ply, mvd, cmd)
		if ply:GetNWBool("zherb_effect_sleep",false) == true and mvd:KeyDown(IN_JUMP) then
			local newbuttons = bit.band(mvd:GetButtons(), bit.bnot(IN_JUMP))
			mvd:SetButtons(newbuttons)
		end
	end)
else

	//local SleepSound_Next = 0
	local ScreenEffect_Duration = 0
	local ScreenEffect_ID
	local ScreenEffects = {
		// Sleep
		[1] = function()

			DrawMotionBlur( 0.1, 1, 0.01 )

			local tab = {
				[ "$pp_colour_addr" ] = 0.0,
				[ "$pp_colour_addg" ] = 0.0,
				[ "$pp_colour_addb" ] = 0.1,
				[ "$pp_colour_brightness" ] = 0,
				[ "$pp_colour_contrast" ] = 0.1,
				[ "$pp_colour_colour" ] = 0,
				[ "$pp_colour_mulr" ] = 0,
				[ "$pp_colour_mulg" ] = 0,
				[ "$pp_colour_mulb" ] = 1
			}
			DrawColorModify(tab)
		end,

		// Bulgeye
		[2] = function()
			DrawMotionBlur( 0.1, 1, 0.01 )

			local tab = {
				[ "$pp_colour_addr" ] = 1,
				[ "$pp_colour_addg" ] = 0.0,
				[ "$pp_colour_addb" ] = 0,
				[ "$pp_colour_brightness" ] = 1,
				[ "$pp_colour_contrast" ] = 0.1,
				[ "$pp_colour_colour" ] = 0,
				[ "$pp_colour_mulr" ] = 1,
				[ "$pp_colour_mulg" ] = 0,
				[ "$pp_colour_mulb" ] = 0
			}
			DrawColorModify(tab)
			DrawMaterialOverlay("effects/tp_eyefx/tpeye3", -0.2)
			DrawMaterialOverlay("effects/water_warp01", 0.1)
		end,

		// Sick GreenNeess
		// Bulgeye
		[3] = function()
			DrawMotionBlur( 0.1, 1, 0.01 )

			local tab = {
				[ "$pp_colour_addr" ] = 0,
				[ "$pp_colour_addg" ] = math.abs(math.sin(CurTime() * 0.25)),
				[ "$pp_colour_addb" ] = 0,
				[ "$pp_colour_brightness" ] = 0,
				[ "$pp_colour_contrast" ] = 1,
				[ "$pp_colour_colour" ] = 0,
				[ "$pp_colour_mulr" ] = 0,
				[ "$pp_colour_mulg" ] = 0.5,
				[ "$pp_colour_mulb" ] = 0
			}
			DrawColorModify(tab)
			DrawMaterialOverlay("effects/tp_eyefx/tpeye3", -0.2)
			//DrawMaterialOverlay("effects/water_warp01", 0.1)
		end,
	}

	sound.Add({
		name = "zherb_sleep_sound",
		channel = CHAN_STATIC,
		volume = 1,
		level = 60,
		pitch = {100, 100},
		sound = "zherb/snoring.wav"
	})

	local function ScreenEffect_Logic()
		if IsValid(LocalPlayer()) and LocalPlayer():Alive() == false then
			LocalPlayer():SetDSP(0)
			zclib.Hook.Remove("RenderScreenspaceEffects", "Sleep")

			return
		end

		if ScreenEffect_Duration > 0 and ScreenEffect_ID then
			ScreenEffect_Duration = math.Clamp(ScreenEffect_Duration - (1 * FrameTime()), 0, 100)

			// Run screen effect
			ScreenEffects[ScreenEffect_ID]()
		else
			LocalPlayer():SetDSP(0)
			zclib.Hook.Remove("RenderScreenspaceEffects", "Sleep")
		end
	end
	net.Receive("zherb_screeneffect_start", function(len)
		ScreenEffect_Duration = net.ReadInt(16)
		ScreenEffect_ID = net.ReadInt(16)
		LocalPlayer():SetDSP(3)
		zclib.Hook.Remove("RenderScreenspaceEffects", "Sleep")
		zclib.Hook.Add("RenderScreenspaceEffects", "Sleep", ScreenEffect_Logic)
	end)
	net.Receive("zherb_screeneffect_stop", function(len)
		ScreenEffect_Duration = 0
		ScreenEffect_ID = nil
		LocalPlayer():SetDSP(0)
		zclib.Hook.Remove("RenderScreenspaceEffects", "Sleep")
	end)

	net.Receive("zherb_sleep_start", function(len)
		local ply = net.ReadEntity()

		if IsValid(ply) then
			zclib.Effect.ParticleEffectAttach("zherb_player_zzz", PATTACH_POINT_FOLLOW,ply, 0)
		end
	end)
	net.Receive("zherb_sleep_stop", function(len)
		local ply = net.ReadEntity()

		if IsValid(ply) then
			ply:StopParticlesNamed("zherb_player_zzz")
		end
	end)
end

// Simulates sleep
ZHERB_EFFECT_SLEEP  = AddEffect({
	name = "Uyku Etkisi",
	desc = "Kişiyi uyutur.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_sleep_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id)

		// Send nw msg to client to make is screen dark and sleepy sound
		net.Start("zherb_screeneffect_start")
		net.WriteInt(data.duration,16)
		net.WriteInt(1,16)
		net.Send(ply)

		// Attach the particle effect for all
		net.Start("zherb_sleep_start")
		net.WriteEntity(ply)
		net.Broadcast()

		ply:SetNWBool("zherb_effect_sleep",true)

		custom_ulx_freeze(ply, false)

		local timerid = "zherb_timer_effect_sleep_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			zherb.Effect.End(ply,id)
		end)
	end,
	OnEnd = function(ply,id)
		ply:SetNWBool("zherb_effect_sleep",false)
		ply.zherb_ActiveEffect[id] = nil
		zclib.Timer.Remove("zherb_timer_effect_sleep_" .. ply:SteamID64())

		net.Start("zherb_sleep_stop")
		net.WriteEntity(ply)
		net.Broadcast()

		custom_ulx_freeze(ply, true)
	end,
})

// Stops the sleep effect
ZHERB_EFFECT_WAKE  = AddEffect({
	name = "Uyandırma Etkisi",
	desc = "Kişiyi uyandırır.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_wake_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		// Send nw msg to client to make is screen dark and sleepy sound
		net.Start("zherb_screeneffect_stop")
		net.Send(ply)

		custom_ulx_freeze(ply, true)
	end,
	OnEnd = function(ply,id)
	end,
})

// Red Vision
ZHERB_EFFECT_BULGEYE  = AddEffect({
	name = "Görüş Değişikliği",
	desc = "Kırmızı görüş falan filan",
	icon = Material( "materials/zerochain/zherb/ui/zherb_eye_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		// Send nw msg to client to make is screen dark and sleepy sound
		net.Start("zherb_screeneffect_start")
		net.WriteInt(data.duration,16)
		net.WriteInt(2,16)
		net.Send(ply)
	end,
	OnEnd = function(ply,id)

	end,
})

// Green Vision
ZHERB_EFFECT_SICKNESS  = AddEffect({
	name = "StomachSickness",
	desc = "You feel sick and everything is vomit green.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_sick_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		// Send nw msg to client to make is screen dark and sleepy sound
		net.Start("zherb_screeneffect_start")
		net.WriteInt(data.duration,16)
		net.WriteInt(3,16)
		net.Send(ply)
	end,
	OnEnd = function(ply,id)

	end,
})
//////////////////////////////////////////////////////////////////////////


// Modifyies the impacted / inflicted damage
ZHERB_EFFECT_DAMAGEMODIFY = AddEffect({
	name = "Hasar Değişikliği",
	desc = "Etkilenen oyuncuların hasarını değiştirir.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_damage_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		// If type is set to "STRENGTH" then this doesent change the damage the player receives but rather the damage other player receive from him

		ply.zherb_EffectModifiers["Damage"] = {type = data.damagetype,scale = data.scale,time = CurTime() + data.duration}
	end,
	OnEnd = function(ply,id)
		ply.zherb_EffectModifiers["Damage"] = nil
	end,
})
//////////////////////////////////////////////////////////////////////////


// Scales the players bones on CLIENT
ZHERB_EFFECT_BONESCALE = AddEffect({
	name = "Kemik Değişikliği",
	desc = "Oyuncuların kemik boyutunu değiştirir.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_bone_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		if data.bonenames == nil then return end
		local boneIDs = {}
		for k,v in pairs(data.bonenames) do
			table.insert(boneIDs,ply:LookupBone(v))
		end
		if boneIDs == nil then return end

		net.Start("zherb_scalebone")
		net.WriteEntity(ply)
		net.WriteInt(data.scale * 10, 16)
		net.WriteTable(boneIDs)
		net.WriteInt(data.duration, 16)
		net.Broadcast()
	end,
	OnEnd = function(ply,id)

	end,
})
if CLIENT then
	// Used to scale the specified players bones
	net.Receive("zherb_scalebone", function(len)
		local ply = net.ReadEntity(ply)
		local scale = net.ReadInt(16) / 10
		local boneids = net.ReadTable()
		local duration = net.ReadInt(16)

		if not IsValid(ply) then return end
		if scale == nil then return end
		if boneids == nil then return end
		if duration == nil then return end

		local speed = 20
		local ScaleEnd = CurTime() + duration

		local function ScaleBones(bones,scaley)
			for k,v in pairs(bones) do
				ply:ManipulateBoneScale(v, Vector(scaley, scaley, scaley))
			end
		end

		// Creates a client side think to scale the specifed playrs bones
		local identifier = "BoneScaler_" .. ply:EntIndex()
		zclib.Hook.Remove("Think", identifier)
		zclib.Hook.Add("Think", identifier, function()
			if IsValid(ply) and ply:Alive() and scale then

				if CurTime() >= ScaleEnd then
					zclib.Hook.Remove("Think", identifier)
					ply.zherb_bonescale = 1
					ScaleBones(boneids,1)
					return
				end

				local cur_scale = ply.zherb_bonescale or 1
				if cur_scale ~= scale then
					if cur_scale < scale then
						cur_scale = math.Clamp(cur_scale + (speed * FrameTime()), cur_scale, scale)
					else
						cur_scale = math.Clamp(cur_scale - (speed * FrameTime()), scale, cur_scale)
					end

					ply.zherb_bonescale = cur_scale
					ScaleBones(boneids,cur_scale)
				end
			else

				if IsValid(ply) then
					ScaleBones(boneids,1)
					ply.zherb_bonescale = 1
				end
				zclib.Hook.Remove("Think", identifier)
			end
		end)
	end)
else
	// Scales the players bone
	util.AddNetworkString("zherb_scalebone")
end
//////////////////////////////////////////////////////////////////////////


// Changes the players model
ZHERB_EFFECT_PLAYERSIZE  = AddEffect({
	name = "Boy Değişikliği",
	desc = "Oyuncu boyutunu değiştirir.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_scale_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id)

		// Dont chgange the size if we already got a size modifier active
		if ply.zherb_EffectModifiers and ply.zherb_EffectModifiers["PlayerSize"] and ply.zherb_EffectModifiers["PlayerSize"].time and CurTime() < ply.zherb_EffectModifiers["PlayerSize"].time then return end

		local LastScale = ply:GetModelScale()
		ply:SetModelScale(data.scale,1)
		ply:SetNWBool("zherb_ModifyViewByScale",true)

		ply.zherb_EffectModifiers["PlayerSize"] = {time = CurTime() + data.duration,previous_scale = LastScale}

		local timerid = "zherb_timer_effect_modelscale_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			zherb.Effect.End(ply,id)
		end)
	end,
	OnEnd = function(ply,id)

		zclib.Timer.Remove("zherb_timer_effect_modelscale_" .. ply:SteamID64())

		ply:SetModelScale(ply.zherb_EffectModifiers["PlayerSize"].previous_scale,1)

		ply.zherb_EffectModifiers["PlayerSize"] = nil

		ply:SetNWBool("zherb_ModifyViewByScale",false)
	end,
})
//////////////////////////////////////////////////////////////////////////


// Gives the player a random xp amount between min / max
ZHERB_EFFECT_XP = AddEffect({
	name = "XP Boost",
	desc = "Increases the players xp!",
	icon = Material( "materials/zerochain/zherb/ui/zherb_xp_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)
		local xp = math.random(data.min,data.max)
		// Call xp function
		ply:LSAddXP(xp)
		zclib.Notify(ply, "+" .. xp .. "XP", 0)
	end,
	OnEnd = function(ply,id)
	end,
})
//////////////////////////////////////////////////////////////////////////


// Causes damage
ZHERB_EFFECT_DAMAGE = AddEffect({
	name = "Hasar Artışı",
	desc = "Verilen hasarı arttırır.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_damage_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		// Damage player
		local d = DamageInfo()
		d:SetDamage(math.random(data.min,data.max))
		d:SetAttacker(Entity(1))
		d:SetDamageType(data.type)
		ply:TakeDamageInfo(d)
	end,
	OnEnd = function(ply,id)

	end,
})
//////////////////////////////////////////////////////////////////////////



// CHEESE CHESE
ZHERB_EFFECT_CHEESE  = AddEffect({
	name = "CHEESE CHEESE",
	desc = "Forces the player to say cheese.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_cheese_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		local timerid = "zherb_timer_effect_cheese_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, 4, data.duration, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			if math.random(10) > 5 then
				ply:EmitSound("vo/npc/female01/question06.wav")
			else
				ply:EmitSound("vo/npc/male01/question06.wav")
			end
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_cheese_" .. ply:SteamID64())
	end,
})
//////////////////////////////////////////////////////////////////////////


// Similiar to cheese but more generic
ZHERB_EFFECT_SOUNDEMIT  = AddEffect({
	name = "Ses Kirliliği",
	desc = "Oyuncuyu ses çıkarmaya zorlar.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_sound_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		local timerid = "zherb_timer_effect_sound_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.interval, data.duration, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			local asound = data.sounds[math.random(#data.sounds)]
			ply:EmitSound(asound)
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_sound_" .. ply:SteamID64())
	end,
})
//////////////////////////////////////////////////////////////////////////


// Distorts the players movement
ZHERB_EFFECT_DISTORTMOVEMENT  = AddEffect({
	name = "Sarhoş Hareket Etkisi",
	desc = "Oyuncuların hareketini bozar",
	icon = Material( "materials/zerochain/zherb/ui/zherb_distort_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id)

		ply:SetNWInt("zherb_DistortMovement", data.strength)

		local timerid = "zherb_timer_effect_movement_distort_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			zherb.Effect.End(ply,id)
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_movement_distort_" .. ply:SteamID64())
		ply:SetNWInt("zherb_DistortMovement", -1)
	end,
})

// Inverts the players movement
ZHERB_EFFECT_INVERTMOVEMENT  = AddEffect({
	name = "Hareket Etkisi",
	desc = "Oyuncuların hareketini tersine çevirir.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_invert_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data,id)

		ply:SetNWInt("zherb_InvertMovement", 1)

		local timerid = "zherb_timer_effect_movement_invert_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end
			zherb.Effect.End(ply,id)
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_movement_invert_" .. ply:SteamID64())
		ply:SetNWInt("zherb_InvertMovement", -1)
	end,
})
//////////////////////////////////////////////////////////////////////////


// Makes the player say random sentences,
ZHERB_EFFECT_CHATBOX  = AddEffect({
	name = "Chat Box",
	desc = "Forces the player to say random texts.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_chat_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		local timerid = "zherb_timer_effect_chatbox_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, 1, data.duration, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end

			if math.random(10) > 5 then
				ply:Say(data.textlist[math.random(#data.textlist)],false)
			end
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_chatbox_" .. ply:SteamID64())
	end,
})
//////////////////////////////////////////////////////////////////////////


// Makes the player say random voice lines
local voicelines = {"behind you", "better reload", "bullshit", "coming", "cut it", "dont tell me", "dejavu", "excuse me", "fantastic", "figures", "finally", "follow", "focus", "freeman",
	"get down", "get in", "get out", "good god", "gosh", "got one", "gotta reload", "gtfo", "hacks", "hax", "haxx", "help", "here they come", "hello, hey, hi", "heads up", "he´s dead", "how about that", "i know", "ill stay here", "im busy",
	"im with you", "isnt good", "incoming", "it cant be", "it is ok", "kay", "lead on", "lets go", "never", "nice", "not good", "not sure", "now what", "oh no", "omg", "ok", "oops", "over here", "over there", "pardon me", "please no", "right on",
	"run", "same here", "shut up", "spread the word", "stop it", "stop looking at me", "sorry", "take cover", "take this medkit", "task at hand", "talking to me", "thats you", "this cant be", "this is bad", "too much info", "uh oh", "wait", "wait for me",
	"wait for us", "wanna bet", "watch out", "we´re done for", "what now", "whatever you say", "whats the use", "whats the point", "whoops", "why go on", "why telling me", "yeah", "you and me both", "you never know", "you sure"
}
ZHERB_EFFECT_BABBLEBOX  = AddEffect({
	name = "Gevezelik Etkisi",
	desc = "Oyuncuyu rastgele ses hatları söylemeye zorlar.",
	icon = Material( "materials/zerochain/zherb/ui/zherb_chat_icon.png", "noclamp smooth" ),
	OnStart = function(ply,data)

		local timerid = "zherb_timer_effect_babblebox_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)
		zclib.Timer.Create(timerid, 5, data.duration, function()
			if not IsValid(ply) then zclib.Timer.Remove(timerid) return end

			if math.random(10) > 3 then
				ply:Say( voicelines[ math.random(#voicelines)],false)
			end
		end)
	end,
	OnEnd = function(ply,id)
		zclib.Timer.Remove("zherb_timer_effect_babblebox_" .. ply:SteamID64())
	end,
})
//////////////////////////////////////////////////////////////////////////


// Invisibility
ZHERB_EFFECT_INVISIBILITY = AddEffect({
	name = "Görünmezlik Etkisi",
	desc = "Oyuncuyu görünmez yapar.",
	icon = Material("materials/zerochain/zherb/ui/zherb_eye_icon.png", "noclamp smooth"),
	OnStart = function(ply, data)
		ply:SetNWBool("ZHERB_EFFECT_INVISIBILITY", true)
		ply:SetNoDraw(true)

		for k, v in pairs(ply:GetWeapons()) do
			v:SetNoDraw(true)
		end

		local timerid = "zherb_timer_effect_invisibility_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)

		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then
				zclib.Timer.Remove(timerid)

				return
			end

			ply:SetNWBool("ZHERB_EFFECT_INVISIBILITY", false)
			ply:SetNoDraw(false)

			for k, v in pairs(ply:GetWeapons()) do
				v:SetNoDraw(false)
			end
		end)
	end,
	OnEnd = function(ply, id)
		zclib.Timer.Remove("zherb_timer_effect_invisibility_" .. ply:SteamID64())
	end
})

if CLIENT then
	hook.Add("cc_HideAccessories", "cc_HideAccessories_ZHERB_EFFECT_INVISIBILITY", function(ply)
		if ply:GetNWBool("ZHERB_EFFECT_INVISIBILITY", false) == true then return true end
	end)
end
//////////////////////////////////////////////////////////////////////////



// Replaces the player material
ZHERB_EFFECT_FORCEMAT = AddEffect({
	name = "Force Material",
	desc = "Oyuncuya bir malzeme uygular.",
	icon = Material("materials/zerochain/zherb/ui/zherb_eye_icon.png", "noclamp smooth"),
	OnStart = function(ply, data)
		ply:SetNWBool("ZHERB_EFFECT_FORCEMAT", true)
		ply:SetMaterial(data.mat,true)

		for k, v in pairs(ply:GetWeapons()) do
			v:SetNoDraw(true)
		end

		local timerid = "zherb_timer_effect_forcemat_" .. ply:SteamID64()
		zclib.Timer.Remove(timerid)

		zclib.Timer.Create(timerid, data.duration, 1, function()
			if not IsValid(ply) then
				zclib.Timer.Remove(timerid)

				return
			end

			ply:SetNWBool("ZHERB_EFFECT_FORCEMAT", false)
			ply:SetMaterial("")

			for k, v in pairs(ply:GetWeapons()) do
				v:SetNoDraw(false)
			end
		end)
	end,
	OnEnd = function(ply, id)
		zclib.Timer.Remove("zherb_timer_effect_forcemat_" .. ply:SteamID64())
	end
})

if CLIENT then
	hook.Add("cc_HideAccessories", "cc_HideAccessories_ZHERB_EFFECT_FORCEMAT", function(ply)
		if ply:GetNWBool("ZHERB_EFFECT_FORCEMAT", false) == true then return true end
	end)
end
//////////////////////////////////////////////////////////////////////////
