zclib.NetEvent.AddDefinition("minigame_win", {
	[1] = {
		type = "entity"
	},
}, function(received)
	local ent = received[1]
	zclib.Effect.ParticleEffect("zherb_couldron_liquid", ent:LocalToWorld(Vector(0,6,57)), Angle(0, 0, 0), ent)
	zherb.Potiontable.LightEvent_Create(ent,ent:LocalToWorld(Vector(0,6,57)), 1, 1, Color(math.random(255),math.random(255),math.random(255)),256,1)
	zclib.Sound.EmitFromEntity("potiontable_error_solved", ent)
end)

zclib.NetEvent.AddDefinition("minigame_fail", {
	[1] = {
		type = "entity"
	},
}, function(received)
	local ent = received[1]
	zclib.Effect.ParticleEffect("zherb_couldron_explo_bad", ent:LocalToWorld(Vector(0,6,57)), Angle(0, 0, 0), ent)
	zherb.Potiontable.LightEvent_Create(ent,ent:LocalToWorld(Vector(0,6,57)), 1, 1,Color(255,125,0),256,1)
	zclib.Sound.EmitFromEntity("potiontable_explosion", ent)
end)
