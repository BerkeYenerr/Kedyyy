game.AddParticles("particles/zherb_vfx.pcf")
PrecacheParticleSystem("zherb_potiontable_projectile")
PrecacheParticleSystem("zherb_couldron_liquid")
PrecacheParticleSystem("zherb_couldron_explosion")
PrecacheParticleSystem("zherb_potion_explosion")
PrecacheParticleSystem("zherb_couldron_loop")
PrecacheParticleSystem("zherb_couldron_explo_bad")

PrecacheParticleSystem("zherb_mandrake_scream")

PrecacheParticleSystem("zherb_player_zzz")



for k, v in pairs(zherb.config.Potions) do
    if v.use_effect then
        PrecacheParticleSystem(v.use_effect)
    end
    if v.explo_effect then
        PrecacheParticleSystem(v.explo_effect)
    end
    if v.EffectOnDestruction and v.EffectOnDestruction.attach_effect then
        PrecacheParticleSystem(v.EffectOnDestruction.attach_effect)
    end
end
