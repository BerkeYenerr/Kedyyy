zherb = zherb or {}

zherb.materials = zherb.materials or {}
zherb.materials["close"] = Material( "materials/zerochain/zherb/ui/zherb_icon_close.png", "noclamp smooth" )
zherb.materials["background"] = Material( "materials/zerochain/zherb/ui/zherb_background.png", "noclamp smooth" )
zherb.materials["item_bg"] = Material( "materials/zerochain/zherb/ui/zherb_item_bg.png", "noclamp smooth" )
zherb.materials["blur"] = Material("pp/blurscreen")
zherb.materials["health_icon"] = Material( "materials/zerochain/zherb/ui/zherb_health_icon.png", "noclamp smooth" )
zherb.materials["potion_craft"] = Material("Models/effects/comball_tape")
zherb.materials["progress_forground"] =  Material( "materials/zerochain/zherb/ui/progress_forground.png", "noclamp smooth" )
zherb.materials["zherb_hoeing_icon"] = Material( "materials/zerochain/zherb/ui/zherb_hoeing_icon.png", "noclamp smooth" )
zherb.materials["zherb_item_locked"] = Material( "materials/zerochain/zherb/ui/zherb_item_locked.png", "noclamp smooth" )

zherb.materials["zherb_shadow01"] = Material( "materials/zerochain/zherb/ui/zherb_shadow01.png", "noclamp smooth" )
zherb.materials["zherb_shadow02"] = Material( "materials/zerochain/zherb/ui/zherb_shadow02.png", "noclamp smooth" )



zherb.colors = zherb.colors or {}
zherb.colors["black01"] = Color(0, 0, 0, 255)
zherb.colors["black02"] = Color(0, 0, 0, 100)
zherb.colors["black03"] = Color(0, 0, 0, 200)

zherb.colors["white01"] = Color(255, 255, 255, 255)
zherb.colors["white02"] = Color(255, 255, 255, 100)
zherb.colors["white03"] = Color(255, 255, 255, 15)
zherb.colors["white04"] = Color(255, 255, 255, 5)

zherb.colors["blue01"] = Color(0, 125, 255, 255)

zherb.colors["grey01"] = Color(50, 50, 50, 255)
zherb.colors["grey02"] = Color(35, 35, 35, 255)
zherb.colors["grey03"] = Color(200, 200, 200, 255)
zherb.colors["grey04"] = Color(125, 125, 125, 255)

zherb.colors["yellow01"] = Color(255, 191, 0, 255)
zherb.colors["yellow02"] = Color(255, 217, 103, 255)

zherb.colors["green01"] = Color(102, 199, 54, 255)
zherb.colors["orange01"] = Color(199, 122, 54, 255)
zherb.colors["red01"] = Color(199, 54, 54, 255)
zherb.colors["red02"] = Color(255, 75, 75, 125)
