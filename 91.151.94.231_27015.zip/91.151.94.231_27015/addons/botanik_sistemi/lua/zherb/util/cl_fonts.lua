if SERVER then return end

////////////////////////////////////////////
///////////////// DEFAULT //////////////////
////////////////////////////////////////////

zclib.FontData["zherb_font01"] = {
	font = "avatarock",
	extended = true,
	size = 100,
	weight = 100,
	antialias = true
}
zclib.FontData["zherb_font02"] = {
	font = "avatarock",
	extended = true,
	size = 200,
	weight = 100,
	antialias = true
}
zclib.FontData["zherb_font03"] = {
	font = "avatarock",
	extended = true,
	size = 50,
	weight = 100,
	antialias = true
}


////////////////////////////////////////////
///////////////// VGUI /////////////////////
////////////////////////////////////////////

zclib.FontData["zherb_vgui_font01"] = {
	font = "avatarock",
	extended = true,
	size = ScreenScale(15),
	weight = ScreenScale(100),
	antialias = true
}
zclib.FontData["zherb_vgui_font02"] = {
	font = "avatarock",
	extended = true,
	size = ScreenScale(8),
	weight = ScreenScale(100),
	antialias = true
}
zclib.FontData["zherb_vgui_font03"] = {
	font = "nexa light",
	extended = true,
	size = ScreenScale(7),
	weight = ScreenScale(1),
	antialias = true
}
zclib.FontData["zherb_vgui_font04"] = {
	font = "avatarock",
	extended = true,
	size = ScreenScale(6),
	weight = ScreenScale(100),
	antialias = true
}

zclib.FontData["zherb_vgui_font05"] = {
	font = "avatarock",
	extended = true,
	size = ScreenScale(5),
	weight = ScreenScale(100),
	antialias = true
}

zclib.FontData["zherb_vgui_font06"] = {
	font = "nexa light",
	extended = true,
	size = ScreenScale(6),
	weight = ScreenScale(1),
	antialias = true
}

zclib.FontData["zherb_vgui_font07"] = {
	font = "avatarock",
	extended = true,
	size = ScreenScale(13),
	weight = ScreenScale(100),
	antialias = true
}
