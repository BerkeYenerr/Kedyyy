zherb = zherb or {}

function zherb.Print(msg)
	print("[Zero´s Herbology] " .. msg)
end
