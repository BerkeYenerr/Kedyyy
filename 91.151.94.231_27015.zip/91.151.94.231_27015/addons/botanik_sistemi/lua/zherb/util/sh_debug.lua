if CLIENT then return end

concommand.Add("zherb_spawn_all", function(ply, cmd, args)
	if zclib.Player.IsAdmin(ply) then
		local tr = ply:GetEyeTrace()
		if tr == nil or tr.Hit == false or tr.HitPos == nil then return end
		//undo.Create("zherb")
		local x, y = 40, 40

		for k, v in pairs(zherb.config.Ingredients) do
			if x > 400 then
				y = y + 40
				x = 40
			end

			local pos = tr.HitPos + Vector(x, y, 15)
			local ing = zherb.Ingredient.Spawn(pos, k, 5)
			zclib.Player.SetOwner(ing, ply)
			local phys = ing:GetPhysicsObject()

			if IsValid(phys) then
				phys:Wake()
				phys:EnableMotion(false)
			end

			//undo.AddEntity(ing)
			x = x + 40
		end


		for k, v in pairs(zherb.config.Plants) do

			if x > 400 then
				y = y + 40
				x = 40
			end

			local pos = tr.HitPos + Vector(x, y, 15)
			local seed = ents.Create("zherb_item_seed")
			seed:SetPos(pos)
			seed:SetSeedID(k)
			seed:SetAmount(1)
			seed:Spawn()
			seed:Activate()
			zclib.Player.SetOwner(seed, ply)
			local phys = seed:GetPhysicsObject()

			if IsValid(phys) then
				phys:Wake()
				phys:EnableMotion(false)
			end

			//undo.AddEntity(seed)
			x = x + 40
		end


		for k, v in pairs(zherb.config.Potions) do
			if x > 400 then
				y = y + 40
				x = 40
			end

			local pos = tr.HitPos + Vector(x, y, 15)
			local potion = zherb.Potion.Spawn(pos, k)
			zclib.Player.SetOwner(potion, ply)
			local phys = potion:GetPhysicsObject()

			if IsValid(phys) then
				phys:Wake()
				phys:EnableMotion(false)
			end

			//undo.AddEntity(potion)
			x = x + 40
		end

		//undo.SetPlayer(ply)
		//undo.Finish()
	end
end)

local function AddSpawnCommand(list, command, default, OnCall)
	local function AutoComplete(cmd, stringargs)
		local tbl = {}
		stringargs = string.Trim(stringargs)
		stringargs = string.lower(stringargs)

		for k, v in pairs(list) do
			if string.find(string.lower(v.uniqueid), stringargs) then
				table.insert(tbl, command .. " " .. v.uniqueid)
			end
		end

		return tbl
	end

	local function SpawnFunc(ply, cmd, args)
		if zclib.Player.IsAdmin(ply) then
			local tr = ply:GetEyeTrace()
			if tr == nil or tr.Hit == false or tr.HitPos == nil then return end
			local unique = args[1]

			if unique == nil then
				unique = default
			end

			pcall(OnCall, unique, ply, tr.HitPos)
		end
	end

	concommand.Add(command, SpawnFunc, AutoComplete)
end

AddSpawnCommand(zherb.config.Ingredients, "zherb_spawn_ingredient", "witchsganglion", function(unique, ply, pos)
	local ingID = zherb.Ingredient.CatchID(unique)
	local ing = zherb.Ingredient.Spawn(pos, ingID, math.random(1, 5))
	zclib.Player.SetOwner(ing, ply)
end)

AddSpawnCommand(zherb.config.Plants, "zherb_spawn_seed", "witchsganglion", function(unique, ply, pos)
	local seedID = zherb.Pot.CatchID(unique)
	local seed = ents.Create("zherb_item_seed")
	seed:SetPos(pos)
	seed:SetSeedID(seedID)
	seed:SetAmount(1)
	seed:Spawn()
	seed:Activate()
	zclib.Player.SetOwner(seed, ply)
end)

AddSpawnCommand(zherb.config.Potions, "zherb_spawn_potion", "healpotion_small", function(unique, ply, pos)
	local potid = zherb.Potion.CatchID(unique)
	local potion = zherb.Potion.Spawn(pos, potid)
	zclib.Player.SetOwner(potion, ply)
end)
