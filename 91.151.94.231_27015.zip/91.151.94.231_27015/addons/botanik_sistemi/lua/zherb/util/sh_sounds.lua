sound.Add( {
	name = "potiontable_brew_loop",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 55,
	pitch = {100, 100},
	sound = "zherb/potiontable_brew_loop.mp3"
} )
sound.Add( {
	name = "mandrake_scream",
	channel = CHAN_STATIC,
	volume = 1.0,
	level = 55,
	pitch = {100, 100},
	sound = "zherb/scream.wav"
} )


zclib.Sound.List["potiontable_add"] = {
	paths = {"zherb/potiontable_add.mp3"},
	lvl = 75,
	pitchMin = 95,
	pitchMax = 105
}

zclib.Sound.List["potiontable_done"] = {
	paths = {"zherb/potiontable_done.mp3"},
	lvl = 75,
	pitchMin = 95,
	pitchMax = 105
}

zclib.Sound.List["potiontable_error_start"] = {
	paths = {"zherb/potiontable_error_start.mp3"},
	lvl = 75,
	pitchMin = 100,
	pitchMax = 100
}

zclib.Sound.List["potiontable_error_solved"] = {
	paths = {"zherb/potiontable_error_solved.mp3"},
	lvl = 75,
	pitchMin = 100,
	pitchMax = 100
}

zclib.Sound.List["potiontable_explosion"] = {
	paths = {"zherb/potiontable_explosion.mp3"},
	lvl = 75,
	pitchMin = 100,
	pitchMax = 100
}

zclib.Sound.List["pot_prepare"] = {
	paths = {"physics/body/body_medium_impact_soft1.wav", "physics/body/body_medium_impact_soft2.wav", "physics/body/body_medium_impact_soft3.wav", "physics/body/body_medium_impact_soft4.wav", "physics/body/body_medium_impact_soft5.wav", "physics/body/body_medium_impact_soft6.wav", "physics/body/body_medium_impact_soft7.wav"},
	lvl = 75,
	pitchMin = 100,
	pitchMax = 100
}


zclib.Sound.List["plant_harvest"] = {
	paths = {"zherb/plant_harvest.mp3"},
	lvl = 75,
	pitchMin = 100,
	pitchMax = 100
}

zclib.Sound.List["plant_sell"] = {
	paths = {"zherb/plant_sell.mp3"},
	lvl = 75,
	pitchMin = 100,
	pitchMax = 100
}
