zherb = zherb or {}
zherb.Potion = zherb.Potion or {}

function zherb.Potion.GetData(uniqueid)
    if zherb.config.Potions[uniqueid] then
        return zherb.config.Potions[uniqueid]
    end
    return zherb.config.Potions[zherb.Potion.CatchID(uniqueid)]
end

function zherb.Potion.CatchID(uniqueid)
    return zherb.config.Potion_ListID[uniqueid]
end

local function GetValidAttachment(ent)
    if not IsValid(ent) then return 0 end

    local attach = ent:LookupAttachment( "eyes" )
    if attach then return attach end

    attach = ent:LookupAttachment( "mouth" )
    if attach then return attach end

    attach = ent:LookupAttachment( "forward" )
    if attach then return attach end

    attach = ent:LookupAttachment( "chest" )
    if attach then return attach end

    return 0
end

if CLIENT then
    net.Receive("zherb_Potion_Visuals", function(len)
        zclib.Debug_Net("zherb_Potion_Visuals", len)
        local pos = net.ReadVector()
        local PotionID = net.ReadInt(16)

        if pos and PotionID then

            local PotionData = zherb.config.Potions[PotionID]
            if PotionData then
                if PotionData.explo_effect then zclib.Effect.ParticleEffect(PotionData.explo_effect, pos, Angle(0, 0, 0), Entity(1)) end
                if PotionData.explo_sound then sound.Play(PotionData.explo_sound, pos, 75, 100, 1) end
            end

            // Check for ents in close proximity and attach 20 seconds particle smoke effect on them
            if PotionData.EffectOnDestruction and PotionData.EffectOnDestruction.attach_effect then
                for k,v in pairs(ents.FindInSphere(pos,PotionData.EffectOnDestruction.Radius or 100)) do
                    if not IsValid(v) then continue end
                    if PotionData.EffectOnDestruction.customcheck then
                        if PotionData.EffectOnDestruction.customcheck(v) == true then
                            zclib.Effect.ParticleEffectAttach(PotionData.EffectOnDestruction.attach_effect, PATTACH_POINT_FOLLOW,v, GetValidAttachment(v))
                        end
                        continue
                    end
                    if v:IsPlayer() == false then continue end
                    if v:Alive() == false then continue end
                    zclib.Effect.ParticleEffectAttach(PotionData.EffectOnDestruction.attach_effect, PATTACH_POINT_FOLLOW,v, GetValidAttachment(v))
                end
            end
        end
    end)

    net.Receive("zherb_Potion_UseVisuals", function(len)
        zclib.Debug_Net("zherb_Potion_UseVisuals", len)
        local ply = net.ReadEntity()
        local PotionID = net.ReadInt(16)

        if IsValid(ply) and ply:Alive() and PotionID then

            local PotionData = zherb.config.Potions[PotionID]
            if PotionData then
                if PotionData.use_effect then zclib.Effect.ParticleEffect(PotionData.use_effect, ply:GetPos(), Angle(0, 0, 0), ply) end
                if PotionData.use_sound then ply:EmitSound(PotionData.use_sound) end

                if PotionData.EffectOnDestruction and PotionData.EffectOnDestruction.attach_effect then
                    zclib.Effect.ParticleEffectAttach(PotionData.EffectOnDestruction.attach_effect, PATTACH_POINT_FOLLOW,ply, GetValidAttachment(v))
                end
            end
        end
    end)
end
