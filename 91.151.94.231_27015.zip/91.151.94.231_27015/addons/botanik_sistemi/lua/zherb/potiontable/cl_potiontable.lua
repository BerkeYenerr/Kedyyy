if not CLIENT then return end
zherb = zherb or {}
zherb.Potiontable = zherb.Potiontable or {}

function zherb.Potiontable.Initialize(Potiontable)
    Potiontable.LightEvents = {}
end

function zherb.Potiontable.Draw(Potiontable)
    Potiontable:DrawModel()

    if zclib.util.InDistance(LocalPlayer():GetPos(), Potiontable:GetPos(), 500) then
        cam.Start3D2D(Potiontable:LocalToWorld(Vector(0,4.5,39.5)), Potiontable:LocalToWorldAngles(Angle(0,180,0)), 0.05)
            //draw.SimpleText("İksir Masası", zclib.GetFont("zherb_font01"), -750, 250, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText("İksir Masası", zclib.GetFont("zherb_font02"), 0, -150, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            if Potiontable:GetErrorStart() <= 0 then
                local PotionData = zherb.config.Potions[Potiontable:GetPotionID()]
                if Potiontable:GetBrewStart() > 0 and PotionData then
                    draw.RoundedBox(0, -400, 220,800, 50, zherb.colors["black03"])

                    local time = Potiontable:GetBrewStart() - CurTime()
                    draw.RoundedBox(0, -400, 220, math.Clamp((800 / PotionData.brewing_time) * (PotionData.brewing_time - time),0,800), 50, zherb.colors["white01"])

                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(zherb.materials["progress_forground"])
                    surface.DrawTexturedRect(-420, 210, 840, 70)
                end
            end
        cam.End3D2D()
    else
        Potiontable.LightEvents = {}
    end

    zherb.Potiontable.LightEvent_Logic(Potiontable)

    // Draws the error screen if we got one
    zherb.MiniGame.DrawError(Potiontable,Vector(0,16,39.5),Angle(0,180,0),Potiontable:OnMiniGame(LocalPlayer()))
end

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
function zherb.Potiontable.LightEvent_Create(Potiontable,_pos, _len, _style, _color,_size,_brightness)
	local lightInfo = {
		pos = _pos, // The Position of the light effect
		time = CurTime() + _len, // The removal time of the light
		style = _style, // The type of the light
		color = _color or Color(255, 202, 133, 255), // The color of the light
		size = _size or 128,
		brightness = _brightness or 2
	}

	table.insert(Potiontable.LightEvents, lightInfo)
end

function zherb.Potiontable.LightEvent_Clear(Potiontable)
	Potiontable.LightEvents = {}
end

function zherb.Potiontable.LightEvent_Logic(Potiontable)
	if Potiontable.LightEvents and table.Count(Potiontable.LightEvents) > 0 then
		for k, v in pairs(Potiontable.LightEvents) do
			if CurTime() > v.time then
				Potiontable.LightEvents[k] = nil
			else
				if zclib.util.InDistance(LocalPlayer():GetPos(), v.pos, 500) == false then continue end

				local dlight = DynamicLight(v.pos:Length() + v.time)
				if (dlight) then
					dlight.Pos = v.pos
					dlight.r = v.color.r
					dlight.g = v.color.g
					dlight.b = v.color.b
					dlight.Brightness = 2
					dlight.Size = v.size
					dlight.Decay = 500
					dlight.Style = v.style
					dlight.DieTime = CurTime() + 0.5
				end
			end
		end
	end
end
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////


function zherb.Potiontable.OnRemove(Potiontable)

    Potiontable:StopSound("potiontable_brew_loop")

    if Potiontable.IngredientMoves then
        for k,v in pairs(Potiontable.IngredientMoves) do
            if v and v.ent then
                zclib.ClientModel.Remove(v.ent)
            end
        end
    end
end

function zherb.Potiontable.Think(Potiontable)

    zclib.util.LoopedSound(Potiontable, "potiontable_brew_loop", Potiontable:GetPotionID() > 0)

    // Here we create or remove the client models
    if zclib.util.InDistance(LocalPlayer():GetPos(), Potiontable:GetPos(), 300) and Potiontable:GetPotionID() > 0 then

        if Potiontable.IngredientMoves then
            for k,v in pairs(Potiontable.IngredientMoves) do
                if IsValid(v.ent) then
                    if CurTime() > (v.add_time + 0.5) then

                        // Times over, remove the ent
                        zclib.ClientModel.Remove(v.ent)

                        zclib.Sound.EmitFromEntity("potiontable_add", Potiontable)
                        zclib.Effect.ParticleEffect("zherb_couldron_liquid", Potiontable:LocalToWorld(Vector(0,6,57)), Potiontable:GetAngles(), Potiontable)

                        // Create light flash
                        zherb.Potiontable.LightEvent_Create(Potiontable,Potiontable:LocalToWorld(Vector(0,6,57)), 1, 1, v.col or Color(math.random(255),math.random(255),math.random(255)),256,1)

                        v.ent = nil
                    else
                        // Move the entity
                        local passed = math.Clamp(CurTime() - v.add_time,0,0.5)

                        local fract = (1 / 0.5) * passed

                        local startPos = Potiontable:LocalToWorld(Vector(0,6,57)) + v.circlePos
                        local endPos = Potiontable:LocalToWorld(Vector(0,6,57))

                        local newPos = LerpVector(fract, startPos, endPos)


                        // Lerp a height position so the drone reached its heighest point in the mid of its path
                        local max_height = 15
                        local height = max_height
                        if passed < 0.5 then
                            height = height * math.EaseInOut((1 / 0.5) * fract, 0, 1)
                        else
                            height = height * math.EaseInOut(1 - (1 / 0.5) * (fract - 0.5), 0,1)
                        end
                        newPos = newPos + Vector(0,0,height)

                        v.ent:SetPos(newPos)
                        v.ent:SetModelScale(1 - fract)

                        local flyDir = v.ent:GetPos() - endPos
                        flyDir = flyDir:Angle()
                        flyDir:RotateAroundAxis(flyDir:Right(),180)
                        local rot = math.Round(CurTime() % 360,2) * 300
                        v.ent:SetAngles(Angle(rot,flyDir.y,rot))
                    end
                else
                    if CurTime() >= v.add_time and CurTime() < (v.add_time + 0.5) then

                        local IngData = zherb.config.Ingredients[v.ing_id]

                        local rad = 30
                        local ang = math.random(0,180)
                        local circlePos = Vector(math.cos(ang) * rad, math.sin(ang) * rad, 1)

                        v.circlePos = circlePos

                        local ent = zclib.ClientModel.Add(IngData.model)
                        if not IsValid(ent) then return end
                        ent:SetModel(IngData.model)
                        ent:SetPos(Potiontable:LocalToWorld(Vector(0,6,57)))
                        ent:Spawn()
                        ent:Activate()

                        zclib.Effect.ParticleEffectAttach("zherb_potiontable_projectile", PATTACH_POINT_FOLLOW,ent, 0)

                        v.col = IngData.color
                        v.ent = ent
                    end
                end
            end
        end

        if Potiontable.HasEffects ~= true then
            zclib.Effect.ParticleEffect("zherb_couldron_loop", Potiontable:LocalToWorld(Vector(0,6,40)), Potiontable:GetAngles(), Potiontable)
            Potiontable.HasEffects = true
        end
    else

        if Potiontable.HasEffects == true then
            Potiontable.HasEffects = false
            Potiontable:StopParticlesNamed("zherb_couldron_loop")
        end

        if Potiontable.IngredientMoves then
            for k,v in pairs(Potiontable.IngredientMoves) do
                if IsValid(v.ent) then

                    v.ent:StopParticles()

                    // Times over, remove the ent
                    zclib.ClientModel.Remove(v.ent)

                    v.ent = nil
                end
            end
            Potiontable.IngredientMoves = nil
        end
    end
end

net.Receive("zherb_PotionTable_Brew", function(len)
    zclib.Debug_Net("zherb_PotionTable_Brew", len)
    local PotionTable = net.ReadEntity()
    if not IsValid(PotionTable) then return end
    if PotionTable:GetClass() ~= "zherb_potiontable" then return end

    if zclib.util.InDistance(LocalPlayer():GetPos(), PotionTable:GetPos(), 1000) == false then return end

    local PotionData = zherb.config.Potions[PotionTable:GetPotionID()]
    if PotionData then

        PotionTable.IngredientMoves = {}
        if PotionTable.IngredientMoves then
            for k,v in pairs(PotionTable.IngredientMoves) do
                if v and v.ent then
                    zclib.ClientModel.Remove(v.ent)
                end
            end
        end

        local CurID = 1
        for k, v in pairs(PotionData.recipe) do
            for i = 1, v do
                table.insert(PotionTable.IngredientMoves,{ing_id = k,add_time = CurTime() + (0.25 * CurID)})
                CurID = CurID + 1
            end
        end
    end
end)
