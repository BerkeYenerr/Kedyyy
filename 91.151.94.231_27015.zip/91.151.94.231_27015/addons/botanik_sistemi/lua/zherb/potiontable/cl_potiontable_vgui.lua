if not CLIENT then return end
zherb = zherb or {}
zherb.Potiontable = zherb.Potiontable or {}



///////////////////////////////////////////
///////////////////////////////////////////
local PotionTableVGUI = {}

local function OpenInterface()

    if IsValid(zherb_PotionTable_panel) then
        zherb_PotionTable_panel:Remove()
    end

    zherb_PotionTable_panel = vgui.Create("zherb_vgui_PotionTable")
end

net.Receive("zherb_PotionTable_Open", function(len)
    zclib.Debug_Net("zherb_PotionTable_Open",len)

    LocalPlayer().zherb_PotionTable = net.ReadEntity()
    local data = net.ReadTable()
    LocalPlayer().iksirler = data
    LocalPlayer().iksirci = net.ReadBool()

    // Open Main interface
    OpenInterface()
end)

function PotionTableVGUI:Init()
    self:SetSize(800 * zclib.wM, 860 * zclib.hM)
    self:Center()
    self:MakePopup()
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetDraggable(true)
    self:SetSizable(false)

    self:DockMargin(0,0,0,0)
    self:DockPadding(5,5,5,5)

    local TopContainer = vgui.Create("DPanel", self)
    TopContainer:SetAutoDelete(true)
    TopContainer:SetSize(self:GetWide(), 50 * zclib.hM)
    TopContainer.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w - 55 * zclib.wM, h, zherb.colors["yellow01"])
    end
    TopContainer:Dock(TOP)

    local close_btn = zclib.vgui.ImageButton(self:GetWide() - 49 * zclib.wM,0,50 * zclib.wM,50 * zclib.hM,TopContainer,zherb.materials["close"],function()
        self:Close()
    end,function()
        return false
    end)
    close_btn:Dock(RIGHT)
    close_btn.MainColor = zherb.colors["yellow01"]
    close_btn.IconColor = color_white
    close_btn.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, s.MainColor)
        surface.SetDrawColor(s.IconColor)
        surface.SetMaterial(zherb.materials["close"])
        surface.DrawTexturedRect(0, 0, w, h)

        if s:IsEnabled() == false then
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
        else
            if s:IsHovered() then
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
            end
        end
    end

    local TitleBox = vgui.Create("DLabel", TopContainer)
    TitleBox:SetAutoDelete(true)
    TitleBox:SetSize(200 * zclib.wM, 50 * zclib.hM)
    TitleBox:SetPos(0 * zclib.wM, 0 * zclib.hM)
    TitleBox:Dock(LEFT)
    TitleBox:SetText("İksir Masasi")
    TitleBox:SetTextColor(zherb.colors["white01"])
    TitleBox:SetFont(zclib.GetFont("zherb_vgui_font01"))
    TitleBox:SetContentAlignment(5)
    TitleBox:SizeToContentsX( 15 * zclib.wM )

    local MainScroll = vgui.Create( "DScrollPanel", self )
    MainScroll:Dock(FILL)
    MainScroll:DockMargin(5 * zclib.wM, 5 * zclib.wM, 395 * zclib.wM, 5 * zclib.wM)
    MainScroll.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    local sbar = MainScroll:GetVBar()
    sbar:SetHideButtons( true )
    function sbar:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"]) end
    function sbar.btnUp:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnDown:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnGrip:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    self.ItemList_Scroll = MainScroll

    local MainContainer = vgui.Create("DIconLayout", MainScroll)
    MainContainer:Dock(FILL)

    MainContainer:SetSpaceX(5)
    MainContainer:SetSpaceY(5)
    MainContainer.Paint = function(s, w, h)
        //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end

    MainScroll:InvalidateLayout(true)
    MainScroll:InvalidateParent(true)

    self.ItemList = {}
    local itemHeight = 70 * zclib.hM
    if not LocalPlayer().iksirler then return end
    
    for k,v in ipairs(zherb.config.Potions) do
        /*if ix.faction.Get(LocalPlayer():Team()).name ~= "İksir Profesörü" then
            if not table.HasValue(LocalPlayer().iksirler, v.uniqueid) and v.uniqueid ~= "antivirus" then 
            	continue 
            end
        end*/

        if v.nocraft then continue end

        local item = MainContainer:Add("DPanel")
        item:SetSize(MainScroll:GetWide() - 25 * zclib.hM, itemHeight)
        item:SetText("")
        item.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["grey02"])
        end
        self.ItemList[k] = item

        local mdl = zclib.vgui.ModelPanel({model = v.model,color = v.color,skin = v.skin,bodygroup = v.bodygroup,render = {FOV = 25}})
        mdl:SetSize(itemHeight,itemHeight)
        mdl:SetParent(item)
        mdl.PreDrawModel = function(ent)
            cam.Start2D()

                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(zherb.materials["item_bg"])
                surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, itemHeight, itemHeight)
                //draw.RoundedBox(1,0 * zclib.wM, 0 * zclib.hM, 100 * zclib.wM, 100 * zclib.hM, zherb.colors["white01"])
            cam.End2D()
        end
        mdl.PostDrawModel = function(ent)
            cam.Start2D()
                zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,itemHeight, itemHeight, 2, zherb.colors["black01"])
            cam.End2D()
        end

        local EffectContainer = vgui.Create("DIconLayout", item)
        EffectContainer:Dock(FILL)
        EffectContainer:DockMargin(itemHeight + 10 * zclib.hM, 30 * zclib.hM, 5 * zclib.hM, 5 * zclib.hM)
        EffectContainer:SetSpaceX(5)
        EffectContainer:SetSpaceY(5)
        EffectContainer.Paint = function(s, w, h)
            //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black01"])
        end

        if v.effects then
            for effet_id, effect_amount in pairs(v.effects) do
                local effect_data = zherb.config.Effects[effet_id]
                if effect_data == nil then continue end
                local itm = EffectContainer:Add("DPanel")
                itm:SetSize(30 * zclib.hM, 30 * zclib.hM)
                itm:SetTooltip(effect_data.desc)
                itm.Paint = function(s, w, h)
                    //draw.RoundedBox(4, 0, 0, w, h, zherb.colors["black02"])

                    draw.RoundedBox(4, 0, 0, w, h, zherb.colors["white04"])


                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(effect_data.icon)
                    surface.DrawTexturedRect(0, 0, w, h)

                    if s:IsHovered() then
                        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white03"])
                    end
                end
            end
        end

        local button = vgui.Create("DButton", item)
        button:SetText("")
        button:Dock(FILL)
        button:DockMargin(0,0,0,0)

        local HasIngredients = zherb.Potiontable.HasIngredients(LocalPlayer(),k)

        local canbrew = true
        if v.canbrew then canbrew = v.canbrew(LocalPlayer()) end

        button.Paint = function(s, w, h)

            draw.SimpleText(v.name, zclib.GetFont("zherb_vgui_font02"),itemHeight + 10 * zclib.wM , 5 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

            if canbrew == false then
                zclib.util.DrawBlur(button, 1, 10)
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black03"])
                zclib.util.DrawOutlinedBox(0, 0, w, h, 3, zherb.colors["grey01"])
                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(zherb.materials["zherb_item_locked"])
                surface.DrawTexturedRect(0, 0, w, h)
            else

                if LocalPlayer().zherb_PotionTable_Selected == k then
                    zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["yellow01"])
                else
                    if HasIngredients or ix.faction.Get(LocalPlayer():Team()).name == "İksir Profesörü" then
                        zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["green01"])
                    else
                        zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["red01"])
                    end
                end

                if s:IsHovered() then
                    draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white03"])
                end
            end
        end
        button.DoClick = function(s)
            if canbrew == false then return end
            zclib.vgui.PlaySound("UI/buttonclick.wav")

            self:SelectPotion(k)
        end
    end

    MainContainer:InvalidateParent(true)
    MainContainer:InvalidateLayout(true)
    MainContainer:SizeToChildren(true, true)
    MainContainer:Center()

    self:SelectPotion(LocalPlayer().zherb_PotionTable_Selected or 1)

    timer.Simple(0.1,function()
        if not IsValid(self) then return end
        // Scroll to this item
        if self.ItemList and self.ItemList_Scroll then
            local SelectedPanel = self.ItemList[LocalPlayer().zherb_PotionTable_Selected]

            if IsValid(SelectedPanel) then
                self.ItemList_Scroll:InvalidateLayout(true)
                local _, y = self.ItemList_Scroll.pnlCanvas:GetChildPosition(SelectedPanel)
                local _, h = SelectedPanel:GetSize()
                y = y + h * 0.5
                y = y - self.ItemList_Scroll:GetTall() * 0.5
                self.ItemList_Scroll.VBar:AnimateTo(y, 0.01, 0, 0.5)
            end
        end
    end)
end

function PotionTableVGUI:Paint(w, h)
    surface.SetDrawColor(zherb.colors["white01"])
    surface.SetMaterial(zherb.materials["background"])
    surface.DrawTexturedRect(0, 0,w * 1.3, h)
end

function PotionTableVGUI:SelectPotion(id)

    LocalPlayer().zherb_PotionTable_Selected = id

    if IsValid(self.PotionInfo) then self.PotionInfo:Remove() end

    local PotionData = zherb.config.Potions[id]

    local item = vgui.Create("DPanel", self)
    item:Dock(FILL)
    item:DockMargin(400 * zclib.wM, 5 * zclib.wM, 5 * zclib.wM, 5 * zclib.wM)
    item.Paint = function(s, w, h)
        //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["grey02"])
    end
    self.PotionInfo = item

    item:InvalidateParent(true)

    local size = item:GetWide()
    local mdl = zclib.vgui.ModelPanel({model = PotionData.model,color = PotionData.color,skin = PotionData.skin,bodygroup = PotionData.bodygroup,render = {FOV = 25}})
    mdl:SetSize(size,size)
    mdl:SetParent(item)
    mdl.PreDrawModel = function(ent)
        cam.Start2D()

            surface.SetDrawColor(zherb.colors["white01"])
            surface.SetMaterial(zherb.materials["item_bg"])
            surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, size, size)
            //draw.RoundedBox(1,0 * zclib.wM, 0 * zclib.hM, 100 * zclib.wM, 100 * zclib.hM, zherb.colors["white01"])
        cam.End2D()
    end
    mdl.PostDrawModel = function(ent)
        cam.Start2D()
            zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,size, size, 2, zherb.colors["black01"])
        cam.End2D()
    end
    mdl:Dock(TOP)
    mdl:DockMargin(0,0,0,5)

    local function AddInfo(parent,dock,txt,font,color)
        local pnl = vgui.Create("DLabel", parent)
        pnl:SetAutoDelete(true)
        pnl:SetSize(size, 50 * zclib.hM)
        pnl:Dock(dock)
        pnl:SetText(txt)
        pnl:SetTextColor(color)
        pnl:SetFont(font)
        pnl:SetContentAlignment(4)
        pnl:DockMargin(10 * zclib.hM,10 * zclib.hM,10 * zclib.hM,10 * zclib.hM)
        pnl:SetWrap(true)
        return pnl
    end

    local name = AddInfo(mdl,TOP,PotionData.name,zclib.GetFont("zherb_vgui_font01"),zherb.colors["white01"])
    name:SetContentAlignment(7)
    name:SetSize(size, 90 * zclib.hM)

    local desc = AddInfo(mdl,BOTTOM,PotionData.desc,zclib.GetFont("zherb_vgui_font03"),zherb.colors["white01"])
    desc:SetContentAlignment(1)

    local ToolTipSize = 300
    local function AddToolTip(data,UseIcon)

        // TODO Give the tooltip a parent and set tooltip:SetAutoDelete(true)

        local tooltip = vgui.Create("DPanel")
        tooltip:SetSize(ToolTipSize * zclib.wM,ToolTipSize * zclib.hM)
        tooltip.LastDraw = 1
        tooltip.Paint = function(s, w, h)
            // TODO Pretty sure thats a stupid way of changing the DToolTips position
            local tt_arent = s:GetParent()
            if IsValid(tt_arent) then
                local cx, cy = input.GetCursorPos()
                tt_arent:SetPos(cx - (w / 2), cy - h - 50 * zclib.hM)

                if (tooltip.LastDraw + 1) < CurTime() then
                    tt_arent.Paint = function() end
                end
                tooltip.LastDraw = CurTime()
            end
        end
        tooltip:SetVisible( false )

        local tt_parent = tooltip:GetParent()
        if IsValid(tt_parent) then

            //print(tt_parent:GetColor())
            tt_parent:SetPaintBackgroundEnabled(false)
            /*
            tt_parent.Paint = function(s, w, h)
                //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black01"])
            end
            */
        end

        local tt_img
        if UseIcon == true then
            tt_img = vgui.Create("DPanel",tooltip)
            tt_img:SetSize(ToolTipSize * zclib.wM,ToolTipSize * zclib.hM)
            tt_img:SetParent(tooltip)
            tt_img.Paint = function(s, w, h)
                //draw.RoundedBox(4, 0, 0, w, h, zherb.colors["black02"])

                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(zherb.materials["item_bg"])
                surface.DrawTexturedRect(0, 0, w, h)

                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(data.icon)
                surface.DrawTexturedRect( w * 0.1, h * 0.1, w * 0.8, h * 0.8)



                zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,w,h, 2, zherb.colors["black01"])

                draw.RoundedBox(0, 0, 0, w, 45 * zclib.hM, zherb.colors["black02"])
                draw.SimpleText(data.name, zclib.GetFont("zherb_vgui_font07"), 10 * zclib.wM / 2, 20 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
        else
            tt_img = zclib.vgui.ModelPanel({model = data.model,color = data.color,skin = data.skin,bodygroup = data.bodygroup,render = {FOV = 25}})
            tt_img:SetSize(ToolTipSize * zclib.wM,ToolTipSize * zclib.hM)
            tt_img:SetParent(tooltip)
            tt_img.PreDrawModel = function(ent)
                cam.Start2D()
                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(zherb.materials["item_bg"])
                    surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, size, size)
                cam.End2D()
            end
            tt_img.PostDrawModel = function(ent)
                cam.Start2D()
                    zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,ToolTipSize * zclib.wM,ToolTipSize * zclib.hM, 2, zherb.colors["black01"])

                    //draw.RoundedBox(0, 0, 170 * zclib.hM, 200 * zclib.wM, 30 * zclib.hM, zherb.colors["black03"])
                    //draw.SimpleText(data.name, zclib.GetFont("zherb_vgui_font02"), 100 * zclib.wM, 180 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

                    draw.RoundedBox(0, 0, 0 * zclib.hM, ToolTipSize * zclib.wM, 45 * zclib.hM, zherb.colors["black02"])
                    draw.SimpleText(data.name, zclib.GetFont("zherb_vgui_font07"), 10 * zclib.wM / 2, 20 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                cam.End2D()
            end
        end
        tt_img:Dock(FILL)

        if data.desc then
            local pnl = vgui.Create("DLabel", tt_img)
            pnl:SetAutoDelete(true)
            pnl:SetSize(ToolTipSize * zclib.hM, 100 * zclib.hM)
            pnl:Dock(BOTTOM)
            pnl:SetText(data.desc)
            pnl:SetTextColor(zherb.colors["white01"])
            pnl:SetFont(zclib.GetFont("zherb_vgui_font06"))
            pnl:SetContentAlignment(4)
            pnl:DockMargin(10 * zclib.hM,10 * zclib.hM,10 * zclib.hM,10 * zclib.hM)
            pnl:SetWrap(true)
            pnl:SetContentAlignment(1)
            //pnl:DockPadding(10 * zclib.hM,10 * zclib.hM,10 * zclib.hM,10 * zclib.hM)
            /*
            pnl.Paint = function(s, w, h)
                draw.RoundedBox(0, 0, 0 , w, h, zherb.colors["black03"])
            end
            */
        end


        table.insert(zherb_tooltips,tooltip)

        return tooltip
    end

    local function AddList(title,items,list,UseIcon,ShowAmount)

        local BoxHeight = 200
        if table.Count(items) > 3 then
            BoxHeight = 100
        end

        local main = vgui.Create("DPanel", item)
        main:Dock(TOP)
        main:SetAutoDelete(true)
        main:SetSize(size, BoxHeight * zclib.hM)
        main:DockMargin(0,0,0,5 * zclib.hM)
        main.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
        end

        local title_pnl = vgui.Create("DLabel", main)
        title_pnl:SetAutoDelete(true)
        title_pnl:SetSize(size, 30 * zclib.hM)
        title_pnl:Dock(TOP)
        title_pnl:SetText(title)
        title_pnl:SetTextColor(zherb.colors["white01"])
        title_pnl:SetFont(zclib.GetFont("zherb_vgui_font02"))
        title_pnl:SetContentAlignment(7)
        title_pnl:DockMargin(5 * zclib.hM, 5 * zclib.hM, 0, 0)

        local layout = vgui.Create("DIconLayout", main)
        layout:SetAutoDelete(true)
        layout:SetSize(size, 100 * zclib.hM)
        layout:Dock(TOP)
        layout:SetSpaceX(5)
        layout:SetSpaceY(5)
        layout:DockMargin(5 * zclib.hM, 0, 0 * zclib.hM, 5 * zclib.hM)
        layout.Paint = function(s, w, h)
            //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white01"])
        end

        local itm_size = 120 * zclib.hM
        if table.Count(items) > 3 then
            if table.Count(items) < 5 then
                itm_size = (layout:GetWide() / table.Count(items)) - 6 * zclib.hM
            else
                itm_size = 70 * zclib.hM
            end
        end

        for _id, val in pairs(items) do
            local data = list[_id]
            if data == nil then continue end

            local itm
            if UseIcon then
                itm = layout:Add("DPanel")
                itm.Paint = function(s, w, h)
                    draw.RoundedBox(4, 0, 0, w, h, zherb.colors["white04"])

                    surface.SetDrawColor(zherb.colors["black02"])
                    surface.SetMaterial(zherb.materials["zherb_shadow02"])
                    surface.DrawTexturedRect(0, 0, w, h)

                    surface.SetDrawColor(zherb.colors["white01"])
                    surface.SetMaterial(data.icon)
                    surface.DrawTexturedRect(0, 0, w, h)


                    if itm:IsHovered() then
                        zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,w, h, 2, zherb.colors["white01"])
                    end
                    //zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,w, h, 2, zherb.colors["white01"])
                end
            else
                itm = zclib.vgui.ModelPanel({model = data.model,color = data.color,skin = data.skin,bodygroup = data.bodygroup,render = {FOV = 25}})
                itm.PreDrawModel = function(ent)
                    cam.Start2D()
                        surface.SetDrawColor(zherb.colors["white01"])
                        surface.SetMaterial(zherb.materials["item_bg"])
                        surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, itm_size,itm_size)
                    cam.End2D()
                end
                itm.PostDrawModel = function(ent)
                    if itm:IsHovered() then
                        cam.Start2D()
                            zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,itm_size, itm_size, 2, zherb.colors["white01"])
                        cam.End2D()
                    end
                end
                layout:Add(itm)
            end

            itm:SetSize(itm_size,itm_size)
            itm:SetTooltipPanel(AddToolTip(data,UseIcon))

            local name_pnl = vgui.Create("DLabel", itm)
            name_pnl:SetAutoDelete(true)
            name_pnl:SetSize(itm:GetWide(), 20 * zclib.hM)
            name_pnl:Dock(BOTTOM)
            name_pnl:SetText(data.name)
            name_pnl:SetTextColor(zherb.colors["white01"])
            name_pnl:SetFont(zclib.GetFont("zherb_vgui_font05"))
            name_pnl:SetContentAlignment(5)
            name_pnl.Paint = function(s, w, h)
                draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black03"])
            end

            if ShowAmount == false then continue end
            local amount_pnl = vgui.Create("DLabel", itm)
            amount_pnl:DockMargin(5 * zclib.hM, 5 * zclib.hM, 10 * zclib.hM, 5 * zclib.hM)
            amount_pnl:SetAutoDelete(true)
            amount_pnl:SetSize(itm:GetWide(), 20 * zclib.hM)
            amount_pnl:Dock(TOP)
            amount_pnl:SetText("x" .. val)
            amount_pnl:SetTextColor(zherb.colors["white01"])
            amount_pnl:SetFont(zclib.GetFont("zherb_vgui_font02"))
            amount_pnl:SetContentAlignment(9)
            amount_pnl.Paint = function(s, w, h)
                //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
            end
        end

        layout:InvalidateLayout(true)
        layout:SizeToChildren(false, true)

        main:InvalidateLayout(true)
        main:SizeToChildren(false, true)
        main:SetTall(main:GetTall() + 5 * zclib.hM)

        return main
    end

    AddList("İçindekiler",PotionData.recipe,zherb.config.Ingredients,false,true)
    AddList("Etkileri",PotionData.effects,zherb.config.Effects,true,false)

    local brew_button = vgui.Create("DButton", item)
    brew_button:SetTall(45 * zclib.wM)
    brew_button:SetText("")
    brew_button:Dock(BOTTOM)
    brew_button:DockMargin(0,0,0,0)
    brew_button.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"])
        draw.SimpleText("Yapmaya Başla", zclib.GetFont("zherb_vgui_font02"), w / 2, h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if s:IsHovered() then
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white03"])
        end
    end
    brew_button.DoClick = function(s)
        zclib.vgui.PlaySound("UI/buttonclick.wav")

        self:BrewPotion(id)
    end
end

function PotionTableVGUI:BrewPotion(id)

    net.Start("zherb_PotionTable_Brew")
    net.WriteEntity(LocalPlayer().zherb_PotionTable)
    net.WriteInt(id,16)
    net.SendToServer()

    self:Close()
end

zherb_tooltips = zherb_tooltips or {}

function PotionTableVGUI:Close()

    LocalPlayer().zherb_PotionTable = nil
    for k,v in pairs(zherb_tooltips) do
        if IsValid(v) then
            v:Remove()
        end
    end
    zherb_tooltips = {}

    if IsValid(zherb_PotionTable_panel) then
        zherb_PotionTable_panel:Remove()
    end
end

vgui.Register("zherb_vgui_PotionTable", PotionTableVGUI, "DFrame")
