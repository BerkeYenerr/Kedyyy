zherb = zherb or {}
zherb.Potiontable = zherb.Potiontable or {}
function zherb.Potiontable.CatchID(uniqueid)
    return zherb.config.Potion_ListID[uniqueid]
end

// This function checks if the player does have the needed items in his itemstore inventory
function zherb.Potiontable.HasIngredients(ply,PotionID)

    if zherb.config.Debug == true then return true end

    local inv = ply:GetCharacter():GetInventory():GetItems(false)

    // Lets build a list of all the Ingredients and their amount, the user currently has in his inventory
    local INV_IngredientList = {}
    for k,v in pairs(inv) do
        if v.ingredient_item then
            INV_IngredientList[v.ingredientid] = (INV_IngredientList[v.ingredientid] or 0) + 1
        end
        
    end

    // Lets check if the user has enough ingredients for this potion
    local HasIngredients = true
    for ing_id,ing_amount in pairs(zherb.config.Potions[PotionID].recipe) do
        local uniqueid = zherb.config.Ingredients[ing_id].uniqueid

        // He doesent have this ingredient
        if INV_IngredientList[uniqueid] == nil then HasIngredients = false break end

        // He doesent have enough
        if INV_IngredientList[uniqueid] and INV_IngredientList[uniqueid] < ing_amount then HasIngredients = false break end
    end

    return HasIngredients
end
