if SERVER then return end
zherb = zherb or {}
zherb.NPC = zherb.NPC or {}

function zherb.NPC.Initialize(NPC)
end

function zherb.NPC.Draw(NPC)
    cam.Start3D2D(NPC:GetPos() + Vector(0, 0, 80), Angle(0, LocalPlayer():EyeAngles().y - 90, 90), 0.05)
        draw.RoundedBox(16, -200, -40, 400, 80, zherb.colors["black02"])
        draw.SimpleText(zherb.config.NPC.name, zclib.GetFont("zherb_font03"), 0, 0, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end
