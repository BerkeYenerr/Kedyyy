zherb = zherb or {}
zherb.NPC = zherb.NPC or {}

// Returns all the valid potions the player can sell and has in his inventory
function zherb.NPC.GetPotions(ply)

    if not ply then return end
    local char = ply:GetCharacter()
    if not char then return end
    local inven = char:GetInventory()
    if not inven then return end
    local inv = inven:GetItems()
    if not inv then return end

    // Lets build a list of all the Ingredients and their amount, the user currently has in his inventory
    local INV_PotionList = {}
    for k,v in pairs(inv) do
        if v.class == "zherb_item_potion" then
            local PotionData = zherb.Potion.GetData(v.data.potid)
            if PotionData == nil then continue end
            if PotionData.price == nil then continue end
            if PotionData.price <= 0 then continue end
            if v.data.amount then
                for i = 1, v.data.amount do
                    table.insert(INV_PotionList, v.data.potid)
                end
            else
                table.insert(INV_PotionList, v.data.potid)
            end
        end
    end

    return INV_PotionList
end
