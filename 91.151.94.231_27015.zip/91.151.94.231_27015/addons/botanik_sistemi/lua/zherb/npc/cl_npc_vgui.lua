if SERVER then return end
zherb = zherb or {}
zherb.NPC = zherb.NPC or {}

///////////////////////////////////////////
///////////////////////////////////////////
local NPCVGUI = {}

local function OpenInterface()

    if IsValid(zherb_NPC_panel) then
        zherb_NPC_panel:Remove()
    end

    zherb_NPC_panel = vgui.Create("zherb_vgui_NPC")
end

net.Receive("zherb_NPC_Open", function(len)
    zclib.Debug_Net("zherb_NPC_Open",len)

    LocalPlayer().zherb_NPC = net.ReadEntity()

    // Open Main interface
    OpenInterface()
end)

function NPCVGUI:Init()
    self:SetSize(500 * zclib.wM, 500 * zclib.hM)
    self:Center()
    self:MakePopup()
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetDraggable(true)
    self:SetSizable(false)

    self:DockMargin(0,0,0,0)
    self:DockPadding(5,5,5,5)

    local TopContainer = vgui.Create("DPanel", self)
    TopContainer:SetAutoDelete(true)
    TopContainer:SetSize(self:GetWide(), 50 * zclib.hM)
    TopContainer.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w - 55 * zclib.wM, h, zherb.colors["yellow01"])
    end
    TopContainer:Dock(TOP)

    local close_btn = zclib.vgui.ImageButton(self:GetWide() - 49 * zclib.wM,0,50 * zclib.wM,50 * zclib.hM,TopContainer,zherb.materials["close"],function()
        self:Close()
    end,function()
        return false
    end)
    close_btn:Dock(RIGHT)
    close_btn.MainColor = zherb.colors["yellow01"]
    close_btn.IconColor = color_white
    close_btn.Paint = function(s, w, h)

		draw.RoundedBox(0, 0, 0, w, h, s.MainColor)

		surface.SetDrawColor(s.IconColor)
		surface.SetMaterial(zherb.materials["close"])
		surface.DrawTexturedRect(0, 0,w, h)

		if s:IsEnabled() == false then
			draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
		else
			if s:IsHovered() then
				draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
			end
		end
	end

    local TitleBox = vgui.Create("DLabel", TopContainer)
    TitleBox:SetAutoDelete(true)
    TitleBox:SetSize(200 * zclib.wM, 50 * zclib.hM)
    TitleBox:SetPos(0 * zclib.wM, 0 * zclib.hM)
    TitleBox:Dock(LEFT)
    TitleBox:SetText("Potions in your inventory:")
    TitleBox:SetTextColor(zherb.colors["white01"])
    TitleBox:SetFont(zclib.GetFont("zherb_vgui_font01"))
    TitleBox:SetContentAlignment(5)
    TitleBox:SizeToContentsX( 15 * zclib.wM )


    local MainScroll = vgui.Create( "DScrollPanel", self )
    MainScroll:Dock(FILL)
    MainScroll:DockMargin(2 * zclib.wM, 5 * zclib.wM, 2  * zclib.wM, 5 * zclib.wM)
    MainScroll.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    local sbar = MainScroll:GetVBar()
    sbar:SetHideButtons( true )
    function sbar:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"]) end
    function sbar.btnUp:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnDown:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnGrip:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    self.ItemList_Scroll = MainScroll

    local MainContainer = vgui.Create("DIconLayout", MainScroll)
    MainContainer:Dock(FILL)
    MainContainer:SetSpaceX(5)
    MainContainer:SetSpaceY(5)
    MainContainer.Paint = function(s, w, h)
        //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    MainScroll:InvalidateLayout(true)
    MainContainer:InvalidateParent(true)

    self.ItemList = {}
    local itemHeight = 100 * zclib.wM

    local inv_potions = zherb.NPC.GetPotions(LocalPlayer())
    for k,v in pairs(inv_potions) do

        local PotionData = zherb.Potion.GetData(v)
        if PotionData == nil then continue end

        local item = MainContainer:Add("DPanel")
        item:SetSize(self:GetWide() - 40 * zclib.wM, itemHeight)
        item:SetText("")
        item.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["grey02"])
        end
        self.ItemList[k] = item

        local mdl = zclib.vgui.ModelPanel({model = PotionData.model,color = PotionData.color,skin = PotionData.skin,bodygroup = PotionData.bodygroup,render = {FOV = 25}})
        mdl:SetSize(itemHeight,itemHeight)
        mdl:SetParent(item)
        mdl.PreDrawModel = function(ent)
            cam.Start2D()

                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(zherb.materials["item_bg"])
                surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, itemHeight, itemHeight)
                //draw.RoundedBox(1,0 * zclib.wM, 0 * zclib.hM, 100 * zclib.wM, 100 * zclib.hM, zherb.colors["white01"])
            cam.End2D()
        end
        mdl.PostDrawModel = function(ent)
            cam.Start2D()
                //zclib.util.DrawOutlinedBox(0 * zclib.wM, 0 * zclib.hM,itemHeight, itemHeight, 2, zherb.colors["black01"])
            cam.End2D()
        end

        local button = vgui.Create("DButton", item)
        button:SetText("")
        button:Dock(FILL)
        button:DockMargin(0, 0, 0, 0)
        button.Paint = function(s, w, h)

            draw.SimpleText(PotionData.name, zclib.GetFont("zherb_vgui_font02"), itemHeight + 10 * zclib.wM, 5 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

            //zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["green01"])

            if s:IsHovered() then
                draw.SimpleText("Sell", zclib.GetFont("zherb_vgui_font01"), itemHeight + 10 * zclib.wM,  h - 50 * zclib.hM, zherb.colors["green01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                //draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white04"])
                zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["green01"])
                draw.SimpleText(zclib.Money.Display(PotionData.price), zclib.GetFont("zherb_vgui_font01"), w - 10 * zclib.wM, h - 50 * zclib.hM, zherb.colors["green01"], TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
            else
                zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["black01"])
                draw.SimpleText(zclib.Money.Display(PotionData.price), zclib.GetFont("zherb_vgui_font02"), w - 10 * zclib.wM, h - 30 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
            end
        end
        button.DoClick = function(s)
            zclib.vgui.PlaySound("UI/buttonclick.wav")
            self:SellPotion(v)

            item:Remove()
        end
    end
end

function NPCVGUI:Paint(w, h)
    surface.SetDrawColor(zherb.colors["white01"])
    surface.SetMaterial(zherb.materials["background"])
    surface.DrawTexturedRect(0, 0,w * 1.3, h)
end

function NPCVGUI:SellPotion(id)
    net.Start("zherb_NPC_SellPotion")
    net.WriteEntity(LocalPlayer().zherb_NPC)
    net.WriteUInt(id,16)
    net.SendToServer()
end

function NPCVGUI:Close()
    LocalPlayer().zherb_NPC = nil
    if IsValid(zherb_NPC_panel) then
        zherb_NPC_panel:Remove()
    end
end

vgui.Register("zherb_vgui_NPC", NPCVGUI, "DFrame")
