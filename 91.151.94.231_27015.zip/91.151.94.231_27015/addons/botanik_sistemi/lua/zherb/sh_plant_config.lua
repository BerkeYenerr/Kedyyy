zherb = zherb or {}
zherb.config = zherb.config or {}
zherb.config.Plants = {}
zherb.config.Plant_ListID = {}
local function AddPlant(data) local id = table.insert(zherb.config.Plants,data) zherb.config.Plant_ListID[data.uniqueid] = id return id end

AddPlant({
	uniqueid = "aconite",
	name = "Aconite",
	desc = "Aconite, (ayni zamanda kesislik veya kurtbogan olarak da bilinir) buyulu ozelliklere sahip bir bitkidir.",
	water = 30,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	model = "models/lol/objects/plants/plant_satchel.mdl",
	ingredients = {
		[ZHERB_ING_ACONITE] = 5
	}
})

AddPlant({
	uniqueid = "alihotsy",
	name = "Alihotsy",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 0.8},
	desc = "Alihotsy, (Sirlan agaci olarak da bilinir) sihirli bir agac turudur.",
	water = 30,
	price = 8,
	tur = "sc",
	model = "models/flowers/poison_joke.mdl",
	ingredients = {
		[ZHERB_ING_ALIHOTSY] = 5
	}
})

AddPlant({
	uniqueid = "angelstrumpet",
	name = "Angel's Trumpet",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 0.8},
	desc = "Angel's Trompet, (Brugmansia) Guney Amerika'ya ozgu cicekli bitkilerin bir cinsidir.",
	water = 30,
	price = 8,
	tur = "sc",
	model = "models/flowers/flower_of_truth.mdl",
	ingredients = {
		[ZHERB_ING_ANGELSTRUMPET] = 5
	}
})

AddPlant({
	uniqueid = "arnica",
	name = "Arnica",
	desc = "Arnica, aycicegi ile ilgili bir bitki turu cinsidir.",
	water = 30,
	offset = { pos = Vector(0,0,-12), ang = Angle(0,0,0), scale = 1.2},
	price = 8,
	tur = "sc",
	model = "models/frenchie/sunflower.mdl",
	ingredients = {
		[ZHERB_ING_ARNICA] = 5
	}
})

AddPlant({
	uniqueid = "asphodel",
	name = "Asphodel",
	desc = "Asphodel, (Kraliyet Personeli olarak da bilinir) zambak ailesinin bir uyesidir.",
	water = 40,
	offset = { pos = Vector(0,0,-10), ang = Angle(0,0,0), scale = 1.2},
	price = 8,
	tur = "sc",
	model = "models/mosi/fnv/props/plants/bananayucca.mdl",
	ingredients = {
		[ZHERB_ING_ROOTOFASPHODEL] = 5
	}
})

AddPlant({
	uniqueid = "bloodroot",
	name = "Bloodroot",
	offset = { pos = Vector(0,0,-12), ang = Angle(0,0,0), scale = 1},
	desc = "Bloodroot, (Sanguinaria canadensis) cok yasli cicekli bir bitkidir.",
	water = 40,
	price = 8,
	tur = "sc",
	model = "models/mosi/fnv/props/plants/brocflower.mdl",
	ingredients = {
		[ZHERB_ING_BLOODROOT] = 5
	}
})

AddPlant({
	uniqueid = "boomberry",
	name = "Boom Berry",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	desc = "Boom Berry, sihirli bir meyvedir. Suyu onarici ozelliklere sahiptir.",
	water = 35,
	price = 8,
	tur = "sc",
	model = "models/props_foliage4/fruit_plant.mdl",
	ingredients = {
		[ZHERB_ING_BOOMBERRY] = 5
	}
})

AddPlant({
	uniqueid = "bouncingbulb",
	name = "Bouncing Bulb",
	desc = "A Bouncing Bulb, kisitlanmadigi takdirde etrafta ziplayan buyulu bir bitkidir.",
	water = 45,
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	price = 8,
	tur = "sc",
	color = Color(141, 96, 255, 255),
	ingredients = {
		[ZHERB_ING_BOUNCINGBULB] = 5
	},
	model = "models/props_foliage5/felucia/felucian_025.mdl"
})

AddPlant({
	uniqueid = "burstingmushroom",
	name = "Bursting mushroom",
	desc = "Bursting mushrooms, beyaz sapli ve kirmizi ve beyaz benekli kapakli buyuk bir sihirli mantar turudur.",
	water = 40,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-11), ang = Angle(0,0,0), scale = 1},
	model = "models/mosi/fnv/props/plants/cavefungus.mdl",
	ingredients = {
		[ZHERB_ING_BURSTINGMUSHROOM] = 5
	}
})

AddPlant({
	uniqueid = "dirigibleplum",
	name = "Dirigible plum",
	desc = "Dirigible plums, küçük çalıların üzerinde baş aşağı büyür",
	water = 40,
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	price = 8,
	tur = "sc",
	model = "models/sbs/hogwarts/wu/hwm_dribbleplum.mdl",
	ingredients = {
		[ZHERB_ING_DIRIGIBLEPLUM] = 5
	}
})

AddPlant({
	uniqueid = "dittany",
	name = "Dittany",
	desc = "Dittany, iksir yapiminda kullanilan buyulu bir bitkidir. Güclü bir sifali bitki ve onaricidir.",
	water = 30,
	offset = { pos = Vector(0,0,-11), ang = Angle(0,0,0), scale = 1},
	price = 8,
	tur = "sc",
	model = "models/props_foliage/mall_bigleaves_plant03_medium.mdl",
	ingredients = {
		[ZHERB_ING_DITTANY] = 5
	}
})

AddPlant({
	uniqueid = "fireseed",
	name = "Fireseed",
	offset = { pos = Vector(0,0,-8), ang = Angle(0,0,0), scale = 1},
	desc = "The fire seed bush, ates tohumu bitkisi olarak da bilinen, yasadigi surece yanan sihirli bir bitkidir.",
	water = 37,
	price = 8,
	tur = "sc",
	model = "models/props_foliage4/red_plant.mdl",
	ingredients = {
		[ZHERB_ING_FIRESEED] = 5
	}
})

AddPlant({
	uniqueid = "fluxweed",
	name = "Fluxweed",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	desc = "Fluxweed, sihirli bir bitkidir ve iyilestirici ozellikleriyle bilinen hardal ailesinin bir üyesidir.",
	water = 30,
	price = 8,
	tur = "sc",
	model = "models/mosi/fnv/props/plants/pinto.mdl",
	ingredients = {
		[ZHERB_ING_FLUXWEED] = 5
	}
})

AddPlant({
	uniqueid = "foxglove",
	name = "Foxglove",
	desc = "Foxgloves, oldukca zehirli, mor ve acik gri tonlarina kadar degisen canli ciceklere sahip otsu bitkilerin bir cinsidir.",
	water = 40,
	offset = { pos = Vector(0,0,-6.5), ang = Angle(0,0,0), scale = 1},
	price = 8,
	tur = "sc",
	model = "models/lol/objects/plants/plant_health_small.mdl",
	ingredients = {
		[ZHERB_ING_FOXGLOVES] = 5
	}
})

AddPlant({
	uniqueid = "ginger",
	name = "Ginger",
	desc = "Ginger, (Zingiber officinale) zencefil koku yuksek aromali bir baharat olarak yemek pisirmede ve halk hekimliginde kullanilan cicekli bir bitkidir.",
	water = 20,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-4), ang = Angle(0,0,0), scale = 1},
	model = "models/mosi/fnv/props/plants/xanderroot01.mdl",
	ingredients = {
		[ZHERB_ING_GINGER] = 5
	}
})

AddPlant({
	uniqueid = "horklump",
	name = "Horklump",
	desc = "Horklumps, Iskandinavya'da ortaya çıktı, ancak sonunda Kuzey Avrupa'ya yayildi.",
	water = 30,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-4), ang = Angle(0,0,0), scale = 0.7},
	model = "models/food/mushroom_blue/mushroom_blue.mdl",
	ingredients = {
		[ZHERB_ING_HORKLUMP] = 5
	}
})

AddPlant({
	uniqueid = "knotgrass",
	name = "Knotgrass",
	desc = "Knotgrass, buyulu ozelliklere sahip bir bitkidir.",
	water = 25,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	color = Color(0, 255, 63, 255),
	model = "models/mosi/fnv/props/plants/jalapeno.mdl",
	ingredients = {
		[ZHERB_ING_KNOTGRASS] = 5
	}
})

AddPlant({
	uniqueid = "lavender",
	name = "Lavender",
	desc = "Lavender güzel rengi ve sakinleştirici kokusu ile dikkat çeken bir çiçektir.",
	water = 45,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	model = "models/props_foliage5/herb02.mdl",
	ingredients = {
		[ZHERB_ING_LAVENDER] = 5
	}
})

AddPlant({
	uniqueid = "lovage",
	name = "Lovage",
	desc = "Levisticum officinale, yüzyillardir bitkisel ilaclarda ozellikle sindirimi kolaylastirmak icin kullanilmistir.",
	water = 35,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	color = Color(33, 255, 0, 255),
	model = "models/mosi/fnv/props/plants/pinto.mdl",
	ingredients = {
		[ZHERB_ING_LOVAGE] = 5
	}
})

AddPlant({
	uniqueid = "mandrake",
	name = "Mandrake",
	desc = "Cok ciglik atan bir bitki.",
	water = 45,
	price = 8,
	tur = "sc",
	model = "models/random/mandrake.mdl",
	ingredients = {
		[ZHERB_ING_MANDRAKEROOT] = 5
	},
	OnSeedPlanted = function(Pot,plant,ply)

		local function HasEarMuffs(pl)
			if pl:Team() == TEAM_BOTANIK then return true end
			if pl.SH_AccessoryInfo and pl.SH_AccessoryInfo.equipped and (pl.SH_AccessoryInfo.equipped["headphones3"] == true or pl.SH_AccessoryInfo.equipped["headphones2"] == true or pl.SH_AccessoryInfo.equipped["headphones4"] == true or pl.SH_AccessoryInfo.equipped["headphones1"] ) then
				return true
			else
				return false
			end
		end

		if SERVER then
			// Create a timer which every second damages players in distance
			zherb.Damage.EntTimer(Pot,1,0,300,1,DMG_SHOCK,function(aply)
				// Is this player immun against the scream damage?
				return HasEarMuffs(aply)
			end)
		else

			// Makes them scream
			zherb.MandrakeScreamers = zherb.MandrakeScreamers or {}
			table.insert(zherb.MandrakeScreamers,Pot)

			local ClosestDist = 99999999999
			local ClosestMandrake

			// Handels Sound and Effect
			zclib.Hook.Remove("Think", "MandrakeScreamer")
			zclib.Hook.Add("Think", "MandrakeScreamer", function()

				if zherb.MandrakeScreamers == nil or table.Count(zherb.MandrakeScreamers) <= 0 then
					zclib.Hook.Remove("Think", "MandrakeScreamer")
					return
				end
				for k,v in pairs(zherb.MandrakeScreamers) do
					if not IsValid(v) then zherb.MandrakeScreamers[k] = nil continue end

					// Here we check which mandrake is the closest
					local curDist = LocalPlayer():GetPos():DistToSqr(v:GetPos())
					if curDist < ClosestDist then
						ClosestDist = curDist
						ClosestMandrake = v
					end

					// Make looped scream sound if the player dont has ear muffs
					zclib.util.LoopedSound(v, "mandrake_scream", IsValid(v:GetPlant()) and HasEarMuffs(LocalPlayer()) == false)

					if not IsValid(v:GetPlant()) then zherb.MandrakeScreamers[k] = nil continue end

					if zclib.util.InDistance(v:GetPos(), LocalPlayer():GetPos(), 500) == false then continue end

					// Create scream effect every second
					if v.LastScreamEffect == nil or CurTime() > (v.LastScreamEffect + 1) then
						zclib.Effect.ParticleEffect("zherb_mandrake_scream", v:LocalToWorld(Vector(0,0,5)), v:GetAngles(), v)
						v.LastScreamEffect = CurTime()
					end
				end
			end)

			// Handels screen effects
			zclib.Hook.Remove("RenderScreenspaceEffects", "MandrakeScreamer")
			zclib.Hook.Add("RenderScreenspaceEffects", "MandrakeScreamer", function()

				if zherb.MandrakeScreamers == nil or table.Count(zherb.MandrakeScreamers) <= 0 then
					zclib.Hook.Remove("RenderScreenspaceEffects", "MandrakeScreamer")
					return
				end
				if IsValid(ClosestMandrake) and HasEarMuffs(LocalPlayer()) == false then
					local curDist = LocalPlayer():GetPos():DistToSqr(ClosestMandrake:GetPos())
					local alpha =  1 - math.Clamp((1 / 50000) * curDist,0,1)
					DrawMotionBlur( 0.1,alpha, 0.01 )
				end
			end)
		end
	end,
	OnRemove = function(Pot)
		if SERVER then
			zclib.Timer.Remove("zherb_enttimer_damage_" .. Pot:EntIndex())
		end
	end,
})

AddPlant({
	uniqueid = "mint",
	name = "Mint",
	desc = "Mint, guclu kokulu bitkilerin bir cinsidir. Mint, belirli bir nane cesididir.",
	water = 20,
	offset = { pos = Vector(0,0,-3), ang = Angle(0,0,0), scale = 1},
	price = 8,
	tur = "sc",
	ingredients = {
		[ZHERB_ING_MINT] = 5
	},
	model = "models/props_foliage/ferns02.mdl"
})

AddPlant({
	uniqueid = "moly",
	name = "Moly",
	offset = { pos = Vector(0,0,0), ang = Angle(0,0,0), scale = 0.6},
	desc = "Moly, buyuleri engellemek icin yenebilen guclu bir bitkidir ve ayni zamanda bir iksir maddesi olarak da kullanilir.",
	water = 30,
	price = 8,
	tur = "sc",
	model = "models/mosi/fnv/props/brocflower.mdl",
	ingredients = {
		[ZHERB_ING_MOLY] = 5
	}
})

AddPlant({
	uniqueid = "moondew",
	name = "Moondew",
	offset = { pos = Vector(0,0,-7), ang = Angle(0,0,0), scale = 1},
	desc = "Moondew, Iskocya'da ve muhtemelen Irlanda'da bulunan cicekli bir bitkiydi.",
	water = 30,
	price = 8,
	tur = "sc",
	model = "models/lol/objects/plants/plant_vision_stalk.mdl",
	ingredients = {
		[ZHERB_ING_MOONDEW] = 5
	}
})

AddPlant({
	uniqueid = "nettle",
	name = "Nettle",
	offset = { pos = Vector(0,0,-11), ang = Angle(0,0,0), scale = 1},
	desc = "Nettle, (Urtica diocia) veya yanik ela olarak da bilinir.",
	water = 20,
	price = 8,
	tur = "sc",
	model = "models/mosi/fnv/props/plants/whitehorsenettle.mdl",
	ingredients = {
		[ZHERB_ING_NETTLE] = 5
	}
})

AddPlant({
	uniqueid = "scurvygrass",
	name = "Scurvy grass",
	offset = { pos = Vector(0,0,-11), ang = Angle(0,0,0), scale = 1},
	desc = "Scurvy grass, buyulu ozelliklere sahip siradan bir bitkidir.",
	water = 45,
	price = 8,
	tur = "sc",
	model = "models/props_foliage4/stalk_plant.mdl",
	ingredients = {
		[ZHERB_ING_SCURVYGRASS] = 5
	}
})

AddPlant({
	uniqueid = "shrivelfig",
	name = "Shrivelfig",
	desc = "Shrivelfig, en iyi ornekleri Habesistan'da bulunan buyulu bir bitkidir.",
	water = 50,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 1},
	model = "models/lol/objects/plants/plant_health_grown.mdl",
	ingredients = {
		[ZHERB_ING_SHRIVELFIG] = 5
	}
})

AddPlant({
	uniqueid = "sopophorous ",
	name = "Sopophorous",
	desc = "Sopophorous, ozellikle Mooncalf gubresi tarafindan dollenirse, kasvetli batakliklarda filizlenen nadir bir buyulu bitkidir.",
	water = 30,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-7), ang = Angle(0,0,0), scale = 1},
	model = "models/frenchie/ghshrub.mdl",
	ingredients = {
		[ZHERB_ING_SOPOPHOROUSBEANS] = 5
	}
})

AddPlant({
	uniqueid = "valerian",
	name = "Valerian",
	desc = "Buyulu ozelliklere sahip bir bitki.",
	water = 50,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,-9), ang = Angle(0,0,0), scale = 0.8},
	model = "models/frenchie/flower.mdl",
	ingredients = {
		[ZHERB_ING_VALERIANROOT] = 5,
		[ZHERB_ING_VALERIANSPRINGS] = 1
	}
})

AddPlant({

	// This will be used to identify the item later
	uniqueid = "witchsganglion",

	// Name of the plant
	name = "Witch's ganglion",

	// Some info
	desc = "Witch's Ganglion, buyulu ozelliklere sahip nadir bir bitkidir.",

	// Water aka Grow time (1 water = 1 second)
	water = 30,

	// Seed price
	price = 8,

	tur = "sc",

	// Model
	model = "models/alchemy/ingreddragonstongue.mdl",

	// Offsets the plant model in the pot
	offset = { pos = Vector(0,0,2), ang = Angle(0,0,0), scale = 1},

	// If defined the model will be colored
	//color = Color(40, 201, 230, 255),

	// If defined the skin will be changed
	//skin = 1,

	// If defined the bodygroup will be changed
	//bodygroup = {1,1},

	// Called once the seed got planted
	//OnSeedPlanted = function(Pot,plant,ply) end,

	// Called once the plant got harvested
	//OnHarvested = function(Pot,ply) end,

	// Called once the plant dies
	//OnDeath = function(Pot) end,

	// Called once the plant gets removed
	//OnRemove = function(Pot) end,

	// Runs a custom check to see if the player is allowed to grow this seed
--	//CanGrow = function(ply) return table.HasValue({"vip", "vip_supervisor", "vip_admin", "vip_moderator", "superadmin"}, ply:GetUserGroup()) end,

	// Defines which ingredient items should the player receive when harvesting this plant
	ingredients = {
		[ZHERB_ING_WITCHSGANGLION] = 1
	}
})


AddPlant({
	uniqueid = "wormwood",
	name = "Wormwood",
	desc = "Wormwood (Artemisa absinthium), eski zamanlardan beri İksir yapımında kullanılan çok acı bir bitkidir.",
	water = 40,
	price = 8,
	tur = "sc",
	offset = { pos = Vector(0,0,1), ang = Angle(0,0,0), scale = 1},
	model = "models/a31/fallout4/props/plants/tarberry_item.mdl",
	ingredients = {
		[ZHERB_ING_WORMWOOD] = 5
	}
})

if NPCRobSystem and NPCRobSystem.Config and NPCRobSystem.Config.ShopContent then
NPCRobSystem.Config.ShopContent = {}
	for k, v in ipairs(zherb.config.Plants) do
		local dat = {
			name = v.name .. " x5",
			desc = v.desc,
			ent = "zherb_item_seed",
			price = v.price,
			model = v.model, //"models/zherb/props/eryk/farmingmod/seedbag.mdl",
			tur = v.tur,
			tab = "Seeds",
			isWep = false,
			postSpawn = function(ply, ent)

				zclib.Player.SetOwner(ent, ply)

				ent:SetSeedID(k)
				ent:SetAmount(5)

				local char = ply:GetCharacter()
				local aydi = ent:GetSeedID()
				local amcik = ent:GetAmount()
				if char then
					local inv = char:GetInventory()
					inv:Add(ent:GetClass())
					timer.Simple(0.5, function() 
						for k,v in pairs(inv:GetItems()) do 
			                if v:GetData("seedid") == aydi then
			                    v:SetData("amount", amcik + v:GetData("amount"))
			                    if ent then
			                        	ent:Remove()
			                    	end
			                    return
			                else
			                	if v:GetName() == "bilinmiyor" then 
			                        v:SetData("seedid", aydi)
			                        v:SetData("amount", amcik)
			                        if ent then
			                        	ent:Remove()
			                    	end
			                        return
			                    end
			                end
			            end
					end)
				end
				ent:Remove()

				
			end,
			customCheck = v.CanGrow
		}
		table.insert(NPCRobSystem.Config.ShopContent, dat)
	end
end
