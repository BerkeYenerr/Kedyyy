zherb = zherb or {}
zherb.config = zherb.config or {}

/////////////////////////// Zeros Herbology ////////////////////////////////

// Developed by ZeroChain:
// http://steamcommunity.com/id/zerochain/
// https://www.gmodstore.com/users/view/76561198013322242
// https://www.artstation.com/zerochain

/////////////////////////////////////////////////////////////////////////////


///////////////////////// zclib Config //////////////////////////////////////
/*
	This config can be used to overwrite the main config of zeros libary
*/
// The Currency
zclib.config.Currency = "ʛ"

// Should the Currency symbol be in front or after the money value?
zclib.config.CurrencyInvert = true

// These Ranks are admins
// If xAdmin, sAdmin or SAM is installed then this table can be ignored
zclib.config.AdminRanks = {
	["superadmin"] = true,
	["user"] = true,
}

//zclib.config.CleanUp.SkipOnTeamChange[TEAM_STAFF] = true
/////////////////////////////////////////////////////////////////////////////


local Herbes = {}
if TEAM_BOTANIK then Herbes[TEAM_BOTANIK] = true end
if TEAM_IKSIRPROF then Herbes[TEAM_IKSIRPROF] = true end

// Used to determent who the HerbologyTeacher is
zherb.config.IsHerbologyTeacher = function(ply)
	/*
	if Herbes[ply:Team()] then
		return true
	else
		if SERVER then zclib.Notify(ply, "Only the Herbology & the Potion Teacher can activate the plants!", 1) end
		return false
	end
	*/
	return true
end

zherb.config.Potion = {
	// Should the potion break on collition?
	Breakable = false,

	// Should the potion break on damage?
	Damageable = true,
}

zherb.config.NPC = {
	model = "models/mailer/characters/tesv_greybeard_npc.mdl",
	name = "Potage (Potion buyer)"
}
