if SERVER then return end
zherb = zherb or {}
zherb.Item = zherb.Item or {}

function zherb.Item.DrawName(ent)
    if ent.UIData == nil then
        local name = "Unkown"

        if ent:GetClass() == "zherb_item_seed" then
            local id = ent:GetSeedID()
            local plantData = zherb.config.Plants[id]

            if plantData then
                name = plantData.name .. " Seed" .. " x" .. ent:GetAmount()
            end
        elseif ent:GetClass() == "zherb_item_ingredient" then
            local id = ent:GetIngredientID()
            local IngData = zherb.config.Ingredients[id]

            if IngData then
                name = IngData.name .. " x" .. ent:GetAmount()
            end
        elseif ent:GetClass() == "zherb_item_potion" then
            local id = ent:GetPotionID()
            local PotionData = zherb.config.Potions[id]

            if PotionData then
                name = PotionData.name
            end
        end

        local size = zclib.util.GetTextSize(name, zclib.GetFont("zherb_font03"))
        size = size + 50

        ent.UIData = {
            BoxSize = size,
            Name = name
        }
    else
        cam.Start3D2D(ent:GetPos() + Vector(0, 0, 20), Angle(0, LocalPlayer():EyeAngles().y - 90, 90), 0.05)
            draw.RoundedBox(16, -ent.UIData.BoxSize / 2, -40, ent.UIData.BoxSize, 80, zherb.colors["black02"])
            draw.SimpleText(ent.UIData.Name, zclib.GetFont("zherb_font03"), 0, 0, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        cam.End3D2D()
    end
end
