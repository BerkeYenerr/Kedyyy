if not CLIENT then return end
zherb = zherb or {}
zherb.MiniGame = zherb.MiniGame or {}

// Display a error button on the screen
function zherb.MiniGame.DrawError(Potiontable, lpos, lang, hover)
    local errorStart = Potiontable:GetErrorStart()

    if errorStart > 0 then
        cam.Start3D2D(Potiontable:LocalToWorld(lpos), Potiontable:LocalToWorldAngles(lang), 0.1)
        draw.RoundedBox(8, -120, -25, 240, 50, zherb.colors["red01"])
        local barSize = 240 - math.Clamp((240 / 5) * (CurTime() - Potiontable:GetErrorStart()), 0, 240)
        draw.RoundedBox(8, -120, 15, barSize, 10, zherb.colors["white01"])
        draw.SimpleText("E'ye Bas!", zclib.GetFont("zherb_font03"), 0, 1, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        Potiontable.Pulse = (Potiontable.Pulse or 0) + (1 * FrameTime())

        if Potiontable.Pulse > 1 then
            Potiontable.Pulse = 0
        end

        if hover then
            draw.RoundedBox(8, -120, -25, 240, 50, zherb.colors["white02"])
        else
            local mul = 1 + math.abs(0.7 * Potiontable.Pulse)
            draw.RoundedBox(8, -100 * mul, -25 * mul, 200 * mul, 50 * mul, Color(255, 75, 75, 200 - 200 * Potiontable.Pulse))
        end

        cam.End3D2D()
    end
end


///////////////////////////////////////////
///////////////////////////////////////////
local MiniGameVGUI = {}

local function OpenInterface()

    if IsValid(zherb_MiniGame_main_panel) then
        zherb_MiniGame_main_panel:Remove()
    end

    zherb_MiniGame_main_panel = vgui.Create("zherb_vgui_MiniGame")
end

net.Receive("zherb_MiniGame", function(len)
    zclib.Debug_Net("zherb_MiniGame",len)

    LocalPlayer().zherb_MiniGame_Ent = net.ReadEntity()
    LocalPlayer().zherb_MiniGame_Time = net.ReadInt(16)

    local char = LocalPlayer():GetCharacter()
    local attrib = char:GetAttribute("iksirbilgisi") or 0
    if attrib >= 100 then 
        net.Start("zherb_MiniGame")
        net.WriteEntity(LocalPlayer().zherb_MiniGame_Ent)
        net.WriteBool(true)
        net.SendToServer()
    else
        // Open Main interface
        OpenInterface()
    end
end)

function MiniGameVGUI:Init()
    self:SetSize(600 * zclib.wM, 100 * zclib.hM)
    self:Center()
    self:SetPos((ScrW() / 2) - 300 * zclib.wM,(ScrH() / 2) + 150 * zclib.wM)
    self:MakePopup()
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetDraggable(true)
    self:SetSizable(false)

    self:DockMargin(0,0,0,0)
    self:DockPadding(5,5,5,5)

    // Defines how big the safe areas will be
    local char = LocalPlayer():GetCharacter()
    local attrib = char:GetAttribute("iksirbilgisi") or 0
    local difficulty = 1
    if attrib >= 5 then 
        difficulty = 10
    end
    
    if LocalPlayer().zherb_MiniGame_Ent and LocalPlayer().zherb_MiniGame_Ent.GetPotionID and LocalPlayer().zherb_MiniGame_Ent:GetPotionID() > 0 then difficulty = zherb.config.Potions[LocalPlayer().zherb_MiniGame_Ent:GetPotionID()].brewing_difficulty or 1 end

    // At which part of the bar is the safe area
    local safe_pos = (1 / 10) * LocalPlayer().zherb_MiniGame_Time

    // The size of the safe area
    local safe_size = 1 - ((1 / 10) * difficulty)

    // The time in seconds
    local game_time = 0
    if attrib < 20 then 
        game_time = 1
    elseif attrib < 40 then
        game_time = 2
    elseif attrib < 60 then
        game_time = 3
    elseif attrib < 80 then
        game_time = 4
    else
        game_time = 5
    end
    

    local safe_start = game_time * safe_pos
    local safe_mul = 0.05 + (0.1 * safe_size)
    local safe_end = safe_start + (game_time * safe_mul)

    local MainContainer = vgui.Create("DPanel", self)
    MainContainer:Dock(FILL)
    MainContainer.Paint = function(s, w, h)

        // The Size of the whole bar
        local max_length = w-20 * zclib.wM

        // The Size of the safe area, its 10% of the whole bar
        local safe_length = max_length * safe_mul

        local diff = CurTime() - MainContainer.CreationTime
        local pointer_pos = (max_length / game_time) * diff
        pointer_pos = math.Clamp(pointer_pos, 0, max_length)

        local CanWin = false
        if diff >= safe_start and diff < safe_end then
            CanWin = true
        end

        draw.RoundedBox(0, 10 * zclib.wM, 10 * zclib.wM, w - 20 * zclib.wM, h - 20 * zclib.wM, zherb.colors["red01"])

        draw.RoundedBox(0, ((max_length / game_time) * safe_start) + 10 * zclib.wM, 10 * zclib.wM, safe_length, h - 20 * zclib.wM, zherb.colors["green01"])

        if CanWin then
            draw.RoundedBox(0, ((max_length / game_time) * safe_start) + 10 * zclib.wM, 10 * zclib.wM, safe_length, h - 20 * zclib.wM, zherb.colors["white02"])
        end

        surface.SetDrawColor(zherb.colors["white01"])
        surface.SetMaterial(zherb.materials["progress_forground"])
        surface.DrawTexturedRect(0, 0, w, h)

        draw.RoundedBox(0, pointer_pos + 10 * zclib.wM, 10 * zclib.wM, 2, h - 20 * zclib.wM, zherb.colors["white01"])

        draw.SimpleText("SPACE", zclib.GetFont("zherb_vgui_font01"), w / 2 , h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    MainContainer.CreationTime = CurTime()
    MainContainer.DidAction = false
    MainContainer.Think = function(s)

        if MainContainer.DidAction == false then

            // Safe area is 10%
            local f_WinArea = game_time * safe_mul

            local f_WinTime = game_time * safe_pos

            local f_CurTime = CurTime() - MainContainer.CreationTime

            // Did we win?
            local result = false
            if f_CurTime >= f_WinTime and f_CurTime < (f_WinTime + f_WinArea) then
                result = true
            end

            if input.IsKeyDown(KEY_SPACE) == true or f_CurTime > game_time then

                MainContainer.DidAction = true

                net.Start("zherb_MiniGame")
                net.WriteEntity(LocalPlayer().zherb_MiniGame_Ent)
                net.WriteBool(result)
                net.SendToServer()

                self:Close()
            end
        end
    end

    self:InvalidateLayout(true)
    self:SizeToChildren(false, true)
end

function MiniGameVGUI:Paint(w, h) end

// Close the editor
function MiniGameVGUI:Close()

    LocalPlayer().zherb_MiniGame_Ent = nil

    if IsValid(zherb_MiniGame_main_panel) then
        zherb_MiniGame_main_panel:Remove()
    end
end

vgui.Register("zherb_vgui_MiniGame", MiniGameVGUI, "DFrame")
