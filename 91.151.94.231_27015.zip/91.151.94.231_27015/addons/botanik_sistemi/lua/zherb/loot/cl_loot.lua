if not CLIENT then return end
zherb = zherb or {}
zherb.Loot = zherb.Loot or {}

local Dots = ""
local NextDotsTime = SysTime() + 0.5
local dots_list = {
    [0] = ".",
    [1] = "..",
    [2] = "...",
    [3] = ""
}

local nextSound = CurTime() + math.Rand(1,2)
zclib.Hook.Add("HUDPaint", "Loot", function()
    local lootEnt = LocalPlayer():GetNWEntity("zherb_loot_ent", NULL)
    local lootStart = LocalPlayer():GetNWFloat("zherb_loot_start", -1)

    if IsValid(lootEnt) and lootStart and lootStart > 0 and CurTime() < (lootStart + zherb.config.Looting.time) then

        if CurTime() > nextSound then
            if math.random(10) > 5 then
                surface.PlaySound("zherb/search01.mp3")
            else
                surface.PlaySound("zherb/search02.mp3")
            end

            nextSound = CurTime() + math.Rand(1, 2)
        end

        if (not NextDotsTime or SysTime() >= NextDotsTime) then
            NextDotsTime = SysTime() + 0.5
            Dots = Dots or ""
            local len = string.len(Dots)
            Dots = dots_list[len]
        end

        local w, h = ScrW() * 0.3, ScrH() * 0.05
        local time = (w / zherb.config.Looting.time) * (CurTime() - lootStart)
        time = math.Clamp(time, 0, w)
        draw.RoundedBox(4, ScrW() / 2 - w / 2, ScrH() * 0.75 - h / 2, w, h, zherb.colors["black03"])
        draw.RoundedBox(4, ScrW() / 2 - w / 2, ScrH() * 0.75 - h / 2, time, h, zherb.colors["yellow02"])
        draw.SimpleText("Araştırılıyor" .. Dots, zclib.GetFont("zherb_vgui_font01"), ScrW() / 2, ScrH() * 0.75, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end)
