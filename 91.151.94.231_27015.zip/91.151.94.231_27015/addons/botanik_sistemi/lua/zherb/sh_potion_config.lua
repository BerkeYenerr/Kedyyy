zherb = zherb or {}
zherb.config = zherb.config or {}
zherb.config.Potions = {}

zherb.config.Potion_ListID = {}
local function AddPotion(data) local id = table.insert(zherb.config.Potions,data) zherb.config.Potion_ListID[data.uniqueid] = id return id end

// Little function for informing about year restriction
local function YearRestriction(ply, year)

	if ply.GetYear and ply:GetYear() < year then
		if SERVER then zclib.Notify(ply, "Bu iksiri yapabilmek için " .. year .. ". yıl olmalısın", 1) end

		return false
	end

	return true
end

AddPotion({

	// This will be used to identify the item later
	uniqueid = "healpotion_small",

	// Name of the potion
	name = "Düşük - İyileştirme İksiri",
crafting_xp = 10,
	// Some info
	desc = "Kullanan kişinin sağlığını 15-30 arası artırır.",

	// Model
	model = "models/food/potion/life_potion.mdl",

	// How long does it take to brew this potion
	brewing_time = 10,

	// Overwrites the hardness of the minigame (1-10) (Default = 1)
	brewing_difficulty = 1,

	// How much money is this potion worth?
		price = 0,

	// Here you can define who can make this potion
	//canbrew = function(ply) return false end,

	// If defined the model will be colored
	//color = Color(40, 201, 230, 255),

	// If defined the skin will be changed
	//skin = 0,

	// If defined the bodygroup will be changed
	//bodygroup = {1,1},

	// Defines which ingredient ids and how many are needed to make this potion
	recipe = {
		[ZHERB_ING_BILLYWIGSTINGS] = 1,
		[ZHERB_ING_LEECH] = 2
	},

	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/life_potion.mp3",

	// Can be used to run some custom code when the potion is used / broken
	// This is diffrent then the effects bellow as this only gets called once and the effects are called per impacted player
	onuse = function(potion,ply) end,

	// Defines which effects will be called on the affected entity and what data will be passed to it
	effects = {
		[ZHERB_EFFECT_HEALTH] = {min = 15,max = 30},
	},

	// Should the potion effects get applied on any entity which were near the potion when it got destroyed

	EffectOnDestruction = {
		// The radius at which we impact other players
		Radius = 180,
		// If this exists then you can overwrite a check to specify which entity gets impacted (By Default only player)
		// customcheck = function(ent,ply) end,
		// If specified then this effect will be attach on affected players / entities
		//attach_effect = "zherb_player_smoke"
	}
})


AddPotion({
	uniqueid = "healpotion_medium",
	name = "Orta - İyileştirme İksiri",
	desc = "Kullanan kişinin sağlığını 30-50 arası artırır.",
	model = "models/food/potion/life_potion.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 12,
	canbrew = function(ply) return YearRestriction(ply, 3) end,
	brewing_difficulty = 1,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/life_potion.mp3",
	recipe = {
		[ZHERB_ING_MANDRAKEROOT] = 1,
		[ZHERB_ING_BILLYWIGSTINGS] = 2,
		[ZHERB_ING_WORMWOOD] = 2
	},
	effects = {
		[ZHERB_EFFECT_HEALTH] = {
			min = 30,
			max = 50
		}
	},
	EffectOnDestruction = {
		Radius = 180
	}
})

AddPotion({
	uniqueid = "kemikiksiri",
	name = "Kemik İksiri",
	desc = "Kemiklerinizi tamir eder.",
	model = "models/food/potion/life_potion.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 12,
	canbrew = function(ply) return YearRestriction(ply, 3) end,
	brewing_difficulty = 1,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/life_potion.mp3",
	recipe = {
		[ZHERB_ING_BOUNCINGBULB] = 1,
		[ZHERB_ING_ACONITE] = 1
	},
	effects = {
		[ZHERB_EFFECT_HEALTH] = {
			min = 20,
			max = 30
		},
		[ZHERB_EFFECT_KEMIK] = {
			min = 0,
			max = 0
		}
	},
	EffectOnDestruction = {
		Radius = 180
	}
})

AddPotion({
	uniqueid = "healpotion_large",
	name = "Büyük - İyileştirme İksiri",
	desc = "Kullanan kişinin sağlığını 50-80 arası artırır.",
	model = "models/food/potion/life_potion.mdl",
	brewing_time = 15,
	price = 0,
	crafting_xp = 15,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/life_potion.mp3",
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	brewing_difficulty = 1,
	--skin = 0,
	recipe = {
		[ZHERB_ING_MANDRAKEROOT] = 1,
		[ZHERB_ING_BILLYWIGSTINGS] = 3,
		[ZHERB_ING_WORMWOOD] = 3
	},
	effects = {
		[ZHERB_EFFECT_HEALTH] = {
			min = 50,
			max = 80
		}
	},
	EffectOnDestruction = {
		Radius = 180,
		attach_effect = "zherb_player_smoke"
	}
})

AddPotion({
	uniqueid = "antivirus",
	name = "Antivirus",
	desc = "Virüsü engelle.",
	model = "models/food/potion/life_potion.mdl",
	brewing_time = 15,
	price = 0,
	crafting_xp = 15,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/life_potion.mp3",
	canbrew = function(ply) return true end,
	brewing_difficulty = 1,
	--skin = 0,
	recipe = {
		[ZHERB_ING_MANDRAKEROOT] = 3,
		[ZHERB_ING_WORMWOOD] = 3,
		[ZHERB_ING_SPIDER] = 3,
		[ZHERB_ING_CHICKEN] = 3,
		[ZHERB_ING_CHERRY] = 3,
		[ZHERB_ING_VALERIANROOT] = 3,
		[ZHERB_ING_ACONITE] = 3,
		[ZHERB_ING_DITTANY] = 3,
		[ZHERB_ING_ALIHOTSY] = 3,
		[ZHERB_ING_CHEESE] = 3,
		[ZHERB_ING_SCURVYGRASS] = 3,
		[ZHERB_ING_EXPLODINGFLUID] = 3,
		[ZHERB_ING_LOVAGE] = 3,
		[ZHERB_ING_NEWTSPLEEN] = 3,
		[ZHERB_ING_GINGER] = 3,
		[ZHERB_ING_ARMADILLOBILE] = 3,
		[ZHERB_ING_SHRIVELFIG] = 3,
		[ZHERB_ING_WORMWOOD] = 3,
		[ZHERB_ING_STANDARDINGREDIENT] = 3,
		[ZHERB_ING_KNOTGRASS] = 3,
		[ZHERB_ING_FLUXWEED] = 3
	},
	effects = {
	},
	EffectOnDestruction = {
		Radius = 180,
		attach_effect = "zherb_player_smoke"
	}
})

AddPotion({
	uniqueid = "potion_haste_small",
	name = "Küçük - Hız İksiri",
	desc = "Hareket hızını 5-15 seviyesinde arttırır.",
	model = "models/alchemylab/potion_green.mdl",
	canbrew = function(ply) return YearRestriction(ply, 3) end,
	brewing_time = 10,
	price = 0,
	crafting_xp = 10,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_DIRIGIBLEPLUM] = 3,
		[ZHERB_ING_BILLYWIGSTINGS] = 1,
		[ZHERB_ING_STANDARDINGREDIENT] = 3
	},
	effects = {
		[ZHERB_EFFECT_HASTE] = {
			duration = 10,
			min = 105,
			max = 115
		}
	}
})

AddPotion({
	uniqueid = "potion_haste_big",
	name = "Büyük - Hız İksiri",
	desc = "Hareket hızını 30-50 seviyesinde arttırır.",
	model = "models/alchemylab/potion_green.mdl",
	canbrew = function(ply) return YearRestriction(ply, 5) end,
	brewing_time = 10,
	price = 0,
	crafting_xp = 13,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_DIRIGIBLEPLUM] = 4,
		[ZHERB_ING_BILLYWIGSTINGS] = 3,
		[ZHERB_ING_STANDARDINGREDIENT] = 3
	},
	effects = {
		[ZHERB_EFFECT_HASTE] = {
			duration = 10,
			min = 130,
			max = 150
		}
	}
})

AddPotion({
	uniqueid = "polijuicepotion",
	name = "Kurt Adam İksiri",
	desc = "Kişiyi bir anlığına kurt adama çevirir.",
	model = "models/mlp_props/nightmare_night/candy_cart/potion_jar.mdl",
	brewing_time = 10,
	skin = 1,
	price = 0,
	crafting_xp = 15,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	recipe = {
		[ZHERB_ING_KNOTGRASS] = 3,
		[ZHERB_ING_BOOMSLANG] = 3,
		[ZHERB_ING_FLUXWEED] = 3,
		[ZHERB_ING_BICORNHORN] = 3,
		[ZHERB_ING_LEECH] = 3,
		[ZHERB_ING_LACEWINGFLY] = 3
	},
	effects = {
		[ZHERB_EFFECT_MODELCHANGE] = {
			duration = 60,
			mdl = "models/player/stenli/lycan_werewolf.mdl"
		}
	}
})

AddPotion({
	uniqueid = "cokozluiksir",
	name = "Çok Özlü İksir",
	desc = "İksirin içindeki saç telinin sahibinin şekline bürünürsünüz.",
	model = "models/mlp_props/nightmare_night/candy_cart/potion_jar.mdl",
	brewing_time = 10,
	skin = 1,
	price = 0,
	crafting_xp = 15,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	recipe = {
		[ZHERB_ING_DIRIGIBLEPLUM] = 4,
		[ZHERB_ING_BILLYWIGSTINGS] = 3,
		[ZHERB_ING_STANDARDINGREDIENT] = 3
	},
	effects = {
		[ZHERB_EFFECT_MODELCHANGE_COKOZLU] = {
			duration = 60,
		}
	}
})

AddPotion({
	uniqueid = "pompionpotion",
	name = "Balkabağı İksiri",
	desc = "Kişiyi bir Balkabağına dönüşür.",
	model = "models/alchemylab/potion_yellow.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 25,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 6) end,
	recipe = {
		[ZHERB_ING_FLITTERBY] = 3,
		[ZHERB_ING_BOUNCINGBULB] = 3,
		[ZHERB_ING_FOXGLOVES] = 3
	},
	effects = {
		[ZHERB_EFFECT_MODELCHANGE] = {
			duration = 30,
			mdl = "models/food/pumpkin/pumpkin01.mdl"
		}
	}
})


AddPotion({
	uniqueid = "potion_poison_small",
	name = "Zehir İksiri",
	desc = "Kullanan kişiye 30 saniye boyunca 1 zehir hasarı verir.",
	model = "models/mlp_props/nightmare_night/candy_cart/potion_jar.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 100,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	recipe = {
		[ZHERB_ING_ANGELSTRUMPET] = 1,
		[ZHERB_ING_BLOODROOT] = 3,
		[ZHERB_ING_BOOMSLANG] = 1,
		[ZHERB_ING_ALCOHOL] = 3
	},
	effects = {
		[ZHERB_EFFECT_POISON] = {
			interval = 3,
			rep = 30,
			min = 1,
			max = 1
		}
	}
})

AddPotion({
	uniqueid = "potion_poison_strong",
	name = "Güçlü Zehir İksiri",
	price = 0,
	crafting_xp = 200,
	desc = "Oyuncuya 15 saniye boyunca 10 zehir hasarı verir.",
	model = "models/items/provisions/potions/stone_potion.mdl",
	brewing_time = 10,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	recipe = {
		[ZHERB_ING_ANGELSTRUMPET] = 2,
		[ZHERB_ING_ARNICA] = 1,
		[ZHERB_ING_BLOODROOT] = 3,
		[ZHERB_ING_BOOMSLANG] = 1,
		[ZHERB_ING_ALCOHOL] = 3
	},
	effects = {
		[ZHERB_EFFECT_POISON] = {
			interval = 3,
			rep = 50,
			min = 1,
			max = 1
		}
	}
})

AddPotion({
	uniqueid = "caxambustyleborborygmuspotion",
	name = "Kaju Borborygmus İksiri",
	price = 0,
	desc = "Zehire benzer şekilde kullanan kişinin sağlığına yavaşça zarar verir, ancak -5 sağlık hasarından sonra durur.",
	model = "models/sohald_spike/props/potion_4.mdl",
	brewing_time = 10,
	skin = 5,
	crafting_xp = 60,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	canbrew = function(ply) return YearRestriction(ply, 6) end,
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_ALCOHOL] = 1,
		[ZHERB_ING_BOOMSLANG] = 1
	},
	effects = {
		[ZHERB_EFFECT_POISON] = {
			interval = 1,
			rep = 5,
			min = 1,
			max = 1
		}
	},
	[ZHERB_EFFECT_SICKNESS] = {
		duration = 10
	},
	[ZHERB_EFFECT_SOUNDEMIT] = {
		duration = 10,
		interval = 3,
		sounds = {"vo/npc/female01/moan01.wav", "vo/npc/female01/moan02.wav", "vo/npc/female01/moan03.wav", "vo/npc/female01/moan04.wav", "vo/npc/female01/moan05.wav", "vo/npc/male01/moan01.wav", "vo/npc/male01/moan02.wav", "vo/npc/male01/moan03.wav", "vo/npc/male01/moan04.wav", "vo/npc/male01/moan05.wav"}
	}
})

AddPotion({
	uniqueid = "potion_anti_poison",
	price = 0,
	name = "Panzehir İksiri",
	desc = "Birisi zehirlenirse, bu etkiyi durdurur.",
	model = "models/alchemylab/potion_orange.mdl",
	brewing_time = 10,
	crafting_xp = 30,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/cure_poison_potion.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 3) end,
	recipe = {
		[ZHERB_ING_CHIZPURFLECARAPACE] = 1,
		[ZHERB_ING_BILLYWIGSTINGS] = 1,
		[ZHERB_ING_UNICORNHORN] = 1,
		[ZHERB_ING_FIRESEED] = 3
	},
	effects = {
		[ZHERB_EFFECT_ANTIPOISON] = true
	}
})

AddPotion({
	uniqueid = "potion_sleep_small",
	name = "Uyutan İksir",
	price = 0,
	crafting_xp = 20,
	desc = "Kullanan kişiyi 30 saniye uyutur.",
	model = "models/alchemylab/potion_black.mdl",
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 3) end,
	brewing_time = 10,
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 6,
		[ZHERB_ING_VALERIANSPRINGS] = 4,
		[ZHERB_ING_LAVENDER] = 4,
		[ZHERB_ING_FLOBBERWORMMUCUS] = 2
	},
	effects = {
		[ZHERB_EFFECT_SLEEP] = {
			duration = 30
		},
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 10,
			interval = 3,
			sounds = {"zherb/snoring.mp3"}
		}
	}
})

AddPotion({
	uniqueid = "potion_sleep_big",
	name = "Yaşayan Ölüm İksiri",
	desc = "Kullanan kişiyi 60 saniye uyutur.",
	canbrew = function(ply) return YearRestriction(ply, 6) end,
	model = "models/alchemylab/potion_black.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 40,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_MOONDEW] = 3,
		[ZHERB_ING_SLOTHBRAIN] = 1,
		[ZHERB_ING_SOPOPHOROUSBEANS] = 2,
		[ZHERB_ING_VALERIANROOT] = 1,
		[ZHERB_ING_WORMWOOD] = 1,
		[ZHERB_ING_ROOTOFASPHODEL] = 1
	},
	effects = {
		[ZHERB_EFFECT_SLEEP] = {
			duration = 60
		},
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 20,
			interval = 3,
			sounds = {"zherb/snoring.mp3"}
		}
	}
})

AddPotion({
	uniqueid = "potion_wake",
	name = "Wiggenweld İksiri",
	desc = "Uyuyan insanı uyandırır.",
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	model = "models/alchemylab/potion_white.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 40,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_MOLY] = 3,
		[ZHERB_ING_DITTANY] = 3,
		[ZHERB_ING_HORKLUMP] = 1,
		[ZHERB_ING_MINT] = 3,
		[ZHERB_ING_MANDRAKEROOT] = 3,
		[ZHERB_ING_BOOMBERRY] = 3,
		[ZHERB_ING_SLOTHBRAIN] = 1,
		[ZHERB_ING_UNICORNHORN] = 1,
		[ZHERB_ING_ACONITE] = 1
	},
	effects = {
		[ZHERB_EFFECT_WAKE] = true
	}
})

AddPotion({
	uniqueid = "fireprotectionpotion",
	name = "Ateşten Korunma İksiri",
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	desc = "60 saniye boyunca yangın hasarından korur.",
	model = "models/alchemylab/potion_red.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 40,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_BURSTINGMUSHROOM] = 3,
		[ZHERB_ING_FIRESEED] = 3
	},
	effects = {
		[ZHERB_EFFECT_DAMAGEMODIFY] = {
			damagetype = DMG_BURN,
			scale = 0,
			duration = 60
		}
	}
})

AddPotion({
	uniqueid = "strengtheningsolution",
	name = "Güç İksiri",
	desc = "Sınırlı bir süre için daha fazla hasar vermenizi sağlar.",
	model = "models/alchemylab/potion_purple.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 50,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/strengh_potion.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	canbrew = function(ply) return YearRestriction(ply, 5) end,
	recipe = {
		[ZHERB_ING_GRIFFINCLAW] = 3,
		[ZHERB_ING_SALAMANDERBLOOD] = 3
	},
	effects = {
		[ZHERB_EFFECT_DAMAGEMODIFY] = {
			damagetype = "STRENGTH",
			scale = 2,
			duration = 20
		}
	}
})

AddPotion({
	uniqueid = "swellingsolution",
	name = "Şişkoluk İksiri",
	canbrew = function(ply) return YearRestriction(ply, 5) end,
	desc = "Kullanan kişinin vücut parçalarını büyütür.",
	model = "models/alchemylab/potion_blue.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 50,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_NETTLE] = 3,
		[ZHERB_ING_DITTANY] = 3,
		[ZHERB_ING_HORKLUMP] = 1,
		[ZHERB_ING_MINT] = 3
	},
	effects = {
		[ZHERB_EFFECT_BONESCALE] = {
			bonenames = {"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_L_Calf"},
			scale = 2,
			duration = 20
		}
	}
})

AddPotion({
	uniqueid = "megasolution",
	name = "Mega Güç İksiri",
	price = 0,
	crafting_xp = 80,
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	desc = "Kullanan kişi büyüyor ve güçleniyor",
	model = "models/items/provisions/potions/stone_potion.mdl",
	brewing_time = 10,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_NETTLE] = 3,
		[ZHERB_ING_MINT] = 3
	},
	effects = {
		[ZHERB_EFFECT_PLAYERSIZE] = {
			scale = 2,
			duration = 20
		},
			[ZHERB_EFFECT_ARMOR] = {
				min = 30,
				max = 50
			}
		}
})

AddPotion({
    uniqueid = "shrinkingsolution",
    name = "Zayıflatma ve Küçültme İksiri",
    canbrew = function(ply) return YearRestriction(ply, 5) end,
    desc = "Kullanan küçülür ve hızlanır.",
    model = "models/items/provisions/potions/stone_potion.mdl",
    brewing_time = 10,
	price = 0,
	crafting_xp = 50,
    explo_effect = "zherb_potion_explosion",
    explo_sound = "physics/glass/glass_bottle_break2.wav",
    use_effect = "zherb_player_usepotion",
    use_sound = "zherb/slurp.mp3",
    EffectOnDestruction = {
        Radius = 180
    },
    recipe = {
        [ZHERB_ING_SHRIVELFIG] = 3,
        [ZHERB_ING_STANDARDINGREDIENT] = 1,
        [ZHERB_ING_HORKLUMP] = 1,
        [ZHERB_ING_WORMWOOD] = 3
    },
    effects = {
        [ZHERB_EFFECT_PLAYERSIZE] = {
            scale = 0.25,
            duration = 20
        },
        [ZHERB_EFFECT_HASTE] = {
            duration = 10,
            min = 105,
            max = 115
        }
    }
})

AddPotion({
	uniqueid = "witsharpeningpotionsmall",
	name = "Düşük - Kudret İksiri",
	canbrew = function(ply) return YearRestriction(ply, 1) end,
	desc = "Kullanan kişi küçük bir xp artışı alır.",
	model = "models/items/provisions/potions/cure_poison_potion.mdl",
	brewing_time = 10,
	price = 0,
	crafting_xp = 10,
	Radius = 180,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/speed_potion.mp3",
	recipe = {
		[ZHERB_ING_GINGER] = 1,
		[ZHERB_ING_NEWTSPLEEN] = 1,
		[ZHERB_ING_MANDRAKEROOT] = 1,
	},
	effects = {
		[ZHERB_EFFECT_XP] = {
			min = 250,
			max = 300
		}
	}
})

AddPotion({
	uniqueid = "witsharpeningpotionmedium",
	name = "Orta - Kudret İksiri",
	desc = "Kullanan kişi orta seviye bir xp artışı alır.",
	canbrew = function(ply) return YearRestriction(ply, 1) end,
	model = "models/items/provisions/potions/cure_poison_potion.mdl",
	brewing_time = 15,
	price = 0,
	crafting_xp = 20,
	Radius = 180,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/speed_potion.mp3",
	recipe = {
		[ZHERB_ING_GINGER] = 2,
		[ZHERB_ING_NEWTSPLEEN] = 2,
		[ZHERB_ING_MANDRAKEROOT] = 1,
	},
	effects = {
		[ZHERB_EFFECT_XP] = {
			min = 450,
			max = 500
		}
	}
})

AddPotion({
	uniqueid = "witsharpeningpotionlarge",
	name = "Büyük - Kudret İksiri",
	canbrew = function(ply) return YearRestriction(ply, 1) end,
	desc = "Kullanan kişi büyük seviye xp artışı alır.",
	model = "models/items/provisions/potions/cure_poison_potion.mdl",
	brewing_time = 18,
	price = 0,
	crafting_xp = 30,
	Radius = 180,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/speed_potion.mp3",
	recipe = {
		[ZHERB_ING_NEWTSPLEEN]  = 3,
		[ZHERB_ING_GINGER] = 3,
		[ZHERB_ING_ARMADILLOBILE] = 2,
		[ZHERB_ING_DIRIGIBLEPLUM] = 2
	},
	effects = {
		[ZHERB_EFFECT_XP] = {
			min = 600,
			max = 750
		}
	}
})

AddPotion({
    uniqueid = "erumpentpotion",
    name = "Patlayıcı İksir",
    canbrew = function(ply) return YearRestriction(ply, 5) end,
    desc = "Kullanılan yerde patlar ve hasara neden olur..",
    model = "models/mlp_props/nightmare_night/candy_cart/potion_jar.mdl",
    brewing_time = 10,
    skin = 0,
	price = 0,
	crafting_xp = 60,
    recipe = {
        [ZHERB_ING_LOVAGE] = 2,
        [ZHERB_ING_SCURVYGRASS] = 2,
        [ZHERB_ING_EXPLODINGFLUID] = 1
    },
    explo_effect = "zherb_potion_explosion01",
    explo_sound = "ambient/explosions/explode_4.wav",
    onuse = function(potion, ply)
        local valid_ent = IsValid(potion) and potion or ply

        if IsValid(valid_ent) then
            for k, v in pairs(ents.FindInSphere(valid_ent:GetPos(), 200)) do
                if not IsValid(v) then continue end
                if v == valid_ent then continue end
                local phy = v:GetPhysicsObject()
                if not IsValid(phy) then continue end
                local force = (v:GetPos() - valid_ent:GetPos()) * phy:GetMass() * 100
                phy:ApplyForceCenter(force)
            end
        end
    end,
    effects = {
        [ZHERB_EFFECT_DAMAGE] = {
            min = 45,
            max = 60,
            type = DMG_BLAST
        }
    },
    EffectOnDestruction = {
        Radius = 200,
        attach_effect = "zherb_player_smoke"
    }
})


AddPotion({
	uniqueid = "alihotsydraugh",
	name = "Güldürme İksiri",
	canbrew = function(ply) return YearRestriction(ply, 5) end,
	desc = "Oyuncuyu gülmeye zorlayan bir iksir.",
	model = "models/sohald_spike/props/potion_4.mdl",
	brewing_time = 10,
	skin = 0,
	price = 0,
	crafting_xp = 50,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_ALIHOTSY] = 5,
		[ZHERB_ING_STANDARDINGREDIENT] = 1
	},
	effects = {
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 30,
			interval = 3,
			sounds = {"vo/npc/Barney/ba_laugh01.wav", "vo/npc/Barney/ba_laugh02.wav", "vo/npc/Barney/ba_laugh03.wav", "vo/npc/Barney/ba_laugh04.wav", "vo/ravenholm/madlaugh01.wav", "vo/ravenholm/madlaugh02.wav", "vo/ravenholm/madlaugh03.wav", "vo/ravenholm/madlaugh04.wav", "vo/Citadel/br_laugh01.wav"}
		}
	}
})

AddPotion({
	uniqueid = "coughpotion",
	name = "Öksürük İksiri",
	desc = "Boğazı tahriş eden bir iksir.",
	model = "models/sohald_spike/props/potion_4.mdl",
	brewing_time = 10,
	skin = 6,
	crafting_xp = 20,
	price = 0,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_FIRESEED] = 1,
		[ZHERB_ING_GINGER] = 1,
		[ZHERB_ING_MINT] = 1
	},
	EffectOnDestruction = {
		Radius = 180
	},
	effects = {
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 10,
			interval = 3,
			sounds = {"zherb/cough/cough01.mp3", "zherb/cough/cough02.mp3", "zherb/cough/cough03.mp3", "zherb/cough/cough04.mp3", "zherb/cough/cough05.mp3", "zherb/cough/cough06.mp3", "zherb/cough/cough07.mp3", "zherb/cough/cough08.mp3"}
		}
	}
})

AddPotion({
	uniqueid = "veritaserumtruthserum",
	name = "Veritaserum",
	desc = "İksir, içiciyi kendisine yöneltilen soruları doğru bir şekilde yanıtlamaya zorlar!",
	model = "models/sohald_spike/props/potion_4.mdl",
	brewing_time = 10,
	skin = 2,
	crafting_xp = 70,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 7) end,
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_BOOMSLANG] = 1,
		[ZHERB_ING_ALCOHOL] = 1
	},
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	effects = {
		[ZHERB_EFFECT_CHATBOX] = {
			duration = 2,
			textlist = {
				[1] = "Ne söylerseniz doğru söyleyeceğime yemin ediyorum. ( OOC = Doğruyu söylemezsen FailRP kuralından uyarı alırsın. )",
				--[2] = "What a story mark!",
				--[3] = "You're a little scary sometimes, you know that? Brilliant ... but scary.",
				--[4] = "Yer a wizard Harry.",
				--[5] = "Dobby is free.",
				--[6] = "Training for the ballet, Potter?",
				--[7] = "When in doubt, go to the library.",
				--[8] = "I solemnly swear I am up to no good.",
				--[9] = "Don’t let the muggles get you down.",
				--[10] = "Mischief Managed!",
				--[11] = "Twitchy little ferret, aren’t you?",
				--[12] = "Anyone can speak Troll. All you have to do is point and grunt.",
				--[13] = "I mean, it's sort of exciting, isn't it, breaking the rules?",
				--[14] = "Wit beyond measure is man’s greatest treasure.",
				--[15] = "There is no need to call me ‘sir,’ Professor.",
				--[16] = "Once again, you show all the sensitivity of a blunt axe.",
				--[17] = "After all this time?' 'Always,' said Snape.",
				--[18] = "Not my daughter, you b*tch!",
				--[19] = "All was well.",
				--[20] = "I've always wanted to use that spell.",
				--[21] = "He can run faster than Severus Snape confronted with shampoo.",
				--[22] = "You’re just as sane as I am.",
				--[23] = "Age is foolish and forgetful when it underestimates youth.",
				--[24] = "I am a wizard, not a baboon brandishing a stick.",
				--[25] = "I'm a what?",
				--[26] = "I’ll be in my bedroom, making no noise and pretending I’m not there.",
				--[27] = "Honestly, if you were any slower, you’d be going backward."
			}
		}
	}
})

AddPotion({
	uniqueid = "babblingbeverage",
	name = "Gevezelik İksiri",
	desc = "Kontrolsüzce saçma sapan konuşmalara neden olan bir iksir",
	model = "models/sohald_spike/props/potion_4.mdl",
	canbrew = function(ply) return YearRestriction(ply, 4) end,
	brewing_time = 10,
	skin = 3,
	price = 0,
	crafting_xp = 40,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/invulnerability_potion.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_VALERIANROOT] = 3,
		[ZHERB_ING_ACONITE] = 3,
		[ZHERB_ING_DITTANY] = 3
	},
	effects = {
		[ZHERB_EFFECT_BABBLEBOX] = {
			duration = 30
		}
	}
})

AddPotion({
	uniqueid = "bulgeyepotion",
	name = "Bulgeye İksiri",
	desc = "Doymuş kırmızı kaplama üzerinde kullanan kişinin vizyonunda olumsuz iksir!",
	model = "models/sohald_spike/props/potion_4.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 80,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/invulnerability_potion.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_KNOTGRASS] = 1,
		[ZHERB_ING_ALCOHOL] = 1,
		[ZHERB_ING_GINGER] = 1,
		[ZHERB_ING_DITTANY] = 1
	},
	effects = {
		[ZHERB_EFFECT_BULGEYE] = {
			duration = 30
		}
	}
})

AddPotion({
	uniqueid = "smallinvisiblepotion",
	name = "Düşük - Görünmezlik İksiri",
	desc = "Seni görünmez yapar!",
	model = "models/mixtures_health/mixtures_health_50hp.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 80,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "hprewrite/spells/hillium.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_SPIDER] = 1,
		[ZHERB_ING_CHICKEN] = 1,
		[ZHERB_ING_CHERRY] = 1,
		[ZHERB_ING_GINGER] = 1,
		[ZHERB_ING_DITTANY] = 1
	},
	effects = {
		[ZHERB_EFFECT_INVISIBILITY] = {
			duration = 8
		}
	}
})

AddPotion({
	uniqueid = "mediuminvisiblepotion",
	name = "Orta - Görünmezlik İksiri",
	desc = "Seni görünmez yapar!",
	model = "models/mixtures_health/mixtures_health_50hp.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 80,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "hprewrite/spells/hillium.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_SPIDER] = 2,
		[ZHERB_ING_CHICKEN] = 2,
		[ZHERB_ING_CHERRY] = 2,
		[ZHERB_ING_GINGER] = 2,
		[ZHERB_ING_DITTANY] = 2
	},
	effects = {
		[ZHERB_EFFECT_INVISIBILITY] = {
			duration = 15
		}
	}
})

AddPotion({
	uniqueid = "biginvisiblepotion",
	name = "Yüksek - Görünmezlik İksiri",
	desc = "Seni görünmez yapar!",
	model = "models/mixtures_health/mixtures_health_50hp.mdl",
	brewing_time = 10,
	price = 0,
	skin = 4,
	crafting_xp = 80,
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "hprewrite/spells/hillium.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_SPIDER] = 3,
		[ZHERB_ING_CHICKEN] = 3,
		[ZHERB_ING_CHERRY] = 3,
		[ZHERB_ING_GINGER] = 3,
		[ZHERB_ING_DITTANY] = 3
	},
	effects = {
		[ZHERB_EFFECT_INVISIBILITY] = {
			duration = 30
		}
	}
})


AddPotion({
	uniqueid = "skinripingpotion",
	name = "Cilt yırtma İksiri",
	desc = "Cildin yok olmasını sağlar.",
	model = "models/items/provisions/potions/mana_potion.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 80,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 8) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/invulnerability_potion.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_KNOTGRASS] = 1,
		[ZHERB_ING_ALCOHOL] = 1,
		[ZHERB_ING_GINGER] = 1,
		[ZHERB_ING_DITTANY] = 1
	},
	effects = {
		[ZHERB_EFFECT_FORCEMAT] = {
			duration = 30,
			mat = "models/flesh",
		}
	}
})


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

AddPotion({
	uniqueid = "amortentialovepotion",
	name = "Amortentia - Aşk İksiri",
	canbrew = function(ply) return YearRestriction(ply, 6) end,
	desc = "Sevgi iksiri. Oyuncunun kontrol edemeden rastgele dolaşmasını sağlar",
	//model = "models/sohald_spike/props/potion_4.mdl",
	model = "models/zerochain/props_harrypotter/cc_items/cc_item25.mdl",
	brewing_time = 10,
	skin = 1,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	price = 0,
	EffectOnDestruction = {
		Radius = 180,
		attach_effect = "unusual_hearts_bubbling"
	},
	recipe = {
		[ZHERB_ING_STANDARDINGREDIENT] = 1,
		[ZHERB_ING_ALCOHOL] = 1,
		[ZHERB_ING_KNOTGRASS] = 1,
		[ZHERB_ING_SHRIVELFIG] = 1
	},
	effects = {
		[ZHERB_EFFECT_DISTORTMOVEMENT] = {
			duration = 30
		},
		[ZHERB_EFFECT_INVERTMOVEMENT] = {
			duration = 30
		}
	}
})

//////////////////////////////////////////////////////////////////////////////////////////


AddPotion({
	uniqueid = "unopoo",
	name = "Ossurtma iksiri",
	desc = "Kullanan kişiyi ossurtur",
	model = "models/items/provisions/potions/mana_potion.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 10,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 2) end,
	explo_effect = "zherb_player_farts",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "physics/glass/glass_bottle_break2.wav",
	recipe = {
		[ZHERB_ING_MINT] = 2,
		[ZHERB_ING_NETTLE] = 1,
		[ZHERB_ING_MANDRAKEROOT] = 1
	},
	EffectOnDestruction = {
		Radius = 210,
		attach_effect = "zherb_player_farts"
	},
	effects = {
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 10,
			interval = 3,
			sounds = {"zherb/fart01.wav","zherb/fart02.wav"}
		}
	}
})

AddPotion({
	uniqueid = "penelopepurplepussycats",
	name = "Kediye Dönüştürme İksiri",
	desc = "Kullanan kişiyi bir kediye dönüştürür.",
	model = "models/zerochain/props_harrypotter/cc_items/cc_item07.mdl",
	nocraft = true,

	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "potions/life_potion.mp3",
	EffectOnDestruction = {
		Radius = 180
	},
	effects = {
		[ZHERB_EFFECT_MODELCHANGE] = {
			duration = 60,
			mdl = "models/cat/malf_cat.mdl"
		}
	}
})

AddPotion({
	uniqueid = "thehappybubblebox",
	name = "Mutluluk İksiri",
	desc = "Kişiyi mutlu yapar. ( Onun yokluğunda mutlu olabilir misin orasını bilemem. )",
	model = "models/items/provisions/potions/mana_potion.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 10,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 2) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	recipe = {
		[ZHERB_ING_MINT] = 2,
		[ZHERB_ING_NETTLE] = 1,
		[ZHERB_ING_MANDRAKEROOT] = 1
	},
	EffectOnDestruction = {
		Radius = 180
	},
	effects = {
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 10,
			interval = 2,
			sounds = {"vo/npc/Barney/ba_laugh01.wav", "vo/npc/Barney/ba_laugh02.wav", "vo/npc/Barney/ba_laugh03.wav", "vo/npc/Barney/ba_laugh04.wav", "vo/ravenholm/madlaugh01.wav", "vo/ravenholm/madlaugh02.wav", "vo/ravenholm/madlaugh03.wav", "vo/ravenholm/madlaugh04.wav", "vo/Citadel/br_laugh01.wav"}
		}
	}
})

AddPotion({
	uniqueid = "skivingsnackboxes",
	name = "Hapşırma İksiri",
	desc = "Kişiyi hapşırtır.",
	model = "models/items/provisions/potions/mana_potion.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 10,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 2) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	recipe = {
		[ZHERB_ING_MINT] = 2,
		[ZHERB_ING_NETTLE] = 1,
		[ZHERB_ING_MANDRAKEROOT] = 1
	},
	EffectOnDestruction = {
		Radius = 180
	},
	effects = {
		[ZHERB_EFFECT_SOUNDEMIT] = {
			duration = 10,
			interval = 3,
			sounds = {"zherb/cough/cough01.mp3", "zherb/cough/cough02.mp3", "zherb/cough/cough03.mp3", "zherb/cough/cough04.mp3", "zherb/cough/cough05.mp3", "zherb/cough/cough06.mp3", "zherb/cough/cough07.mp3", "zherb/cough/cough08.mp3"}
		},
		[ZHERB_EFFECT_POISON] = {
			interval = 1,
			rep = 30,
			min = 1,
			max = 1
		}
	}
})

AddPotion({
	uniqueid = "twilightmoonbeams",
	name = "Ayışığı İksiri",
	desc = "Kullanan kişinin kontrolünü kaybetmesini sağlar.",
	model = "models/items/provisions/potions/mana_potion.mdl",
	brewing_time = 10,
	skin = 4,
	crafting_xp = 10,
	price = 0,
	canbrew = function(ply) return YearRestriction(ply, 2) end,
	explo_effect = "zherb_potion_explosion",
	explo_sound = "physics/glass/glass_bottle_break2.wav",
	use_effect = "zherb_player_usepotion",
	use_sound = "zherb/slurp.mp3",
	recipe = {
		[ZHERB_ING_LEECH] = 1,
		[ZHERB_ING_FIRESEED] = 2,
		[ZHERB_ING_BLOODROOT] = 1
	},
	EffectOnDestruction = {
		Radius = 180,
		attach_effect = "unusual_hearts_bubbling"
	},
	effects = {
		[ZHERB_EFFECT_DISTORTMOVEMENT] = {
			duration = 15
		},
		[ZHERB_EFFECT_INVERTMOVEMENT] = {
			duration = 15
		}
	}
})
