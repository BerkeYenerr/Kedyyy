zherb = zherb or {}
zherb.config = zherb.config or {}

zherb.config.Looting = {
	mdls = {
		"models/prop/treasurebox/treasurebox.mdl",
		"models/objects/common/guild_box.mdl",
		"models/gchest/gchest.mdl",
		"models/props/furnitures/humans/chests/crateb_new.mdl"
	},
	time = 10,
	cooldown = 60,
	rewards = {}
}
zherb.config.Looting.rewards = {}
local function AddReward(data) table.insert(zherb.config.Looting.rewards,data) end




// THIS DEFINES HOW HIGH THE CHANCE IS THAT THE FIND NOTHING *Caps
AddReward({
	chance = 1,
	ent = "NO_WIN",
	// name = "Some name",
	func = function(ent)
		// Gets called after the prize got spawned
	end
})




/*

	Just add the Ingredient  / Potion ids bellow and define a dropchance

*/

local IngredientLoot = {
	[ZHERB_ING_ACONITE] = 1,
	[ZHERB_ING_CHEESE] = 2,
	[ZHERB_ING_EXPLODINGFLUID] = 3,
	[ZHERB_ING_STANDARDINGREDIENT] = 4,
	[ZHERB_ING_ARMADILLOBILE] = 5,
	[ZHERB_ING_BICORNHORN] = 6,
	[ZHERB_ING_LEECH] = 7,
	[ZHERB_ING_CHIZPURFLECARAPACE] = 8,
	[ZHERB_ING_ALCOHOL] = 9,
	[ZHERB_ING_FIRESEED] = 10,
	[ZHERB_ING_UNICORNHORN] = 11,
	[ZHERB_ING_FLOBBERWORMMUCUS] = 12,
	[ZHERB_ING_SLOTHBRAIN] = 13,
	[ZHERB_ING_FLITTERBY] = 14,
	[ZHERB_ING_GRIFFINCLAW] = 15,
	[ZHERB_ING_SALAMANDERBLOOD] = 16,
	[ZHERB_ING_BOOMSLANG] = 17,
	[ZHERB_ING_NEWTSPLEEN] = 18,
	[ZHERB_ING_BURSTINGMUSHROOM] = 19,
	[ZHERB_ING_CHICKEN] = 20,
	[ZHERB_ING_CHERRY] = 21,
}



local PotionLoot = {
	--["healpotion_small"] = 5
}








for k, v in pairs(IngredientLoot) do
    AddReward({
        chance = v,
        ent = "zherb_item_ingredient",
        name = zherb.config.Ingredients[k].name,
        func = function(ent)
            ent:SetIngredientID(k)
            ent:SetAmount(1)
            zherb.Ingredient.UpdateVisual(ent, k)
            ent:PhysicsInit(SOLID_VPHYSICS)
            ent:SetSolid(SOLID_VPHYSICS)
            ent:SetMoveType(MOVETYPE_VPHYSICS)
            ent:SetUseType(SIMPLE_USE)
            ent:SetCollisionGroup(COLLISION_GROUP_WEAPON)
            ent:UseClientSideAnimation()
            ent:SetCustomCollisionCheck(true)
            local phys = ent:GetPhysicsObject()

            if IsValid(phys) then
                phys:Wake()
                phys:EnableMotion(true)
            end
        end
    })
end

for k, v in pairs(PotionLoot) do
    AddReward({
        chance = v,
        ent = "zherb_item_potion",
        name = zherb.config.Potions[zherb.config.Potion_ListID[k]].name,
        func = function(ent)
            ent:SetPotionID(zherb.config.Potion_ListID[k])
            zherb.Potion.UpdateVisual(ent, k)
            ent:PhysicsInit(SOLID_VPHYSICS)
            ent:SetSolid(SOLID_VPHYSICS)
            ent:SetMoveType(MOVETYPE_VPHYSICS)
            ent:SetUseType(SIMPLE_USE)
            ent:UseClientSideAnimation()
            local phys = ent:GetPhysicsObject()

            if IsValid(phys) then
                phys:Wake()
                phys:EnableMotion(true)
            end
        end
    })
end

// Recalculates the final chance for all the items in the list
local function roundChance(what, precision)
	return math.floor(what * math.pow(10, precision) + 0.5) / math.pow(10, precision)
end

local function recalculateChance()
	local totalChance = 0

	for k, v in pairs(zherb.config.Looting.rewards) do
		totalChance = totalChance + v.chance
	end

	for k, v in pairs(zherb.config.Looting.rewards) do
		local chance = roundChance((100 / totalChance) * v.chance, 2)
		v.final_chance = chance
	end
end

recalculateChance()
