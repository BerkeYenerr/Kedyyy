
AddCSLuaFile()



SWEP.PrintName = "Gölge Yürüyüşü"

SWEP.Author = "Wheatley"



SWEP.Spawnable = false



SWEP.ViewModel = Model( "models/wheatleymodels/dishonored/shadowwalk_vm.mdl" )

SWEP.WorldModel = ""

SWEP.ViewModelFOV = 75

SWEP.UseHands = false



SWEP.Primary.ClipSize = -1

SWEP.Primary.DefaultClip = -1

SWEP.Primary.Automatic = true

SWEP.Primary.Ammo = "none"



SWEP.Secondary.ClipSize = -1

SWEP.Secondary.DefaultClip = -1

SWEP.Secondary.Automatic = true

SWEP.Secondary.Ammo = "none"



SWEP.SpawnPerc = 0

SWEP.SpawnTime = 0

SWEP.Moving = false

SWEP.Strafing = false

SWEP.InIntroSequence = false

SWEP.LoopSound = nil

SWEP.LoopSoundRestart = 0



SWEP.DrawAmmo = false

SWEP.DrawWeaponInfoBox = false

SWEP.DrawCrosshair = false



SWEP.HitDistance = 128



SWEP.PlaybackRate = 1



local SwingSound = Sound( "WeaponFrag.Throw" )

local HitSound = Sound( "Flesh.ImpactHard" )



function SWEP:SetupDataTables()

	self:NetworkVar( "Float", 0, "AngleBlendSpeed" )

	self:NetworkVar( "Angle", 0, "AngleBlendAng" )

	self:NetworkVar( "Angle", 1, "AngleBlendSAng" )

	self:NetworkVar( "Bool", 0, "PlayingFPScene" )

end



function SWEP:Initialize()

	self:SetHoldType( "fist" )

	

	self.SpawnTime = CurTime() + 1.0

end



function SWEP:BlendEyeAngles( ang, speed )

	speed = speed or 0.1



	self:SetAngleBlendAng( ang )

	self:SetAngleBlendSpeed( speed )

end



local function FrameToSecond( frame, fps )

	fps = fps or 30

	return frame / fps

end



function SWEP:DelayedAction( delay, func )

	timer.Simple( delay, function()

		if !IsValid( self ) || !IsValid( self.Owner ) then return end

		func( self )

	end )

end



local anim2tier_npcs = { "npc_headcrab", "npc_headcrab_fast", "npc_headcrab_black", "npc_fastzombie_torso", "npc_antlion", "npc_antlionguard",

	"npc_zombie_torso", "npc_rollermine" }



function SWEP:Attack()

	local ply = self.Owner

	

	local seqID = 1



	local vm = ply:GetViewModel()



	local eyepos = ply:GetPos() + Vector( 0, 0, 15 )

	

	local tr = util.TraceHull( {

		start = eyepos,

		endpos = eyepos + ply:EyeAngles():Forward() * self.HitDistance,

		filter = ply,

		mins = Vector( -10, -10, -10 ),

		maxs = Vector( 10, 10, 10 ),

		mask = MASK_SHOT_HULL

	} )



	local ent = tr.Entity

	

	if !IsValid( ent ) || ent:IsWorld() || ( !ent:IsNPC() && !ent:IsPlayer() ) then return end



	if ent:IsPlayer() then

		ent:Freeze( true )

		timer.Simple( 1, function()

			if IsValid( ent ) then

				ent:Freeze( false )

			end

		end )

	else

		ent:NextThink( CurTime() + 1 )

	end

	

	if table.HasValue( anim2tier_npcs, ent:GetClass() ) then

		seqID = 2

	end

	

	local attack_anim = 'attack' .. seqID



	local cang = ply:EyeAngles()

	local nang = ( ( ent:GetPos() + ent:OBBCenter() ) - eyepos ):Angle()

	

	self:SetAngleBlendAng( cang )

	self:SetAngleBlendSAng( self:GetAngleBlendAng() )



	local iniang = cang * 1

	iniang.p = 0

	

	self:BlendEyeAngles( iniang, 0.5 )

	self:DelayedAction( FrameToSecond( 3 ), function()

		self:BlendEyeAngles( nang, 0.25 )

	end )

	

	self:SetPlayingFPScene( true )

	ply:Freeze( true )

	vm:SendViewModelMatchingSequence( vm:LookupSequence( attack_anim ) )

	

	-- can't do this in DelayedAction because it also checks

	-- if weapon is valid too. in situation, where we lost

	-- our weapon bull still on the server, player will

	-- remain frozen

	timer.Simple( FrameToSecond( 23 ), function()

		if IsValid( ply ) then

			ply:Freeze( false )

		end

	end )

	

	self:DelayedAction( FrameToSecond( 15 ), function()

		self:Ragdolize( ent )

			

		self:DelayedAction( 0.15, function()

			self:BlendEyeAngles( cang, 0.25 )

		end )



		self:DelayedAction( 0.4, function()

			self:SendWeaponAnim( ACT_VM_IDLE )

			self:SetPlayingFPScene( false )

		end )

	end )

end



function SWEP:PrimaryAttack( right )

	self.Owner:LagCompensation( true )

	

	self:Attack()

	

	self.Owner:LagCompensation( false )

	

	self:SetNextPrimaryFire( CurTime() + 0.5 )

	self:SetNextSecondaryFire( CurTime() + 0.5 )

end



function SWEP:SecondaryAttack()

	self:PrimaryAttack( true )

end



function SWEP:Ragdolize( npc )

	if IsValid( npc ) and ( npc:IsNPC() || npc:IsPlayer() ) and SERVER then

		npc:EmitSound( HitSound )

		

		if npc:GetClass() == "npc_rollermine" then

			npc:Fire( "TurnOff" )

		end

		

		local dmg = DamageInfo()

		dmg:SetDamage( npc:Health() )

		dmg:SetDamageType( DMG_DIRECT )

		dmg:SetDamageForce( self.Owner:EyeAngles():Forward() * 5000 )

		dmg:SetAttacker( self.Owner )

		dmg:SetInflictor( self )

		npc:TakeDamageInfo( dmg )

	end

end



function SWEP:OnRemove()

	if self.LoopSound then

		self.LoopSound:Stop()

		self.LoopSound = nil

	end

end



function SWEP:OnDrop()

	self:Remove()

end



function SWEP:Holster()

	if IsValid( self.Owner ) && SERVER then

		WDA_END_SHADOWWALK( self.Owner )

	end



	return false

end



function SWEP:Deploy()

	local ply = self.Owner

	

	self:SendWeaponAnim( ACT_VM_DEPLOY )

	self.SpawnPerc = 0

	self.SpawnTime = CurTime() + 1.0

	ply.OldMoveSpeed = ply:GetWalkSpeed()

	ply.OldRunSpeed = ply:GetRunSpeed()

	ply.OldJumpPower = ply:GetJumpPower()

	ply.OldAllowFlashlight = ply:CanUseFlashlight()

	ply.WDA_OldHullSize = { ply:GetHull() }

	ply.WDA_OldHullSizeD = { ply:GetHullDuck() }

	ply:SetHull( Vector( -16, -16, 0 ), Vector( 16, 16, 16 ) )

	ply:SetHullDuck( Vector( -16, -16, 0 ), Vector( 16, 16, 16 ) )

	ply:DrawShadow( false )

	

	net.Start( 'WDA_NWMessage' )

		net.WriteInt( 7, 5 )

		net.WriteVector( Vector( -16, -16, 0 ) )

		net.WriteVector( Vector( 16, 16, 16 ) )

		net.WriteVector( Vector( -16, -16, 0 ) )

		net.WriteVector( Vector( 16, 16, 16 ) )

	net.Send( ply )

	

	ply:SetWalkSpeed( 50 )

	ply:SetRunSpeed( 100 )

	ply:SetJumpPower( 0 )

	ply:AllowFlashlight( false )

	

	local vm = ply:GetViewModel()

	vm:SetPlaybackRate( 1 )



	timer.Simple( 0.7, function()

		if !IsValid( self ) then return end

		ply:ViewPunch( Angle( -15, 15, 15 ) )

		ply:ScreenFade( SCREENFADE.IN, Color( 0, 0, 0, 245 ), 0.25, 0.1 )

		

		self.LoopSound = CreateSound( ply, 'dishonored/shadowwalk_loop.wav' )

		self.LoopSoundRestart = CurTime() + 8.8

		self.LoopSound:Play()

	end )

	

	timer.Simple( 1.0, function()

		if !IsValid( self ) then return end

		self:SendWeaponAnim( ACT_VM_IDLE )

		ply:SetModelScale( 0.1, 0.35 )

		self.Moving = false

		self.Strafing = false

	end )

	

	return true

end



function SWEP:Think()

	local ply = self.Owner

	if !IsValid( ply ) then return end



	local vm = self.Owner:GetViewModel()

	if self.SpawnTime < CurTime() then

		if ply:KeyDown( IN_FORWARD ) && !self.Moving && !self.Strafing then

			self.Moving = true

			self:SetPlaybackRate( 2 )

			self:SendWeaponAnim( ACT_VM_SWINGHIT )

		end

		

		if ply:KeyDown( IN_MOVELEFT ) and !self.Strafing then

			self.Strafing = true

			self.Moving = false

			vm:SendViewModelMatchingSequence( vm:LookupSequence( "move_left" ) )

		elseif ply:KeyDown( IN_MOVERIGHT ) and !self.Strafing then

			self.Strafing = true

			self.Moving = false

			vm:SendViewModelMatchingSequence( vm:LookupSequence( "move_right" ) )

		end

		

		self.PlaybackRate = Lerp( 0.1, self.PlaybackRate, math.Clamp( ply:GetVelocity():Length() / 50, 1, 2 ) )

		vm:SetPlaybackRate( self.PlaybackRate )

	end

	

	if !ply:KeyDown( IN_FORWARD ) && !ply:KeyDown( IN_MOVELEFT ) && !ply:KeyDown( IN_MOVERIGHT ) && ( self.Moving || self.Strafing ) then

		self.Moving = false

		self.Strafing = false

		self:SetPlaybackRate( 1 )

		self:SendWeaponAnim( ACT_VM_IDLE )

	end

	

	self.Strafing = ply:KeyDown( IN_MOVELEFT ) || ply:KeyDown( IN_MOVERIGHT )

	

	local vm = ply:GetViewModel()

	local ang = vm:GetAngles()

	local p, a = vm:GetBonePosition( vm:LookupBone( "rhand.upperarm" ) )

	local cp, ca = vm:GetBonePosition( vm:LookupBone( "rhand.lowerarm" ) )

	local ep, ea = vm:GetBonePosition( vm:LookupBone( "rhand.hand" ) )

	

	local ed = EffectData()

	ed:SetOrigin( p )

	ed:SetStart( cp )

	ed:SetAngles( ang )

	util.Effect( "wda_shadowwalk", ed )

	

	ed:SetOrigin( cp )

	ed:SetStart( ep )

	util.Effect( "wda_shadowwalk", ed )

	

	local p, a = vm:GetBonePosition( vm:LookupBone( "lhand.upperarm" ) )

	local cp, ca = vm:GetBonePosition( vm:LookupBone( "lhand.lowerarm" ) )

	local ep, ea = vm:GetBonePosition( vm:LookupBone( "lhand.hand" ) )

	

	ed:SetOrigin( p )

	ed:SetStart( cp )

	ed:SetAngles( ang )

	util.Effect( "wda_shadowwalk", ed )

	

	ed:SetOrigin( cp )

	ed:SetStart( ep )

	util.Effect( "wda_shadowwalk", ed )

	

	if self.LoopSound then

		if self.LoopSoundRestart <= CurTime() then

			self.LoopSoundRestart = CurTime() + 8.8

			self.LoopSound:Stop()

			self.LoopSound:Play()

		end

	end

end



if CLIENT then

	local AngleBlend = Angle()

	local IsBlending = false

	function SWEP:CalcView( ply, pos, ang, fov )

		if GetViewEntity() != ply then return end

		self.SpawnPerc = 1 - math.Clamp( self.SpawnTime - CurTime(), 0, 0.35 ) / 0.35

		

		local viewShake = math.sin( CurTime() * 2 )

		

		if self:GetPlayingFPScene() then

			if !IsBlending then

				IsBlending = true

				AngleBlend = self:GetAngleBlendSAng()

			end

			

			local vm = ply:GetViewModel()

			AngleBlend = LerpAngle( self:GetAngleBlendSpeed(), AngleBlend, self:GetAngleBlendAng() )



			ang = AngleBlend

		else

			IsBlending = false

		end



		return Lerp( self.SpawnPerc, pos, ply:GetPos() + Vector( 0, 0, 5 ) ), Angle( ang.p, ang.y, 5 * viewShake ), 90

	end



	local pitch = 0

	function SWEP:CalcViewModelView( vm, oldPos, oldAng, pos, ang )

		local ta = ang * 1

		ta.p = 0

		local tr = util.QuickTrace( LocalPlayer():GetPos() + Vector( 0, 0, 5 ), Vector( 0, 0, -25 ), LocalPlayer() )

		local isup = util.QuickTrace( LocalPlayer():GetPos() + Vector( 0, 0, 0 ), ta:Forward() * 18, LocalPlayer() )



		local targetPitch = tr.HitNormal:Angle().p - 270

		if isup.Hit then

			targetPitch = -targetPitch

		end

		

		pitch = Lerp( 0.05, pitch, targetPitch )

		

		local zlowering = math.max( EyeAngles().p, 0 ) / 15

		

		if self:GetPlayingFPScene() then

			return LocalPlayer():GetPos() - Vector( 0, 0, zlowering ), Angle( pitch, oldAng.y, 0 )

		end



		return LerpVector( self.SpawnPerc, oldPos, LocalPlayer():GetPos() - Vector( 0, 0, 5 + zlowering ) ), LerpAngle( self.SpawnPerc, oldAng, Angle( pitch, oldAng.y, 0 ) )

	end

end