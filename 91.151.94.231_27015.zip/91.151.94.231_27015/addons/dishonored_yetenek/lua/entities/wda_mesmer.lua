
AddCSLuaFile()

local BaseClass = baseclass.Get( "base_anim" )

ENT.Editable 	= true
ENT.Spawnable 	= false
ENT.AdminOnly 	= false
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.MesmerRange	= 250
ENT.SpawnPerc	= 0

function ENT:SetupDataTables()
	self:NetworkVar( "Float", 0, "LifeTime" )
end

function ENT:Initialize()
	if CLIENT then
		self.LoopSoundRestart = RealTime() + 22
		self.LoopSound = CreateSound( self, "dishonored/mesmerize_loop.wav" )
		if LocalPlayer() == self:GetOwner() then
			self:EmitSound( "dishonored/mesmerize_spawn.wav" )
			self.LoopSound:Play()
		end
		
		return
	end

	self:SetModel( "models/wheatleymodels/dishonored/mesmer.mdl" )

	WDA_MESMER_DATA[ self:EntIndex() ] = {}
	for i, v in pairs( ents.FindInSphere( self:GetPos(), self.MesmerRange ) ) do
		if v:IsPlayer() and v != self:GetOwner() || v:IsNPC() then
			// to do: handle nextbots (xenomorph, soma, maybe others?)
			table.insert( WDA_MESMER_DATA[ self:EntIndex() ], v )
			v:SetNWBool( "WDA_Mesmerized", true )
			
			if v:IsNPC() then
				self:MesmerNPC( v )
			end
		end
	end
	
	self:SetAutomaticFrameAdvance( true )
	
	local seq = self:LookupSequence( 'spawn' )

	self:SetSequence( seq )
		
	self:ResetSequenceInfo()
	self:SetCycle( 0 )
	self:SetPlaybackRate( 1 )
	
	timer.Simple( 0.16, function()
		if IsValid( self ) then
			local seq = self:LookupSequence( 'idle' )

			self:SetSequence( seq )
				
			self:ResetSequenceInfo()
			self:SetCycle( 0 )
			self:SetPlaybackRate( 1 )
		end
	end )
end

local idle_anims = { 'idle_unarmed', 'idle_subtle', 'idle1', 'idle' }
function ENT:MesmerNPC( ent, nodomino )
	if !ent:IsNPC() then return end
	if ent.SummonedFromVoid then return end
	
	local mt = ent:GetMoveType()
	ent:SetMoveType( MOVETYPE_NONE )
	ent.WDA_SAVEDPOS = ent:GetPos()
	ent:NextThink( self:GetLifeTime() )
	local a = ( self:GetPos() - ent:GetPos() ):Angle()
	a.p = 0
	a.r = 0
	ent:SetAngles( a )
	ent:ResetSequenceInfo()
	ent.savedMT = mt
	
	for i, v in pairs( idle_anims ) do
		local seq = self:LookupSequence( v )
		if seq && seq != -1 && seq != 0 then
			ent:SetSequence( seq )
			break
		end
	end
	
	ent:SetCycle( 0 )
	ent:SetEnemy( NULL )
	
	if nodomino then return end
	
	if IsValid( ent ) && ent.WDA_DOMINO && !ent.WDA_DOMINO_DAMAGE then
		if !ent.WDA_DOMINO_OWNER then return end
			
		for i, v in pairs( ent.WDA_DOMINO ) do
			if v == ent then continue end
			if !IsValid( v ) then
				ent.WDA_DOMINO[ i ] = nil
				if IsValid( ent.WDA_DOMINO_OWNER ) then
					ent.WDA_DOMINO_OWNER[ i ] = nil
				end
				continue
			end

			self:MesmerNPC( v, true )
		end
	end
end

function ENT:Think()
	if CLIENT then
		if self.LoopSound then
			if self.LoopSoundRestart <= RealTime() then
				self.LoopSoundRestart = RealTime() + 22
				self.LoopSound:Stop()
				self.LoopSound:Play()
			end
		end
		
		return
	end
	
	if self:GetLifeTime() <= CurTime() then
		self:Remove()
	end
end

function ENT:OnRemove()
	self:EmitSound( "dishonored/mesmerize_end.wav" )
	
	if self.LoopSound then
		self.LoopSound:Stop()
	end
	
	if WDA_MESMER_DATA[ self:EntIndex() ] then
		for i, v in pairs( WDA_MESMER_DATA[ self:EntIndex() ] ) do
			local canDisrepse = true
			for i, t in pairs( WDA_MESMER_DATA ) do
				if i == self:EntIndex() then
					continue
				end
				
				if table.HasValue( t, v ) then
					canDisrepse = false
					break
				end
			end
			
			if canDisrepse and IsValid( v ) then
				v:SetNWBool( "WDA_Mesmerized", false )
				if v.savedMT then
					v:SetMoveType( v.savedMT )
					v.savedMT = nil
				end
				if v.WDA_SAVEDPOS then
					v:SetPos( v.WDA_SAVEDPOS )
				end
				
				if v:IsNPC() then
					v:SetEnemy( NULL )
				end
			end
		end
		
		WDA_MESMER_DATA[ self:EntIndex() ] = nil
	end
end

if ( SERVER ) then return end
local bludge = Material( "effects/dishonored/strider_bulge_dudv.vmt" )
local flare = Material( "effects/dishonored/mesmer_darkglow.png" )

function ENT:Draw()
	if LocalPlayer() != self:GetOwner() && LocalPlayer():GetNWBool( "WDA_Mesmerized" ) then
		return
	end
	
	self.SpawnPerc = math.Approach( self.SpawnPerc, 1, RealFrameTime() * 1 )

	local sizex, sizey = 120 - 30 * ( ( math.sin( CurTime() * 15 ) + 1 ) / 2 ), 
		220 - 30 * ( ( math.cos( CurTime() * 20 ) + 1 ) / 2 )
		
	local pos = self:GetAttachment( self:LookupAttachment( 'middle' ) ).Pos
	
	render.SetMaterial( bludge )
	render.UpdateRefractTexture()
	render.DrawSprite( pos, sizex, sizey, color_white )

	render.SetMaterial( flare )
	render.DrawSprite( pos, 70, 200, Color( 5, 5, 5, 200 * self.SpawnPerc ) )
	render.DrawSprite( pos, 120, 250, Color( 0, 0, 0, 230 * self.SpawnPerc ) )
	
	local size = 255 * math.Clamp( math.tan( CurTime() * 1 ), 0, 1 )
	render.DrawSprite( pos, size, size, Color( 10, 10, 10, ( 255 - size ) * self.SpawnPerc ) )
	
	self:DrawModel()
end
