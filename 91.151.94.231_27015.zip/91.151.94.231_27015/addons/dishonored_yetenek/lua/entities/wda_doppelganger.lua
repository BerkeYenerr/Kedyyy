
AddCSLuaFile()



local BaseClass = baseclass.Get( "base_anim" )



ENT.Editable 	= false

ENT.Spawnable 	= false

ENT.AdminOnly 	= false

ENT.RenderGroup = RENDERGROUP_OPAQUE

ENT.Health = 100

ENT.SpawnDelay	= 0

ENT.DesiredYaw 	= 0

ENT.Velocity = Vector()

ENT.GroundEntity = NULL

ENT.GroundLocal = Vector()

ENT.GroundPos = Vector()



function ENT:SetupDataTables()

	self:NetworkVar( "Float", 0, "LifeTime" )

end



function ENT:Initialize()

	self.Owner = self:GetOwner()

	

	if CLIENT then

		self.SpawnDelay = CurTime() + 0.25

		return

	end

	

	local tr = util.QuickTrace( self:GetPos(), Vector( 0, 0, -1 ), self )

	self.GroundEntity = tr.Entity

	if IsValid( self.GroundEntity ) then

		self.GroundPos = tr.Entity:GetPos()

		self.GroundLocal = self:GetPos() - self.GroundPos

	end

	

	self.Bullseye = ents.Create( 'npc_bullseye' )

	self.Bullseye:SetPos( self:GetPos() + Vector( 0, 0, 46 ) )

	self.Bullseye:SetHealth( self.Owner:Health() )

	self.Bullseye:SetModelScale( 1 )

	self.Bullseye:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )

	self.Bullseye.Doppelganger = self

	self.Bullseye:Spawn()



	for i, v in pairs( ents.FindByClass( 'npc_*' ) ) do

		if v.AddEntityRelationship then

			v:AddEntityRelationship( self.Bullseye, D_HT, 99 )

			//self:AddEntityRelationship( v, D_HT, 99 )

		end

	end

	

	self:SetModel( self:GetOwner():GetModel() )



	local targetAnim = 'idle_all_01'

	local wep = self:GetOwner():GetActiveWeapon()

	if IsValid( wep ) then

		local ht = wep:GetHoldType()

		if wep:IsScripted() and wep.HoldType then

			ht = wep.HoldType

		end



		if ht == 'smg' then

			ht = 'smg1'

		end

		

		targetAnim = 'idle_' .. ht

		self:SetNWString( 'WDA_WeaponModel', wep:GetModel() )

	end

	

	self:SetAutomaticFrameAdvance( true )

	

	local seq = self:LookupSequence( 'cidle_all' )



	self:SetSequence( seq )

			

	self:ResetSequenceInfo()

	self:SetCycle( 0 )

	self:SetPlaybackRate( 1 )

	

	timer.Simple( 0.5, function()

		if !IsValid( self ) then return end

		local seq = self:LookupSequence( targetAnim )

		if seq == -1 then

			seq = self:LookupSequence( 'idle_all_01' )

		end



		self:SetSequence( seq )

				

		self:ResetSequenceInfo()

		self:SetCycle( 0 )

		self:SetPlaybackRate( 1 )

	end )

	

	self.DesiredYaw = self:GetAngles().y

	

	self:SetSolid( SOLID_BBOX )

	self:SetCollisionGroup( COLLISION_GROUP_BREAKABLE_GLASS )

	

	self:SetOwner( NULL )

end



function ENT:Tick()

	if CLIENT then return end

	if self:GetLifeTime() <= CurTime() then

		self:Remove()

	end

	

	self:SetAngles( LerpAngle( 0.35, self:GetAngles(), Angle( 0, self.DesiredYaw, 0 ) ) )



	local owner = self.Owner

	if IsValid( owner ) then



		if owner:KeyDown( IN_USE ) and owner:GetAimVector():Dot( ( self:GetPos() + Vector( 0, 0, 40 ) - owner:EyePos() ):GetNormalized() ) > 0.99

			and owner:GetPos():Distance( self:GetPos() ) < GetConVarNumber( 'sv_wda_doppelganger_swap_range' ) then

			local tr = util.TraceLine( { start = self:GetPos() + Vector( 0, 0, 40 ), endpos = owner:EyePos(), filter = { self, owner, self.Bullseye }, MASK_VISIBLE } )

			if tr.Hit then return end

			local ppos = owner:GetPos()

			owner.WDA_DPPOS = self:GetPos()

			self:SetPos( ppos )

			owner:SetPos( owner.WDA_DPPOS )

			local fov = owner:GetFOV()

			owner:SetFOV( 150, 0 )

			owner:SetFOV( fov, 0.4 )

			owner:EmitSound( 'dishonored/doppelganger_swap.wav' )

		end

	end

	

	local tr = util.QuickTrace( self:GetPos() + Vector( 0, 0, 25 ), Vector( 0, 0, -26 ), self )

	if !tr.Hit || tr.HitNormal.z <= 0.7071 then

		self.GroundEntity = NULL

		local ftr = util.QuickTrace( self:GetPos(), Vector( 0, 0, -16000 ), self )

		local npos = self:GetPos() + self.Velocity

		npos.z = math.max( npos.z, ftr.HitPos.z )

		self:SetPos( npos )

		self.Velocity = self.Velocity + physenv.GetGravity() * FrameTime() * 0.05

	else

		if self.GroundEntity == NULL && IsValid( tr.Entity ) then

			self.GroundEntity = tr.Entity

			self.GroundPos = tr.Entity:GetPos()

			self.GroundLocal = self:GetPos() - self.GroundPos

		end

		self.Velocity = Vector()

	end



	if IsValid( self.GroundEntity ) and self.GroundEntity:GetPos() != self.GroundPos then

		self:SetPos( self.GroundEntity:GetPos() + self.GroundLocal )

		self.GroundPos = self.GroundEntity:GetPos()

	end

	

	if IsValid( self.Bullseye ) then

		self.Bullseye:SetPos( self:GetPos() + Vector( 0, 0, 46 ) )

		

		if self.Bullseye:Health() <= 0 then

			self:Remove()

			return

		end

	else

		self:Remove()

	end

end



if CLIENT then

	ENT.SpawnPerc = 0

	ENT.HeadAngleTarget = Angle( 0, 0, 0 )

	ENT.WeaponModel = nil

	function ENT:Draw()

		if self.WeaponModel == nil and self:GetNWString( 'WDA_WeaponModel' ) != '' then

			self.WeaponModel = ClientsideModel( self:GetNWString( 'WDA_WeaponModel' ) )

			if self.WeaponModel then

				self.WeaponModel:SetParent( self )

				self.WeaponModel:AddEffects( EF_BONEMERGE )

				self.WeaponModel:SetNoDraw( true )

			end

		end

	

		if self.SpawnDelay <= CurTime() and self.SpawnPerc != 1 then

			self.SpawnPerc = math.Approach( self.SpawnPerc, 1, FrameTime() * 3 )

		end

		

		if IsValid( LocalPlayer() ) then

			local ang = ( LocalPlayer():EyePos() - ( self:GetPos() + Vector( 0, 0, 72 ) ) ):Angle()

			ang = self:WorldToLocalAngles( ang )

			if math.abs( ang.y ) > 50 then

				ang = Angle( 0, 0, 0 )

			end

			

			self.HeadAngleTarget = LerpAngle( 0.05, self.HeadAngleTarget, Angle( 0, -ang.p + 10, ang.y ) )

		end

		

		local headBone = self:LookupBone( 'ValveBiped.Bip01_Head1' )

		if not headBone then return end

		self:ManipulateBoneAngles( headBone, self.HeadAngleTarget )

		

		render.SetBlend( self.SpawnPerc )

		self:DrawModel()

		if self.WeaponModel and IsValid(self.WeaponModel) then

			self.WeaponModel:DrawModel()

		end

		render.SetBlend( 1 )

	end

end



function ENT:OnRemove()

	if SERVER then

		local ed = EffectData()

		ed:SetOrigin( self:GetPos() )

		util.Effect( 'wda_doppelganger_puff', ed )

	end

	

	if IsValid( self.WeaponModel ) then

		self.WeaponModel:Remove()

	end

	

	if IsValid( self.Bullseye ) then

		self.Bullseye:Remove()

	end

end



function ENT:OnTakeDamage( dmg )

	if IsValid( self.Bullseye ) then

		self.Bullseye.WDA_RecursionSave = true

		self.Bullseye:TakeDamageInfo( dmg )

		self.Bullseye.WDA_RecursionSave = false

		

		local att = dmg:GetAttacker()

		if IsValid( att ) then

			local dir = ( att:GetPos() - self:GetPos() )

			self.DesiredYaw = dir:Angle().y

		end

	end

end



function ENT:Health()

	if IsValid( self.Bullseye ) then

		return self.Bullseye:Health()

	end

	

	return 0

end