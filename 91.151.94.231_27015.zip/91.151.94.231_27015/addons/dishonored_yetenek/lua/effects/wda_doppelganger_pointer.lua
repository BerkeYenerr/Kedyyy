
-----------------------------------------------------
local mat_smoke = Material( "effects/dishonored/smokesprites_0012.vmt" )

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	
	if !WDA_DOPPELGANGER_AIMHELPER_POS then return end

	local hull = Vector( 10, 10, 15 )
	
	local em = ParticleEmitter( Vector(), false )

	for i = 1, 1 do
		local pos = origin + Vector( math.random( -hull.x, hull.x ), math.random( -hull.y, hull.y ), math.random( -hull.z, hull.z ) )
		
		local prtl = em:Add( mat_smoke, pos )
		if prtl then
			prtl.spawnDisplace = pos - WDA_DOPPELGANGER_AIMHELPER_POS
			prtl:SetGravity( Vector( 0, 0, -10 ) )
			prtl:SetColor( 234, 216, 195 )
			prtl:SetStartSize( 10 )
			prtl:SetEndSize( 16 )
			prtl:SetStartAlpha( 100 )
			prtl:SetEndAlpha( 0 )
			prtl:SetRoll( math.random( 0, 360 ) )
			prtl:SetDieTime( math.random( 3, 6 ) / 10 )
			prtl:SetNextThink( FrameTime() )
			prtl:SetThinkFunction( function( self )
				self:SetPos( WDA_DOPPELGANGER_AIMHELPER_POS + self.spawnDisplace )
				self:SetNextThink( FrameTime() )
			end )
		end
	end
	
	em:Finish()
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end