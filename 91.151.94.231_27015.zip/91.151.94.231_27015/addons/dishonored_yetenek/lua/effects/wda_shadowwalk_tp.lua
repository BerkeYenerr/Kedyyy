
-----------------------------------------------------
local mat_smoke = Material( "effects/dishonored/smokesprites_0012_withz.vmt" )

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	
	local em = ParticleEmitter( Vector(), false )
	
	local prtl = em:Add( mat_smoke, origin + Vector( 0, 0, 10 ) + VectorRand() * 5 )
	if prtl then
		prtl:SetGravity( Vector( 0, 0, -10 ) )
		prtl:SetColor( 0, 0, 0 )
		prtl:SetStartSize( 15 )
		prtl:SetEndSize( 45 )
		prtl:SetStartAlpha( 100 )
		prtl:SetEndAlpha( 0 )
		prtl:SetRoll( math.random( 0, 360 ) )
		prtl:SetDieTime( math.random( 5, 9 ) / 10 )
		prtl:SetVelocity( VectorRand() * 10 )
	end
	
	em:Finish()
end

function EFFECT:Think()
	return false
end