
-----------------------------------------------------
local mat_smoke = Material( "effects/dishonored/smokesprites_0012.vmt" )

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	local hull = Vector( 16, 16, 32 )
	
	local em = ParticleEmitter( Vector(), false )

	for i = 1, 64 do
		local pos = origin + Vector( math.random( -hull.x, hull.x ), math.random( -hull.y, hull.y ), math.random( -hull.z, hull.z ) + 28 )
		
		local prtl = em:Add( mat_smoke, pos + VectorRand() * 3 )
		if prtl then
			prtl:SetGravity( Vector( 0, 0, -10 ) )
			prtl:SetColor( 234, 216, 195 )
			prtl:SetStartSize( 2 )
			prtl:SetEndSize( math.random( 20, 50 ) )
			prtl:SetStartAlpha( 255 )
			prtl:SetEndAlpha( 0 )
			prtl:SetRoll( math.random( 0, 360 ) )
			prtl:SetDieTime( math.random( 5, 7 ) / 10 )
			prtl:SetVelocity( ( pos - origin ):GetNormalized() * math.random( 2, 7 ) )
		end
	end
	
	em:Finish()
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end