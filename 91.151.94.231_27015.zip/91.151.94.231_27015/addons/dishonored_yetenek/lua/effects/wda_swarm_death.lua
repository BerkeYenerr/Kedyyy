
-----------------------------------------------------
local mat_smoke = Material( "effects/dishonored/smokesprites_0012_withz.vmt" )

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	
	local em = ParticleEmitter( Vector(), false )

	for i = 1, 16 do
		local prtl = em:Add( mat_smoke, origin + Vector( 0, 0, 8 ) )
		if prtl then
			//prtl:SetGravity( Vector( 0, 0, -35 ) )
			prtl:SetColor( 0, 0, 0 )
			prtl:SetStartSize( 2 )
			prtl:SetEndSize( math.random( 15, 35 ) )
			prtl:SetStartAlpha( 255 )
			prtl:SetEndAlpha( 0 )
			prtl:SetRoll( math.random( 0, 360 ) )
			prtl:SetDieTime( math.random( 5, 7 ) / 10 )
			prtl:SetVelocity( VectorRand() * 16 )
		end
	end
	
	em:Finish()
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end