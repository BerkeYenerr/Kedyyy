
-----------------------------------------------------
local mat = Material( 'models/wheatleymodels/dishonored/windblast_sheet' )
local mat_bludge = Material( "effects/dishonored/strider_bulge_dudv.vmt" )
local spriteSize = 100
local lifetime = 0.35

function EFFECT:Init( data )
	self.LifeTime = CurTime() + lifetime

	local owner = data:GetEntity()
	local pos = data:GetOrigin()
	local ang = data:GetAngles()

	self.Owner = owner
	
	self:SetModel( 'models/wheatleymodels/dishonored/windblast.mdl' )
	self:SetPos( pos )
	self:SetAngles( ang )
	self:SetPlaybackRate( 1 )
end

function EFFECT:Think()
	if ( self.LifeTime > CurTime() ) then
		return true
	end

	return false
end

function EFFECT:Render()
	local frac = ( self.LifeTime - CurTime() ) / lifetime

	self:SetCycle( frac )

	local shouldIgnoreZ = self.Owner == LocalPlayer()
	
	cam.IgnoreZ( shouldIgnoreZ )
	
	mat_bludge:SetFloat( '$refractamount', 0.05 * frac )
	render.UpdateRefractTexture()
	render.SetMaterial( mat_bludge )
	local newSpriteSize = spriteSize - 35 * frac
	render.DrawSprite( self:GetPos() + self:GetAngles():Forward() * 15, newSpriteSize, newSpriteSize, Color( 255, 255, 255, 255 ) )
	
	render.SetBlend( frac )
	render.MaterialOverride( mat )
		self:DrawModel()
	render.MaterialOverride( 0 )
	render.SetBlend( 1 )
	
	cam.IgnoreZ( false )
end