
-----------------------------------------------------
local mat_line = Material( "effects/dishonored/bendtime_line.vmt" )
local life = 0.25

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()

	self.LifeTime = RealTime() + life -- in case I use SetTimeScale
	
	self.Beams = {}

	for i = 1, 45 do
		local radius = 800
		local rad = math.rad( math.random( 0, 360 ) )
		local x, y = math.sin( rad ) * radius, math.cos( rad ) * radius
		table.insert( self.Beams, Vector( x, y, math.random( -200, 200 ) ) )
	end
end

function EFFECT:Think()
	if self.LifeTime > RealTime() then
		self:SetPos( EyePos() )
		return true
	end
	
	return false
end

function EFFECT:Render()
	if self.Beams then
		local anim = ( self.LifeTime - RealTime() ) / life
		local add = Vector( 0, 0, 300 * anim )
		local clr = Color( 255, 255, 255, 255 * ( 1 - anim ) )
		local p = EyePos()
		
		for i, v in pairs( self.Beams ) do
			render.SetMaterial( mat_line )
			render.DrawBeam( p + v + add, p + v - add, 5, 0, 1, clr )
		end
	end
end