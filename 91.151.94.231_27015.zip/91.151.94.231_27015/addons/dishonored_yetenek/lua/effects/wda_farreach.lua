
-----------------------------------------------------
local mat_beam = Material( "effects/dishonored/farreach_beam" )
local mat_hitpos = Material( "effects/dishonored/blink_sprite_sphere" )
local beamwidth = 12
local lifetime = 0.25
local traveltime = 0.15
local fadeoutime = 0.15

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	local start = fx:GetStart()
	local ply = fx:GetEntity()
	self.Origin = origin
	self.StartOrigin = start
	self.Owner = ply
	self.LifeTime = CurTime() + lifetime
end

function EFFECT:Think()
	if self.LifeTime and self.LifeTime + traveltime + fadeoutime > CurTime() then
		return true
	end
	
	return false
end

function EFFECT:Render()
	if self.StartOrigin and self.Origin then
		if LocalPlayer() == self.Owner then
			cam.IgnoreZ( true )
		end
		
		local adj = Vector( 0, 10, -5 )
		adj:Rotate( EyeAngles() )
		local strt = ( LocalPlayer() == self.Owner ) and LocalPlayer():GetShootPos() or self.StartOrigin
		local dist = ( strt - self.Origin ):Length() / 500 
		local start, endpos = strt + adj, self.Origin
		
		/*local lifeperc = math.min( ( self.LifeTime - CurTime() + traveltime ) / lifetime, 1 )
		local frac = 1 - math.max( self.LifeTime - CurTime() - ( lifetime - traveltime ), 0 ) / traveltime
		local bepos = LerpVector( frac, start, endpos )
		local texend = 2
		
		render.SetMaterial( mat_beam )
		render.DrawBeam( start, bepos, beamwidth + 15 * ( 1 - lifeperc ), 0, texend, Color( 64, 160, 252, 255 * lifeperc ) )
		
		local add = 64 * ( 1 - lifeperc )
		render.SetMaterial( mat_hitpos )
		render.DrawSprite( bepos, beamwidth + add, beamwidth + add, Color( 0, 0, 0, 255 * lifeperc ) )*/
		
		local totalLifeTime = lifetime + traveltime + fadeoutime
		local actualLifeTime = self.LifeTime - CurTime() + traveltime + fadeoutime
		local spawnPerc = math.Min( totalLifeTime - actualLifeTime, traveltime ) / traveltime
		local perc = math.Min( actualLifeTime, fadeoutime ) / fadeoutime
		//print( spawnPerc )
		
		local bepos = LerpVector( spawnPerc, start, endpos )
		local texend = dist
		
		render.SetMaterial( mat_beam )
		render.DrawBeam( start, bepos, beamwidth + 15 * ( 1 - perc ), texend, 0, Color( 64, 160, 252, 255 * perc ) )
		
		local add = 64 * ( 1 - perc )
		render.SetMaterial( mat_hitpos )
		render.DrawSprite( bepos, beamwidth + add, beamwidth + add, Color( 0, 0, 0, 255 * perc ) )
		
		cam.IgnoreZ( false )
	end
end