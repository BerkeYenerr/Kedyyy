
-----------------------------------------------------
local mat_smoke = Material( "effects/dishonored/smokesprites_0012.vmt" )

function EFFECT:SpawnOnElement( emitter, s, e, ang )
	
end

function EFFECT:Init( fx )
	local s = fx:GetOrigin()
	local e = fx:GetStart()
	local ang = fx:GetAngles()
	
	local em = ParticleEmitter( Vector(), false )
	
	/*-- right hand
	local p, a = ent:GetBonePosition( ent:LookupBone( "rhand.upperarm" ) )
	local cp, ca = ent:GetBonePosition( ent:LookupBone( "rhand.lowerarm" ) )
	local ep, ea = ent:GetBonePosition( ent:LookupBone( "rhand.hand" ) )
	self:SpawnOnElement( em, p, cp, ang )
	self:SpawnOnElement( em, cp, ep, ang )
	
	-- left hand
	local p, a = ent:GetBonePosition( ent:LookupBone( "lhand.upperarm" ) )
	local cp, ca = ent:GetBonePosition( ent:LookupBone( "lhand.lowerarm" ) )
	local ep, ea = ent:GetBonePosition( ent:LookupBone( "lhand.hand" ) )
	self:SpawnOnElement( em, p, cp, ang )
	self:SpawnOnElement( em, cp, ep, ang )*/
	
	local pos = LerpVector( math.random( 1, 100 ) / 100, s, e ) + Vector( 0, 0, 2 )
	
	local prtl = em:Add( mat_smoke, pos + VectorRand() * 3 )
	if prtl then
		prtl:SetGravity( Vector( 0, 0, -10 ) )
		prtl:SetColor( 0, 0, 0 )
		prtl:SetStartSize( 2 )
		prtl:SetEndSize( 11 )
		prtl:SetStartAlpha( 255 )
		prtl:SetEndAlpha( 0 )
		prtl:SetRoll( math.random( 0, 360 ) )
		prtl:SetDieTime( math.random( 7, 13 ) / 10 )
		prtl:SetVelocity( VectorRand() * 10 )
	end
	
	em:Finish()
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end