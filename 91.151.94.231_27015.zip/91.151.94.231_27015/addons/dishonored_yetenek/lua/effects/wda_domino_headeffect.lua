
-----------------------------------------------------
local mat_spark = Material( "effects/dishonored/energysplash.vmt" )
local mat_smoke = Material( "effects/dishonored/smokesprites_0012.vmt" )

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	local inivel = fx:GetStart() * 0.1

	local em = ParticleEmitter( Vector(), false )
		
	local prtl = em:Add( mat_smoke, origin + inivel )
	if prtl then
		local velocity = VectorRand() * 12
		local roll = ( ( origin + velocity ) - origin ):Angle().p
		
		prtl:SetColor( 255, 200, 120 )
		prtl:SetStartSize( 0 )
		prtl:SetEndSize( 10 )
		prtl:SetStartAlpha( 10 )
		prtl:SetEndAlpha( 0 )
		prtl:SetRoll( roll )
		prtl:SetDieTime( math.random( 7, 15 ) / 10 )
		prtl:SetVelocity( inivel + velocity * 0.5 )
	end
	
	em:Finish()
	
	local em = ParticleEmitter( Vector(), false )
	
	local prtl = em:Add( mat_spark, origin )
	if prtl then
		local velocity = VectorRand() * 30
		local ang = ( ( origin + velocity ) - origin ):Angle()
		ang:RotateAroundAxis( Vector( 0, 0, 1 ), 90 )
		
		prtl:SetColor( 255, 200, 120 )
		prtl:SetStartSize( 0 )
		prtl:SetEndSize( 2 )
		prtl:SetStartAlpha( 255 )
		prtl:SetEndAlpha( 0 )
		prtl:SetAngles( ang )
		prtl:SetDieTime( math.random( 2, 5 ) / 10 )
		prtl:SetVelocity( inivel + velocity * 0.5 )
	end
	
	em:Finish()
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end