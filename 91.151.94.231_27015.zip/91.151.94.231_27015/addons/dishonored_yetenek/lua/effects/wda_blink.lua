
-----------------------------------------------------
function EFFECT:Init( fx )
	local origin = fx:GetOrigin()
	
	local extra = CurTime() % 2 > 1.98
	
	self.mat 		= Material( 'effects/dishonored/blink_leak' )
	self.lifetime	= ( extra ) and math.random( 2, 7 ) / 10 or math.random( 1, 2 ) / 10
	self.deathtime 	= CurTime() + self.lifetime
	self.drop 		= 0
	self.size		= ( extra ) and math.random( 22, 32 ) or math.random( 22, 32 )

	/*local PE = ParticleEmitter( origin )
		for i = 1, 2 do
			local spawnPos = origin + VectorRand() * 2
			local ptcl = PE:Add( 'effects/dishonored/blink_leak', spawnPos )
				ptcl:SetDieTime( math.random( 2, 6 ) / 10 )
				ptcl:SetStartAlpha( 255 )
				ptcl:SetEndAlpha( 0 )
				ptcl:SetRollDelta( 0 )
				ptcl:SetGravity( Vector( 0, 0, -500 ) )
				ptcl:SetCollide( true )
				ptcl:SetColor( 255, 255, 255 )
				ptcl:SetAirResistance( 0 )
				ptcl:SetStartSize( math.random( 5, 9 ) )
				ptcl:SetEndSize( 0 )
				ptcl:SetVelocityScale( true )
				ptcl:SetLighting( false )
		end
	PE:Finish()*/
end

function EFFECT:Think()
	if self.deathtime and self.deathtime > CurTime() then
		return true
	end
	
	return false
end

function EFFECT:Render()
	if self.mat and WDA_TARGET_EFFECT and self.lifetime and self.deathtime and self.size then
		local anim = 1 - ( self.deathtime - CurTime() ) / self.lifetime
		local origin = WDA_TARGET_EFFECT
		self.mat:SetFloat( '$frame', 8 * anim )
		render.SetMaterial( self.mat )
		render.DrawSprite( origin + Vector( 0, 0, self.drop ), self.size, self.size, Color( 110, 200, 255, 80 * anim ) )
		self.drop = self.drop - 1
	end
end