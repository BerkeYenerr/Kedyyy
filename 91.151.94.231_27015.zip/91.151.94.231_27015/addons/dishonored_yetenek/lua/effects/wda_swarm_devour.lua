
-----------------------------------------------------
local mat_smoke = Material( "effects/dishonored/smokesprites_0012_withz.vmt" )

local length = 1

function EFFECT:Init( fx )
	local ent = fx:GetEntity()
	self.Inversed = fx:GetFlags() == 2

	self.LifeTime = CurTime() + length

	self.AssignedEntity = ent
	ent.RenderOverride = self.DrawEntity
	ent.DevourEffect = self
end

function EFFECT:DrawEntity()
	local mn, mx = self:GetRenderBounds()
	local Up = ( mx - mn ):GetNormal()
	local Bottom = self:GetPos() + mn
	local Top = self:GetPos() + mx

	local Fraction = ( self.DevourEffect.LifeTime - CurTime() ) / length
	Fraction = math.Clamp( Fraction / 1, 0, 1 )
	if self.DevourEffect.Inversed then
		Fraction = 1 - Fraction
	end

	local Lerped = LerpVector( 1 - Fraction, Bottom, Top )

	local normal = Up
	local distance = normal:Dot( Lerped )

	local bEnabled = render.EnableClipping( true )
	render.PushCustomClipPlane( normal, distance )

	self:DrawModel()
	
	render.PopCustomClipPlane()
	render.EnableClipping( bEnabled )
end

function EFFECT:Think()
	if !IsValid( self.AssignedEntity ) then
		return false
	end
	
	if ( self.LifeTime > CurTime() ) then
		return true
	end

	self.AssignedEntity.RenderOverride = nil
	self.AssignedEntity.SpawnEffect = nil

	return false
end

function EFFECT:Render()
end