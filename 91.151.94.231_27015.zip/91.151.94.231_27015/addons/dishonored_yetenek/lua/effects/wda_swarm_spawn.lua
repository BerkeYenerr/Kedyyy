
-----------------------------------------------------
local mat_smoke_noz = Material( "effects/dishonored/smokesprites_0012.vmt" )
local mat_smoke = Material( "effects/dishonored/smokesprites_0012_withz.vmt" )

function EFFECT:Init( fx )
	local origin = fx:GetOrigin()

	if fx:GetFlags() == 2 then
		local em = ParticleEmitter( Vector(), false )
		
		local prtl = em:Add( mat_smoke_noz, origin + VectorRand() * 10 )
		if prtl then
			prtl:SetGravity( Vector( 0, 0, -35 ) )
			prtl:SetColor( 0, 0, 0 )
			prtl:SetStartSize( 2 )
			prtl:SetEndSize( math.random( 20, 50 ) )
			prtl:SetStartAlpha( 255 )
			prtl:SetEndAlpha( 0 )
			prtl:SetRoll( math.random( 0, 360 ) )
			prtl:SetDieTime( math.random( 3, 6 ) / 10 )
			prtl:SetVelocity( VectorRand() * 8 + Vector( 0, 0, 25 ) )
		end
		
		em:Finish()
		
		local em = ParticleEmitter( Vector(), true )
		
		local prtl = em:Add( mat_smoke_noz, origin )
		if prtl then
			prtl:SetColor( 0, 0, 0 )
			prtl:SetStartSize( 15 )
			prtl:SetEndSize( 45 )
			prtl:SetStartAlpha( 255 )
			prtl:SetEndAlpha( 0 )
			prtl:SetAngles( Angle( -90, math.random( 0, 360 ), 0 ) )
			prtl:SetDieTime( 0.25 )
		end
		
		em:Finish()
	else
		local em = ParticleEmitter( Vector(), false )
		
		for i = 1, 45 do
			local prtl = em:Add( mat_smoke, origin + VectorRand() * 10 )
			if prtl then
				prtl:SetGravity( Vector( 0, 0, -35 ) )
				prtl:SetColor( 0, 0, 0 )
				prtl:SetStartSize( 2 )
				prtl:SetEndSize( math.random( 20, 50 ) )
				prtl:SetStartAlpha( 255 )
				prtl:SetEndAlpha( 0 )
				prtl:SetRoll( math.random( 0, 360 ) )
				prtl:SetDieTime( math.random( 5, 13 ) / 10 )
				prtl:SetVelocity( VectorRand() * 8 + Vector( 0, 0, 25 ) )
			end
		end
		
		em:Finish()
		
		-- ground 'hole'
		local em = ParticleEmitter( Vector(), true )

		for i = 1, 6 do
			local prtl = em:Add( mat_smoke, origin )
			if prtl then
				prtl:SetColor( 0, 0, 0 )
				prtl:SetStartSize( 15 )
				prtl:SetEndSize( 80 )
				prtl:SetStartAlpha( 255 )
				prtl:SetEndAlpha( 0 )
				prtl:SetAngles( Angle( -90, math.random( 0, 360 ), 0 ) )
				prtl:SetDieTime( 1 )
			end
		end
		
		em:Finish()
	end
end

function EFFECT:Think()
	return false
end

function EFFECT:Render()
end