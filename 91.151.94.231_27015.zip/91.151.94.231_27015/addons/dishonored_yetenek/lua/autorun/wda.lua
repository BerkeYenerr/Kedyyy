if SERVER then
util.AddNetworkString( "wdabilgiiste" ) 
util.AddNetworkString( "wdabilgiyanit" ) 
net.Receive( "wdabilgiiste", function( len, pl )
if (pl:IsAdmin() or pl:IsSuperAdmin()) then
local ply = net.ReadEntity()
local steam64 = ply:SteamID64()
local dosya = file.Read( "yetenekler/"..steam64..".txt", "DATA" ) or ""
net.Start( "wdabilgiyanit", false ) 
net.WriteString(dosya)
net.Send(pl)
end
end)
util.AddNetworkString( "wdanetyazdir" ) 
net.Receive( "wdanetyazdir", function( len, pl )
if ( IsValid( pl ) and pl:IsPlayer() and (pl:IsAdmin() or pl:IsSuperAdmin())) then
local oyuncu = net.ReadEntity()
local mod = net.ReadString()
local yetenek = net.ReadString()
wdayazdir(oyuncu,mod,yetenek)
end
end )
local function wdakur()
if not file.Exists( "yetenekler", "DATA" ) then
file.CreateDir( "yetenekler" )
end
end
hook.Add( "Initialize", "wdasys1", wdakur )
local function wdaokut(ply)
local st64 = ply:SteamID64()
local dosya = file.Read( "yetenekler/"..st64..".txt", "DATA" ) or ""
ply:SetNWString("yetenekler",dosya)
end
hook.Add( "PlayerInitialSpawn", "wdasys2", wdaokut )
function wdayazdir(ply,mod,yetenek)
local st64 = ply:SteamID64()
if not file.Exists( "yetenekler/"..st64..".txt", "DATA" ) then
file.Write( "yetenekler/"..st64..".txt", "" )
end
local dosya = file.Read( "yetenekler/"..st64..".txt", "DATA" ) or ""
if mod == "sil" then
dosya = string.Replace( dosya, "|"..yetenek.."|", "" ) 
file.Write( "yetenekler/"..st64..".txt", dosya )
elseif mod == "ekle" then
dosya = dosya.."|"..yetenek.."|"
file.Write( "yetenekler/"..st64..".txt", dosya )
end
ply:SetNWString("yetenekler",dosya)
end
end


-- Dishonored Abilities --



local ABILITY_NONE = 0

-- Corvo

local ABILITY_BLINK = 1

local ABILITY_DARKVISION = 2 -- shared

local ABILITY_BENDTIME = 3

local ABILITY_WINDBLAST = 4

local ABILITY_POSSESSION = 5

local ABILITY_SWARM = 6



-- Emily

local ABILITY_FARREACH = 7

local ABILITY_DOMINO = 8

local ABILITY_DOPPELGANGER = 9

local ABILITY_MESMERIZE = 10

local ABILITY_SHADOWWALK = 11



-- Network Message Types

local NWM_CAST 			= 1

local NWM_MESMER_SPAWN 	= 2

local NWM_DOMINO_LINK	= 3

local NWM_BENDTIME_EF	= 4

local NWM_BLINK_JUMP	= 5

local NWM_DARKVISION	= 6

local NWM_UPDHULL		= 7



-- Some globals

WDA_MESMER_DATA	= {}



if SERVER then

	util.AddNetworkString( "WDA_NWMessage" )

end



-- Server managed convars

local sv_wda_disable = CreateConVar( "sv_wda_disable", "0", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_prohibited = CreateConVar( "sv_wda_prohibited", "", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local sv_wda_blink_range = CreateConVar( "sv_wda_blink_range", "670", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_farreach_range = CreateConVar( "sv_wda_farreach_range", "670", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_mermerize_cast_range = CreateConVar( "sv_wda_mermerize_cast_range", "670", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_windblast_cast_range = CreateConVar( "sv_wda_windblast_cast_range", "140", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_doppelganger_cast_range = CreateConVar( "sv_wda_doppelganger_cast_range", "670", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_doppelganger_swap_range = CreateConVar( "sv_wda_doppelganger_swap_range", "1340", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_domino_cast_range = CreateConVar( "sv_wda_domino_cast_range", "1340", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_swarm_cast_range = CreateConVar( "sv_wda_swarm_cast_range", "1340", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_possession_cast_range = CreateConVar( "sv_wda_possession_cast_range", "1340", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_shadowwalk_vis_range = CreateConVar( "sv_wda_shadowwalk_vis_range", "220", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local sv_wda_shadowwalk_lifetime = CreateConVar( "sv_wda_shadowwalk_lifetime", "16", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_possession_lifetime = CreateConVar( "sv_wda_possession_lifetime", "16", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_swarm_lifetime = CreateConVar( "sv_wda_swarm_lifetime", "22", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_mermerize_lifetime = CreateConVar( "sv_wda_mermerize_lifetime", "22", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_doppelganger_lifetime = CreateConVar( "sv_wda_doppelganger_lifetime", "22", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local sv_wda_darkvision_duration = CreateConVar( "sv_wda_darkvision_duration", "1", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_bendtime_duration = CreateConVar( "sv_wda_bendtime_duration", "12", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

local sv_wda_domino_max_links = CreateConVar( "sv_wda_domino_max_links", "3", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local sv_wda_farreach_pullprops = CreateConVar( "sv_wda_farreach_pullprops", "1", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local sv_wda_ability_cooldown = CreateConVar( "sv_wda_ability_cooldown", "3.5", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local sv_wda_adminonly = CreateConVar( "sv_wda_adminonly", "0", { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )



local propNPCs = { 'npc_rollermine', 'npc_clawscanner', 'npc_manhack', 'npc_turret_floor' }



local function WDA_RestoreDefaults()

	RunConsoleCommand( "sv_wda_blink_range", "670" )

	RunConsoleCommand( "sv_wda_farreach_range", "670" )

	RunConsoleCommand( "sv_wda_mermerize_cast_range", "670" )

	RunConsoleCommand( "sv_wda_doppelganger_cast_range", "670" )

	RunConsoleCommand( "sv_wda_doppelganger_swap_range", "1340" )

	RunConsoleCommand( "sv_wda_domino_cast_range", "1340" )

	RunConsoleCommand( "sv_wda_swarm_cast_range", "1340" )

	RunConsoleCommand( "sv_wda_possession_cast_range", "1340" )

	

	RunConsoleCommand( "sv_wda_possession_lifetime", "16" )

	RunConsoleCommand( "sv_wda_swarm_lifetime", "22" )

	RunConsoleCommand( "sv_wda_mermerize_lifetime", "22" )

	RunConsoleCommand( "sv_wda_doppelganger_lifetime", "22" )

	

	RunConsoleCommand( "sv_wda_darkvision_duration", "1" )

	RunConsoleCommand( "sv_wda_bendtime_duration", "12" )

	RunConsoleCommand( "sv_wda_domino_max_links", "3" )

end

 

if SERVER then

	concommand.Add( "wda_restore_defaults", function( ply )

		if !ply:IsAdmin() then return end

		WDA_RestoreDefaults()

	end )

end



-- Shared functions and variables

local exclude_items = { 'item_healthcharger', 'item_suit', 'item_suitcharger' }

local include_items = { 'grenade_helicopter', 'qb_container', 'combine_mine', 'sent_ball', 'obj_vj_flareround' }

local doublem_items = { 'sent_ball', 'grenade_helicopter', 'item_healthvial', 'weapon_slam' }

local halfm_items = { 'qb_container', 'prop_physics' }

local possesion_excludes = { 'npc_combinegunship', 'npc_cscanner', 'npc_combine_camera', 'npc_turret_ceiling', 'npc_combinedropship', 

		'npc_helicopter', 'npc_manhack', 'npc_clawscanner', 'npc_rollermine', 'npc_turret_floor', 'npc_strider', 'npc_barnacle', 'npc_dog' }



local BendTime_InvalidClasses = {

	'func_',

	'env_',

	'info_',

	'light',

	'point_',

	'gmod_',

	'lua_',

	'path_',

	'prop_dynamic',

	'prop_static',

	'predicted_',

	'soundent',

	'player_manager',

	'physgun_beam',

	'network',

	'scene_manager',

	'shadow_',

	'beam',

	'spotlight_',

	'ai_hint',

	'sky_',

	'logic_',

	'water_lod_control',

	'key',

	'move',

	'phys_',

	'ambient_',

	'trigger_',

	'math_',

	'game_',

	'_firesmoke',

	'filter_',

	'hint',

	'bodyque',

	'spotlight_end',

	'class C_FogController',

	'class C_ShadowControl',

	'viewmodel',

	'class C_Sun',

	'class C_SpotlightEnd',

	'class C_PlayerResource',

	'class C_GMODGameRulesProxy',

	'class C_WaterLODControl',

	'class C_BaseEntity'

}



local function ValidateEntity( class )

	if class == 'func_rotating' then return true end

	if class == 'func_tracktrain' then return true end

		

	for i, v in pairs( BendTime_InvalidClasses ) do

		if string.find( class, v ) then

			return false

		end

	end

		

	return true

end



local function BLINK_FULLSIZEDTRACE( pos, normal, halfhull, filter )

	return util.QuickTrace( pos, normal * halfhull * 2, filter ).Hit

end



local function BLINK_PLACEMENT( pos, normal, filter )

	local hull = 16

	local hull_tall = 72

	local ang = normal:Angle()

	local center = pos + normal * hull

	

	local right = ang:Right()

	local up = ang:Up()

	local frw = ang:Forward()

	

	local ftr = util.QuickTrace( center, frw * hull, filter )



	local canblink = !ftr.Hit

	

	if !canblink then

		return center, false

	end

	

	local ltr = util.QuickTrace( center, -right * hull, filter )

	local rtr = util.QuickTrace( center, right * hull, filter )

	local btr = util.QuickTrace( center, -up * hull, filter )

	local ttr = util.QuickTrace( center, up * hull, filter )

	

	if ltr.HitSky || rtr.HitSky || btr.HitSky || ttr.HitSky then

		return center, false

	end

	

	if canblink && ltr.Hit then

		canblink = !BLINK_FULLSIZEDTRACE( ltr.HitPos, right, hull, filter )

	elseif canblink && rtr.Hit then

		canblink = !BLINK_FULLSIZEDTRACE( rtr.HitPos, -right, hull, filter )

	elseif canblink && btr.Hit then

		canblink = !BLINK_FULLSIZEDTRACE( btr.HitPos, up, hull, filter )

	elseif canblink && ttr.Hit then

		canblink = !BLINK_FULLSIZEDTRACE( ttr.HitPos, -up, hull, filter )

	end

	

	//debugoverlay.Line( ltr.HitPos, ltr.HitPos + right * hull * 2, 0.1, color_white )

	return center + ang:Right() * ( 1 - ltr.Fraction ) * hull

		- ang:Right() * ( 1 - rtr.Fraction ) * hull

		+ ang:Up() * ( 1 - btr.Fraction ) * hull

		- ang:Up() * ( 1 - ttr.Fraction ) * hull,

		canblink,

		normal.z > 0.5

end



-- | ABILITY DEFINITION | --

if SERVER then

	AddCSLuaFile()

	AddCSLuaFile( "autorun/client/wbs.lua" )



	--[

	--	CAST BLINK

	--]

	local function WDA_CAST_BLINK( ply )

		local length = sv_wda_blink_range:GetFloat()

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		local pos, canblink = BLINK_PLACEMENT( tr.HitPos, tr.HitNormal, ply )

		local _, hull = ply:GetHull()

		if ply:Crouching() then

			_, hull = ply:GetHullDuck()

		end

		local ttr = util.QuickTrace( pos - Vector( 0, 0, 16 ), Vector( 0, 0, hull.z ), ply )

		if ttr.Hit then

			ttr = util.QuickTrace( ttr.HitPos, Vector( 0, 0, -hull.z ), ply )

			if ttr.Hit then canblink = false end

			pos = ttr.HitPos

		end

		if !canblink then return end



		local ctr = util.TraceLine( { start = pos + Vector( 0, 0, 16 ), endpos = pos + Vector( 0, 0, 16 ) - tr.HitNormal * 18 } )

		local ctrd = util.QuickTrace( ctr.HitPos, Vector( 0, 0, -16 ) )

		local utr = util.QuickTrace( ctrd.HitPos, Vector( 0, 0, hull.z ) )

		

		if !ctr.Hit && !utr.Hit then

			pos = ctrd.HitPos

		else

			pos = pos - Vector( 0, 0, 16 )

		end



		net.Start( "WDA_NWMessage" )

			net.WriteInt( NWM_BLINK_JUMP, 5 )

			net.WriteVector( ply:GetPos() )

			net.WriteVector( pos )

			net.WriteFloat( ( ply:EyePos() - ply:GetPos() ).z )

		net.Send( ply )

		

		ply:SetPos( pos )

	end

	

	--[

	--	CAST FAR REACH

	--]

	local function WDA_CAST_FARREACH( ply )

		local dir = ply:EyeAngles():Forward()

		local length = sv_wda_farreach_range:GetFloat()

	

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		if !tr.Hit || tr.HitSky then

			tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length / 2 - Vector( 0, 0, length ), filter = ply } )

		end

		

		if !tr.Hit then return end

		

		local pos = tr.HitPos

		

		local _, hull = ply:GetHull()

		if ply:Crouching() then

			_, hull = ply:GetHullDuck()

		end

		

		local heightMul = 1

		if tr.HitNormal.z < 0 then

			pos.z = pos.z - hull.z * 0.5

			heightMul = 1

		end

		

		local ctr = util.TraceLine( { start = pos + Vector( 0, 0, 16 ), endpos = pos + Vector( 0, 0, 16 ) - tr.HitNormal * 18 } )

		local ctrd = util.QuickTrace( ctr.HitPos, Vector( 0, 0, -16 ) )

		local utr = util.QuickTrace( ctrd.HitPos, Vector( 0, 0, hull.z ) )

		

		if !ctr.Hit && !utr.Hit then

			pos.z = ctrd.HitPos.z + 20

				+ ( ( pos.z - ply:GetPos().z ) / ( length * 0.25 ) ) * 8

				+ 8 * ( ( pos - ply:GetPos() ):Length() / ( length * 0.5 ) )

				

			if pos.z > ply:GetPos().z then

				ply.WDA_InFRTravel = pos

			end

		end

			

		timer.Simple( 0.15, function()

			if !IsValid( ply ) then return end

			

			ply:ViewPunch( Angle( -2, 4, -2 ) )

			

			// pull props towards the player

			if IsValid( tr.Entity ) && 

				( ( string.find( tr.Entity:GetClass(), 'item_' ) || string.find( tr.Entity:GetClass(), 'weapon_' ) ) 

				&& !table.HasValue( exclude_items, tr.Entity:GetClass() ) )

				|| table.HasValue( include_items, tr.Entity:GetClass() )

				|| sv_wda_farreach_pullprops:GetBool() && tr.Entity:GetClass() == 'prop_physics'

				&& IsValid( tr.Entity:GetPhysicsObject() ) && tr.Entity:GetPhysicsObject():IsMotionEnabled() then

				

				local ent = tr.Entity

				local phy = ent:GetPhysicsObject()

				

				ent:SetPos( ent:GetPos() + Vector( 0, 0, 3 ) )

				if IsValid( phy ) then

					local massMul = phy:GetMass() * 0.35

					if table.HasValue( doublem_items, ent:GetClass() ) then

						massMul = 2

					elseif table.HasValue( halfm_items, ent:GetClass() ) then

						massMul = 1.5

					end

					

					local velocity = -phy:GetVelocity() + ( ply:GetPos() - ent:GetPos() ) * massMul

					velocity.z = velocity.z + 300 - tr.Fraction * 60

					phy:SetVelocity( velocity )

				end

			else

				ply:SetPos( ply:GetPos() + Vector( 0, 0, 1 ) )

				if ply:IsOnGround() then

					ply:SetVelocity( Vector( 0, 0, 100 ) )

				end

				

				//pos = pos + Vector( 0, 0, 30 )

				

				if pos.z < ply:GetPos().z - 230 then

					// push the player off the ledge first

					ply:SetVelocity( -ply:GetVelocity() + ply:EyeAngles():Forward() * 150 + Vector( 0, 0, 250 ) )

					timer.Simple( 0.1, function()

						ply:SetVelocity( -ply:GetVelocity() + ( pos - ply:GetPos() ) + Vector( 0, 0, 300 - ( ( tr.Fraction ) * 60 ) * heightMul ) )



						ply.WDA_IgnoreFallDamage = true

					end )

				else

					// throw player in the direction of our target

					ply:SetVelocity( -ply:GetVelocity() + ( pos - ply:GetPos() ) + Vector( 0, 0, 310 - ( ( tr.Fraction ) * 60 ) ) )

				end

				

				ply.WDA_FRTravelDst = ( pos - ply:GetPos() ):Length() / 15

				

				ply.WDA_IgnoreFallDamage = true

			end

			

			local rf = RecipientFilter()

			for i, v in pairs( player.GetAll() ) do

				if ply == v then continue end

				rf:AddPlayer( v )

			end

			

			local ed = EffectData()

			ed:SetStart( ply:GetShootPos() )

			ed:SetOrigin( pos )

			ed:SetEntity( ply )

			util.Effect( 'wda_farreach', ed, true, rf )

		end )

	end

	

	--[

	--	CAST MESMERIZE

	--]

	local function WDA_CAST_MESMERIZE( ply )

		local length = sv_wda_mermerize_cast_range:GetFloat()

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		local lifetime = sv_wda_mermerize_lifetime:GetFloat()

		

		if !tr.Hit || tr.HitSky then return end

		

		if IsValid( ply.wda_mesmer ) then

			ply.wda_mesmer:Remove()

		end

		

		local mesmer = ents.Create( 'wda_mesmer' )

		mesmer:SetPos( tr.HitPos )

		mesmer:SetOwner( ply )

		mesmer:SetLifeTime( CurTime() + lifetime )

		mesmer:Spawn()

		

		ply.wda_mesmer = mesmer

	end

	

	--[

	--	CAST DOPPELGANGER

	--]

	local function WDA_CAST_DOPPELGANGER( ply )

		local length = sv_wda_doppelganger_cast_range:GetFloat()

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		local lifetime = sv_wda_doppelganger_lifetime:GetFloat()

		

		if tr.HitSky then

			return

		end

		

		local pos, canplace = BLINK_PLACEMENT( tr.HitPos, tr.HitNormal, ply )

		

		tr = util.QuickTrace( tr.HitPos, Vector( 0, 0, -1000 ) )

		

		if tr.HitSky || !tr.Hit then

			return

		end

		

		pos.z = tr.HitPos.z

		

		if !canplace then

			return

		end

		

		if IsValid( ply.wda_replica ) then

			ply.wda_replica:Remove()

		end

		

		local a = ( ply:GetPos() - tr.HitPos ):Angle()

		a.p = 0

		a.r = 0

		

		local ed = EffectData()

		ed:SetOrigin( pos )

		ed:SetStart( ply:GetHull() )

		util.Effect( 'wda_doppelganger_puff', ed )

		

		local replica = ents.Create( 'wda_doppelganger' )

		replica:SetPos( pos )

		replica:SetAngles( a )

		replica:SetOwner( ply )

		replica:SetLifeTime( CurTime() + lifetime )

		replica:Spawn()

		replica:Activate()

		ply.wda_replica = replica

	end

	

	--[

	--	CAST WINDBLAST

	--]

	local function WDA_CAST_WINDBLAST( ply )

		local p, a = ply:EyePos(), ply:EyeAngles()

		

		local ed = EffectData()

		ed:SetEntity( ply )

		ed:SetOrigin( p + a:Forward() * 25 )

		ed:SetAngles( a )

		util.Effect( 'wda_windblast', ed, true, true )

		

		ply:EmitSound( 'dishonored/windblast_cast.wav' )

		

		local ta = a + Angle( 0, 0, 0 )

		ta.p = 0

		local dir = ta:Forward()

		local length = sv_wda_windblast_cast_range:GetFloat()

		for i, v in pairs( ents.FindInSphere( p + a:Forward() * ( length / 2 ), length ) ) do

			if !IsValid( v ) then continue end

			if v:IsPlayer() && v != ply || v:IsNPC() && !table.HasValue( propNPCs, v:GetClass() ) then

				if v:IsNPC() then

					v:SetVelocity( ( dir + Vector( 0, 0, 0.02 ) ) * 7000 )

					continue

				end

				

				if v:IsOnGround() then

					v:SetPos( v:GetPos() + Vector( 0, 0, 2 ) )

					v:SetVelocity( dir * 2200 )

				else

					v:SetVelocity( dir * 900 )

				end

			else

				if v:GetClass() == 'prop_combine_ball' then

					v:SetOwner( ply )

				end

				

				if v:GetClass() == 'grenade_ar2' || v:GetClass() == 'crossbow_bolt' then

					v:SetVelocity( a:Forward() * 1800 )

				end

				

				local phy = v:GetPhysicsObject()

				if IsValid( phy ) then

					a.p = math.min( 0, a.p )

					phy:SetVelocity( a:Forward() * 1800 )

				end

			end

		end

	end

	

	--[

	--	CAST DOMINO

	--]

	local function WDA_CAST_DOMINO( ply )

		ply.WDA_DOMINO = ply.WDA_DOMINO or {}

		

		local tr = util.TraceLine( { 

			start = ply:EyePos(), 

			endpos = ply:EyePos() + ply:EyeAngles():Forward() * sv_wda_domino_cast_range:GetFloat(),

			filter = ply } )

	

		local ent = tr.Entity

		if !IsValid( ent ) then return end

		if ent:IsNPC() || ( ent.BaseClass and ent.BaseClass.Type == 'nextbot' ) || ent:GetClass() == 'wda_doppelganger' then

			if ent:GetClass() == 'npc_bullseye' and IsValid( ent.Doppelganger ) then

				ent = ent.Doppelganger

			end

			

			if !table.HasValue( ply.WDA_DOMINO, ent ) then

				table.insert( ply.WDA_DOMINO, ent )

				ply:EmitSound( 'dishonored/domino_begin.wav' )

				if sv_wda_domino_max_links:GetInt() < table.Count( ply.WDA_DOMINO ) then

					for i, v in pairs( ply.WDA_DOMINO ) do

						table.remove( ply.WDA_DOMINO, i )

						break

					end

				end

				

				for i, v in pairs( ply.WDA_DOMINO ) do

					if !IsValid( v ) then

						table.remove( ply.WDA_DOMINO, i )

					end

				end



				net.Start( "WDA_NWMessage" )

					net.WriteInt( NWM_DOMINO_LINK, 5 )

					net.WriteTable( ply.WDA_DOMINO )

				net.Send( ply )

				

				ent.WDA_DOMINO = ply.WDA_DOMINO

				ent.WDA_DOMINO_OWNER = ply

			else

				table.RemoveByValue( ply.WDA_DOMINO, ent )

				

				net.Start( "WDA_NWMessage" )

					net.WriteInt( NWM_DOMINO_LINK, 5 )

					net.WriteTable( ply.WDA_DOMINO )

				net.Send( ply )

			end

		end

	end

	

	--[

	--	CAST BEND TIME

	--]

	WDA_BENDTIME_DATA = {}

	local function WDA_END_BENDTIME( ply )

		SetGlobalBool( 'WDA_TIMEBEND', false )

		BroadcastLua( "WDA_TIMEBEND_END()" )

		ply.WDA_TIME_BENDED = false

		

		timer.Remove( 'wda_bendtime_normalize_time' )

		

		for entindex, data in pairs( WDA_BENDTIME_DATA ) do

			local type = data.type

			local ent = Entity( entindex )

			

			if !IsValid( ent ) then continue end

			

			if type == 2 then

				ent:NextThink( CurTime() )

				timer.Simple( FrameTime() * 2, function()

					if IsValid( ent ) then

						ent:SetMoveType( data.mv )

						ent:SetPos( data.pos )

						

						local phy = ent:GetPhysicsObject()

						if IsValid( phy ) then

							phy:EnableMotion( data.me )

							phy:SetVelocity( data.vel )

						end

					end

				end )

			elseif type == 1 then

				ent:SetMoveType( data.mv )

			elseif type == 0 then

				local phy = ent:GetPhysicsObject()

				ent:SetMoveType( data.mv )

				

				if IsValid( phy ) then

					phy:EnableMotion( data.me )

					phy:SetVelocity( data.vel )

					phy:AddAngleVelocity( data.avel )

				end

				

				if ent:GetClass() == 'prop_combine_ball' then

					timer.Create( 'wda_bendtime_remove_cball_' .. tostring( ent:EntIndex() ), 5, 1, function()

						if IsValid( ent ) then

							ent:Fire( 'Explode' )

						end

					end )

				end

				

				if ent:GetClass() == 'npc_grenade_frag' and ent.savedtime then

					ent:SetSaveValue( 'm_flNextBlipTime', ent.savedblip or 0 )

					ent:SetSaveValue( 'm_flDetonateTime', ent.savedtime )

					

					ent.savedtime = nil

					ent.savedblip = nil

				end

			elseif type == 3 then

				for i = 0, ent:GetPhysicsObjectCount() - 1 do

					local me, vel, avel = data.mes[ i ], data.vels[ i ], data.avels[ i ]

					if !me || !vel || !avel then continue end

					

					local phy = ent:GetPhysicsObjectNum( i )

					phy:EnableMotion( me )

					phy:SetVelocity( vel )

					phy:AddAngleVelocity( avel )

				end

			elseif type == 4 then

				ent:Fire( 'SetSpeed', '1', 0 )

			elseif type == 5 then

				ent:Fire( 'Resume' )

			elseif type == 6 then

				ent:SetMoveType( data.mv )

				ent:SetVelocity( data.vel )

			end

		end

	end

	

	local function WDA_BENDTIME_FREEZE_OBJECT( ent, length )

		if !IsValid( ent ) then return end

		if !ValidateEntity( ent:GetClass() ) then return end

		if ent:IsPlayer() then return end

		if !length || length == 0 then

			length = 21600

		end

		

		if ent:IsNPC() then

			ent:NextThink( CurTime() + length )

			local mv = ent:GetMoveType()

			local me = nil

			local pos = ent:GetPos()

			local vel = ent:GetVelocity()

					

			ent:SetMoveType( MOVETYPE_NONE )

			local phy = ent:GetPhysicsObject()

			if IsValid( phy ) then

				vel = phy:GetVelocity()

				me = phy:IsMotionEnabled()

				phy:EnableMotion( false )

			end

					

			WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 2, mv = mv, pos = pos, vel = vel, me = me }

		else

			if ent:GetClass() == 'func_rotating' then

				WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 4 }

				ent:Fire( 'SetSpeed', '0', 0 )

			elseif ent:GetClass() == 'func_tracktrain' then

				WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 5 }

				ent:Fire( 'Stop' )

			elseif ent:GetClass() == 'crossbow_bolt' then

				local vel = ent:GetVelocity()

				local mv = ent:GetMoveType()

				ent:SetMoveType( MOVETYPE_NONE )

				WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 6, mv = mv, vel = vel }

			elseif ent:GetPhysicsObjectCount() > 1 then

				local mes, vels, avels = {}, {}, {}

				for i = 0, ent:GetPhysicsObjectCount() - 1 do

					local phy = ent:GetPhysicsObjectNum( i )

					mes[ i ] = phy:IsMotionEnabled()

					vels[ i ] = phy:GetVelocity()

					avels[ i ] = phy:GetAngleVelocity()

							

					phy:EnableMotion( false )

				end

				WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 3, mes = mes, vels = vels, avels = avels }

			elseif ent:GetPhysicsObjectCount() == 1 || ent:IsWeapon() && ent:GetOwner() == NULL then

				local phy = ent:GetPhysicsObject()

				local mv = ent:GetMoveType()

				ent:SetMoveType( MOVETYPE_NONE )

	

				if IsValid( phy ) then

					local me = phy:IsMotionEnabled()

					local vel = phy:GetVelocity()

					local avel = phy:GetAngleVelocity()



					phy:EnableMotion( false )



					WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 0, mv = mv, me = me, vel = vel, avel = avel }

				end

						

				if ent:GetClass() == 'prop_combine_ball' then

					timer.Remove( 'wda_bendtime_remove_cball_' .. tostring( ent:EntIndex() ) )

				end

						

				if ent:GetClass() == 'npc_grenade_frag' then

					ent.savedtime = ent:GetSaveTable().m_flDetonateTime

					ent.savedblip = ent:GetSaveTable().m_flNextBlipTime

					ent:SetSaveValue( 'm_flDetonateTime', 999 )

					ent:SetSaveValue( 'm_flNextBlipTime', 999 )

				end

			else

				local mv = ent:GetMoveType()

				ent:SetMoveType( MOVETYPE_NONE )

						

				WDA_BENDTIME_DATA[ ent:EntIndex() ] = { type = 1, mv = mv }

			end

		end

	end

	

	local function WDA_CAST_BENDTIME( ply )

		if !game.SinglePlayer() then return end

		ply.WDA_TIME_BENDED = ply.WDA_TIME_BENDED or false

		ply.WDA_TIME_BENDED = !ply.WDA_TIME_BENDED

		

		if ply.WDA_TIME_BENDED then

			if GetGlobalBool( 'WDA_TIMEBEND' ) then

				return

			end

			

			local rf = RecipientFilter()

			rf:AddPlayer( ply )

			

			local ed = EffectData()

			ed:SetOrigin( ply:EyePos() )

			util.Effect( "wda_bendtime", ed, true, rf )

			

			SetGlobalBool( 'WDA_TIMEBEND', true )

			

			local length = sv_wda_bendtime_duration:GetFloat()

			

			for i, ent in pairs( ents.GetAll() ) do

				WDA_BENDTIME_FREEZE_OBJECT( ent, length )

			end



			if length != 0 then

				timer.Create( 'wda_bendtime_normalize_time', length, 1, function()

					WDA_END_BENDTIME( ply )

				end )

			end

			

			BroadcastLua( "WDA_TIMEBEND_START()" )

		else

			WDA_END_BENDTIME( ply )

		end

		

		net.Start( "WDA_NWMessage" )

			net.WriteInt( NWM_BENDTIME_EF, 5 )

			net.WriteBit( ply.WDA_TIME_BENDED )

		net.Broadcast()

	end

	

	--[

	--	CAST DARK VISION

	--]

	local function WDA_CAST_DARKVISION( ply )

		net.Start( "WDA_NWMessage" )

			net.WriteInt( NWM_DARKVISION, 5 )

			net.WriteFloat( sv_wda_darkvision_duration:GetFloat() )

		net.Send( ply )

	end

	

	-- [

	--	CAST SHADOW WALK

	-- ]

	function WDA_END_SHADOWWALK( ply )

		timer.Remove( 'wda_end_shadow_walk_' .. tostring( ply:EntIndex() ) )

		

		ply:SetNWBool( "WDA_InShadowWalk", false )

		

		ply:SetNoTarget( false )

		ply:SetModelScale( 1, 0.35 )

		ply:SetWalkSpeed( ply.OldMoveSpeed or 200 )

		ply:SetRunSpeed( ply.OldRunSpeed or 400 )

		ply:SetJumpPower( ply.OldJumpPower or 300 )

		ply:AllowFlashlight( ply.OldAllowFlashlight )

		ply:DrawShadow( true )

		ply:StripWeapon( 'weapon_dishonored_shadowwalk' )

		ply:EmitSound( 'dishonored/shadowwalk_end.wav' )

		if IsValid( ply.WDA_LastUsedWeapon ) then

			ply:SelectWeapon( ply.WDA_LastUsedWeapon:GetClass() )

		end

			

		if ply.WDA_OldHullSize then

			ply:SetHull( unpack( ply.WDA_OldHullSize ) )

			ply:SetHullDuck( unpack( ply.WDA_OldHullSizeD ) )

			

			net.Start( 'WDA_NWMessage' )

				net.WriteInt( NWM_UPDHULL, 5 )

				net.WriteVector( ply.WDA_OldHullSize[1] )

				net.WriteVector( ply.WDA_OldHullSize[2] )

				net.WriteVector( ply.WDA_OldHullSizeD[1] )

				net.WriteVector( ply.WDA_OldHullSizeD[2] )

			net.Send( ply )

		end

		

		local heighttest = util.QuickTrace( ply:GetPos(), Vector( 0, 0, ply.WDA_OldHullSize[2].z - 6 ), ply )

		if heighttest.Hit && !heighttest.Entity:IsNPC() && !heighttest.Entity:IsPlayer() then

			ply:Kill()

		end

		

		ply.OldMoveSpeed = nil

		ply.OldRunSpeed = nil

		ply.OldJumpPower = nil

		ply.WDA_LastUsedWeapon = nil

		ply.WDA_OldHullSize = nil

		ply.WDA_OldHullSizeD = nil

	end

	

	local function WDA_CAST_SHADOWWALK( ply )

		ply:SetNWBool( "WDA_InShadowWalk", !ply:GetNWBool( "WDA_InShadowWalk" ) )

		

		if ply:GetNWBool( "WDA_InShadowWalk" ) then

			ply.WDA_LastUsedWeapon = ply:GetActiveWeapon()

			local wep = nil

			if ply:HasWeapon( 'weapon_dishonored_shadowwalk' ) then

				wep = ply:GetWeapon( 'weapon_dishonored_shadowwalk' )

			else

				ply:SetSuppressPickupNotices( true )

				wep = ply:Give( 'weapon_dishonored_shadowwalk' )

				ply:SetSuppressPickupNotices( false )

			end

			

			if IsValid( wep ) then

				ply:SetActiveWeapon( wep )

				wep:Deploy()

			end

			

			local dur = sv_wda_shadowwalk_lifetime:GetFloat()

			if dur != 0 then

				timer.Create( 'wda_end_shadow_walk_' .. tostring( ply:EntIndex() ), dur, 1, function()

					if IsValid( ply ) then

						WDA_END_SHADOWWALK( ply )

					end

				end )

			end

			

			ply:EmitSound( 'dishonored/shadowwalk_begin.wav' )

			ply:SetNoTarget( true )

		else

			WDA_END_SHADOWWALK( ply )

		end

	end

	

	-- [

	--	CAST DEVOURING SWARM

	-- ]

	local function WDA_CAST_SWARM( ply )

		local length = sv_wda_swarm_cast_range:GetFloat()

		local tr = util.QuickTrace( ply:EyePos(), ply:EyeAngles():Forward() * length, ply )

		

		if !tr.Hit || tr.HitSky then

			return

		end

		

		local pos = tr.HitPos + tr.HitNormal * 8

		

		tr = util.QuickTrace( pos, Vector( 0, 0, -32000 ), ply )



		pos = tr.HitPos + tr.HitNormal * 8

		

		local ed = EffectData()

		ed:SetOrigin( pos )

		ed:SetFlags( 0 )

		util.Effect( 'wda_swarm_spawn', ed )

		

		if istable( ply.WDA_SWARM ) then

			for i, v in pairs( ply.WDA_SWARM ) do

				if IsValid( v ) then

					v:Remove()

				end

			end

			

			ply.WDA_SWARM = nil

		end

		

		ply.WDA_SWARM = {}

		

		for i = 0, 15 do

			local crab = ents.Create( 'npc_headcrab_fast' )

			crab:SetPos( pos )

			crab:Spawn()

			crab:SetModelScale( 0.5 )

			crab:AddEntityRelationship( ply, D_LI, 999 )

			crab.SummonedFromVoid = true

			crab:SetVelocity( VectorRand() * 100 )

			crab:SetCustomCollisionCheck( true )

			crab:SetOwner( ply )

			

			crab:AddRelationship( 'npc_stalker D_HT 999' )

			crab:AddRelationship( 'npc_zombie D_HT 999' )

			crab:AddRelationship( 'npc_zombie_torso D_HT 999' )

			crab:AddRelationship( 'npc_zombine D_HT 999' )

			crab:AddRelationship( 'npc_poisonzombie D_HT 999' )

			crab:AddRelationship( 'npc_fastzombie D_HT 999' )



			local ed = EffectData()

			ed:SetEntity( crab )

			ed:SetFlags( 2 )

			util.Effect( 'wda_swarm_devour', ed )



			table.insert( ply.WDA_SWARM, crab )

		end



		local duration = sv_wda_swarm_lifetime:GetFloat()

		timer.Create( 'wda_remove_swarm_' .. tostring( ply:EntIndex() ), duration, 1, function()

			if IsValid( ply ) then

				if istable( ply.WDA_SWARM ) then

					for i, v in pairs( ply.WDA_SWARM ) do

						if IsValid( v ) then

							local ed = EffectData()

							ed:SetOrigin( v:GetPos() )

							util.Effect( 'wda_swarm_death', ed )

			

							v:Remove()

						end

					end

					

					ply.WDA_SWARM = nil

				end

			end

		end )

	end

	

	-- [

	--	CAST POSSESSION | EXIT POSSESSION

	-- ]

	local crabmodels = {

		"models/headcrabclassic.mdl",

		"models/headcrab.mdl",

		"models/headcrabblack.mdl"

	}

	local function AttachHeadcrab( ply, crabtype )

		crabtype = crabtype or 1

		

		local att = ply:GetAttachment( 1 )

		

		local crab = ents.Create( 'prop_dynamic' )

		crab:SetPos( att.Pos )

		crab:SetAngles( att.Ang )

		crab:SetModel( crabmodels[ crabtype ] )

		crab:SetParent( ply, 1 )

		crab:Spawn()

		

		if crabtype == 1 then

			local idle = crab:LookupSequence( 'headcrabbedpost' )

			crab:SetPlaybackRate( 0 )

			crab:SetSequence( idle )

		end

		

		return crab

	end

	

	local function WDA_ExitPossession( ply, lethal, dmgtype, dmgforce, dmgattacker )

		local npc = nil

		if IsValid( ply ) then

			timer.Remove( 'wda_possessiontimer_' .. tostring( ply:EntIndex() ) )

			

			npc = ply.wda_p_npc

			ply:SetNWBool( 'WDA_Possessing', false )

			ply:SetNWBool( 'WDA_UseLegacyAnimations', false )

				

			ply:StripWeapons()

			

			ply:DrawViewModel( true, 0 )

			ply:DrawViewModel( true, 1 )



			if ply.wda_p_maxhealth == nil || ply.wda_p_maxhealth <= 0 then

				ply.wda_p_maxhealth = 100

			end

			

			if IsValid( ply.wda_p_crab ) then

				ply.wda_p_crab:Remove()

				ply.wda_p_crab = nil

			end

			

			for i, v in pairs( ply.wda_p_dispositions ) do

				local ent = Entity( i )

				if !IsValid( ent ) then continue end

				if ent.AddEntityRelationship == nil then return end

				ent:AddEntityRelationship( ply, v, 9999 )

			end

			

			if IsValid( ply.wda_p_npc ) then

				for i, v in pairs( ply.wda_p_npc_dispositions ) do

					local ent = Entity( i )

					if !IsValid( ent ) then continue end

					if ent.AddEntityRelationship == nil then return end

					ent:AddEntityRelationship( ply.wda_p_npc, v, 9999 )

				end

			end

			

			ply:SetMaxHealth( ply.wda_p_maxhealth )

			ply:SetHealth( ply.wda_p_health or 100 )

			ply:SetArmor( ply.wda_p_armor or 0 )

			

			ply:SetWalkSpeed( ply.wda_p_wspeed or 400 )

			ply:SetRunSpeed( ply.wda_p_rspeed or 600 )

			ply:SetJumpPower( ply.wda_p_jpwr or 200 )

			

			ply:SetHull( unpack( ply.wda_p_hull ) )

			ply:SetHullDuck( unpack( ply.wda_p_hulld ) )

			

			net.Start( 'WDA_NWMessage' )

				net.WriteInt( NWM_UPDHULL, 5 )

				net.WriteVector( ply.wda_p_hull[1] )

				net.WriteVector( ply.wda_p_hull[2] )

				net.WriteVector( ply.wda_p_hulld[1] )

				net.WriteVector( ply.wda_p_hulld[2] )

			net.Send( ply )

			

			ply:SetMoveType( ply.wda_p_mv or MOVETYPE_WALK )

			

			ply:SetModel( ply.wda_mdl )

			

			ply:SetModelScale( 1 )



			ply.wda_p_npc = nil

			

			ply.wda_p_maxhealth = nil

			ply.wda_p_health = nil

			ply.wda_p_armor = nil

			

			local heighttest = util.QuickTrace( ply:GetPos(), Vector( 0, 0, ply.wda_p_hull[2].z - 6 ), ply )



			ply.wda_p_wspeed = nil

			ply.wda_p_rspeed = nil

			ply.wda_p_jpwr = nil

			ply.wda_p_hull = nil

			ply.wda_p_hulld = nil

			

			ply.wda_p_dispositions = nil

			ply.wda_p_npc_dispositions = nil

			

			if heighttest.Hit && !heighttest.Entity:IsNPC() && !heighttest.Entity:IsPlayer() then

				if GetConVarNumber( 'developer' ) > 0 then

					print( "[WDA]: Possession Exit: 1014 : Trace hit entity : " .. tostring( heighttest.Entity ) )

				end

				

				ply:Kill()

			end

			

			if ply.wda_p_oldweapons then

				ply:SetSuppressPickupNotices( true )

				ply:SetShouldPlayPickupSound( false )

				

				for i, v in pairs( ply.wda_p_oldweapons ) do

					ply:Give( v )

				end

				

				if ply.wda_p_lwep then

					ply:SelectWeapon( ply.wda_p_lwep )

					ply.wda_p_lwep = nil

				end

				

				ply.wda_p_oldweapons = nil

				ply:SetSuppressPickupNotices( false )

				ply:SetShouldPlayPickupSound( true )

			end



			if ply.wda_p_repammo then

				ply:SetAmmo( ply.wda_p_repammo[2], ply.wda_p_repammo[1] )

				ply.wda_p_repammo = nil

			end

			

			local fov = ply:GetFOV()

			ply:SetFOV( 150, 0 )

			ply:SetFOV( fov, 0.25 )

			

			ply:ScreenFade( SCREENFADE.IN, Color( 255, 255, 255, 255 ), 0.25, 0 )

			

			if ply.WDA_DOMINO then

				net.Start( "WDA_NWMessage" )

					net.WriteInt( NWM_DOMINO_LINK, 5 )

					net.WriteTable( ply.WDA_DOMINO )

				net.Send( ply )

			end

			

			ply:SendLua( "WDA_EndPossessionEffects()" )

		end

		

		if IsValid( npc ) then

			if IsValid( npc.wda_p_wep ) then

				npc.wda_p_wep:SetNoDraw( false )

			end

			npc.wda_p_possesser = nil

			npc.wda_p_wep = nil

			npc:SetNoDraw( false )

			npc:NextThink( CurTime() + 0.25 )

			npc:SetSolid( npc.wda_p_solid )

			if IsValid( ply ) then

				local hullSize = { ply:GetHull() }



				local tr = util.TraceHull( {

					start = ply:GetPos(),

					endpos = ply:GetPos() - ply:GetAngles():Forward() * 20,

					filter = ply,

					mins = hullSize[1],

					maxs = hullSize[2],

					mask = MASK_SOLID

				} )

				ply:SetPos( tr.HitPos )

				npc:SetPos( tr.HitPos + ply:GetAngles():Forward() * 42 )

				npc:SetAngles( ply:GetAngles() )

				if npc.DesiredYaw then

					npc.DesiredYaw = ply:GetAngles().y

				end

			end

			

			if lethal then

				npc.WDA_RecursionSave = true

				local dmg = DamageInfo()

				dmg:SetDamage( npc:Health() * 2 )

				dmg:SetAttacker( dmgattacker )

				dmg:SetDamageType( dmgtype )

				dmg:SetDamageForce( dmgforce )

				npc:TakeDamageInfo( dmg )

			end

		end

	end

	

	local function SetHullBoth( ply, mins, maxs )

		ply:SetHull( mins, maxs )

		ply:SetHullDuck( mins, maxs )

		

		net.Start( 'WDA_NWMessage' )

			net.WriteInt( NWM_UPDHULL, 5 )

			net.WriteVector( mins )

			net.WriteVector( maxs )

			net.WriteVector( mins )

			net.WriteVector( maxs )

		net.Send( ply )

	end

	

	local function WDA_CAST_POSSESSION( ply )

		if ply:GetNWBool( 'WDA_Possessing' ) then

			timer.Remove( 'wda_possessiontimer_' .. tostring( ply:EntIndex() ) )

			WDA_ExitPossession( ply )

			return

		end

		

		local length = sv_wda_possession_cast_range:GetFloat()

		local tr = util.QuickTrace( ply:EyePos(), ply:EyeAngles():Forward() * length, ply )

		

		if !tr.Hit || tr.HitSky || !IsValid( tr.Entity ) || !tr.Entity:IsNPC() then

			return

		end

		

		local npc = tr.Entity

		

		if npc.Doppelganger then

			npc = npc.Doppelganger

		end

		

		if table.HasValue( possesion_excludes, npc:GetClass() ) then

			return

		end



		ply.wda_p_wspeed = ply:GetWalkSpeed()

		ply.wda_p_rspeed = ply:GetRunSpeed()

		ply.wda_p_jpwr = ply:GetJumpPower()

		ply.wda_p_hull = { ply:GetHull() }

		ply.wda_p_hulld = { ply:GetHullDuck() }

		ply.wda_p_mv = ply:GetMoveType()

		ply.wda_mdl = ply:GetModel()

		

		local npcmdl = npc:GetModel()

		if !npcmdl then

			npcmdl = ply:GetModel()

		end

		

 		local pm = 'models/player/' .. string.lower( string.GetFileFromFilename( npcmdl ) )

		if util.IsValidModel( pm ) then

			ply:SetModel( pm )

		else

			// there is no valid player model

			// let's assign this NPC's model

			// (ignoring missing animations)

			ply:SetModel( npc:GetModel() )

			ply:SetNWBool( 'WDA_UseLegacyAnimations', true )

		end

		

		local dispositions = {}

		local npc_dispositions = {}

		for i, inpc in pairs( ents.FindByClass( 'npc_*' ) ) do

			if inpc.Disposition == nil then continue end

			if inpc == npc then continue end

			

			-- save disposition of this npc towards player

			dispositions[ inpc:EntIndex() ] = inpc:Disposition( ply )

			-- trasfer disposition towards possessed NPC to player

			inpc:AddEntityRelationship( ply, inpc:Disposition( npc ), 9999 )

			

			-- store disposition towards possessed NPC and make

			-- everyone ignore it

			npc_dispositions[ inpc:EntIndex() ] = inpc:Disposition( npc )

			inpc:AddEntityRelationship( npc, D_LI, 9999 )

		end

		

		ply.wda_p_dispositions = dispositions

		ply.wda_p_npc_dispositions = npc_dispositions

		

		ply:SetNWFloat( 'WDA_Possession_EyeHeight', 1 )

		if npc:GetClass() == 'npc_headcrab' || npc:GetClass() == 'npc_headcrab_black' then

			ply:SetNWFloat( 'WDA_Possession_EyeHeight', 0.25 )

			ply:SetModelScale( 0.25 )

			ply:SetWalkSpeed( 100 )

			ply:SetRunSpeed( 150 )

			ply:SetJumpPower( 400 )

			SetHullBoth( ply, Vector( -16, -16, 0 ), Vector( 16, 16, 12 ) )

		elseif npc:GetClass() == 'npc_headcrab_fast' then

			ply:SetNWFloat( 'WDA_Possession_EyeHeight', 0.25 )

			ply:SetModelScale( 0.25 )

			ply:SetWalkSpeed( 200 )

			ply:SetRunSpeed( 450 )

			ply:SetJumpPower( 400 )

			SetHullBoth( ply, Vector( -16, -16, 0 ), Vector( 16, 16, 12 ) )

		elseif npc:GetClass() == 'npc_zombie_torso' then

			ply:SetNWFloat( 'WDA_Possession_EyeHeight', 0.25 )

			ply:SetWalkSpeed( 40 )

			ply:SetRunSpeed( 40 )

			ply:SetJumpPower( 0 )

			SetHullBoth( ply, Vector( -16, -16, 0 ), Vector( 16, 16, 16 ) )

			//ply.wda_p_crab = AttachHeadcrab( ply, 1 )

		elseif npc:GetClass() == 'npc_fastzombie_torso' then

			ply:SetNWFloat( 'WDA_Possession_EyeHeight', 0.25 )

			ply:SetWalkSpeed( 130 )

			ply:SetRunSpeed( 130 )

			ply:SetJumpPower( 0 )

			SetHullBoth( ply, Vector( -16, -16, 0 ), Vector( 16, 16, 16 ) )

			//ply.wda_p_crab = AttachHeadcrab( ply, 2 )

		elseif npc:GetClass() == 'npc_fastzombie' then

			ply:SetNWFloat( 'WDA_Possession_EyeHeight', 0.85 )

			ply:SetWalkSpeed( 200 )

			ply:SetRunSpeed( 300 )

			ply:SetJumpPower( 500 )

			//ply.wda_p_crab = AttachHeadcrab( ply, 2 )

		elseif npc:GetClass() == 'npc_crow' || npc:GetClass() == 'npc_pigeon' || npc:GetClass() == 'npc_seagull' then

			ply:SetMoveType( MOVETYPE_FLY )

			ply:SetNWFloat( 'WDA_Possession_EyeHeight', 0.1 )

			SetHullBoth( ply, Vector( -8, -8, 0 ), Vector( 8, 8, 8 ) )

		else

			ply:SetWalkSpeed( 200 )

			ply:SetRunSpeed( 200 )

		end



		if ply.WDA_DOMINO && table.Count( ply.WDA_DOMINO ) > 0 then

			local tempdominolink = {}

			for i, v in pairs( ply.WDA_DOMINO ) do

				if v != npc then

					table.insert( tempdominolink, v )

				else

					table.insert( tempdominolink, ply )

				end

			end

			

			net.Start( "WDA_NWMessage" )

				net.WriteInt( NWM_DOMINO_LINK, 5 )

				net.WriteTable( tempdominolink )

			net.Send( ply )

		end

		

		npc.wda_p_possesser = ply

		npc:NextThink( CurTime() + 16.25 )

		npc:SetNoDraw( true )

		npc.wda_p_solid = npc:GetSolid()

		npc:SetSolid( SOLID_NONE )

		

		local oldpm = ply:GetModel()

		local oldbg = ply:GetBodyGroups()

		local oldsk = ply:GetSkin()

		ply.wda_p_oldweapons = {}

		

		for i, v in pairs( ply:GetWeapons() ) do

			table.insert( ply.wda_p_oldweapons, v:GetClass() )

		end

		

		ply.wda_p_maxhealth = ply:GetMaxHealth()

		ply.wda_p_health = ply:Health()

		ply.wda_p_armor = ply:Armor()

		

		if npc.GetMaxHealth then

			if npc:GetClass() == 'wda_doppelganger' then

				if IsValid( npc.Bullseye ) then

					ply:SetMaxHealth( npc.Bullseye:GetMaxHealth() )

				end

			else

				ply:SetMaxHealth( npc:GetMaxHealth() )

			end

		end

		

		if npc.Health then

			if npc:GetClass() == 'wda_doppelganger' then

				if IsValid( npc.Bullseye ) then

					ply:SetHealth( npc.Bullseye:Health() )

				end

			else

				ply:SetHealth( npc:Health() )

			end

		end

		

		ply:SetArmor( 0 )



		if ply:GetActiveWeapon() then

			ply.wda_p_lwep = ply:GetActiveWeapon():GetClass()

		end

		

		ply:StripWeapons()

		

		ply.wda_p_npc = npc

		

		if npc.GetActiveWeapon then

			npc.wda_p_wep = npc:GetActiveWeapon()

		end



		if IsValid( npc.wda_p_wep ) then

			npc.wda_p_wep:SetNoDraw( true )

			// there was no such behavior in dishonored but I'll

			// leave it here if someone needs it for some reason



			/*ply:SetSuppressPickupNotices( true )

			ply.wda_p_repammo = { npc.wda_p_wep:GetPrimaryAmmoType(), ply:GetAmmoCount( npc.wda_p_wep:GetPrimaryAmmoType() ) }

			ply:SetShouldPlayPickupSound( false )

			local wep = ply:Give( npc.wda_p_wep:GetClass() )

			ply:SetAmmo( 999, npc.wda_p_wep:GetPrimaryAmmoType() )

			ply:SelectWeapon( npc.wda_p_wep:GetClass() )

			ply:SetSuppressPickupNotices( false )

			ply:SetShouldPlayPickupSound( true )*/

		end

		

		ply:SetPos( npc:GetPos() )

		local ang = npc:GetAngles()

		ang.p = math.Clamp( ang.p, -89, 89 )

		ang.r = 0

		ply:SetEyeAngles( ang )

		

		local fov = ply:GetFOV()

		ply:SetFOV( 1, 0 )

		ply:SetFOV( fov, 0.25 )

		

		ply:ScreenFade( SCREENFADE.IN, Color( 255, 255, 255, 255 ), 0.25, 0 )

		

		ply:SetNWBool( 'WDA_Possessing', true )

		ply:SendLua( 'WDA_StartPossessionEffects()' )



		timer.Create( 'wda_possessiontimer_' .. tostring( ply:EntIndex() ), sv_wda_possession_lifetime:GetFloat(), 1, function()

			WDA_ExitPossession( ply )

		end )

	end

	

	net.Receive( "WDA_NWMessage", function( buff, ply )

		local _type = net.ReadInt( 5 )
		if ply.buyulendi then ply:ChatPrint("Şu anda kullanamazsın.") return end



		ply.WDA_Cooldown = ply.WDA_Cooldown or 0

		

		if ply:GetNWFloat( "WDA_Cooldown" ) >= CurTime() then return end

		if !ply:Alive() then return end

		if ply:Team() == TEAM_SPECTATOR then return end

		

		if _type == NWM_CAST then

			local ability = net.ReadInt( 8 )

			

			--if sv_wda_disable:GetBool() then return end

			--if sv_wda_adminonly:GetBool() && !ply:IsAdmin() then return end

			if ply:InVehicle() then return end

			//if string.find( sv_wda_prohibited:GetString(), tostring( ability ) ) then return end -- broken

			for i, v in pairs( string.Explode( '/', sv_wda_prohibited:GetString() ) ) do

				local num = tonumber( v )

				if num == nil then continue end

				if num == ability then

					return

				end

			end

			if string.find(ply:GetNWString("yetenekler","") , "|"..tostring(ability).."|") == nil then return end

			ply:LagCompensation( true )

			if ability == ABILITY_BLINK then

				WDA_CAST_BLINK( ply )

			elseif ability == ABILITY_FARREACH then

				WDA_CAST_FARREACH( ply )

			elseif ability == ABILITY_MESMERIZE then

				WDA_CAST_MESMERIZE( ply )

			elseif ability == ABILITY_DOPPELGANGER then

				WDA_CAST_DOPPELGANGER( ply )

			elseif ability == ABILITY_WINDBLAST then

				WDA_CAST_WINDBLAST( ply )

			elseif ability == ABILITY_DOMINO then

				WDA_CAST_DOMINO( ply )

			elseif ability == ABILITY_BENDTIME then

				WDA_CAST_BENDTIME( ply )

			elseif ability == ABILITY_DARKVISION then

				WDA_CAST_DARKVISION( ply )

			elseif ability == ABILITY_SHADOWWALK then

				WDA_CAST_SHADOWWALK( ply )

			elseif ability == ABILITY_SWARM then

				WDA_CAST_SWARM( ply )

			elseif ability == ABILITY_POSSESSION then

				WDA_CAST_POSSESSION( ply )

			end

			ply:LagCompensation( false )

			

			ply:SetNWFloat( "WDA_Cooldown", CurTime() + sv_wda_ability_cooldown:GetFloat() )

			

			ply:SendLua( "WDA_PlayCorrespondingCastSound( '" .. ability .. "' )" )

		end

	end )



	hook.Add( 'GetFallDamage', 'WDA_IGNOREFALLDAMAGE', function( ply, speed )

		if ply.WDA_IgnoreFallDamage then

			ply.WDA_IgnoreFallDamage = false

			return 0

		end

	end )

	

	hook.Add( 'EntityTakeDamage', 'WDA_DOMINO_DAMAGE', function( ent, dmg )

		if ent.WDA_RecursionSave then return end

		

		if ent:GetNWBool( 'WDA_Possessing' ) then

			if ent:Health() - dmg:GetDamage() <= 0 then

				timer.Remove( 'wda_possessiontimer_' .. tostring( ent:EntIndex() ) )

				WDA_ExitPossession( ent, true, dmg:GetDamageType(), dmg:GetDamageForce(), dmg:GetAttacker() )

				dmg:ScaleDamage( 0 )

			end

		end

		

		if ent:GetClass() == 'npc_bullseye' and IsValid( ent.Doppelganger ) then

			ent.Doppelganger:TakeDamageInfo( dmg )

			return true

		end

		

		if IsValid( ent ) && ent.WDA_DOMINO && !ent.WDA_DOMINO_DAMAGE then

			if !ent.WDA_DOMINO_OWNER then return end

			

			local perc = dmg:GetDamage() / ent:Health()

			

			for i, v in pairs( ent.WDA_DOMINO ) do

				if v == ent then continue end

				if !IsValid( v ) then

					ent.WDA_DOMINO[ i ] = nil

					if IsValid( ent.WDA_DOMINO_OWNER ) then

						ent.WDA_DOMINO_OWNER[ i ] = nil

					end

					continue

				end



				v.WDA_DOMINO_DAMAGE = true

				dmg:SetDamage( v:Health() * perc )

				v:TakeDamageInfo( dmg )

				v:SetNWFloat( 'WDA_HP_OVR', v:Health() )

				

				v.WDA_DOMINO_DAMAGE = false

			end

		end

	end )

	

	hook.Add( 'OnNPCKilled', 'WDA_REMOVE_SWARM_CRABS', function( npc, att )

		if GetGlobalBool( "WDA_TIMEBEND" ) then

			local wep = npc:GetActiveWeapon()

			if IsValid( wep ) then

				timer.Simple( 0, function()

					if IsValid( wep ) then

						WDA_BENDTIME_FREEZE_OBJECT( wep )

					end

				end )

			end

		end

		

		if npc.SummonedFromVoid then

			local ed = EffectData()

			ed:SetOrigin( npc:GetPos() )

			util.Effect( 'wda_swarm_death', ed )

			

			npc:Remove()

			return true

		elseif IsValid( att ) and att.SummonedFromVoid then

			npc:SetShouldServerRagdoll( true )

			npc.WDA_Devoured = true

			

			local owner = att:GetOwner()

			if IsValid( owner ) then

				net.Start( "PlayerKilledNPC" )

					net.WriteString( npc:GetClass() )

					net.WriteString( 'wda_swarm' )

					net.WriteEntity( owner )

				net.Broadcast()

			end

			

			return true

		end

	end )

	

	hook.Add( 'CreateEntityRagdoll', 'WDA_REMOVE_SWARM_CORPSES', function( ent, doll )

		if ent.WDA_Devoured then

			doll:DrawShadow( false )

			

			local ed = EffectData()

			ed:SetEntity( doll )

			ed:SetFlags( 0 )

			util.Effect( 'wda_swarm_devour', ed )

			

			timer.Simple( 1, function()

				if IsValid( doll ) then

					doll:Remove()

				end

			end )

		end

		

		if ent.WDA_ShadowWalkAnim == 1 then

			local leg = doll:GetPhysicsObjectNum( 12 )

			if IsValid( leg ) then

				leg:SetPos( leg:GetPos() + Vector( 0, 0, 36 ) )

				leg:EnableMotion( false )

				

				timer.Simple( 0.7, function()

					if IsValid( leg ) then

						leg:EnableMotion( true )

					end

				end )

			end

		end

	end )

	

	hook.Add( 'PlayerDeath', 'WDA_PLAYER_DEATH_ACTIONS', function( ply, infl, att )

		if ply.WDA_InShadowWalk then

			WDA_END_SHADOWWALK( ply )

		end

		

		if ply:GetNWBool( 'WDA_Possessing' ) then

			ply.wda_p_oldweapons = nil

			WDA_ExitPossession( ply )

		end

		

		if IsValid( att ) and att.SummonedFromVoid then

			local owner = att:GetOwner()

			if IsValid( owner ) then

				net.Start( "PlayerKilledByPlayer" )

					net.WriteEntity( ply )

					net.WriteString( 'wda_swarm' )

					net.WriteEntity( owner )

				net.Broadcast()

			end

			

			local doll = ply:GetRagdollEntity()

			if IsValid( doll ) then

				doll:DrawShadow( false )

			

				local ed = EffectData()

				ed:SetEntity( doll )

				ed:SetFlags( 0 )

				util.Effect( 'wda_swarm_devour', ed )

				

				timer.Simple( 1, function()

					if IsValid( doll ) then

						doll:Remove()

					end

				end )

			end

			

			return true

		end

	end )

	

	hook.Add( 'PlayerCanPickupWeapon', 'WDA_POSSESSION_RESTRICT_PICKUP', function( ply )

		if ply:GetNWBool( 'WDA_Possessing' ) then

			return false

		end

	end )

	

	hook.Add( 'PlayerCanPickupItem', 'WDA_POSSESSION_RESTRICT_PICKUP', function( ply )

		if ply:GetNWBool( 'WDA_Possessing' ) then

			return false

		end

	end )

	

	hook.Add( 'AllowPlayerPickup', 'WDA_POSSESSION_RESTRICT_PICKUP', function( ply )

		if ply:GetNWBool( 'WDA_Possessing' ) then

			return false

		end

	end )

	

	hook.Add( 'EntityRemoved', 'WDA_ENTITY_REMOVAL_ACTIONS', function( ent )

		if ent.wda_p_possesser then

			WDA_ExitPossession( ent.wda_p_possesser )

		end

	end )

	

	hook.Add( 'ShouldCollide', 'WDA_SWARM_NOCOLLIDE', function( ent1, ent2 )

		if ent1.SummonedFromVoid && ent2.SummonedFromVoid then

			return false

		end

		

		-- not returning anything

		-- let other implementations of this

		-- hook decide

	end )

	

	// we need to clear some data and remove

	// some entities if player leaves the server

	hook.Add( 'PlayerDisconnected', 'WDA_DISCONNECT_ACTIONS', function( ply )

		if istable( ply.WDA_SWARM ) then

			for i, v in pairs( ply.WDA_SWARM ) do

				if IsValid( v ) then

					local ed = EffectData()

					ed:SetOrigin( v:GetPos() )

					util.Effect( 'wda_swarm_death', ed )

			

					v:Remove()

				end

			end

		end

		

		if ply.wda_p_npc then

			WDA_ExitPossession( ply )

		end

	end )

	

	hook.Add( 'EntityEmitSound', 'WDA_BENDTIME_SOUNDWARP', function( snd )

		if string.find( snd.SoundName, 'dishonored' ) then return end

		

		if GetGlobalBool( 'WDA_TIMEBEND' ) then

			snd.Pitch = snd.Pitch * 0.5

			return true

		end

	end )

	

	hook.Add( "OnEntityCreated", "WDA_BENDTIME_FREEZEENTS", function( ent )

		if GetGlobalBool( "WDA_TIMEBEND" ) then

			timer.Simple( 0, function()

				WDA_BENDTIME_FREEZE_OBJECT( ent, sv_wda_bendtime_duration:GetFloat() )

			end )

		end

	end )

end



-- has to be shared because of the velocity adjustment

/*hook.Add( 'Tick', 'WDA_MANAGE_TICKS', function()

	for _, ply in pairs( player.GetAll() ) do

		if SERVER && ply.WDA_IgnoreFallDamage && 

			( ply:IsOnGround() || ply:GetMoveType() != MOVETYPE_WALK || ply:WaterLevel() > 0 ) then

			ply.WDA_IgnoreFallDamage = false

		end

			

		-- this preventing players from flying far far away

		-- when using far reach from large distance (>800)

		if ply.WDA_InFRTravel then

			local dist = ply:GetPos():Distance( ply.WDA_InFRTravel )

			if ply.WDA_FRTravelDst && dist < ply.WDA_FRTravelDst then

				local plyvel = ply:GetVelocity()

				ply:SetVelocity( -plyvel + ( ply.WDA_InFRTravel - ply:GetPos() ) * 3 )

				

				ply.WDA_FRTravelDst = nil

				ply.WDA_InFRTravel = nil

			end

		end

	end

		

	if SERVER then

		for i, v in pairs( ents.FindByClass( 'wda_*' ) ) do

			if isfunction( v.Tick ) then

				v:Tick()

			end

		end

	end

end )*/

/*

hook.Add( 'UpdateAnimation', 'WDA_LEGACY_ANIMATIONS', function( ply, vel, maxSpeed )

	if ply:GetNWBool( 'WDA_UseLegacyAnimations' ) then

		if ply:IsOnGround() then

			vel = vel:Length()

			if vel > 0 then

				local run = ply:LookupSequence( 'run' )

				local walk_all = ply:LookupSequence( 'walk_all' )

				local crawl = ply:LookupSequence( 'crawl' )

				local walk = ply:LookupSequence( 'walk' )

				

				if vel >= ply:GetRunSpeed() && run != -1 then

					ply:SetSequence( run )

				elseif walk_all != -1 then

					ply:SetSequence( walk_all )

				elseif crawl != -1 then

					ply:SetSequence( crawl )

				else

					ply:SetSequence( walk )

				end

			else

				local idle01 = ply:LookupSequence( 'idle01' )

				local idle = ply:LookupSequence( 'idle' )

				

				if idle01 != -1 then

					ply:SetSequence( idle01 )

				else

					ply:SetSequence( idle )

				end

			end

		else

			local leapstrike = ply:LookupSequence( 'leapstrike' ) -- fast zombie only

			if leapstrike != -1 then

				ply:SetSequence( leapstrike )

			end

		end		

	end

end )

*/

-- | CLIENT SIDE ABILITY DEFINITION | --

if CLIENT then

	local cl_wda_disable_dynamic_lights = CreateConVar( "cl_wda_disable_dynamic_lights", "0", { FCVAR_ARCHIVE } )

	include( "autorun/client/wbs.lua" )

	

	-- | DEFINE FONTS | --

	surface.CreateFont( "WDA_ABILITYNAME", {

		font = "OptimusPrincepsSemiBold",

		size = 36,

		weight = 1000,

		antialias = true,

		italic = false

	} )

	

	surface.CreateFont( "WDA_ABILITYDESCRIPTION", {

		font = "OptimusPrinceps",

		size = 16,

		weight = 500,

		antialias = true,

		italic = true

	} )

	

	-- | DEFINE CUSTOM KILLICONS | --

	killicon.Add( "wda_swarm", "hud/dishonored/killicon_swarm", Color( 255, 80, 0, 255 ) )

	killicon.Add( "weapon_dishonored_shadowwalk", "hud/dishonored/killicon_shadowwalk", Color( 255, 80, 0, 255 ) )

	

	-- | MENU VARIABLES | --

	

	local menu_visible 		= false

	local menu_percentage	= 0

	local menu_cursorpos	= Vector()

	local menu_selected		= ABILITY_BLINK

	local menu_selected_ph	= false

	local isCasting = false

	

	WDA_DOMINO_LINKS = WDA_DOMINO_LINKS or {}

	

	-- | NETWORK MESSAGES | --

	net.Receive( "WDA_NWMessage", function( buff, ply )

		local _type = net.ReadInt( 5 )



		if _type == NWM_DOMINO_LINK then

			WDA_DOMINO_LINKS = table.Reverse( net.ReadTable() )

		elseif _type == NWM_BLINK_JUMP then

			WDA_BLINK_TRAVELPERC = 0

			WDA_BLINK_TRAVELSTART = net.ReadVector()

			WDA_BLINK_TRAVELEND = net.ReadVector()

			WDA_BLINK_EYEHEIGHT = net.ReadFloat()

		elseif _type == NWM_DARKVISION then

			local dur = net.ReadFloat()

			if dur == 0 then

				dur = 21600

			end

			

			WDA_IN_DARKVISION = !WDA_IN_DARKVISION

			if WDA_IN_DARKVISION then

				WDA_DARKVISION_DURATION = CurTime() + dur

			end

		elseif _type == NWM_UPDHULL then

			local mins, maxs = net.ReadVector(), net.ReadVector()

			local minsd, maxsd = net.ReadVector(), net.ReadVector()

			

			LocalPlayer():SetHull( mins, maxs )

			LocalPlayer():SetHullDuck( minsd, maxsd )

		end

	end )

	

	-- | SOUNDS | --

	local castLoopSounds 		= {}

	local castLoopSound  		= nil

	local castLoopSoundDuration	= 0

	

	local function CreatePlayLoopSoundSlot( ability, sound )

		if !castLoopSounds[ ability ] then

			local length = SoundDuration( sound )

			castLoopSounds[ ability ] = { CreateSound( LocalPlayer(), sound ), length }

			castLoopSounds[ ability ][1]:Play()

			castLoopSounds[ ability ][1]:ChangeVolume( 0 )

			castLoopSounds[ ability ][1]:ChangeVolume( 1, 6 )

			castLoopSoundDuration = CurTime() + length

		elseif castLoopSound == nil then

			castLoopSounds[ ability ][1]:Play()

			castLoopSounds[ ability ][1]:ChangeVolume( 0 )

			castLoopSounds[ ability ][1]:ChangeVolume( 1, 6 )

			castLoopSoundDuration = CurTime() + castLoopSounds[ ability ][2]

		end

		

		castLoopSound = castLoopSounds[ ability ][1]

	end

	

	local function StartCastLoopSound()

		if menu_selected == ABILITY_BLINK then

			CreatePlayLoopSoundSlot( menu_selected, 'dishonored/blink_loop.wav' )

		elseif menu_selected == ABILITY_FARREACH then

			CreatePlayLoopSoundSlot( menu_selected, 'dishonored/blink_loop.wav' )

		end

	end

	

	local function StopCastLoopSound()

		if castLoopSound then

			castLoopSound:Stop()

			castLoopSound = nil

		end

	end

	

	local function PlayAbortSound()

		surface.PlaySound( "dishonored/abort" .. math.random( 1, 4 ) .. ".wav" )

	end

	

	-- | SPECIAL EVENTS | --

	local function WDA_CREATE_BLINK_POINTER()

		WDA_BLINK_POINTER = ClientsideModel( 'models/wheatleymodels/dishonored/blink_pointer.mdl', RENDERGROUP_TRANSLUCENT )

		WDA_BLINK_POINTER:SetNoDraw( true )



		local mat = Matrix()

		mat:SetScale( Vector( 0.55, 0.55, 0.55 ) )

		WDA_BLINK_POINTER:EnableMatrix( 'RenderMultiply', mat )

		

		WDA_BLINK_POINTER_BOT = ClientsideModel( 'models/wheatleymodels/dishonored/blink_pointer.mdl', RENDERGROUP_TRANSLUCENT )

		WDA_BLINK_POINTER_BOT:SetNoDraw( true )

			

		mat:Rotate( Angle( 0, 0, 180 ) )

		WDA_BLINK_POINTER_BOT:EnableMatrix( 'RenderMultiply', mat )

	end

	

	local function WDA_REMOVE_BLINK_POINTER()

		if WDA_BLINK_POINTER then

			WDA_BLINK_POINTER:Remove()

			WDA_BLINK_POINTER = nil

		end

		

		if WDA_BLINK_POINTER_BOT then

			WDA_BLINK_POINTER_BOT:Remove()

			WDA_BLINK_POINTER_BOT = nil

		end

	end

	

	local function WDA_PERFORM_CAST_BEGIN()

		if menu_selected == ABILITY_BLINK || menu_selected == ABILITY_FARREACH || menu_selected == ABILITY_DOPPELGANGER then

			WDA_CREATE_BLINK_POINTER()

		elseif menu_selected == ABILITY_WINDBLAST then

			net.Start( "WDA_NWMessage" )

				net.WriteInt( NWM_CAST, 5 )

				net.WriteInt( menu_selected, 8 )

			net.SendToServer()

			isCasting = false

		end

	end



	local function WDA_PERFORM_CAST_END( success )

		if menu_selected == ABILITY_FARREACH && WDA_FARREACH_SUCCESS && isCasting then

			surface.PlaySound( "dishonored/farreach_cast.wav" )

				

			WDA_FARREACH_SUCCESS = false

			local ed = EffectData()

			ed:SetStart( LocalPlayer():GetShootPos() )

			ed:SetOrigin( WDA_FARREACH_POS )

			ed:SetEntity( LocalPlayer() )

			util.Effect( 'wda_farreach', ed )

		elseif menu_selected == ABILITY_FARREACH && !WDA_FARREACH_SUCCESS && isCasting then

			PlayAbortSound()

		end



		WDA_REMOVE_BLINK_POINTER()

	end

	

	-- | BINDINGS & MENU | --



	local function PlayCorrespondingBeginSound()

		if menu_selected == ABILITY_BLINK then

			surface.PlaySound( "dishonored/blink_begin.wav" )

		elseif menu_selected == ABILITY_FARREACH then

			surface.PlaySound( "dishonored/farreach_begin.wav" )

		elseif menu_selected == ABILITY_MESMERIZE then

			surface.PlaySound( "dishonored/mesmerize_begin.wav" )

		elseif menu_selected == ABILITY_SWARM then

			surface.PlaySound( "dishonored/swarm_begin.wav" )

		end

	end

	

	function WDA_PlayCorrespondingCastSound( ability )

		ability = tonumber( ability ) or menu_selected

		if ability == ABILITY_BLINK then

			surface.PlaySound( "dishonored/blink_cast.wav" )

		elseif ability == ABILITY_DOPPELGANGER then

			surface.PlaySound( "dishonored/doppelganger_cast.wav" )

		elseif ability == ABILITY_DOMINO then

			//surface.PlaySound( "dishonored/doppelganger_cast.wav" )

		elseif ability == ABILITY_SWARM then

			surface.PlaySound( "dishonored/swarm_cast.wav" )

		end

		

		if castLoopSound then

			castLoopSound:Stop()

			castLoopSound = nil

		end

	end

	

	-- Definition of the client-side possession effects

	-- functions, which called from server via SendLua

	

	local possessionLoop = nil

	local possessionLoopRestart = -1

	local possesion_anim = 0

	local possesion_animate = 0

	

	function WDA_StartPossessionEffects()

		local duration = sv_wda_possession_lifetime:GetFloat()

		surface.PlaySound( "dishonored/possesion_cast.wav" )

		

		if possessionLoop then

			possessionLoop:Stop()

			possessionLoop = nil

		end

		

		possessionLoop = CreateSound( LocalPlayer(), "dishonored/possesion_loop.wav" )

		possessionLoop:Play()

		

		possesion_animate = 0

		possesion_anim = 0



		timer.Create( 'wda_possession_loop_restart', SoundDuration( "dishonored/possesion_loop.wav" ), 0, function()

			possessionLoop:Stop()

			possessionLoop:Play()

		end )

		

		timer.Create( 'wda_possession_half_alert', duration / 2, 1, function()

			surface.PlaySound( "dishonored/possesion_half.wav" )

			possesion_animate = -1

		end )

		

		timer.Create( 'wda_possession_4sec_alert', duration - 3, 1, function()

			surface.PlaySound( "dishonored/possesion_4secleft.wav" )

			possesion_anim = 0

			possesion_animate = 1

		end )

	end

	

	function WDA_EndPossessionEffects()

		possessionLoopRestart = -1

		if possessionLoop then

			possessionLoop:Stop()

			possessionLoop = nil

		end

		

		surface.PlaySound( "dishonored/possesion_end.wav" )

		

		timer.Remove( 'wda_possession_half_alert' )

		timer.Remove( 'wda_possession_4sec_alert' )

		timer.Remove( 'wda_possession_loop_restart' )

	end

	

	-- Same for the Bend Time

	local bendtime_anim = 0

	local bendtime_animate = 0

	local bendtime_loop = nil

	local bendtime_soundid = 1

	local bendtime_ragdolls = {}

	

	function WDA_TIMEBEND_START()

		bendtime_anim = 0

		bendtime_animate = 1

		

		bendtime_soundid = math.random( 1, 2 )

		if bendtime_loop then

			bendtime_loop:Stop()

			bendtime_loop = nil

		end

		

		local startsound = 'dishonored/bendtime_begin' .. tostring( bendtime_soundid ) .. '.wav'

		local loopsound = 'dishonored/bendtime_loop' .. tostring( bendtime_soundid ) .. '.wav'

		

		surface.PlaySound( startsound )

		

		bendtime_loop = CreateSound( LocalPlayer(), loopsound )

		bendtime_loop:Play()

		

		timer.Create( 'wda_bendtime_loop_restart', SoundDuration( loopsound ), 0, function()

			if bendtime_loop then

				bendtime_loop:Stop()

				bendtime_loop:Play()

			end

		end )

	end

	

	function WDA_TIMEBEND_END()

		bendtime_animate = -1

		

		timer.Remove( 'wda_bendtime_loop_restart' )

		

		surface.PlaySound( 'dishonored/bendtime_end' .. tostring( bendtime_soundid ) .. '.wav' )

		

		if bendtime_loop then

			bendtime_loop:Stop()

			bendtime_loop = nil

		end

		

		for i, data in pairs( bendtime_ragdolls ) do

			local ent = data.ent

			if !IsValid( ent ) then continue end

			

			for i = 0, ent:GetPhysicsObjectCount() - 1 do

				local phy = ent:GetPhysicsObjectNum( i )

				local me, vel, avel = data.me[ i ], data.vel[ i ], data.avel[ i ]

				if !me || !vel || !avel then continue end

				

				phy:EnableMotion( me )

				phy:SetVelocity( vel )

				phy:AddAngleVelocity( avel )

			end

		end

		

		bendtime_ragdolls = {}

	end

	

	hook.Add( "OnEntityCreated", "WDA_BENDTIME_FREEZEDOLLS", function( ent )

		if GetGlobalBool( "WDA_TIMEBEND" ) && ent:GetClass() == "class C_ClientRagdoll" then

			local me, vel, avel = {}, {}, {}

			for i = 0, ent:GetPhysicsObjectCount() - 1 do

				local phy = ent:GetPhysicsObjectNum( i )

				me[ i ] = phy:IsMotionEnabled()

				vel[ i ] = phy:GetVelocity()

				avel[ i ] = phy:GetAngleVelocity()

				

				phy:EnableMotion( false )

			end

			

			table.insert( bendtime_ragdolls, { ent = ent, me = me, vel = vel, avel = avel } )

		end

	end )



	concommand.Add( "+dishonored_cast", function( ply )
		if ply.buyulendi then ply:ChatPrint("Şu an kullanamazsın.") return end
		hook.Run( "OnBindPressed", "dishonored_cast" )

	end )

	

	concommand.Add( "-dishonored_cast", function( ply )

		hook.Run( "OnBindReleased", "dishonored_cast" )

	end )

	

	concommand.Add( "+dishonored_menu", function( ply )

		hook.Run( "OnBindPressed", "dishonored_menu" )

	end )

	

	concommand.Add( "-dishonored_menu", function( ply )

		hook.Run( "OnBindReleased", "dishonored_menu" )

	end )

	

	concommand.Add( "dishonored_interrupt", function( ply )

		hook.Run( "OnBindPressed", "dishonored_interrupt" )

	end )

	

	concommand.Add( "+dishonored_cast", function( ply, cmd, args )
		if ply.buyulendi then ply:ChatPrint("Şu an kullanamazsın.") return end
		local id = tonumber( args[ 1 ] )

		

		if( !id ) then

			MsgC( Color( 200, 0, 0 ), "Improper use of the command!\nSyntax: +dishonored_cast <ability id>\nExample: +dishonored_cast 1\n" )

			return

		end

		

		if( id < ABILITY_BLINK || id > ABILITY_SHADOWWALK ) then

			MsgC( Color( 200, 0, 0 ), "Improper use of the command!\nAttempted use of unexistent ability. Valid range is 1-11.\n" )

			return

		end

		

		if LocalPlayer():GetNWFloat( "WDA_Cooldown" ) >= CurTime() then return end

		if !LocalPlayer():Alive() then return end

		if LocalPlayer():Team() == TEAM_SPECTATOR then return end

		if LocalPlayer():InVehicle() then return end

		if isCasting then return end

		

		menu_selected = id

		

		isCasting = true

		PlayCorrespondingBeginSound()

		StartCastLoopSound()

		WDA_PERFORM_CAST_BEGIN()

	end )

	

	concommand.Add( "-dishonored_cast", function( ply, cmd, args )

		if isCasting then

			WDA_PERFORM_CAST_END( true )

			isCasting = false

			net.Start( "WDA_NWMessage" )

				net.WriteInt( NWM_CAST, 5 )

				net.WriteInt( menu_selected, 8 )

			net.SendToServer()

			StopCastLoopSound()

		end

	end )

	

	local prohibited_abilities = {}

	local function UpdateCLRestrictedAbilities()

		prohibited_abilities = {}

		for i, v in pairs( string.Explode( '/', sv_wda_prohibited:GetString() ) ) do

			local num = tonumber( v )

			if num == nil then continue end

			table.insert( prohibited_abilities, num )

		end

	end

	

	hook.Add( "OnBindPressed", "WDA_LISTENTO_WBS", function( cmd )

		--if sv_wda_disable:GetBool() then return end

		if cmd == "dishonored_menu" 

			&& !LocalPlayer():GetNWBool( "WDA_InShadowWalk" )

			&& !LocalPlayer():GetNWBool( "WDA_Possessing" ) then

			

			UpdateCLRestrictedAbilities()

			menu_visible = true

			StopCastLoopSound()

			isCasting = false

			WDA_PERFORM_CAST_END()

		elseif cmd == "dishonored_cast" && !menu_selected_ph && !isCasting then
			if LocalPlayer():GetNWFloat( "WDA_Cooldown" ) >= CurTime() then return end

			if !LocalPlayer():Alive() then return end

			if LocalPlayer():Team() == TEAM_SPECTATOR then return end

			if LocalPlayer():InVehicle() then return end

		

			isCasting = true

			PlayCorrespondingBeginSound()

			StartCastLoopSound()

			WDA_PERFORM_CAST_BEGIN()

		elseif cmd == "dishonored_cast" && menu_selected_ph then

			chat.AddText( Color( 200, 25, 25 ), "[KEDIRP] Bu yeteneği kullanamazsın." )

		elseif cmd == "dishonored_interrupt" then

			if isCasting then

				PlayAbortSound()

				StopCastLoopSound()

				isCasting = false

				WDA_PERFORM_CAST_END()

			end

		end

	end )

	

	hook.Add( "OnBindReleased", "WDA_LISTENTO_WBS", function( cmd )

		if cmd == "dishonored_menu" then

			menu_visible = false

		elseif cmd == "dishonored_cast" then

			if isCasting then

				WDA_PERFORM_CAST_END( true )

				isCasting = false

				net.Start( "WDA_NWMessage" )

					net.WriteInt( NWM_CAST, 5 )

					net.WriteInt( menu_selected, 8 )

				net.SendToServer()

				StopCastLoopSound()

			end

		end

	end )

	

	hook.Add( "StartCommand", "WDA_CATCHMOUSEINPUT", function( ply, cmd )

		if !menu_visible then return end

		menu_cursorpos.x = math.Clamp( menu_cursorpos.x + cmd:GetMouseX() / 300, -1, 1 )

		menu_cursorpos.y = math.Clamp( menu_cursorpos.y + cmd:GetMouseY() / 300, -1, 1 )

	end )



	local abilities = {
		[ABILITY_BLINK] = { "Parilti", "Hızlıca ilerlemeni sağlar.", Material( "hud/dishonored/icon_blink.png" ) },
		[ABILITY_DARKVISION] = { "KARANLIK GORUS", "Karanlıkta daha iyi görmeni sağlar.\nVarlıkları duvar arkası görebilirsin. ", Material( "hud/dishonored/icon_darkvision.png" ) },
		[ABILITY_BENDTIME] = { "ZAMAN BÜKÜMÜ", "Zamanı kısa süre durdurur.", Material( "hud/dishonored/icon_bendtime.png" ) },
		[ABILITY_WINDBLAST] = { "Rüzgar patlamasI", "Rüzgarın gücüyle herhangi \nbir şeyi ileri fırlatır.", Material( "hud/dishonored/icon_windblast.png" ) },
		[ABILITY_POSSESSION] = { "Hüküm", "Kısa süreliğine birini kontrol altına alırsın.", Material( "hud/dishonored/icon_possession.png" ) },
		[ABILITY_SWARM] = { "Böcek Sürüsü", "Düşmanlarına böceklerle saldırırsın.", Material( "hud/dishonored/icon_swarm.png" ) },
		[ABILITY_FARREACH] = { "Uzak Erişim", "Bir yere kendinizi çekersiniz.\nEşyaları size getirebilir.", Material( "hud/dishonored/icon_farreach.png" ) },
		[ABILITY_DOMINO] = { "Kader", "İki insanın kaderini birbirine bağlayın\nBirine ne olursa onada o olur.", Material( "hud/dishonored/icon_domino.png" ) },
		[ABILITY_DOPPELGANGER] = { "TIPATIP", "Düşmanlarınıza karşı kendinize ait bir gövde çağırın.", Material( "hud/dishonored/icon_doppelganger.png" ) },
		[ABILITY_MESMERIZE] = { "Hipnotize", "İnsanları büyülemek için ruh çağırır.", Material( "hud/dishonored/icon_mesmerize.png" ) },
		[ABILITY_SHADOWWALK] = { "Gölge Yürüyüşü", "Kısa süreliğine bir ruh formuna dönüşürsün.", Material( "hud/dishonored/icon_shadowwalk.png" ) }
	}

	

	local bendtime_warning = 'Bu özellik sunucudan kaldırılmıştır!' --Bend Time cannot be used in multiplayer

	

	local background_mat = Material( "hud/dishonored/menu_bg.png" )

	local background_ring_mat = Material( "hud/dishonored/menu_ring.png" )

	local background_ring_inner_mat = Material( "hud/dishonored/menu_ring_inner.png" )

	local background_mark_mat = Material( "hud/dishonored/menu_mark.png" )

	local background_shade_mat = Material( "hud/dishonored/menu_shade.png" )

	local selector_mat = Material( "hud/dishonored/menu_selector.png" )

	local blur_mat = Material( "pp/blurscreen" )

	

	local shadowwalk_anim = 0

	local vignette = Material( 'effects/dishonored/shadowwalk_vignette.png' )

	

	local function WDA_DRAW_SHADOWWALK_SE()

		if shadowwalk_anim == 0 then return end

		

		surface.SetDrawColor( 100, 100, 100, 200 * shadowwalk_anim )

		surface.SetMaterial( vignette )

		surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )

	end

	

	hook.Add( "HUDPaint", "WDA_DRAWMENU", function()

		WDA_DRAW_SHADOWWALK_SE()

		

		if castLoopSound and castLoopSound:IsPlaying() then

			if castLoopSoundDuration <= CurTime() then

				castLoopSound:Stop()

				castLoopSound:Play()

				castLoopSoundDuration = CurTime() + castLoopSounds[ menu_selected ][2]

			end

		end

		

		if menu_visible then

			menu_percentage = math.Approach( menu_percentage, 1, RealFrameTime() * 10 )

		else

			menu_percentage = math.Approach( menu_percentage, 0, RealFrameTime() * 10 )

		end

		

		if menu_percentage == 0 then

			return

		end

		

		local w, h = ScrW(), ScrH()

		local rad = h / 3

		local cellsize = 100

		local selector_angle = ( Vector( -menu_cursorpos.y, -menu_cursorpos.x, 0 ) ):Angle().y

		

		blur_mat:SetFloat( '$blur', menu_percentage * 2 )

		blur_mat:Recompute()

	

		surface.SetMaterial( blur_mat )

		surface.SetDrawColor( 255, 255, 255, 255 )

		render.UpdateScreenEffectTexture()

		surface.DrawTexturedRect( 0, 0, w, h )

		

		surface.SetDrawColor( 0, 0, 0, 240 * menu_percentage )

		surface.DrawRect( 0, 0, w, h )

		

		render.PushFilterMag( TEXFILTER.ANISOTROPIC )

		render.PushFilterMin( TEXFILTER.ANISOTROPIC )

		

		surface.SetDrawColor( 255, 255, 255, 10 * menu_percentage )

		surface.SetMaterial( background_mat )

		surface.DrawTexturedRect( 0, 0, w, h )

		

		surface.SetDrawColor( 255, 255, 255, 255 * menu_percentage )

		surface.SetMaterial( background_ring_mat )

		surface.DrawTexturedRect( w / 2 - h / 2, 0, h, h )

		

		surface.SetDrawColor( 165, 165, 165, 255 * menu_percentage )

		surface.SetMaterial( background_ring_inner_mat )

		surface.DrawTexturedRect( w / 2 - h / 2, 0, h, h )



		-- | RADIAL MENU | --

		local sector = 360 / table.Count( abilities )

		local ability = 0

		for i = 0, 360, sector do

			ability = ability + 1

			

			local rd = math.rad( i )

			local x, y = w / 2 - math.sin( rd ) * rad - cellsize * 0.5, h / 2 - math.cos( rd ) * rad - cellsize * 0.5



			local prohibited = ( string.find(LocalPlayer():GetNWString("yetenekler","") , "|"..tostring(ability).."|") == nil  ) --ability == ABILITY_BENDTIME && !game.SinglePlayer() || table.HasValue( prohibited_abilities, ability )

			

			if selector_angle > i - sector / 2 and selector_angle < i + sector / 2 or i == 0 and -sector / 2 <= selector_angle - 360 then

				surface.SetDrawColor( 255, 255, 255, 255 * menu_percentage )

				menu_selected = ability

				menu_selected_ph = prohibited



				x, y = w / 2 - math.sin( rd ) * ( rad + 5 ) - cellsize * 0.5, h / 2 - math.cos( rd ) * ( rad + 5 ) - cellsize * 0.5

			else

				surface.SetDrawColor( 100, 100, 100, 255 * menu_percentage )

			end

			

			if prohibited then

				surface.SetDrawColor( 255, 25, 25, 255 * menu_percentage )

			end

			

			if abilities[ ability ][3] then

				surface.SetMaterial( abilities[ ability ][3] )

				surface.DrawTexturedRect( x, y, cellsize, cellsize )

			end

		end

		

		surface.SetDrawColor( 255, 255, 255, 255 * menu_percentage )

		surface.SetMaterial( selector_mat )

		surface.DrawTexturedRectRotated( w / 2, h / 2, h - 25, h - 25, selector_angle )

		

		render.PopFilterMag()

		render.PopFilterMin()

		

		-- | SELECTION DISPLAY | --

		if abilities[ menu_selected ] then

			local name = string.upper( string.Replace( abilities[ menu_selected ][1], 'ä', 'Ä' ) )

			draw.SimpleText( name, "WDA_ABILITYNAME", w / 2, h / 2 + h / 9.5, Color( 255, 255, 255, 255 * menu_percentage ), 

				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			

			local new_y = h / 2 + h / 8 + 12

			for i, v in pairs( string.Explode( "\n", abilities[ menu_selected ][2] ) ) do

				draw.SimpleText( v, "WDA_ABILITYDESCRIPTION", w / 2, new_y, Color( 255, 255, 255, 255 * menu_percentage ), 

				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )

				

				new_y = new_y + 11

			end



			new_y = new_y + 4

			

			if menu_selected == ABILITY_BENDTIME && !game.SinglePlayer() then

				draw.SimpleText( bendtime_warning, "WDA_ABILITYDESCRIPTION", w / 2, new_y, Color( 255, 0, 0, 255 * menu_percentage ), 

				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )

			end

		end

	end )

	

	-- | CLIENT-SIDE ABILITY EFFECTS | --

	

	local mat_blink_sphere_spirte = Material( 'effects/dishonored/blink_sprite_sphere' )

	local mat_blink_sphere_arrow = Material( 'effects/dishonored/blink_sprite_arrow' )

	local mat_blink_leak = Material( 'effects/dishonored/blink_leak' )



	local function WDA_BLINK()

		local ply = LocalPlayer()

		local length = sv_wda_blink_range:GetFloat()

		local tr = util.TraceLine( { start = EyePos(), endpos = EyePos() + EyeAngles():Forward() * length, filter = ply } )

		local normal = tr.Hit and tr.HitNormal or Vector( 0, 0, 1 )

		local pos, canblink, isfloor = BLINK_PLACEMENT( tr.HitPos, normal, ply )

		local size = 38 + ( ( math.sin( CurTime() * 10 ) + 1 ) / 2 ) * 3

		local size2 = 32 + ( ( math.sin( CurTime() * 10 + 1000 ) + 1 ) / 2 ) * 3

		local beamwidth = 64 + ( ( math.sin( CurTime() * 5 + 1000 ) + 1 ) / 2 ) * 6



		local _, hull = ply:GetHull()

		if ply:Crouching() then

			_, hull = ply:GetHullDuck()

		end

		

		local ctr = util.TraceLine( { start = pos + Vector( 0, 0, 16 ), endpos = pos + Vector( 0, 0, 16 ) - normal * 18 } )

		local ctrd = util.QuickTrace( ctr.HitPos, Vector( 0, 0, -16 ) )

		local utr = util.QuickTrace( ctrd.HitPos, Vector( 0, 0, hull.z ) )

		

		local mat_to_use = mat_blink_sphere_spirte

		if !ctr.Hit && !utr.Hit && !isfloor then

			mat_to_use = mat_blink_sphere_arrow

		end

		

		if canblink and !tr.HitSky then

			if !( !ctr.Hit && !utr.Hit && !isfloor ) then

				local dtr = util.QuickTrace( pos, -Vector( 0, 0, 9999 ), ply )

				//render.DrawBeam( pos + Vector( 0, 0, 24 ), dtr.HitPos + Vector( 0, 0, 16 ), beamwidth, 0, 0.5, Color( 64, 160, 252, 120 ) )

				//render.DrawBeam( pos + Vector( 0, 0, 18 ), dtr.HitPos + Vector( 0, 0, 16 ), beamwidth / 2, 0, 0.5, Color( 255, 255, 255, 120 ) )

				

				// bottom sphere

				render.SetMaterial( mat_blink_sphere_spirte )

				//render.DrawSprite( dtr.HitPos + Vector( 0, 0, 16 ), size * 1.2, size * 1.2, Color( 64, 160, 252, 150 ) )

				//render.DrawSprite( dtr.HitPos + Vector( 0, 0, 16 ), size2 * 1.2 / 1.25, size2 * 1.2 / 1.25, Color( 184, 246, 252, 200 ) )

				

				if IsValid( WDA_BLINK_POINTER ) then

					WDA_BLINK_POINTER_BOT:SetPos( dtr.HitPos + Vector( 0, 0, 6 ) )

					WDA_BLINK_POINTER_BOT:DrawModel()

				end

				

				if IsValid( WDA_BLINK_POINTER ) then

					WDA_BLINK_POINTER:SetPos( pos )

					WDA_BLINK_POINTER:DrawModel()

				end

				

				render.SetMaterial( mat_blink_sphere_spirte )

				render.DrawSprite( dtr.HitPos + Vector( 0, 0, 8 ), size2, size2, Color( 222, 246, 255, 255 ) )

				

				render.SetMaterial( mat_blink_sphere_spirte )

				render.DrawSprite( pos, size, size, Color( 190, 226, 255, 200 ) )

				

				render.SetMaterial( mat_blink_sphere_spirte )

				render.DrawSprite( pos, size2 / 1.25, size2 / 1.25, Color( 222, 246, 255, 255 ) )

			else

				if IsValid( WDA_BLINK_POINTER ) then

					WDA_BLINK_POINTER_BOT:SetPos( pos )

					WDA_BLINK_POINTER_BOT:DrawModel()

				end

				

				render.SetMaterial( mat_blink_sphere_spirte )

				render.DrawSprite( pos, size, size, Color( 200, 230, 255, 200 ) )

				render.DrawSprite( pos, size, size, Color( 0, 0, 0, 100 ) )

				

				render.SetMaterial( mat_blink_sphere_arrow )

				render.DrawSprite( pos, size2, size2, Color( 200, 246, 255, 255 ) )

			end

			

			if !cl_wda_disable_dynamic_lights:GetBool() then

				local light = DynamicLight( LocalPlayer():EntIndex() )

				if ( light ) then

					light.pos = pos

					light.r = 100

					light.g = 100

					light.b = 100

					light.brightness = 2

					light.Decay = 2000

					light.Size = 160

					light.DieTime = CurTime() + FrameTime() * 2

				end

			end



			/*local ed = EffectData()

			ed:SetOrigin( pos )

			util.Effect( 'wda_blink', ed )*/

			

			WDA_TARGET_EFFECT = pos

		end

	end

	

	local mat_farreach_beam = Material( 'effects/dishonored/farreach_helper_beam.png' )

	local farreach_beamwidth = 6

	

	local function WDA_FARREACH()

		local ply = LocalPlayer()

		local length = sv_wda_farreach_range:GetFloat()

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		if !tr.Hit || tr.HitSky then

			tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length / 2 - Vector( 0, 0, length ), filter = ply } )

		end

		

		if !tr.Hit then

			WDA_FARREACH_SUCCESS = false

			return

		end

		WDA_FARREACH_SUCCESS = true

		

		local beamstart = ply:EyePos() - ply:EyeAngles():Right() * 24

		local length = ( tr.HitPos - beamstart ):Length()



		//render.DrawBeam( beamstart, tr.HitPos, 15, 0, length / 128, Color( 255, 255, 255, 255 ) )

		

		local lastPoint = beamstart

		local target = tr.HitPos

		local dir = target - beamstart

		local peak = Vector( 0, 0, 20 - ( ( tr.Fraction ) * 1 ) )



		local _, hull = ply:GetHull()

		if ply:Crouching() then

			_, hull = ply:GetHullDuck()

		end

		

		local ctr = util.TraceLine( { start = target + Vector( 0, 0, 16 ), endpos = target + Vector( 0, 0, 16 ) - tr.HitNormal * 18 } )

		local ctrd = util.QuickTrace( ctr.HitPos, Vector( 0, 0, -16 ) )

		local utr = util.QuickTrace( ctrd.HitPos, Vector( 0, 0, hull.z ) )

		

		local canGrab = IsValid( tr.Entity ) && 

				( ( string.find( tr.Entity:GetClass(), 'item_' ) || string.find( tr.Entity:GetClass(), 'weapon_' ) ) 

				&& !table.HasValue( exclude_items, tr.Entity:GetClass() ) )

				|| table.HasValue( include_items, tr.Entity:GetClass() )

				|| sv_wda_farreach_pullprops:GetBool() && tr.Entity:GetClass() == 'prop_physics'



		local mat_to_use = mat_blink_sphere_spirte

		if !ctr.Hit && !utr.Hit && !isfloor && !canGrab then

			mat_to_use = mat_blink_sphere_arrow

		end

		

		WDA_FARREACH_POS = target

		

		cam.IgnoreZ( true )

		if IsValid( WDA_BLINK_POINTER ) then

			WDA_BLINK_POINTER:SetPos( target )

			if canGrab then

				WDA_BLINK_POINTER:SetAngles( EyeAngles() + Angle( 90, 0, 0 ) )

			else

				WDA_BLINK_POINTER:SetAngles( tr.HitNormal:Angle() - Angle( 90, 0, 0 ) )

			end

			WDA_BLINK_POINTER:DrawModel()

			

			if !cl_wda_disable_dynamic_lights:GetBool() then

				local light = DynamicLight( LocalPlayer():EntIndex() )

				if ( light ) then

					light.pos = target

					light.r = 100

					light.g = 100

					light.b = 100

					light.brightness = 2

					light.Decay = 2000

					light.Size = 160

					light.DieTime = CurTime() + FrameTime() * 2

				end

			end

		end

		

		render.SetMaterial( mat_farreach_beam )

		local prev = nil

		local prev_t = nil

		local prev_b = nil

		local plyPitch = ply:EyeAngles().p

		

		render.PushFilterMag( TEXFILTER.LINEAR )

		render.PushFilterMin( TEXFILTER.LINEAR )

		for i = 1, 10 do

			local perc = i / 10

			local pos = beamstart + dir * perc + peak * ( math.sin( math.rad( perc * 180 ) ) )

			

			local t, b = Vector( 0, 0, farreach_beamwidth / 2 ), Vector( 0, 0, farreach_beamwidth / 2 )

			

			t:Rotate( ply:EyeAngles() )

			b:Rotate( ply:EyeAngles() )

			

			if prev_t == nil || prev_b == nil || prev == nil then

				prev = beamstart

				prev_t = beamstart + t

				prev_b = beamstart - b

			end

			

			local t, b = Vector( 0, 0, farreach_beamwidth / 2 ), Vector( 0, 0, farreach_beamwidth / 2 )



			local rdir = ( prev - pos ):GetNormalized()

			local focusPoint = ply:EyeAngles():Forward() * ( ply:EyePos() - pos ):Length()

			local camDir = ( pos - focusPoint ):GetNormalized():Angle()

			local rot = rdir:Angle()



			local point = ply:EyePos() + dir * perc

			local a = ( pos - point ):Angle()

			

			//debugoverlay.Cross( ply:EyePos() + point, 16, 0.1, Color( 255, 0, 0, 255 ) )



			rot.r = rot.r - i * 6 * ( 1 - plyPitch / 45 ) * perc

			t:Rotate( rot )

			b:Rotate( rot )



			local cur_t, cur_b = pos + t, pos - b



			render.DrawQuad( cur_t, cur_b, prev_b, prev_t, Color( 255, 255, 255, 255 ) )



			prev = pos

			prev_t = cur_t

			prev_b = cur_b

			

			lastPoint = pos

		end

		render.PopFilterMag()

		render.PopFilterMin()

		

		render.SetMaterial( mat_to_use )

		render.DrawSprite( target, 32, 32, Color( 255, 255, 255, 200 ) )

		render.DrawSprite( target, 36, 36, Color( 177, 234, 255, 150 ) )



		cam.IgnoreZ( false )

	end

	

	local mat_mesmerize_bludge = Material( "effects/dishonored/strider_bulge_dudv.vmt" )

	local mat_mesmerize_flare = Material( "effects/dishonored/mesmer_darkglow.png" )

	local mesmer_sprite_size = 64

	local function WDA_MESMERIZE()

		local ply = LocalPlayer()

		local length = sv_wda_mermerize_cast_range:GetFloat()

		

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		

		if tr.Hit then

			cam.IgnoreZ( true )



			render.SetMaterial( mat_mesmerize_flare )

			render.DrawSprite( tr.HitPos, mesmer_sprite_size / 6, mesmer_sprite_size, Color( 0, 0, 0, 255 ) )

			

			cam.IgnoreZ( false )

		end

	end

	

	local function WDA_DOPPELGANGER()

		local ply = LocalPlayer()

		local length = sv_wda_doppelganger_cast_range:GetFloat()

		local tr = util.TraceLine( { start = ply:EyePos(), endpos = ply:EyePos() + ply:EyeAngles():Forward() * length, filter = ply } )

		

		if tr.HitSky then

			return

		end

		

		local top = tr.HitPos

		local top_normal = tr.HitNormal

		

		tr = util.QuickTrace( tr.HitPos, Vector( 0, 0, -1000 ) )

		

		if tr.HitSky || !tr.Hit then

			return

		end

		

		local pos, canblink, isfloor = BLINK_PLACEMENT( top, top_normal, ply )



		WDA_DOPPELGANGER_AIMHELPER_POS = tr.HitPos

		if IsValid( WDA_BLINK_POINTER ) then

			local ed = EffectData()

			ed:SetOrigin( pos )

			util.Effect( 'wda_doppelganger_pointer', ed )

		

			render.SetColorModulation( 0.91, 0.84, 0.76 )

			WDA_BLINK_POINTER:SetPos( pos )

			WDA_BLINK_POINTER:DrawModel()

			

			local bpos = pos

			bpos.z = tr.HitPos.z



			ed:SetOrigin( bpos + Vector( 0, 0, 10 ) )

			util.Effect( 'wda_doppelganger_pointer', ed )

			

			WDA_BLINK_POINTER_BOT:SetPos( bpos )

			WDA_BLINK_POINTER_BOT:DrawModel()

			render.SetColorModulation( 1, 1, 1 )

		end

	end

	

	local function WDA_SWARM()

		local ply = LocalPlayer()

		

		local length = sv_wda_swarm_cast_range:GetFloat()

		local tr = util.QuickTrace( ply:EyePos(), ply:EyeAngles():Forward() * length, ply )

		

		if !tr.Hit || tr.HitSky then

			return

		end

		

		local pos = tr.HitPos + tr.HitNormal * 8

		

		tr = util.QuickTrace( pos, Vector( 0, 0, -32000 ), ply )



		pos = tr.HitPos + tr.HitNormal * 2

		

		local ed = EffectData()

		ed:SetOrigin( pos )

		ed:SetFlags( 2 )

		util.Effect( 'wda_swarm_spawn', ed )

	end

	

	local possessionSpriteSize = 18

	local function WDA_POSSESSION()

		if LocalPlayer():GetNWBool( "WDA_Possessing" ) then return end

		

		local ply = LocalPlayer()

		

		local length = sv_wda_possession_cast_range:GetFloat()

		local tr = util.QuickTrace( ply:EyePos(), ply:EyeAngles():Forward() * length, ply )

		

		if !tr.Hit || tr.HitSky || !IsValid( tr.Entity ) || !tr.Entity:IsNPC() then

			return

		end

		

		local npc = tr.Entity

		local pos

		

		if table.HasValue( possesion_excludes, npc:GetClass() ) then

			return

		end



		local head = npc:LookupBone( 'ValveBiped.Bip01_Head1' )

		local head_zombie = npc:LookupAttachment( 'headcrab' )

		

		if head && npc:GetClass() != 'npc_fastzombie' then

			pos = npc:GetBonePosition( head ) + Vector( 0, 0, 2 )

		elseif head_zombie then

			local att = npc:GetAttachment( head_zombie )

			if att then

				pos = att.Pos

			else

				pos = npc:GetPos() + npc:OBBCenter()

			end

		else

			pos = npc:GetPos() + npc:OBBCenter()

		end

		

		local sine = ( ( math.sin( CurTime() * 5 ) + 1 ) / 2 )

		

		cam.IgnoreZ( true )

		render.SetMaterial( mat_mesmerize_flare )

		render.DrawSprite( pos, possessionSpriteSize + sine * 7, possessionSpriteSize + sine * 7, Color( 255, 200, 115, 120 - sine * 50 ) )

		cam.IgnoreZ( false )

		

		local ed = EffectData()

		ed:SetOrigin( pos )

		ed:SetStart( npc:GetVelocity() )

		util.Effect( 'wda_domino_headeffect', ed )

	end

	

	-- | SCREEN SPACE EFFECTS | -- 

	local dominoSpriteSize = 16

	local function WDA_DRAW_DOMINO_LINKS()

		cam.Start3D()

		local linkCenter = nil

		

		if table.Count( WDA_DOMINO_LINKS ) > 0 then

			local pos = Vector()

			

			local sine = 50 * ( ( math.sin( CurTime() * 2 ) + 1 ) / 2 )



			cam.IgnoreZ( true )

			for i, v in pairs( WDA_DOMINO_LINKS ) do

				if IsValid( v ) && ( v:IsPlayer() || v:IsNPC() || ( v.BaseClass && v.BaseClass.Type == 'nextbot' ) || v:GetClass() == 'wda_doppelganger' ) then

					if v:GetNWFloat( 'WDA_HP_OVR', v:Health() ) <= 0 && !table.HasValue( propNPCs, v:GetClass() ) && v:GetClass() != 'wda_doppelganger' then

						table.remove( WDA_DOMINO_LINKS, i )

						continue

					end

					

					if linkCenter == nil then

						linkCenter = v

						

						pos = linkCenter:GetPos()

							

						local head = linkCenter:LookupBone( 'ValveBiped.Bip01_Head1' )

						if head then

							pos = linkCenter:GetBonePosition( head ) + Vector( 0, 0, 2 )

						end

						

						if v:IsPlayer() then

							pos = pos + Vector( 0, 0, 5 )

						end

						

						render.SetMaterial( mat_mesmerize_flare )

						render.DrawSprite( pos, dominoSpriteSize, dominoSpriteSize, Color( 255, 200, 115, 120 - sine ) )

					end

					

					local cpos = v:GetPos()

					

					local head = v:LookupBone( 'ValveBiped.Bip01_Head1' )

					if head then

						cpos = v:GetBonePosition( head ) + Vector( 0, 0, 2 )

					end

					

					if v:IsPlayer() then

						cpos = cpos + Vector( 0, 0, 5 )

					end

					

					local ed = EffectData()

					ed:SetOrigin( cpos )

					ed:SetStart( v:GetVelocity() )

					util.Effect( 'wda_domino_headeffect', ed )

					

					render.SetMaterial( mat_mesmerize_flare )

					render.DrawSprite( cpos, dominoSpriteSize, dominoSpriteSize, Color( 255, 200, 115, 100 - sine ) )

					

					render.SetMaterial( mat_farreach_beam )

					render.DrawBeam( pos, cpos, 2, 0, 1, Color( 255, 200, 120, 35 - sine * 0.25 ) )

				else

					WDA_DOMINO_LINKS[i] = nil

					continue

				end

			end

			cam.IgnoreZ( false )

		end

		cam.End3D()

	end



	local screenblur = Material( 'pp/blurscreen' )

	local function WDA_DRAW_POSSESSION()

		local clr = ( ( math.sin( CurTime() ) + 1 ) / 2 ) * 255

		local alpha = ( ( math.sin( CurTime() * 2 ) + 1 ) / 2 ) * 50 + 100

		surface.SetDrawColor( clr, clr, clr, alpha )

		surface.SetMaterial( vignette )

		surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )

		

		screenblur:SetFloat( '$blur', possesion_anim * 5 )

		screenblur:Recompute()

		

		surface.SetMaterial( screenblur )

		surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )

	end

	

	local dv_anim = 0

	local darkvision_pp = {

		[ "$pp_colour_addr" ] = 106 * 0.02,

		[ "$pp_colour_addg" ] = 92 * 0.02,

		[ "$pp_colour_addb" ] = 0,

		[ "$pp_colour_brightness" ] = -1.62,

		[ "$pp_colour_contrast" ] = 1.16,

		[ "$pp_colour_colour" ] = 0.50,

		[ "$pp_colour_mulr" ] = 0,

		[ "$pp_colour_mulg" ] = 0,

		[ "$pp_colour_mulb" ] = 0

	}

	

	local function WDA_DRAW_DARKVISION_PP()

		--if dv_anim == 0 then
			--return 
		--end


		darkvision_pp[ "$pp_colour_addr" ] = dv_anim == 0 and 0 or Lerp( dv_anim, 0, 106 * 0.02 )

		darkvision_pp[ "$pp_colour_addg" ] = dv_anim == 0 and 0 or Lerp( dv_anim, 0, 92 * 0.02 )

		darkvision_pp[ "$pp_colour_brightness" ] = dv_anim == 0 and 0 or Lerp( dv_anim, 0, -2.62 )

		darkvision_pp[ "$pp_colour_contrast" ] = dv_anim == 0 and 1 or Lerp( dv_anim, 1, 1.16 )

		darkvision_pp[ "$pp_colour_colour" ] = dv_anim == 0 and 1 or Lerp( ( dv_anim * 0.5 ) / 0.5, 1, 0.50 )

		

		DrawColorModify( darkvision_pp )

	end



	local possession_pp = {

		[ "$pp_colour_addr" ] = 5 * 0.02,

		[ "$pp_colour_addg" ] = 41 * 0.02,

		[ "$pp_colour_addb" ] = 53 * 0.02,

		[ "$pp_colour_brightness" ] = -0.83,

		[ "$pp_colour_contrast" ] = 0.64,

		[ "$pp_colour_colour" ] = 0.29,

		[ "$pp_colour_mulr" ] = 0,

		[ "$pp_colour_mulg" ] = 0,

		[ "$pp_colour_mulb" ] = 0

	}

	

	local bendtime_pp = {

		[ "$pp_colour_addr" ] = 0,

		[ "$pp_colour_addg" ] = 0,

		[ "$pp_colour_addb" ] = 0,

		[ "$pp_colour_brightness" ] = 0,

		[ "$pp_colour_contrast" ] = 1,

		[ "$pp_colour_colour" ] = 1,

		[ "$pp_colour_mulr" ] = 0,

		[ "$pp_colour_mulg" ] = 0,

		[ "$pp_colour_mulb" ] = 0

	}

	

	local shadowwalk_pp = {

		[ "$pp_colour_addr" ] = 0,

		[ "$pp_colour_addg" ] = 0,

		[ "$pp_colour_addb" ] = 0,

		[ "$pp_colour_brightness" ] = 0,

		[ "$pp_colour_contrast" ] = 1,

		[ "$pp_colour_colour" ] = 1,

		[ "$pp_colour_mulr" ] = 0,

		[ "$pp_colour_mulg" ] = 0,

		[ "$pp_colour_mulb" ] = 0

	}

	

	hook.Add( 'PrePlayerDraw', 'WDA_SHADOWWALK_HIDPLAYER', function( ply )

		if ply:GetNWBool( 'WDA_InShadowWalk' ) then

			local dist = LocalPlayer():GetPos():Distance( ply:GetPos() )



			if dist > sv_wda_shadowwalk_vis_range:GetFloat() then

				return true

			else

				local speedAmpf = math.min( ply:GetVelocity():Length() / 50, 1 )

				local right = ply:GetAngles():Right()

				local ed = EffectData()

				ed:SetOrigin( ply:GetPos() + math.sin( CurTime() * ( 1 + 4 * speedAmpf ) ) * right * 16 * speedAmpf )

				util.Effect( 'wda_shadowwalk_tp', ed )

				return true

			end

		end

	end )



	hook.Add( 'RenderScreenspaceEffects', 'WDA_RENDEREFFECTS', function()

		if isCasting then

			cam.Start3D()

				if menu_selected == ABILITY_BLINK then

					WDA_BLINK()

				elseif menu_selected == ABILITY_FARREACH then

					WDA_FARREACH()

				elseif menu_selected == ABILITY_MESMERIZE then

					WDA_MESMERIZE()

				elseif menu_selected == ABILITY_DOPPELGANGER then

					WDA_DOPPELGANGER()

				elseif menu_selected == ABILITY_SWARM then

					WDA_SWARM()

				elseif menu_selected == ABILITY_POSSESSION then

					WDA_POSSESSION()

				end

			cam.End3D()

		end

		

		if LocalPlayer():GetNWBool( 'WDA_InShadowWalk' ) then

			shadowwalk_anim = math.Approach( shadowwalk_anim, 1, RealFrameTime() )

		else

			shadowwalk_anim = math.Approach( shadowwalk_anim, 0, RealFrameTime() * 3 )

		end

		

		if shadowwalk_anim > 0 then

			shadowwalk_pp[ "$pp_colour_colour" ] = Lerp( shadowwalk_anim, 1, 0.5 )

			DrawColorModify( shadowwalk_pp )

		end

		

		if LocalPlayer():GetNWBool( 'WDA_Possessing' ) then

			cam.Start2D()

			WDA_DRAW_POSSESSION()

			cam.End2D()

			

			DrawColorModify( possession_pp )

		end

		

		if bendtime_animate == 1 then

			bendtime_anim = math.Approach( bendtime_anim, 1, RealFrameTime() * 2 )

		elseif bendtime_animate == -1 then

			bendtime_anim = math.Approach( bendtime_anim, 0, RealFrameTime() * 3 )

			if bendtime_anim == 0 then

				bendtime_animate = 0

			end

		end

		

		if bendtime_anim > 0 then

			bendtime_pp[ "$pp_colour_colour" ] = 1 - bendtime_anim

			DrawColorModify( bendtime_pp )

		end

		

		-- draw domino links

		WDA_DRAW_DOMINO_LINKS()

		-- draw dark vision post processing

		WDA_DRAW_DARKVISION_PP()

	end )

	

	-- | DARK VISION | --

	local inVisionMode = false

	local sound = nil

	local nextBubble = 0

	local bubbleAnim = 0

	local bubblePos = Vector()

	local bubbleSize = 0

	local dv_foundEntities = {}



	local explosives = {

		'models/props_c17/oildrum001_explosive.mdl',

		'models/props_junk/gascan001a.mdl',

		'models/props_junk/propane_tank001a.mdl'

	}

	

	local _visionMat = Material( 'vgui/white' )



	local mat_copy		= Material( 'pp/mat_copy' )

	local mat_add		= Material( "pp/add" )

	local source 		= render.GetScreenEffectTexture( 0 )

	local blur 			= render.GetScreenEffectTexture( 1 )

	local pre_blur		= GetRenderTarget( "_wda_darkvision_preblur", ScrW(), ScrH(), true )

	local mat_preblur 	= CreateMaterial( "_wda_preblur_material", "UnlitGeneric", {

		["$basetexture"] 	= "_wda_darkvision_preblur",

		["$additive"]		= "1"

	} )

	local mat_viewBeam	= Material( "effects/lamp_beam" )

	local mat_viewGlow	= Material( "sprites/light_ignorez" )



	hook.Add( 'PostDrawEffects', 'WDA_DRAW_DARKVISION', function()

		if WDA_IN_DARKVISION then

			if !inVisionMode then

				inVisionMode = true

				surface.PlaySound( 'dishonored/darkvision_begin.wav' )

				bubblePos = EyePos()

			end

			

			if WDA_DARKVISION_DURATION <= CurTime() then

				WDA_IN_DARKVISION = false

			end

			

			dv_anim = math.Approach( dv_anim, 1, RealFrameTime() * 2 )

		else

			if inVisionMode then

				inVisionMode = false

				surface.PlaySound( 'dishonored/darkvision_end.wav' )

			end

			

			dv_anim = math.Approach( dv_anim, 0, RealFrameTime() * 5 )

		end

		

		if dv_anim == 0 then return end

		local maxDist = 1000

		

		if nextBubble <= CurTime() then

			nextBubble = CurTime() + 4

			bubblePos = EyePos()

			surface.PlaySound( 'dishonored/darkvision_scan.wav' )

			dv_foundEntities = {}

			for i, v in pairs( ents.FindInSphere( bubblePos, maxDist + 300 ) ) do

				if !IsValid( v ) || v == LocalPlayer() || 

					( !v:IsNPC() && !v:IsPlayer() && v:GetClass() != 'prop_physics' && v:GetClass() != 'combine_mine'

					&& v.Base != 'base_nextbot' && !string.find( v:GetClass(), 'item' ) ) || v:GetNoDraw() then continue end

					if v:GetClass() == 'prop_physics' && !table.HasValue( explosives, v:GetModel() ) then continue end

					

				table.insert( dv_foundEntities, v )

			end

		end

		

		if nextBubble - CurTime() > 1 then

			bubbleAnim = math.Approach( bubbleAnim, 1, RealFrameTime() * 5 )

			bubbleSize = maxDist * ( 1 - bubbleAnim )

		else

			bubbleAnim = math.Approach( bubbleAnim, 0, RealFrameTime() * 2 )

		end



		if table.Count( dv_foundEntities ) > 0 then

			local rt_Scene = render.GetRenderTarget()

			render.CopyRenderTargetToTexture( source )



			render.Clear( 0, 0, 0, 255, true, true )



			cam.Start3D()

				cam.IgnoreZ( true )

				render.SetStencilEnable( true )

					render.SetStencilWriteMask( 1 )

					render.SetStencilTestMask( 1 )

					render.SetStencilReferenceValue( 1 )



					render.SetStencilFailOperation( STENCIL_KEEP )

					render.SetStencilZFailOperation( STENCIL_KEEP )



					for i, v in pairs( dv_foundEntities ) do

						if !IsValid( v ) then

							dv_foundEntities[i] = nil

							continue

						end

						render.ClearStencil()

						local dist = v:GetPos():Distance( bubblePos )



						local frac = 1 - math.Clamp( ( dist - 300 ) / ( maxDist - bubbleSize ), 0, 1 )

						

						render.SetBlend( math.min( bubbleAnim * frac, 0.99 ) )

						

						render.SetStencilCompareFunction( STENCIL_ALWAYS )

						render.SetStencilPassOperation( STENCIL_REPLACE )



						v:DrawModel()

						

						if ( v:IsNPC() || v:IsPlayer() ) && IsValid( v:GetActiveWeapon() ) then

							v:GetActiveWeapon():DrawModel()

						end



						render.SetStencilCompareFunction( STENCIL_EQUAL )

						render.SetStencilPassOperation( STENCIL_KEEP )

						

						cam.Start2D()

						if string.find( v:GetClass(), 'item' ) then

							surface.SetDrawColor( 50, 190, 50, 150 * dv_anim * bubbleAnim * frac )

						elseif v:IsNPC() || v.Base == 'base_nextbot' || v:IsPlayer() then

							surface.SetDrawColor( 255, 200, 0, 150 * dv_anim * bubbleAnim * frac )

						else

							surface.SetDrawColor( 0, 130, 255, 150 * dv_anim * bubbleAnim * frac )

						end

						surface.DrawRect( 0, 0, ScrW(), ScrH() )

						cam.End2D()

						

						if v:IsNPC() || v:IsPlayer() then

							render.SetStencilCompareFunction( STENCIL_ALWAYS )

							

							local head = v:LookupBone( 'ValveBiped.Bip01_Head1' )

							if head then

								local p, a = v:GetBonePosition( head )

								p = p + Vector( 0, 0, 5 )

								local nrm = a:Right() + Vector( 0, 0, 0.15 )

								

								local view_nrm = ( p - EyePos() ):GetNormalized()

								local view_dot = 1 - math.abs( view_nrm:Dot( nrm ) )

								

								render.StartBeam( 2 )

									render.AddBeam( p - nrm * 1, 0, 0.0, Color( 255, 200, 0, 150 * dv_anim * bubbleAnim * frac * view_dot ) )

									render.AddBeam( p + nrm * 200, 128, 0.5, Color( 255, 200, 0, 0 ) )

								render.EndBeam()

								

								local spr_size_w, spr_size_h = 256, 128

								render.SetMaterial( mat_viewGlow )

								render.DrawSprite( p, spr_size_w, spr_size_h, Color( 255, 200, 0, 150 * dv_anim * bubbleAnim * frac * ( 1 - view_dot ) ) )

							end

						end

					end

				render.SetStencilEnable( false )

				cam.IgnoreZ( false )

			cam.End3D()



			render.SetBlend( 1 )

				

			render.CopyRenderTargetToTexture( blur )

			render.CopyRenderTargetToTexture( pre_blur )

			render.BlurRenderTarget( blur, 3, 0.2, 5 )



			render.SetRenderTarget( rt_Scene )

			mat_copy:SetTexture( '$basetexture', source )

			render.SetMaterial( mat_copy )

			render.DrawScreenQuad()



			mat_preblur:SetTexture( '$basetexture', pre_blur )

			render.SetMaterial( mat_preblur )

			render.DrawScreenQuad()

				

			mat_add:SetTexture( '$basetexture', blur )

			render.SetMaterial( mat_add )

			render.DrawScreenQuad()





			render.SetStencilTestMask( 0 )

			render.SetStencilWriteMask( 0 )

			render.SetStencilReferenceValue( 0 )

		end

		

		if !cl_wda_disable_dynamic_lights:GetBool() then

			local light = DynamicLight( LocalPlayer():EntIndex() )

			if ( light ) then

				light.pos = LocalPlayer():GetShootPos()

				light.r = 100

				light.g = 60

				light.b = 0

				light.brightness = 0.01

				light.Decay = 2000

				light.Size = 500

				light.DieTime = CurTime() + FrameTime() * 2

			end

		end

	end )

	

	-- | CALC VIEW & VIEW MODEL VIEW | --

	

	local traveling = false

	hook.Add( "CalcView", "WDA_CALCVIEW", function( ply, origin, angles, fov, znear, zfar )

		if GetViewEntity() != ply then return end

		

		if ply:GetNWBool( 'WDA_Possessing' ) then

			if possesion_animate == 1 then

				possesion_anim = math.Approach( possesion_anim, 1, RealFrameTime() * 0.35 )

			elseif possesion_animate == 0 then

				possesion_anim = math.Approach( possesion_anim, 0, RealFrameTime() * 0.5 )

			elseif possesion_animate == -1 then

				possesion_anim = math.Approach( possesion_anim, 0.5, RealFrameTime() * 3 )

				if possesion_anim == 0.5 then

					possesion_animate = 0

				end

			end

			

			local heightmul = ply:GetNWFloat( 'WDA_Possession_EyeHeight' )

			local diff = ( origin - ply:GetPos() ).z

			local nfov = fov + 5 * possesion_anim

			local view = {

				origin = ply:GetPos() + Vector( 0, 0, diff * heightmul ),

				angles = angles,

				fov = nfov

			}



			return view

		end

		

		if WDA_BLINK_TRAVELPERC && WDA_BLINK_TRAVELPERC != 1 then

			local nfov = Lerp( WDA_BLINK_TRAVELPERC, 150, fov )

			local pos = LerpVector( WDA_BLINK_TRAVELPERC, WDA_BLINK_TRAVELSTART, WDA_BLINK_TRAVELEND )

			local view = {

				origin = pos + Vector( 0, 0, WDA_BLINK_EYEHEIGHT ),

				angles = angles,

				fov = nfov

			}

			

			WDA_BLINK_TRAVELPERC = math.Approach( WDA_BLINK_TRAVELPERC, 1, RealFrameTime() * 5 )

			traveling = true

			

			return view

		else

			traveling = false

		end

		

		return nil

	end )

	

	hook.Add( "CalcViewModelView", "WDA_CALCVIEWMODELVIEW", function( wep, vm, oldpos, oldang, pos, ang )

		if traveling then

			local npos = EyePos() - ang:Forward() * 500

			

			return npos, ang

		end

		

		return nil

	end )

	

	local function UI_MakeBinder( cmd )

		local p = vgui.Create( 'DBinder' )

		p:SetTall( 50 )

		if __WBS:GetBoundKey( cmd ) then

			p:SetValue( __WBS:GetBoundKey( cmd ) )

		end

		

		function p:OnChange( num )

			__WBS:BindKey( num, cmd )

		end

		

		return p

	end

	

	hook.Add( 'PopulateToolMenu', 'WDA_CreateToolMenu', function()

		spawnmenu.AddToolMenuOption( 'Options',

			'Player',

			'WDAMenu',

			'Dishonored Abilities',

			'',

			'',

			function( pnl )

				pnl:CheckBox( 'Disable Abilities', 'sv_wda_disable' )

				pnl:CheckBox( 'Disable Dynamic Lights', 'cl_wda_disable_dynamic_lights' )

				pnl:ControlHelp( 'Disables dynamic lights from Blink, Far Reach and Dark Vision.' )

				/*

				-- Corvo

local ABILITY_BLINK = 1

local ABILITY_DARKVISION = 2 -- shared

local ABILITY_BENDTIME = 3

local ABILITY_WINDBLAST = 4

local ABILITY_POSSESSION = 5

local ABILITY_SWARM = 6



-- Emily

local ABILITY_FARREACH = 7

local ABILITY_DOMINO = 8

local ABILITY_DOPPELGANGER = 9

local ABILITY_MESMERIZE = 10

local ABILITY_SHADOWWALK = 11

				*/

				

				pnl:Help( [[If you want to restrict certain abilities, open server console, type sv_wda_prohibited followed by the ability indexes, split by /.

Example: sv_wda_prohibited 2/5

This will disable Dark Vision and Possession.

Ability numbers:

Blink - 1

Dark Vision - 2

Bend Time - 3

Wind Blast - 4

Possession - 5

Devouring Swarm - 6

Far Reach - 7

Domino - 8

Doppelganger - 9

Mesmerize - 10

Shadow Walk - 11]] )

				

				pnl:Help( 'Show Menu' )

				pnl:AddItem( UI_MakeBinder( 'dishonored_menu' ) )

				

				pnl:Help( 'Cast Ability' )

				pnl:AddItem( UI_MakeBinder( 'dishonored_cast' ) )

				

				pnl:Help( 'Interrupt Cast' )

				pnl:AddItem( UI_MakeBinder( 'dishonored_interrupt' ) )



				pnl:Help( [[You can also bind this from console:

+dishonored_cast

dishonored_interrupt

+dishonored_menu



If you don't like use of the menu you can bind abilities individualy using +dishonored_cast <ability number> command.

Example: bind b "+dishonored_cast 1"

this will allow you to use B button as blink.]] )



				local btn = vgui.Create( 'DButton' )

				btn:SetText( 'REPORT BUG' )

				btn.DoClick = function()

					gui.OpenURL( 'http://steamcommunity.com/workshop/filedetails/discussion/903151150/135514151378739692' )

				end

				btn:SetTall( 25 )

				pnl:AddItem( btn )

				

				local def = vgui.Create( 'DButton' )

				def:SetText( 'RESTORE DEFAULTS' )

				def.DoClick = function()

					Derma_Query( [[Are you sure you want to restore default settings?

					This action can't be undone!

					

					[Won't affect bindings] ]],

						'Dishonored Abilities: Defaults',

						'Yes, I\'m sure',

						function()

							RunConsoleCommand( "wda_restore_defaults" )

						end,

						'No, abort action' )

				end

				def:SetTall( 25 )

				pnl:AddItem( def )

				pnl:Help( "If nothing happens, go to the server console and run 'wda_restore_defaults' command (without quotes)" )



				pnl:Help( '' )

				pnl:Help( "These sliders will not work on dedicated server." )

				pnl:Help( "Use convars instead. All of them start with sv_wda_ prefix." )

				

				pnl:Help( 'Cast Ranges' )

				pnl:NumSlider( 'Blink', 'sv_wda_blink_range', 1, 16000, 0 )

				pnl:NumSlider( 'Far Reach', 'sv_wda_farreach_range', 1, 16000, 0 )

				pnl:NumSlider( 'Mesmerize', 'sv_wda_mermerize_cast_range', 1, 16000, 0 )

				pnl:NumSlider( 'Wind Blast', 'sv_wda_windblast_cast_range', 1, 800, 0 )

				pnl:NumSlider( 'Doppelganger', 'sv_wda_doppelganger_cast_range', 1, 16000, 0 )

				pnl:NumSlider( 'Doppelganger Swap', 'sv_wda_doppelganger_swap_range', 1, 16000, 0 )

				pnl:NumSlider( 'Domino', 'sv_wda_domino_cast_range', 1, 16000, 0 )

				pnl:NumSlider( 'Devouring Swarm', 'sv_wda_swarm_cast_range', 1, 16000, 0 )

				pnl:NumSlider( 'Possession', 'sv_wda_possession_cast_range', 1, 16000, 0 )

				

				pnl:Help( 'Effect Durations' )

				pnl:NumSlider( 'Possession', 'sv_wda_possession_lifetime', 1, 300, 0 )

				pnl:NumSlider( 'Swarm', 'sv_wda_swarm_lifetime', 1, 300, 0 )

				pnl:NumSlider( 'Mesmerize', 'sv_wda_mermerize_lifetime', 1, 300, 0 )

				pnl:NumSlider( 'Doppelganger', 'sv_wda_doppelganger_lifetime', 1, 300, 0 )

				pnl:NumSlider( 'Shadow Walk', 'sv_wda_shadowwalk_lifetime', 0, 300, 0 )

				pnl:ControlHelp( '0 = infinite/until recast' )

				pnl:NumSlider( 'Dark Vision', 'sv_wda_darkvision_duration', 0, 300, 0 )

				pnl:ControlHelp( '0 = infinite/until recast' )

				pnl:NumSlider( 'Bend Time', 'sv_wda_bendtime_duration', 0, 300, 0 )

				pnl:ControlHelp( '0 = infinite/until recast' )

				pnl:NumSlider( 'Domino', 'sv_wda_domino_max_links', 1, 300, 0 )

				

				pnl:Help( 'Globals' )

				pnl:NumSlider( 'Cast Delay', 'sv_wda_ability_cooldown', 0, 60, 1 )

				pnl:CheckBox( 'Far Reach: Pull Props', 'sv_wda_farreach_pullprops' )

				

				pnl:Help( 'Shadow Walk Ranges' )

				pnl:NumSlider( 'Visibility', 'sv_wda_shadowwalk_vis_range', 1, 16000, 0 )

			end )

	end )

end 