-- Wheatley's Binding System --



local currentVersion = 1.0



if( __WBS && __WBS.Version <= currentVersion ) then

	return

end



print( 'wbs init' )



__WBS = {}

// do not modify this

__WBS.Version 	= currentVersion

__WBS.Bound 	= {}

__WBS.Invalid	= { KEY_ESCAPE,

	KEY_BACKQUOTE }

__WBS.KeyStates = {}



// __WBS:BindKey

// validates all the input data and adds new

// command to bound keys list

function __WBS:BindKey( key, command )

	if( !key || !command || command == "" || table.HasValue( __WBS.Invalid, key ) ) then

		// invalid input data - ignore

		print( "[WBS] Failed to bind a key: invalid input data provided!" )

		return

	end

	

	local prevBound = __WBS:GetBoundKey( command )

	if prevBound then

		__WBS.Bound[ prevBound ] = nil

	end

	

	if( __WBS.Bound[ key ] ) then

		// there is already an action bound to this key - ignore

		print( string.format( "[WBS] Attempt to bind command (%s) to a key (%s) failed: already bound!",

			command, key ) )

		return

	end



	table.RemoveByValue( __WBS.Bound, command )

	__WBS.KeyStates[ key ] = nil

	

	if( key == KEY_NONE ) then

		// binding to NONE equals to removing a bind

		return

	end

	

	__WBS.Bound[ key ] = command

	

	__WBS:SaveConfig()

end



// __WBS:UnbindKey

// removes a command from binding list

function __WBS:UnbindKey( key )

	__WBS.Bound[ key ] = nil

	__WBS.KeyStates[ key ] = nil

	

	__WBS:SaveConfig()

end



// __WBS:HasBoundKey

// checks if command bound to a key

// returns that key if so

function __WBS:GetBoundKey( command )

	return table.KeyFromValue( __WBS.Bound, command ) || false

end



// __WBS:GetBindData

// return a copy of bind table

function __WBS:GetBindData()

	return table.Copy( __WBS.Bound )

end



// __WBS:SaveConfig()

// save bind data to file

function __WBS:SaveConfig()

	local dt = util.TableToJSON( __WBS.Bound )

	

	file.Write( "wbs.txt", dt )

end



// __WBS:RestoreConfig()

// load bind data from file

function __WBS:RestoreConfig()

	if !file.Exists( "wbs.txt", "DATA" ) then return end

	local dt = file.Read( "wbs.txt", "DATA" )

	if dt && dt != "" then

		local tab = util.JSONToTable( dt )

		if istable( tab ) then

			__WBS.Bound = tab

		end

	end

end



// process all the data

hook.Add( "Tick", "__WBS:ProcessBindings", function()

	if vgui.GetKeyboardFocus() || gui.IsGameUIVisible() || gui.IsConsoleVisible() then return end

	

	for key, command in pairs( __WBS.Bound ) do

		if( !__WBS.KeyStates[ key ] && ( input.IsKeyDown( key ) || input.IsMouseDown( key ) ) ) then

			__WBS.KeyStates[ key ] = true

			hook.Run( 'OnBindPressed', command )

		elseif( __WBS.KeyStates[ key ] && !input.IsKeyDown( key ) && !input.IsMouseDown( key ) ) then

			__WBS.KeyStates[ key ] = false

			hook.Run( 'OnBindReleased', command )

		end

	end

end )



// restore config

__WBS:RestoreConfig()