AddCSLuaFile()
local BaseClass = baseclass.Get("zww_npc_base")
ENT.Type                    = "ai"
ENT.Base                    = "zww_npc_base"
ENT.AutomaticFrameAdvance   = true
ENT.Spawnable               = true
ENT.AdminSpawnable          = false
ENT.Category			    = "Zero´s Magic Pets"
ENT.RenderGroup             = RENDERGROUP_BOTH

ENT.PrintName               = "Pet Shop"
ENT.UI_Y                    = 80
ENT.Model                   = "models/spg/workshopman_f.mdl"
ENT.ShouldDrawModel         = true

/*
ENT.CanInteract             = function(ply)
    if ply:Team() == TEAM_MUGGLE then
        zclib.Notify(ply, "I dont deal with muggles!", 1)
        return false
    end
    return true
end
*/

ENT.ShopItems = {}
local function AddItem(data) table.insert(ENT.ShopItems,data) end

AddItem({
    class = "zmp_cage",
    name = "Kafes",
    desc = "Evcil hayvanlarin icin kafes. Satin aldiginda envanterine gelecek!",
    model = "models/konnie/diagonalley/misc/owlcage1.mdl",
    tur = "sc",
    price = 10,
    canbuy = function(ply)
        //if CLIENT then return true end

        // Bring cage to him
        local HisCage
        for k,v in pairs(ents.FindByClass("zmp_cage")) do
            if IsValid(v) and zclib.Player.IsOwner(ply, v) then
                HisCage = v
                break
            end
        end

        if IsValid(HisCage) then
            if SERVER then
                zclib.Notify(ply, "Zaten bir baykus kafesine sahipsin, Kafesini Envanterine geri koy!", 0)
                ply:PickupItem(HisCage)
                return false
            else
                return true , zherb.colors["blue01"] , "Bul"
            end
        else

            // Lets check his inventory too
            local result = true
            for k,v in pairs(zclib.Inventory.GetItems(ply)) do
                if v.Class == "zmp_cage" then
                    result = false
                    break
                end
            end

            if result == false then
                if SERVER then
                    zclib.Notify(ply, "Zaten bir baykus kafesine sahipsin, Su an envanterinde!", 0)
                else
                    return true , zherb.colors["blue01"] , "Bul"
                end
            end
            return result
        end
    end
})

AddItem({
    class = "zherb_pot",
    name = "Saksi",
    desc = "Tohumlarinizi buyutmek icin gerekli olan esya, satin aldiginda envanterine gelecek. ",
    model = "models/zerochain/props_herbology/zherb_pot.mdl",
    tur = "sc",
    price = 10,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"zherb_pot") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"zherb_pot")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"zherb_pot") ~= true
    end
})

AddItem({
    pet = "owl01",
    name = "Kahverengi Baykus",
    desc = "Kahverengi Baykus, Mesaj gondermeni saglar.",
    model =  "models/zerochain/props_harrypotter/cc_owl.mdl",
    Angles = Angle(0,200,0),
    Pos = Vector(10,0,-5),
    FOV = 15,
    skin = 0,
    color = nil,
    price = 6,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"owl01") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"owl01")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"owl01") ~= true
    end
})

AddItem({
    pet = "owl03",
    name = "Alaca Baykus",
    desc = "Alaca Baykus, Mesaj gondermeni saglar.",
    model =  "models/zerochain/props_harrypotter/cc_owl.mdl",
    Angles = Angle(0,200,0),
    Pos = Vector(10,0,-5),
    FOV = 15,
    skin = 1,
    color = nil,
    price = 20,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"owl03") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"owl03")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"owl03") ~= true
    end
})

AddItem({
    pet = "owl04",
    name = "Cuce Baykus",
    desc = "Cuce Baykus, Mesaj gondermeni saglar.",
    model =  "models/zerochain/props_harrypotter/cc_owl.mdl",
    Angles = Angle(0,200,0),
    Pos = Vector(10,0,-5),
    FOV = 15,
    skin = 0,
    color = Color(221,90,123),
    price = 40,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"owl04") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"owl04")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"owl04") ~= true
    end
})

AddItem({
    pet = "owl02",
    name = "Kar Baykusu",
    desc = "Sahibine %5 saldiri ve %5 savunma gucu verir.",
    model =  "models/zerochain/props_harrypotter/cc_owl.mdl",
    Angles = Angle(0,200,0),
    Pos = Vector(10,0,-5),
    FOV = 15,
    skin = 2,
    color = nil,
    price = 60,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"owl02") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"owl02")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"owl02") ~= true
    end
})

AddItem({
    pet = "lol01",
    name = "Siyah Kaplan",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/tiger_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(0,0,-5),
    FOV = 15,
    skin = 4,
    color = nil,
    price = 10000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol01") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol01")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol01") ~= true
    end
})

AddItem({
    pet = "lol02",
    name = "Pembe Kaplan",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/tiger_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(0,0,-5),
    FOV = 15,
    skin = 3,
    color = nil,
    price = 20000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol02") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol02")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol02") ~= true
    end
})

AddItem({
    pet = "lol03",
    name = "Kırmızı Kaplan",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/tiger_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(0,0,-5),
    FOV = 15,
    skin = 2,
    color = nil,
    price = 30000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol03") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol03")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol03") ~= true
    end
})

AddItem({
    pet = "lol04",
    name = "Pembe Griffin",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/griffin_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-10,0,8),
    FOV = 15,
    skin = 4,
    color = nil,
    price = 10000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol04") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol04")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol04") ~= true
    end
})

AddItem({
    pet = "lol05",
    name = "Beyaz Griffin",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/griffin_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-10,0,8),
    FOV = 15,
    skin = 3,
    color = nil,
    price = 20000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol05") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol05")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol05") ~= true
    end
})

AddItem({
    pet = "lol06",
    name = "Rengarenk Griffin",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/griffin_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-10,0,8),
    FOV = 15,
    skin = 2,
    color = nil,
    price = 30000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol06") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol06")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol06") ~= true
    end
})

AddItem({
    pet = "lol07",
    name = "Mor Tilki",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/fox_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-20,0,8),
    FOV = 15,
    skin = 6,
    color = nil,
    price = 10000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol07") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol07")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol07") ~= true
    end
})

AddItem({
    pet = "lol08",
    name = "Kırmızı Tilki",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/fox_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-20,0,8),
    FOV = 15,
    skin = 3,
    color = nil,
    price = 20000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol08") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol08")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol08") ~= true
    end
})

AddItem({
    pet = "lol09",
    name = "Beyaz Tilki",
    desc = "Sadece siteden satin alim yapabilirsiniz. kediyuvasi.com",
    model =  "models/gonzo/fox_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-20,0,8),
    FOV = 15,
    skin = 4,
    color = nil,
    price = 30000,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol09") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol09")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol09") ~= true
    end
})

AddItem({
    pet = "lol10",
    name = "Siyah Canavar",
    desc = "Siyah Canavar",
    model =  "models/gonzo/gargoyle_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-10,0,3),
    FOV = 15,
    skin = 3,
    color = nil,
    price = 200,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol10") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol10")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol10") ~= true
    end
})

AddItem({
    pet = "lol11",
    name = "Mavi Canavar",
    desc = "Mavi Canavar",
    model =  "models/gonzo/gargoyle_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-10,0,3),
    FOV = 15,
    skin = 0,
    color = nil,
    price = 200,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol11") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol11")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol11") ~= true
    end
})

AddItem({
    pet = "lol12",
    name = "Yeşil Canavar",
    desc = "Yeşil Canavar",
    model =  "models/gonzo/gargoyle_pet.mdl",
    Angles = Angle(0,0,0),
    Pos = Vector(-10,0,3),
    FOV = 15,
    skin = 2,
    color = nil,
    price = 200,
    cansell = function(ply)
        return zmp.Pet.Owned(ply,"lol12") , 0.5
    end,
    onsell = function(ply)
        zmp.Pet.Take(ply,"lol12")
    end,
    canbuy = function(ply)
        return zmp.Pet.Owned(ply,"lol12") ~= true
    end
})
