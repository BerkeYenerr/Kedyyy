ENT.Type					= "anim"
ENT.Base					= "base_anim"
ENT.RenderGroup             = RENDERGROUP_BOTH
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  false

ENT.PrintName		        = "Cage"
ENT.Author					= "ClemensProduction aka Zerochain"
ENT.Information				= "info"
ENT.Category			    = "Zero´s Magic Pets"
ENT.Model                   = "models/konnie/diagonalley/misc/owlcage1.mdl"
ENT.AutomaticFrameAdvance   = true
ENT.DisableDuplicator		= false
