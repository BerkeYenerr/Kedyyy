include("shared.lua")

function ENT:Initialize()
	zmp.Cage.Initialize(self)
end

function ENT:Draw()
	self:DrawModel()
	zmp.Cage.Draw(self)
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:Think()
	zmp.Cage.Think(self)
end

function ENT:OnRemove()
	zmp.Cage.Remove(self)
end
