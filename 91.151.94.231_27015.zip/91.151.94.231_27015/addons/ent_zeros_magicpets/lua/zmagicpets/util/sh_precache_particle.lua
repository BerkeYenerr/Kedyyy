
game.AddParticles( "particles/zmp_vfx.pcf")
PrecacheParticleSystem( "zmp_feather" )
