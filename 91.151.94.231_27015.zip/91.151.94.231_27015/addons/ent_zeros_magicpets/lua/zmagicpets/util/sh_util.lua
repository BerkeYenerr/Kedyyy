zmp = zmp or {}

function zmp.Print(msg)
	print("[Zero´s Magic Pets] " .. msg)
end
