/*
zclib.colors["heat01"] = Color(240, 43, 23, 255)
zclib.colors["heat02"] = Color(232, 202, 81, 255)
zclib.colors["fuel"] = Color(153, 53, 53, 255)
zclib.colors["light_color"] = Color(255, 255, 225, 15)
zclib.colors["rot_color"] = Color(155, 179, 141, 255)
*/
