if SERVER then return end
zmp = zmp or {}
zmp.Cage = zmp.Cage or {}

function zmp.Cage.Initialize(Cage) end

function zmp.Cage.Draw(Cage)

end

function zmp.Cage.Think(Cage)
    if zclib.util.InDistance(Cage:GetPos(), LocalPlayer():GetPos(), 1000) then

        if not IsValid(Cage.Owner) or Cage.Owner:IsPlayer() == false then
            local ply = zclib.Player.GetOwner(Cage)
            if not IsValid(ply) then zmp.Cage.Remove(Cage) return end
            Cage.Owner = ply
            return
        end

        if Cage.Owner.zmp_PetLoadout == nil then zmp.Cage.Remove(Cage) return end
        if Cage.Owner.zmp_PetLoadout.id == nil then zmp.Cage.Remove(Cage) return end

        if Cage.Owner.zmp_PetLoadout.equipped == true then
            zmp.Cage.Remove(Cage)
            return
        end

        local PetData = zmp.Pet.GetData(Cage.Owner.zmp_PetLoadout.id)
        if PetData == nil then zmp.Cage.Remove(Cage) return end

        if IsValid(Cage.PetModel) then

            if Cage.PetModel.PetID ~= Cage.Owner.zmp_PetLoadout.id then
                zmp.Cage.Remove(Cage)
                return
            end

            Cage.PetModel:SetPos(Cage:LocalToWorld(Vector(-2,0,2)))
            Cage.PetModel:SetAngles(Cage:LocalToWorldAngles(angle_zero))

            Cage.PetModel.Cycle = (Cage.PetModel.Cycle or 0) + (0.2 * FrameTime())
            Cage.PetModel:SetSequence(Cage.PetModel:LookupSequence(PetData.animations.idle))
            Cage.PetModel:SetCycle(Cage.PetModel.Cycle)
        else
            Cage.PetModel = zclib.ClientModel.AddProp()
            if not IsValid(Cage.PetModel) then return end

            Cage.PetModel:SetModel(PetData.model)
            Cage.PetModel.PetID = Cage.Owner.zmp_PetLoadout.id
            if PetData.skin then Cage.PetModel:SetSkin(PetData.skin) end
            if PetData.color then Cage.PetModel:SetColor(PetData.color) end
        end
    else
        zmp.Cage.Remove(Cage)
    end
end

function zmp.Cage.Remove(Cage)
    if IsValid(Cage.PetModel) then
        zclib.ClientModel.Remove(Cage.PetModel)
        Cage.PetModel = nil
    end
end
