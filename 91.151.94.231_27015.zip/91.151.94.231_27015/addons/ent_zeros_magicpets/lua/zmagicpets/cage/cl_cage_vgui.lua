if SERVER then return end
zmp = zmp or {}
zmp.Cage = zmp.Cage or {}


local CageVGUI = {}

local function OpenInterface()

    if IsValid(zmp_Cage_panel) then
        zmp_Cage_panel:Remove()
    end

    zmp_Cage_panel = vgui.Create("zmp_vgui_Cage")
end

local function AddButton(parent,GetName,OnClick)
    local btn = vgui.Create("DButton", parent)
    btn:SetText("")
    btn:Dock(BOTTOM)
    btn:SetTall(60 * zclib.hM)
    btn:DockMargin(0, 10  * zclib.hM, 0, 0)
    btn.Paint = function(s, w, h)

        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"])
        local name = GetName()
        draw.SimpleText(name, zclib.GetFont("zherb_vgui_font01"), w / 2,  h / 2, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        zclib.util.DrawOutlinedBox(0, 0, w, h, 2, color_white)

        if zmp.Pet.Has(LocalPlayer()) then
            if s:IsHovered() then
                draw.RoundedBox(0, 0, 0,w, h, zclib.colors["white_a100"])
            end
        else
            draw.RoundedBox(0, 0, 0,w, h, zclib.colors["black_a100"])
        end
    end
    btn.DoClick = function(s)
        zclib.vgui.PlaySound("UI/buttonclick.wav")
        pcall(OnClick)
    end
end

net.Receive("zmp_Cage_Open", function(len)

    LocalPlayer().zmp_Cage = net.ReadEntity()

    // Open Main interface
    OpenInterface()
end)

function CageVGUI:Init()
    self:SetSize(600 * zclib.wM, 800 * zclib.hM)
    self:Center()
    self:MakePopup()
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetDraggable(true)
    self:SetSizable(false)

    self:DockMargin(0,0,0,0)
    self:DockPadding(5,5,5,5)

    local TopContainer = vgui.Create("DPanel", self)
    TopContainer:SetAutoDelete(true)
    TopContainer:SetSize(self:GetWide(), 50 * zclib.hM)
    TopContainer.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w - 55 * zclib.wM, h, zherb.colors["yellow01"])
    end
    TopContainer:Dock(TOP)

    local close_btn = zclib.vgui.ImageButton(self:GetWide() - 49 * zclib.wM,0,50 * zclib.wM,50 * zclib.hM,TopContainer,zherb.materials["close"],function()
        self:Close()
    end,function()
        return false
    end)
    close_btn:Dock(RIGHT)
    close_btn.MainColor = zherb.colors["yellow01"]
    close_btn.IconColor = color_white
    close_btn.Paint = function(s, w, h)

		draw.RoundedBox(0, 0, 0, w, h, s.MainColor)

		surface.SetDrawColor(s.IconColor)
		surface.SetMaterial(zherb.materials["close"])
		surface.DrawTexturedRect(0, 0,w, h)

		if s:IsEnabled() == false then
			draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
		else
			if s:IsHovered() then
				draw.RoundedBox(0, 0, 0, w, h, zherb.colors["white02"])
			end
		end
	end

    local TitleBox = vgui.Create("DLabel", TopContainer)
    TitleBox:SetAutoDelete(true)
    TitleBox:SetSize(200 * zclib.wM, 50 * zclib.hM)
    TitleBox:SetPos(0 * zclib.wM, 0 * zclib.hM)
    TitleBox:Dock(LEFT)
    TitleBox:SetText("Kafes")
    TitleBox:SetTextColor(zherb.colors["white01"])
    TitleBox:SetFont(zclib.GetFont("zherb_vgui_font01"))
    TitleBox:SetContentAlignment(5)
    TitleBox:SizeToContentsX( 15 * zclib.wM )

    self:MainMenu()
end

function CageVGUI:MainMenu()
    self:SetSize(600 * zclib.wM, 800 * zclib.hM)
    self:Center()

    if IsValid(self.MainContainer) then self.MainContainer:Remove() end
    local mc = vgui.Create("DPanel", self)
    mc:Dock(FILL)
    mc.Paint = function(s, w, h)
        //draw.RoundedBox(0, 0, 0, w, h, zclib.colors["black_a100"])
    end
    self.MainContainer = mc

    AddButton(mc,function()
        return LocalPlayer().zmp_PetLoadout.equipped == false and "Hayvanini Al" or "Kafese koy"
    end,function()
        if zmp.Pet.Has(LocalPlayer()) == false then return end
        net.Start("zmp_Pet_Equip")
        net.SendToServer()
        self:Close()
    end)

    AddButton(mc,function()
        return "Hayvanina isim ver"
    end,function()
        if zmp.Pet.Has(LocalPlayer()) == false then return end
        self:RenamePet()
    end)

    local MainScroll = vgui.Create( "DScrollPanel", mc )
    MainScroll:Dock(FILL)
    MainScroll:DockMargin(2 * zclib.wM, 5 * zclib.hM, 2  * zclib.wM, 5 * zclib.hM)
    MainScroll.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"])
    end
    local sbar = MainScroll:GetVBar()
    sbar:SetHideButtons( true )
    function sbar:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["black02"]) end
    function sbar.btnUp:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnDown:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end
    function sbar.btnGrip:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, zherb.colors["yellow01"]) end

    local MainContainer = vgui.Create("DIconLayout", MainScroll)
    MainContainer:Dock(FILL)
    MainContainer:SetSpaceX(5)
    MainContainer:SetSpaceY(5)
    MainContainer.Paint = function(s, w, h) end
    MainScroll:InvalidateLayout(true)
    MainContainer:InvalidateParent(true)

    local itemHeight = 100 * zclib.hM
    for k,v in pairs(zmp.config.Pets) do
        if isnumber(k) == false then continue end

        // Does the player own this pet?
        if zmp.Pet.Owned(LocalPlayer(),v.uniqueid) ~= true then continue end

        local item = MainContainer:Add("DPanel")
        item:SetSize(self:GetWide() - 40 * zclib.wM, itemHeight)
        item:SetText("")
        item.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, zherb.colors["grey02"])
        end

        local mdl = zclib.vgui.ModelPanel({model = v.model,skin = v.skin,color = v.color,render = {FOV = 15}})
        mdl:SetSize(itemHeight,itemHeight)
        mdl:SetParent(item)
        mdl.PreDrawModel = function(ent)
            cam.Start2D()
                surface.SetDrawColor(zherb.colors["white01"])
                surface.SetMaterial(zherb.materials["item_bg"])
                surface.DrawTexturedRect(0 * zclib.wM, 0 * zclib.hM, itemHeight, itemHeight)
            cam.End2D()
        end
        mdl.PostDrawModel = function(ent) end
        mdl.Entity:SetAngles(Angle(0,200,0))
        mdl.Entity:SetPos(Vector(10,0,-10))

        local itm_btn = vgui.Create("DButton", item)
        itm_btn:SetText("")
        itm_btn:Dock(FILL)
        itm_btn:DockMargin(0, 0, 0, 0)
        itm_btn.Paint = function(s, w, h)

            draw.SimpleText(v.name, zclib.GetFont("zherb_vgui_font02"), itemHeight + 10 * zclib.wM, 5 * zclib.hM, zherb.colors["white01"], TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            if s:IsHovered() then
                zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["green01"])
            else

                if k == LocalPlayer().zmp_PetLoadout.id then
                    zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["white01"])
                else
                    zclib.util.DrawOutlinedBox(0, 0, w, h, 2, zherb.colors["black01"])
                end
            end
        end
        itm_btn.DoClick = function(s)
            zclib.vgui.PlaySound("UI/buttonclick.wav")

            net.Start("zmp_Pet_Change")
            net.WriteUInt(k,16)
            net.SendToServer()
        end
    end
end

function CageVGUI:RenamePet()

    self:SetSize(600 * zclib.wM, 300 * zclib.hM)
    self:Center()
    if IsValid(self.MainContainer) then self.MainContainer:Remove() end
    local mc = vgui.Create("DPanel", self)
    mc:Dock(FILL)
    mc.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, zclib.colors["black_a100"])
    end
    self.MainContainer = mc

    local NewName
    local txt = zclib.vgui.TextEntry(mc, LocalPlayer().zmp_PetLoadout.name or "Name",function(val)
        NewName = val
    end)
    txt:Dock(TOP)
    txt:DockMargin(10 * zclib.wM, 30  * zclib.hM, 10 * zclib.wM, 10  * zclib.hM)

    AddButton(mc,function()
        return "Cancel"
    end,function()
        self:MainMenu()
    end)

    AddButton(mc,function()
        return "Change"
    end,function()
        if NewName == nil then
            zclib.vgui.Notify("Name invalid!",NOTIFY_ERROR)
            return
        end
        if string.len(NewName) < 2 then
            zclib.vgui.Notify("Name to short!",NOTIFY_ERROR)
            return
        end
        if string.len(NewName) > 20 then
            zclib.vgui.Notify("Name to long!",NOTIFY_ERROR)
            return
        end
        net.Start("zmp_Pet_Rename")
        net.WriteString(NewName)
        net.SendToServer()

        self:MainMenu()
    end)
end

function CageVGUI:Paint(w, h)
    surface.SetDrawColor(zherb.colors["white01"])
    surface.SetMaterial(zherb.materials["background"])
    surface.DrawTexturedRect(0, 0,w * 1.3, h)
end

function CageVGUI:Close()
    LocalPlayer().zmp_Cage = nil
    if IsValid(zmp_Cage_panel) then
        zmp_Cage_panel:Remove()
    end
end

vgui.Register("zmp_vgui_Cage", CageVGUI, "DFrame")
