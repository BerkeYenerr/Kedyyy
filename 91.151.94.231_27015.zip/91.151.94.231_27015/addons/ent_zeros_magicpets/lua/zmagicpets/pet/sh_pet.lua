zmp = zmp or {}
zmp.Pet = zmp.Pet or {}

function zmp.Pet.GetData(id)
    if zmp.config.Pets[id] then return zmp.config.Pets[id] end
    if zmp.config.Pets_ListID[id] and zmp.config.Pets[zmp.config.Pets_ListID[id]] then return zmp.config.Pets[zmp.config.Pets_ListID[id]] end
end


function zmp.Pet.GetLoadout(ply)
    return ply.zmp_PetLoadout
end

function zmp.Pet.Owned(ply,uniqueid)

    if isnumber(uniqueid) then uniqueid = zmp.config.Pets[uniqueid].uniqueid end
    if ply.zmp_PetLoadout.owned == nil then ply.zmp_PetLoadout.owned = {} end
    return ply.zmp_PetLoadout.owned[uniqueid]
end

function zmp.Pet.Has(ply)
    return table.Count(ply.zmp_PetLoadout.owned) > 0
end
