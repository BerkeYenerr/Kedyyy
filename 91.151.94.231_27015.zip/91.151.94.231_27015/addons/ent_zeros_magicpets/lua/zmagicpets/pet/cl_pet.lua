if SERVER then return end
zmp = zmp or {}
zmp.Pet = zmp.Pet or {}

local petUniqueIDs = {"lol01", "lol02", "lol03", "lol04","lol05","lol06","lol07","lol08","lol09","lol10","lol11","lol12"} -- Eklemek istediğiniz diğer uniqueid'ler

local modelScale = {
    ["models/gonzo/tiger_pet.mdl"] = 0.7,
    ["models/gonzo/griffin_pet.mdl"] = 0.8,
    ["models/gonzo/fox_pet.mdl"] = 0.7,
    ["models/gonzo/gargoyle_pet.mdl"] = 0.7,
    -- Eklemek istediğiniz diğer modeller
}

net.Receive("zmp_Pet_Update", function()
    local ply = net.ReadEntity()
    local dataLength = net.ReadUInt(16)
    local dataDecompressed = util.Decompress(net.ReadData(dataLength))
    local data = util.JSONToTable(dataDecompressed)

    if not IsValid(ply) or not ply:IsPlayer() then return end

    if IsValid(ply.zmp_PetModel) then
        ply.zmp_PetModel:StopParticlesNamed("zmp_feather")
        SafeRemoveEntity(ply.zmp_PetModel)
    end

    ply.zmp_PetLoadout = table.Copy(data)
end)

net.Receive("petayarlarilyrical", function() 
    local gidecekoyuncu = net.ReadEntity()
    local mesaj = net.ReadString()
    local gonderen = net.ReadEntity()
    local pet = gonderen.zmp_PetModel
    if not pet then return end
    if not gidecekoyuncu then return end
    pet.gidecekoyuncu = gidecekoyuncu
    pet.mesaj = mesaj
    pet.gonderen = gonderen
end)

function zmp.Pet.DrawUI(Pet)
    if Pet.UIData == nil then
        local name = Pet.zmp_Owner.zmp_PetLoadout.name or "Owner: " .. Pet.zmp_Owner:Nick()
        local size = zclib.util.GetTextSize(name, zclib.GetFont("zherb_font03"))
        size = size + 50

        Pet.UIData = {
            BoxSize = size,
            Name = name
        }
    else
        local pos = Pet:GetBonePosition(1)
        if pos == nil then
            pos = Pet:GetPos()
        end
        cam.Start3D2D(pos + Vector(0, 0, 25), Angle(0, LocalPlayer():EyeAngles().y - 90, 90), 0.05)
            draw.RoundedBox(16, -Pet.UIData.BoxSize / 2, -40, Pet.UIData.BoxSize, 80, zherb.colors["black02"])
            draw.SimpleText(Pet.UIData.Name, zclib.GetFont("zherb_font03"), 0, 0, zherb.colors["white01"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        cam.End3D2D()
    end
end

net.Receive("petayarlarilyricalsil", function() 
    local gidecekoyuncu = net.ReadEntity()
    local gonderen = net.ReadEntity()
    local pet1 = gidecekoyuncu.zmp_PetModel
    local pet2 = gonderen.zmp_PetModel

    for _, uniqueid in ipairs(petUniqueIDs) do
        if IsValid(pet1) and gidecekoyuncu.zmp_PetLoadout.uniqueid == uniqueid then
            local dir = (pet1:GetPos() - pet1.TargetPos):Angle()
            pet1.TargetAng = Angle(0, dir.y, 0)
            pet1.TargetPos = gidecekoyuncu:GetPos() + Vector(0, 50, 0)
            pet1.TargetPos.z = 0  -- Z koordinatını 0 yaparak yere indir
            pet1.gidecekoyuncu = false
            pet1.mesaj = nil
            pet1.gonderen = nil
        end
        if IsValid(pet2) and gonderen.zmp_PetLoadout.uniqueid == uniqueid then
            local dir2 = (pet2:GetPos() - pet2.TargetPos):Angle()
            pet2.TargetAng = Angle(0, dir2.y, 0)
            pet2.TargetPos = gonderen:GetPos() + Vector(0, 50, 0)
            pet2.TargetPos.z = 0  -- Z koordinatını 0 yaparak yere indir
            pet2.gidecekoyuncu = false
            pet2.mesaj = nil
            pet2.gonderen = nil
        end
    end
end)

function zmp.Pet.ReachedTarget(Pet)
    if Pet.TargetPos then 
        if not Pet.gidecekoyuncu then 
            return Pet:GetPos():Distance(Pet.TargetPos) <= 2
        else
            timer.Simple(2, function() 
                if Pet:GetPos():Distance(Pet.TargetPos) <= 2 then
                    if Pet.mesaj then
                        net.Start("yenibaykuslyricalbaba")
                        net.WriteString(Pet.mesaj)
                        net.WriteEntity(Pet.gidecekoyuncu)
                        net.WriteEntity(Pet.gonderen)
                        net.SendToServer()
                    end
                    Pet.gidecekoyuncu = false
                    Pet.mesaj = nil
                    Pet.gonderen = nil
                    timer.Simple(0.5, function()
                        local dir = (Pet:GetPos() - Pet.TargetPos):Angle()
                        Pet.TargetAng = Angle(0, dir.y, 0)
                    end)
                end
            end)
        end
    end
end

function zmp.Pet.AnimationHandler(Pet, ply)
    local PetData = zmp.Pet.GetData(ply.zmp_PetLoadout.id)

    -- Pet yere mi inmeli?
    local isGroundPet = false
    for _, uniqueid in ipairs(petUniqueIDs) do
        if PetData.uniqueid == uniqueid then
            isGroundPet = true
            break
        end
    end

    -- Celebrate animasyonu kontrolü
    if Pet.IsCelebrating then
        Pet:SetSequence(Pet:LookupSequence(PetData.animations.celebrate))
        if isGroundPet then
            Pet.Cycle = (Pet.Cycle or 0) + (0.2 * FrameTime())
        else
            Pet.Cycle = (Pet.Cycle or 0) + (0.5 * FrameTime())
        end
        Pet:SetCycle(Pet.Cycle)
        return
    end

    -- Attack animasyonu kontrolü
    if Pet.FinishAttack and CurTime() < Pet.FinishAttack and IsValid(Pet.Attack_Target) then
        Pet:SetSequence(Pet:LookupSequence(PetData.animations.attack))
        if isGroundPet then
            Pet.Cycle = (Pet.Cycle or 0) + (0.15 * FrameTime())
        else
            Pet.Cycle = (Pet.Cycle or 0) + (0.5 * FrameTime())
        end
        Pet:SetCycle(Pet.Cycle)

        local x = math.sin(CurTime() * 3)
        local y = math.cos(CurTime() * 3)
        local radius = 25
        Pet.TargetPos = Pet.Attack_Target:GetPos() + Vector(x * radius, y * radius, isGroundPet and 0 or 50)
        local dir = (Pet:GetPos() - Pet.Attack_Target:GetPos()):Angle()
        Pet.TargetAng = isGroundPet and Angle(0, dir.y + 180, 0) or Angle(0, dir.y, 0)

        return
    end

    if zmp.Pet.ReachedTarget(Pet) then
        Pet:SetSequence(Pet:LookupSequence(PetData.animations.idle))
        Pet.Cycle = (Pet.Cycle or 0) + (0.05 * FrameTime())

        if Pet.IsIdle == nil then
            -- Trace for data
            local c_trace = zclib.util.TraceLine({
                start = ply:GetPos() + Vector(0, 50, 50),
                endpos = ply:GetPos() + Vector(0, 50, 50) + Vector(0, 0, -100000),
                filter = {ply},
                mask = MASK_PLAYERSOLID_BRUSHONLY,
            }, "zmp_owl_getidlepos")

            if c_trace and c_trace.Hit and c_trace.HitPos and zclib.util.InDistance(ply:GetPos(), c_trace.HitPos, 100) then
                Pet.TargetPos = c_trace.HitPos
            else
                Pet.TargetPos = ply:GetPos() + Vector(0, 50, 0)
            end

            Pet:StopParticlesNamed("zmp_feather")
            Pet.IsIdle = true
            if Pet.donus then Pet.donus = nil end
            if Pet.gidecekoyuncu then 
                Pet.gidecekoyuncu = false
                Pet.TargetPos = ply:GetPos() + Vector(0, 50, isGroundPet and 0 or 50)
            end
        else
            if Pet.donus then Pet.donus = nil end
            Pet.TargetPos = ply:GetPos() + Vector(0, 50, isGroundPet and 0 or 50)
        end

    else
        if Pet.IsIdle then
            Pet.IsIdle = nil
            Pet:StopParticlesNamed("zmp_feather")
            --zclib.Effect.ParticleEffectAttach("zmp_feather", PATTACH_POINT_FOLLOW, Pet, 0)
        end

        Pet:SetSequence(Pet:LookupSequence(PetData.animations.move))
        if isGroundPet then
            Pet.Cycle = (Pet.Cycle or 0) + (0.2 * FrameTime())
        else
            Pet.Cycle = (Pet.Cycle or 0) + (0.5 * FrameTime())
        end

        if Pet.gidecekoyuncu then 
            Pet.TargetPos = Pet.gidecekoyuncu:GetPos() + Vector(0, 50, isGroundPet and 0 or 50)
            local dir = (Pet:GetPos() - gidecekoyuncu:GetPos()):Angle()
            if isGroundPet then
                Pet.TargetAng = Angle(0, dir.y + 180, 0)
            else
                Pet.TargetAng = Angle(0, dir.y, 0)
            end  
        end
        if zclib.util.InDistance(ply:GetPos(), Pet:GetPos(), 100) == false then
            if not Pet.gidecekoyuncu then
                Pet.TargetPos = ply:GetPos() + Vector(0, 50, isGroundPet and 0 or 50)
                local dir = (Pet:GetPos() - ply:GetPos()):Angle()
                if isGroundPet then
                    Pet.TargetAng = Angle(0, dir.y + 180, 0)
                else
                    Pet.TargetAng = Angle(0, dir.y, 0)
                end    
            end
        end
    end
    Pet:SetCycle(Pet.Cycle)
end


function zmp.Pet.Draw(ply)
    if zclib.util.InDistance(LocalPlayer():GetPos(), ply:GetPos(), 1000) == false or ply.zmp_PetLoadout == nil or ply.zmp_PetLoadout.equipped == nil or ply.zmp_PetLoadout.equipped == false then
        return
    end

    if IsValid(ply.zmp_PetModel) then
        local cs = ply.zmp_PetModel

        zmp.Pet.AnimationHandler(cs, ply)

        cs.SmoothPos = LerpVector(FrameTime() * 0.4, cs.SmoothPos or cs:GetPos(), cs.TargetPos or cs:GetPos())
        if table.HasValue(petUniqueIDs, ply.zmp_PetLoadout.uniqueid) then
            cs.SmoothPos.z = 0  -- Z koordinatını 0 yaparak yere indir
        end
        cs.SmoothAng = LerpAngle(FrameTime() * 1, cs.SmoothAng or cs:GetAngles(), cs.TargetAng or cs:GetAngles())

        local vec = zclib.util.ColorToVector(cs.color)
        render.SetColorModulation(vec.x, vec.y, vec.z, 1)
        cs:SetModelScale(modelScale[cs:GetModel()] or 1, 0) -- Modelin ölçeğini ayarla
        render.Model({
            model = cs:GetModel(),
            pos = cs.SmoothPos,
            angle = cs.SmoothAng
        }, cs)
        render.SetColorModulation(1, 1, 1, 1)

        zmp.Pet.DrawUI(cs)
    else
        local PetData = zmp.Pet.GetData(ply.zmp_PetLoadout.id)
        if PetData == nil then return end
        local cs = zclib.ClientModel.AddProp()

        if IsValid(cs) then
            cs:SetModel(PetData.model)
            cs:SetNoDraw(true)
            cs:SetPredictable(false)
            cs:SetMoveType(MOVETYPE_NONE)
            cs:Spawn()
            cs:SetPos(Vector(ply:GetPos().x, ply:GetPos().y, table.HasValue(petUniqueIDs, PetData.uniqueid) and 0 or ply:GetPos().z))  -- Z koordinatını 0 yaparak yere indir
            cs:SetSkin(PetData.skin)
            cs:SetColor(PetData.color)

            cs.OnRemove = function()
                cs:StopParticlesNamed("zmp_feather")
            end

            cs.mdl = PetData.model
            cs.color = PetData.color or color_white

            cs.zmp_OwnerID = zclib.Player.GetID(ply)
            cs.zmp_Owner = ply
            ply.zmp_PetModel = cs
            cs.TargetPos = ply:GetPos() + Vector(0, 50, 0)
            if table.HasValue(petUniqueIDs, PetData.uniqueid) then
                cs.TargetPos.z = 0  -- Z koordinatını 0 yaparak yere indir
            end
        end
    end
end

function zmp.Pet.Celebrate(Pet)
    if not IsValid(Pet) then return end

    local PetData = zmp.Pet.GetData(Pet.zmp_Owner.zmp_PetLoadout.id)
    if not PetData or not PetData.animations or not PetData.animations.celebrate then return end

    -- Celebrate animasyonu oynat
    Pet:SetSequence(Pet:LookupSequence(PetData.animations.celebrate))
    if table.HasValue(petUniqueIDs, PetData.uniqueid) then
        Pet.Cycle = (Pet.Cycle or 0) + (0.23 * FrameTime())
    else
        Pet.Cycle = (Pet.Cycle or 0) + (0.5 * FrameTime())
    end

    Pet.IsCelebrating = true
    timer.Simple(3, function()
        if IsValid(Pet) then
            Pet.IsCelebrating = false
        end
    end)
end




net.Receive("zmp_Pet_Attack", function()
    local attacker = net.ReadEntity()
    local ent = net.ReadEntity()

    zmp.Pet.Attack(attacker.zmp_PetModel, ent)
end)

function zmp.Pet.Attack(Pet, target)
    if not IsValid(Pet) then return end
    if not IsValid(target) then return end

    -- Eğer pet celebrate yapıyorsa attack animasyonu oynatılmasın
    if Pet.IsCelebrating then return end

    Pet.FinishAttack = CurTime() + 3
    Pet.Attack_Target = target
end


zclib.Hook.Add("PostPlayerDraw", "zmp_Pet_PostPlayerDraw", function(ply)
    if ply ~= LocalPlayer() and IsValid(ply) and ply:Alive() then zmp.Pet.Draw(ply) end
end)

zclib.Hook.Add("PostDrawOpaqueRenderables", "zmp_Pet_PostDrawOpaqueRenderables", function(ply)
    if IsValid(LocalPlayer()) and LocalPlayer():Alive() then zmp.Pet.Draw(LocalPlayer()) end
end)

gameevent.Listen("player_disconnect")
zclib.Hook.Add("player_disconnect", "zmp_Pet_player_disconnect", function(data)
    for k, v in pairs(ents.GetAll()) do
        if IsValid(v) and v.zmp_OwnerID and v.zmp_OwnerID == data.networkid then
            v:StopParticlesNamed("zmp_feather")
            SafeRemoveEntity(v)
        end
    end
end)

gameevent.Listen("entity_killed")
zclib.Hook.Add("entity_killed", "zmp_Pet_entity_killed", function(data)
    local victim = Entity(data.entindex_killed)
    local attacker = Entity(data.entindex_attacker)

    -- Ölen kişinin petini kaldırma
    if IsValid(victim) and IsValid(victim.zmp_PetModel) then
        victim.zmp_PetModel:StopParticlesNamed("zmp_feather")
        SafeRemoveEntity(victim.zmp_PetModel)
    end

    -- Saldırganın petinin celebrate animasyonunu oynat
    if IsValid(attacker) and attacker:IsPlayer() and IsValid(attacker.zmp_PetModel) then
        zmp.Pet.Celebrate(attacker.zmp_PetModel)
    end
end)



