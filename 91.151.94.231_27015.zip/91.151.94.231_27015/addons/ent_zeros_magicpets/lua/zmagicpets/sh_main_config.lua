zmp = zmp or {}
zmp.config = zmp.config or {}

zmp.config.Pets = {}
zmp.config.Pets_ListID = {}
local function AddPet(data) zmp.config.Pets_ListID[data.uniqueid] = table.insert(zmp.config.Pets,data) end

AddPet({
    uniqueid = "owl01",
    name = "Kahverengi Baykus",
    model = "models/zerochain/props_harrypotter/cc_owl.mdl",
    skin = 0,
    animations = {
        idle = "idle",
        move = "fly",
        attack = "attack",
    },
    attack_boost = 1.05,
})


AddPet({
    uniqueid = "owl03",
    name = "Alaca Baykus",
    model = "models/zerochain/props_harrypotter/cc_owl.mdl",
    skin = 1,
    animations = {
        idle = "idle",
        move = "fly",
        attack = "attack",
    },

    // This value multiples the players damage he inflicts on other people / entities
    attack_boost = 1.1,
    defence_boost = 0.95,
})

AddPet({
    uniqueid = "owl04",
    name = "Cuce Baykus",
    model = "models/zerochain/props_harrypotter/cc_owl.mdl",
    skin = 2,
    color = Color(221,90,123),
    animations = {
        idle = "idle",
        move = "fly",
        attack = "attack",
    },

    // This value multiples the players move speed
    attack_boost = 1.15,
    defence_boost = 0.82,
})


AddPet({
    uniqueid = "owl02",
    name = "Kar Baykusu",
    model = "models/zerochain/props_harrypotter/cc_owl.mdl",
    skin = 2,
    animations = {
        idle = "idle",
        move = "fly",
        attack = "attack",
    },

    // This value halfs the received damage
    attack_boost = 1.2,
    defence_boost = 1.1,
})

AddPet({
    uniqueid = "lol01",
    name = "Siyah Kaplan",
    model = "models/gonzo/tiger_pet.mdl",
    scale = 0.5,
    skin = 4,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    attack_boost = 1.15,
})

AddPet({
    uniqueid = "lol02",
    name = "Pembe Kaplan",
    model = "models/gonzo/tiger_pet.mdl",
    skin = 3,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    attack_boost = 1.30,
})

AddPet({
    uniqueid = "lol03",
    name = "Kırmızı Kaplan",
    model = "models/gonzo/tiger_pet.mdl",
    skin = 2,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    attack_boost = 1.50,
})

AddPet({
    uniqueid = "lol04",
    name = "Pembe Griffin",
    model = "models/gonzo/griffin_pet.mdl",
    skin = 4,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    defence_boost = 0.85,
})

AddPet({
    uniqueid = "lol05",
    name = "Beyaz Griffin",
    model = "models/gonzo/griffin_pet.mdl",
    skin = 3,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    defence_boost = 0.70,
})

AddPet({
    uniqueid = "lol06",
    name = "Rengarenk Griffin",
    model = "models/gonzo/griffin_pet.mdl",
    skin = 2,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    defence_boost = 0.50,
})

AddPet({
    uniqueid = "lol07",
    name = "Mor Tilki",
    model = "models/gonzo/fox_pet.mdl",
    skin = 6,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    move_boost = 1.15,
})

AddPet({
    uniqueid = "lol08",
    name = "Kırmızı Tilki",
    model = "models/gonzo/fox_pet.mdl",
    skin = 3,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    move_boost = 1.30,
})

AddPet({
    uniqueid = "lol09",
    name = "Beyaz Tilki",
    model = "models/gonzo/fox_pet.mdl",
    skin = 4,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
    move_boost = 1.50,
})

AddPet({
    uniqueid = "lol10",
    name = "Siyah Canavar",
    model = "models/gonzo/gargoyle_pet.mdl",
    skin = 3,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
})

AddPet({
    uniqueid = "lol11",
    name = "Mavi Canavar",
    model = "models/gonzo/gargoyle_pet.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
})

AddPet({
    uniqueid = "lol12",
    name = "Yeşil Canavar",
    model = "models/gonzo/gargoyle_pet.mdl",
    skin = 2,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "idle",
        move = "run",
        attack = "taunt",
        celebrate = "celebrate",
    },
})

/*
AddPet({
    uniqueid = "cat01",
    name = "Cat",
    model = "models/konnie/diagonalley/zoo/cat.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 12
    animations = {
        idle = "Sleep",
        move = "idle",
        attack = "Angry",
    },
})

AddPet({
    uniqueid = "ferret01",
    name = "Ferret",
    model = "models/konnie/diagonalley/zoo/ferret.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 2
    animations = {
        idle = "idle",
        move = "idle2",
        attack = "standing1",
    },
})

AddPet({
    uniqueid = "firecrab01",
    name = "Firecrab",
    model = "models/konnie/diagonalley/zoo/firecrab.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 2
    animations = {
        idle = "idle3",
        move = "idle3",
        attack = "idle3",
    },
})

AddPet({
    uniqueid = "frog01",
    name = "Frog",
    model = "models/konnie/diagonalley/zoo/frog.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 4
    animations = {
        idle = "idle3",
        move = "idle3",
        attack = "idle3",
    },
})

AddPet({
    uniqueid = "pygmypuff01",
    name = "Pygmypuff",
    model = "models/konnie/diagonalley/zoo/pygmypuff.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 4
    animations = {
        idle = "idle3",
        move = "idle3",
        attack = "idle3",
    },
})

AddPet({
    uniqueid = "rat01",
    name = "Rat",
    model = "models/konnie/diagonalley/zoo/rat.mdl",
    skin = 0,
    //skin = 2, Has skins 0 - 2
    animations = {
        idle = "idle3",
        move = "idle3",
        attack = "idle3",
    },
})
*/
