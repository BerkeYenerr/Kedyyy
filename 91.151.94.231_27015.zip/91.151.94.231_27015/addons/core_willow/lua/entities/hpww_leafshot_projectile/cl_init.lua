include("shared.lua")

function ENT:Draw()
	//self:DrawModel()
end
function ENT:DrawTranslucent()
	self:Draw()
end


function ENT:Initialize()
	ParticleEffectAttach( "hp_ww_leafprojectile", PATTACH_POINT_FOLLOW, self, 0 )
end

function ENT:OnRemove()
	ParticleEffect( "hp_ww_leafexplosion", self:GetPos(),self:GetAngles(), nil )
end
