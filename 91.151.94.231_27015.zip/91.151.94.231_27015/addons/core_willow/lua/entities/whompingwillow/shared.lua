ENT.Type							= "anim"
ENT.Base							= "base_anim"

ENT.Spawnable		            	=  true
ENT.AdminSpawnable		            =  false

ENT.PrintName		                = "WhompingWillow"
ENT.Author					        = "ClemensProduction aka Zerochain"
ENT.Information					    = "info"
ENT.Category					    = "Whomping Willow"
ENT.Model                           = "models/minecraft/creeper/poop.mdl"
ENT.AutomaticFrameAdvance           = true
ENT.RenderGroup                     = RENDERGROUP_OPAQUE


function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "CurrentState" );
	self:NetworkVar( "Float", 0, "TreeHealth" );
	self:NetworkVar( "Float", 1, "TreeAnger" );

    if(SERVER)then
        self:SetCurrentState("IDLE")
		local st, er = pcall(function() self:SetTreeHealth(hpww.config.TreeHealth) end)
		self:SetTreeAnger(0)
    end
end
