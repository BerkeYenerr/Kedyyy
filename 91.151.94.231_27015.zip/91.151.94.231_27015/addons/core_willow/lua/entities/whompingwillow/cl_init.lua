include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ENT:ClientAnim(anim, speed)
	local sequence = self:LookupSequence(anim)
	self:SetCycle(0)
	self:ResetSequence(sequence)
	self:SetPlaybackRate(speed)
	self:SetCycle(0)
end

function ENT:Think()
	self:SetNextClientThink(CurTime())

	// Quick fix to make sure the npc is animating once the player gets closer and the npc is in idle
	if self:GetPos():Distance(LocalPlayer():GetPos()) < 1000 then
		local cur_state = self:GetCurrentState()

		if self.LastState ~= cur_state then
			self.LastState = cur_state

			if cur_state == "IDLE" then
				self:ClientAnim("seq01", 1)
			end
		end
	else
		self.LastState = nil
	end

	return true
end
