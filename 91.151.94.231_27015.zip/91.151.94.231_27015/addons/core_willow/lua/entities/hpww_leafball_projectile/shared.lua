ENT.Type					= "anim"
ENT.Base					= "base_anim"
ENT.RenderGroup             = RENDERGROUP_BOTH
ENT.Spawnable		        =  true
ENT.AdminSpawnable		    =  false

ENT.PrintName		        = "LeafBall"
ENT.Author					= "ClemensProduction aka Zerochain"
ENT.Information				= "info"
ENT.Category			    = "Whomping Willow"
ENT.Model                   = nil
ENT.AutomaticFrameAdvance   = true
ENT.DisableDuplicator		= false
