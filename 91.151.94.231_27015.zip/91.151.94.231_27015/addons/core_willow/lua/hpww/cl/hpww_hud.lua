if !CLIENT then return end

local function LerpColor(t, c1, c2)
	local c3 = Color(0,0,0)
	c3.r = Lerp(t, c1.r , c2.r)
	c3.g = Lerp(t, c1.g , c2.g)
	c3.b = Lerp(t, c1.b , c2.b)
	c3.a = Lerp(t, c1.a , c2.a)
	return c3
end

surface.CreateFont( "hpww_treehud_font01", {
	font = "Roboto",
	extended = false,
	size = 30,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

local progress_forground = Material("materials/treehud/progress_forground.png", "smooth")

local sm = ScrH() / 1080

// This handels the hud
hook.Add("PostDrawHUD", "hpww.PostDrawHUD.cl.TreeHud", function()
	local tr = LocalPlayer():GetEyeTrace()
	local trEnt, trHit = tr.Entity, tr.HitPos

	if (IsValid(trEnt) and trEnt:GetClass() == "whompingwillow") then
		local health = trEnt:GetTreeHealth()

		if (trHit:Distance(LocalPlayer():GetPos()) < 2000 and health > 0) then
			local progress = (1 / hpww.config.TreeHealth) * health

			draw.RoundedBox(0, (ScrW() / 2) - (300 * sm), 25 * sm, Lerp(progress, 0, 600 * sm), 45 * sm, LerpColor(progress, Color(30, 180, 30), Color(180, 125, 30)))

			surface.SetDrawColor(Color(255, 255, 255, 255))
			surface.SetMaterial(progress_forground)
			surface.DrawTexturedRect((ScrW() / 2) - (312 * sm), 15 * sm, 624 * sm, 65 * sm)

			draw.SimpleText("SAMARCI SOGUT " .. math.Round(health), "thelmnmlkxlkucukforkillfeedxx", ScrW() / 2, 48 * sm, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end)
