if !SERVER then return end

hook.Add("ShouldCollide", "ShouldCollideTreeHook", function(ent1, ent2)
    if (ent1:GetClass() == "hpww_earthball_projectile") && (ent2:GetClass() == "hpww_earthball_projectile")then
        return false
    elseif (ent1:GetClass() == "hpww_leafball_projectile") && (ent2:GetClass() == "hpww_leafball_projectile")then
        return false
    elseif (ent1:GetClass() == "hpww_earthball_projectile") && (ent2:GetClass() == "hpww_leafball_projectile")then
        return false
    elseif (ent1:GetClass() == "hpww_leafball_projectile") && (ent2:GetClass() == "hpww_earthball_projectile")then
        return false
    end
end)
