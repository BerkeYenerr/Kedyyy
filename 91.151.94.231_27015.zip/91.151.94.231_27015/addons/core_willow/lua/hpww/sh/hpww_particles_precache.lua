AddCSLuaFile()

game.AddParticles( "particles/hp_ww_leafs_vfx.pcf")
PrecacheParticleSystem( "hp_ww_leafstorm" )
PrecacheParticleSystem( "hp_ww_main_vfx" )
PrecacheParticleSystem( "hp_ww_head_vfx" )
PrecacheParticleSystem( "hp_ww_leaffall" )
PrecacheParticleSystem( "hp_ww_heal_vfx" )
PrecacheParticleSystem( "hp_ww_leafprojectile" )
PrecacheParticleSystem( "hp_ww_leafexplosion" )
PrecacheParticleSystem( "hp_ww_loot_vfx" )

game.AddParticles( "particles/hp_ww_player_vfx.pcf")
PrecacheParticleSystem( "hp_ww_playerhit" )



PrecacheParticleSystem( "hp_ww_rock" )
PrecacheParticleSystem( "hp_ww_rock_explosion" )
