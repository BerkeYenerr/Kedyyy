sound.Add( {
	name = "hpww_sfx_playerhit",
	channel = CHAN_STATIC,
	volume = 1,
	level = 70,
	pitch = { 80, 90 },
	sound =
	"physics/body/body_medium_impact_soft1.wav",
	"physics/body/body_medium_impact_soft2.wav",
	"physics/body/body_medium_impact_soft3.wav",
	"physics/body/body_medium_impact_soft4.wav",
	"physics/body/body_medium_impact_soft5.wav",
	"physics/body/body_medium_impact_soft6.wav",
	"physics/body/body_medium_impact_soft7.wav",
} )
sound.Add( {
	name = "hpww_sfx_attack",
	channel = CHAN_STATIC,
	volume = 1,
	level = 90,
	pitch = { 80, 90 },
	sound =
    "hpww_woosh.mp3",
} )
