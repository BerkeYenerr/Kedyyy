hpww = hpww || {}
hpww.config = hpww.config || {}
hpww.f = hpww.f || {}


hpww.config.TreeHealth = 1000
hpww.config.TreeRecoverTime = 10 // seconds

hpww.config.AttackAngerThreshold = 5 // If it has more then this amount of anger then it triggers the attack state
hpww.config.ShortAttack_Range = 460 // A player in distance smaller then this means short range attack
hpww.config.ShortAttack_HurtRange = 500 // if a player is closer to the trees head then this, then he gets damage
hpww.config.ShortAttack_Damage = 25

hpww.config.ProjectileAttack_Range = 2000 // A player in distance smaller then this means projectile attack
hpww.config.ProjectileAttack_RandomShots = 2 // How many random rock projectile shoud we spawn per attack
hpww.config.ProjectileAttack_AimedShots = 5 // How many aimed projectiles do we spawn per player

hpww.config.ProjectileAttack_Leaf_Damage = 6 // How much damage does the LeafShot do
hpww.config.ProjectileAttack_Leaf_Radius = 100 // How big is the Damage radius
hpww.config.ProjectileAttack_Leaf_Distance = 150 // The Distance between the leaf explosions
hpww.config.ProjectileAttack_Leaf_Count = 30 // How many Leaf explosions do we want do make beween tree and player

hpww.config.Recharge = {
    Time = 10, //(seconds) How long is the tree recharging his health?
    Interval = 1, //(seconds) The interval we add new health too the tree
    Health = 40, // The health
}

hpww.config.AngerMultiplicator = 10 // Anger = Damage * hpww.config.AngerMultiplicator

// Here you can add all the classes which are not allowed do inflict damage on the tree
hpww.config.InflictorBlacklist = {"entityflame", "point_hurt"}

// Here you can add all the weapon classes which are not allowed do inflict damage on the tree
hpww.config.WeaponBlacklist = {"weapon_mor_iron_club", "weapon_baseballbat", "magic_dragon", "stunstick", "m9k_damascus", "cc_gryffindorsword", "rphands", "medieval_crossbow"}

// Here we add all the entitys that we want do spawns after death
// TODO NOT USED ANYMORE
hpww.config.DeathLoot = {"anan","entity_autowander","entity_autowander_pre"}

// How many loot do we wanna drop at max
hpww.config.DeathLoot_MaxCount = 40


hpww.config.IngredientLoot = {
--   ZHERB_ING_ALCOHOL,
-- 	ZHERB_ING_FIRESEED,
-- 	ZHERB_ING_ARMADILLOBILE,
-- 	ZHERB_ING_EXPLODINGFLUID,
-- 	ZHERB_ING_SPIDER,
-- 	ZHERB_ING_CHERRY,
-- 	ZHERB_ING_NEWTSPLEEN,
-- 	ZHERB_ING_CHICKEN,
}

// How much anger want we reduce per second if the tree is in attack idle mode
hpww.config.AngerReducer = 10

hpww.config.HeadSit_AngerPenaltiy = 1 // How much anger gets added when a player is on top of the tree per second
