hpww = hpww or {}
hpww.config = hpww.config or {}
hpww.f = hpww.f or {}

if SERVER then
	-- Animation
	util.AddNetworkString("hpww_AnimEvent")

	local function ServerAnim(prop, anim, speed)
		local sequence = prop:LookupSequence(anim)
		prop:SetCycle(0)
		prop:ResetSequence(sequence)
		prop:SetPlaybackRate(speed)
		prop:SetCycle(0)
	end

	function hpww.f.CreateAnimTable(prop, anim, speed)
		ServerAnim(prop, anim, speed)
		net.Start("hpww_AnimEvent")
		local animInfo = {}
		animInfo.anim = anim
		animInfo.speed = speed
		animInfo.parent = prop
		net.WriteTable(animInfo)
		net.SendPVS(prop:GetPos())
	end

	--Effects
	util.AddNetworkString("hpww_FX")

	function hpww.f.CreateEffectTable(effect, sound, parent, angle, position, attach)
		net.Start("hpww_FX")
		local effectInfo = {}
		effectInfo.effect = effect
		effectInfo.pos = position
		effectInfo.ang = angle
		effectInfo.parent = parent
		effectInfo.attach = attach
		effectInfo.sound = sound
		net.WriteTable(effectInfo)
		net.Broadcast()
	end

	util.AddNetworkString("hpww_remove_FX")

	function hpww.f.RemoveEffectNamed(prop, effect, sound)
		net.Start("hpww_remove_FX")
		local effectInfo = {}
		effectInfo.effect = effect
		effectInfo.parent = prop
		effectInfo.sound = sound
		net.WriteTable(effectInfo)
		net.SendPVS(prop:GetPos())
	end
end

if CLIENT then
	-- Animation
	local function ClientAnim(prop, anim, speed)
		local sequence = prop:LookupSequence(anim)
		prop:SetCycle(0)
		prop:ResetSequence(sequence)
		prop:SetPlaybackRate(speed)
		prop:SetCycle(0)
	end

	net.Receive("hpww_AnimEvent", function(len)
		local animInfo = net.ReadTable()

		if (animInfo) then
			if (IsValid(animInfo.parent)) then
				if (animInfo.anim) then
					timer.Simple(0.1, function()
						if (IsValid(animInfo.parent)) then
							ClientAnim(animInfo.parent, animInfo.anim, animInfo.speed)
						end
					end)
				end
			end
		end
	end)

	-- Effects
	net.Receive("hpww_FX", function(len)
		local effectInfo = net.ReadTable()

		if (effectInfo) then
			if (effectInfo.parent == nil) then return end

			if (IsValid(effectInfo.parent)) then
				if (effectInfo.sound) then
					effectInfo.parent:EmitSound(effectInfo.sound)
				end

				if (effectInfo.effect) then
					if (effectInfo.attach) then
						ParticleEffectAttach(effectInfo.effect, PATTACH_POINT_FOLLOW, effectInfo.parent, effectInfo.attach)
					else
						ParticleEffect(effectInfo.effect, effectInfo.pos, effectInfo.ang, effectInfo.parent)
					end
				end
			end
		end
	end)

	net.Receive("hpww_remove_FX", function(len)
		local effectInfo = net.ReadTable()

		if (effectInfo) then
			if (effectInfo.parent == nil) then return end

			if (IsValid(effectInfo.parent)) then
				if (effectInfo.sound) then
					effectInfo.parent:StopSound(effectInfo.sound)
				end

				if (effectInfo.effect) then
					effectInfo.parent:StopParticlesNamed(effectInfo.effect)
				end
			end
		end
	end)
end
