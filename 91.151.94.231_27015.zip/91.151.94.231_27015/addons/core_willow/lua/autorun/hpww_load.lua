local function hpww_LoadAllFiles(fdir)
	local files, dirs = file.Find(fdir .. '*', 'LUA')

	for _, afile in ipairs(files) do
		if string.match(afile, '.lua') then
			if SERVER then
				AddCSLuaFile(fdir .. afile)
			end

			include(fdir .. afile)
		end
	end

	for _, dir in ipairs(dirs) do
		hpww_LoadAllFiles(fdir .. dir .. '/')
	end
end

timer.Simple(1,function()
    hpww_LoadAllFiles('hpww/')
end)