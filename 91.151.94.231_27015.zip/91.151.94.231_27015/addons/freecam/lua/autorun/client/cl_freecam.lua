local freeCam = false
local cameraLocked = false
local camPos = Vector(0, 0, 0)
local camAng = Angle(0, 0, 0)
local camSpeed = 1
local toggleCooldown = 0
local camOrigin = Vector(0, 0, 0)
local maxDistance = 600

net.Receive("freecam_toggle", function()
    freeCam = net.ReadBool()
    if freeCam then
        camOrigin = LocalPlayer():EyePos()
        camPos = camOrigin
        camAng = LocalPlayer():EyeAngles()
    end
end)

hook.Add("Think", "freecam_toggle_keybind", function()
    if toggleCooldown > CurTime() then return end

    if input.IsKeyDown(KEY_F9) then
        toggleCooldown = CurTime() + 0.5
        net.Start("freecam_toggle")
        net.WriteBool(not freeCam)
        net.SendToServer()
    elseif input.IsKeyDown(KEY_F8) and freeCam then
        toggleCooldown = CurTime() + 0.5
        cameraLocked = not cameraLocked
        net.Start("freecam_camera_lock")
        net.WriteBool(cameraLocked)
        net.SendToServer()
    end
end)

hook.Add("InputMouseApply", "freecam_mouse_rotate", function(cmd, x, y, ang)
    if not freeCam or cameraLocked then return end
    camAng:RotateAroundAxis(Vector(0, 0, 1), -x * 0.02)
    camAng:RotateAroundAxis(camAng:Right(), -y * 0.02)
    return true
end)

hook.Add("CalcView", "freecam_view", function(ply, pos, angles, fov)
    if not freeCam then return end
    return {
        origin = camPos,
        angles = camAng,
        fov = fov,
        drawviewer = true
    }
end)

hook.Add("HUDPaint", "freecam_letterbox_bars", function()
    if not freeCam then return end
    local barHeight = ScrH() * 0.05
    surface.SetDrawColor(0, 0, 0, 255)
    surface.DrawRect(0, 0, ScrW(), barHeight)
    surface.DrawRect(0, ScrH() - barHeight, ScrW(), barHeight)
    if cameraLocked then
        draw.SimpleText("Kamera Sabitlendi (F8)", "DermaLarge", ScrW() - 10, ScrH() - 1030, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
    end
end)

hook.Add("CreateMove", "freecam_movement", function(cmd)
    if not freeCam or cameraLocked then return end

    local mv = Vector(0, 0, 0)
    if input.IsKeyDown(KEY_W) then mv = mv + camAng:Forward() end
    if input.IsKeyDown(KEY_S) then mv = mv - camAng:Forward() end
    if input.IsKeyDown(KEY_A) then mv = mv - camAng:Right() end
    if input.IsKeyDown(KEY_D) then mv = mv + camAng:Right() end
    if input.IsKeyDown(KEY_SPACE) then mv = mv + camAng:Up() end
    if input.IsKeyDown(KEY_LCONTROL) then mv = mv - camAng:Up() end

    local newPos = camPos + mv * camSpeed
    if newPos:Distance(camOrigin) <= maxDistance then
        camPos = newPos
    end

    cmd:ClearMovement()
    cmd:ClearButtons()
end)