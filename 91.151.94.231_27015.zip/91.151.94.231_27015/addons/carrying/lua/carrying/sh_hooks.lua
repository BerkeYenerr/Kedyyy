--[[

Author: tochonement
Email: tochonement@gmail.com

24.05.2021

--]]

hook.Add("StartCommand", "carry.BlockMovement", function(ply, cmd)
    if ply:GetNWBool("Carried", false) then
        cmd:ClearMovement()
        cmd:ClearButtons()
    end
end)

hook.Add("PlayerFootstep", "carry.SilentFootstep", function(ply)
    if ply:GetNWBool("Carried") then
        return true
    end
end)

if CLIENT then
    hook.Add("ShouldCollide", "carry.NoCollide", function(ent1, ent2)
        if (ent1:IsPlayer() and ent2:IsPlayer() and ent1:GetNWBool("Carried") and ent2:GetNWBool("Carrying")) then
            return false
        end
    end)
end