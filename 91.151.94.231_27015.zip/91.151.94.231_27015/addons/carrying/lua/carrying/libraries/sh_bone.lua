--[[

Author: tochonement
Email: tochonement@gmail.com

02.05.2021

--]]

if SERVER then
    util.AddNetworkString("revive.bone:Set")
    util.AddNetworkString("revive.bone:Reset")
end

carry.bone = carry.bone or {}
carry.bone.storage = carry.bone.storage or {}

local bone = carry.bone

function bone.register(id, tbl)
    bone.storage[id] = tbl
end

if SERVER then
    function bone.set(ply, id)
        ply:SetNWBool("BoneAnimation", true)

        net.Start("revive.bone:Set")
            net.WriteEntity(ply)
            net.WriteString(id)
        net.Broadcast()
    end

    function bone.reset(ply)
        ply:SetNWBool("BoneAnimation", false)

        net.Start("revive.bone:Reset")
            net.WriteEntity(ply)
        net.Broadcast()
    end
else
    net.Receive("revive.bone:Set", function()
        local target = net.ReadEntity()
        local id = net.ReadString()

        local tbl = bone.storage[id]
        if tbl then
            for key, angle in pairs(tbl) do
                local bone_id = target:LookupBone("ValveBiped." .. key)
                if bone_id then
                    target:ManipulateBoneAngles(bone_id, angle)
                end
            end
        end
    end)

    net.Receive("revive.bone:Reset", function()
        local target = net.ReadEntity()
        local count = target:GetBoneCount()
        for i = 0, count - 1 do
            local mat = target:GetBoneMatrix(i)
            if mat then
                target:ManipulateBoneAngles(i, angle_zero)
            end
        end
    end)
end

hook.Add("CalcMainActivity", "revive.bone.Animation", function(ply, velocity)
    if ply:GetNWBool("BoneAnimation", false) then
        return ACT_HL2MP_IDLE, "aimlayer_ar2"
    end
end)