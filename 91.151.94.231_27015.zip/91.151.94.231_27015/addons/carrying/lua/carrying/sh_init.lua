--[[

Author: tochonement
Email: tochonement@gmail.com

24.05.2021

--]]

-- Original
-- carry.bone.register("taken", {
--     ["Bip01_R_Calf"] = Angle(0, 90, -50),
--     ["Bip01_L_Calf"] = Angle(0, 90, 50),
--     ["Bip01_R_Thigh"] = Angle(0, -90, 30),
--     ["Bip01_L_Thigh"] = Angle(0, -90, -30),
--     ["Bip01_Spine1"] = Angle(0, 20, 0),
--     ["Bip01_R_UpperArm"] = Angle(30, -90, 0),
--     ["Bip01_L_UpperArm"] = Angle(-30, -90, 0),
--     ["Bip01_R_Forearm"] = Angle(-90, 0, 0),
--     ["Bip01_L_Forearm"] = Angle(90, 0, 0),
--     ["Bip01_R_Hand"] = Angle(0, -30, 0),
--     ["Bip01_L_Hand"] = Angle(0, -30, 0)
-- })

-- With tweaks
carry.bone.register("taken", {
    ["Bip01_R_Calf"] = Angle(0, 60, -50),
    ["Bip01_L_Calf"] = Angle(0, 90, 50),
    ["Bip01_R_Thigh"] = Angle(0, -90, 30),
    ["Bip01_L_Thigh"] = Angle(0, -90, -30),
    ["Bip01_Spine1"] = Angle(0, 20, 0),
    ["Bip01_R_UpperArm"] = Angle(30, -90, 0),
    ["Bip01_L_UpperArm"] = Angle(-30, -90, 0),
    ["Bip01_R_Forearm"] = Angle(-90, 0, 0),
    ["Bip01_L_Forearm"] = Angle(90, 0, 0),
    ["Bip01_R_Hand"] = Angle(0, -30, 0),
    ["Bip01_L_Hand"] = Angle(0, -30, 0)
})