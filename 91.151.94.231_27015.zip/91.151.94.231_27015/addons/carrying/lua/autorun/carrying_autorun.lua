--[[

Author: tochonement
Email: tochonement@gmail.com

24.05.2021

--]]

carry = carry or {}
carry.storage = carry.storage or {}

AddCSLuaFile("carrying/libraries/sh_bone.lua")
AddCSLuaFile("carrying/sh_init.lua")
AddCSLuaFile("carrying/sh_hooks.lua")

include("carrying/libraries/sh_bone.lua")
include("carrying/sh_init.lua")
include("carrying/sh_hooks.lua")

if SERVER then
    include("carrying/sv_functions.lua")
    include("carrying/sv_hooks.lua")
end