-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

AddCSLuaFile()

ENT.Base = "inc_base_snpc"

ENT.PrintName = "Gestures NPC (Refund)"
ENT.Author   = "gmodstore.com/users/beelzebub"
ENT.Contact  = "discord.incredible-gmod.ru"
ENT.Category = "Incredible GMod"

ENT.Spawnable 	= true

ENT.Model = "models/player/barney.mdl"
ENT.Sequence = "menu_combine"

if CLIENT then return end

function ENT:Use(ply)
	INC_GESTURES:Refund(ply)
end