-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

ENT.Base = "base_entity"
ENT.AutomaticFrameAdvance = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

ENT.NetID = ENT.Folder

ENT.Spawnable 	= false -- its base :v
ENT.AdminOnly 	= false

ENT.Author   = "gmodstore.com/users/beelzebub"
ENT.Contact  = "discord.incredible-gmod.ru"

function ENT:SetAutomaticFrameAdvance(bool)
	self.AutomaticFrameAdvance = bool
end
