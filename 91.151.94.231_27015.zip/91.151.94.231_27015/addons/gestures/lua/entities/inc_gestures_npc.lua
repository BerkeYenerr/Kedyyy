-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

AddCSLuaFile()

ENT.Base = "inc_base_snpc"

ENT.PrintName = "Gestures NPC"
ENT.Author   = "gmodstore.com/users/beelzebub"
ENT.Contact  = "discord.incredible-gmod.ru"
ENT.Category = "Incredible GMod"

ENT.Spawnable 	= true

ENT.Model = "models/player/barney.mdl"
ENT.Sequence = "menu_combine"

AddCSLuaFile("inc_gestures/src/npc/cl_main.lua")

if CLIENT then
	include("inc_gestures/src/npc/cl_main.lua")
else
	include("inc_gestures/src/npc/sv_main.lua")
end