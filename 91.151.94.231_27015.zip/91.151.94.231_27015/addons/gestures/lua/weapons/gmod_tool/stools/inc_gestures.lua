-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

TOOL.Category = "Incredible GMod"
TOOL.Author   = "gmodstore.com/users/beelzebub"
TOOL.Contact  = "discord.incredible-gmod.ru"

TOOL.Name = "Gestures Vendor NPC"

local include_cl = SERVER and AddCSLuaFile or include

include_cl("inc_gestures/src/tool/cl_main.lua")
include_cl("inc_gestures/src/tool/cl_menu.lua")
if SERVER then include("inc_gestures/src/tool/sv_main.lua") end