return {
	NpcName = "Торговец Жестами", -- npc overhead, also displayed in the menu header
	Press = "Нажмите",  -- npc overhead

	-- vendor npc shop menu
	Purchased = "Куплено",
	Free = "Бесплатно",
	ForThisJobOnly = "Только для этой профессии",

	-- vendor npc tool menu
	SpawnNPC = "Создать NPC",
	ChangeModel = "Изменить модель",
	ChangeAnimation = "Изменить анимацию",
	Remove = "Удалить",

	-- vendor npc tool popup menues
	ModelSelector = "Выбор модели",
	AnimationSelector = "Выбор анимации",
	CopyToClipboard = "Скопировать",

	NpcNameRefund = "Возврат жестов",
	RefundAlready = "Вы уже делали возврат!",
	RefundCant = "Ваш список покупок пуст, вам нечего возвращать.",
	HowManyRefund = "Вы вернули %s"
}