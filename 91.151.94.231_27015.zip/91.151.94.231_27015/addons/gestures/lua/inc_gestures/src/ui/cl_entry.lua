-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

local empty_col = Color(0, 0, 0, 0)
local BackgroundColor = Color(200, 200, 200, 10)
local FocusedBackgroundColor = Color(150, 150, 150, 15)

local PANEL = {}

PANEL.BackgroundColor = BackgroundColor
PANEL.FocusedBackgroundColor = FocusedBackgroundColor

function PANEL:Init()
	self:SetDrawLanguageID(false)
end

function PANEL:Paint(w, h)
	SKIN.tex.TextBox_Disabled(0, 0, w, h, self.BackgroundColor)
	SKIN.tex.TextBox(0, 0, w, h, self.FocusedBackgroundColor)
	SKIN.tex.TextBox(0, 0, w, h, self.BackgroundColor)

	if ( self.GetPlaceholderText && self.GetPlaceholderColor && self:GetPlaceholderText() && self:GetPlaceholderText():Trim() != "" && self:GetPlaceholderColor() && ( !self:GetText() || self:GetText() == "" ) ) then
		local oldText = self:GetText()

		local str = self:GetPlaceholderText()
		if str:StartWith("#") then str = str:sub(2) end
		str = language.GetPhrase(str)

		self:SetText(str)
		self:DrawTextEntryText(self:GetPlaceholderColor(), self:GetHighlightColor(), self:GetCursorColor())
		self:SetText(oldText)

		return
	end

	self:DrawTextEntryText(self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor())
end

function PANEL:RoundedCorners(num)
	self.BackgroundColor = empty_col
	self.FocusedBackgroundColor = empty_col

	local parent = self:GetParent()

	local new_parent = vgui.Create("DPanel", parent)
	new_parent:SetSize(self:GetSize())
	new_parent:Dock(self:GetDock())
	new_parent:SetPos(self:GetPos())
	new_parent.Paint = function(me, w, h)
		draw.RoundedBox(num, 0, 0, w, h, (self:GetDisabled() and BackgroundColor) or (self:HasFocus() and FocusedBackgroundColor) or BackgroundColor)
	end

	self:SetParent(new_parent)
	self:SetPos(num, num)
	self:SetSize(new_parent:GetWide() - num, new_parent:GetTall() - num)
	self:Dock(FILL)
end

vgui.Register("gestures/entry", PANEL, "DTextEntry")