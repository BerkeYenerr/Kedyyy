local PANEL = {}

PANEL.Angles = Angle(0, 60, 0)
PANEL.Pos = Vector(-50, 0, -61)

function PANEL:Init()
	self:SetFOV(50)

	self:SetDirectionalLight(BOX_RIGHT, DIR_LIGHT_LEFT_COL)
	self:SetDirectionalLight(BOX_LEFT, DIR_LIFT_RIGHT_COL)
	self:SetAmbientLight(Vector(-64, -64, -64))
	self:SetAnimated(true)

	self:SetCamPos(vector_origin)
    self.Angles = angle_zero
	self:SetLookAt(Vector( -100, 0, -22 ))

	self:SetEntity(LocalPlayer())
end

function PANEL:PlayGesture(sec_id)
	local dur = self.Entity:SequenceDuration(sec_id)
	
	self.Entity:ResetSequence(sec_id)

	timer.Simple(dur, function()
		if not IsValid(self) then return end

		if IsValid(self.SoundStation) then
			self.SoundStation:SetTime(0)
		end

		self:PlayGesture(sec_id)
	end)
end

function PANEL:SetGesture(name, emit_sound, volume_hover)
	local id, cfg = INC_GESTURES:FindByName(self._ent, name)
	if not cfg then return end

	self.ActiveGesture = name
	self.VolumeHover = tobool(volume_hover)

	local sec_id = self.Entity:LookupSequence(cfg.Sequence)
    if sec_id > 0 then
    	if emit_sound and cfg.SoundPath then
    		self.SoundVolume = cfg.SoundVolume or 1

    		sound.PlayFile(cfg.SoundPath, "mono noplay noblock", function(station)
    			if not IsValid(self) then
    				if IsValid(station) then
    					station:Stop()
    				end

    				return
    			end

				if IsValid(station) then
					station:SetVolume(self.VolumeHover and 0 or self.SoundVolume)
					station:Play()

					self.SoundStation = station
					self:PlayGesture(sec_id)
				else
					self:PlayGesture(sec_id)
				end
			end)
		else
			self:PlayGesture(sec_id)
    	end
    else
    	 self:ResetSequence()
    end

    self.Entity:SetCycle(0)
    self.Entity:SetPlaybackRate(1)
	return self.Entity:SequenceDuration(sec_id)
end

function PANEL:OnRemove()
	if IsValid(self.SoundStation) then
		self.SoundStation:Stop()
	end
end

function PANEL:SetVolume(vol)
	local old = self.SoundStation:GetVolume()
	INC_GESTURES.NewAnimation(vol > 0 and 1.5 or 0.75, 0.5, function(fraction)
		if IsValid(self.SoundStation) then
			self.SoundStation:SetVolume(vol > 0 and vol * fraction or old - old * fraction)
		end
	end)
end

function PANEL:LayoutEntity(Entity)
	if self.bAnimated then
	    self:RunAnimation()

		if self.VolumeHover and IsValid(self.SoundStation) then
			if self._Hover ~= self:GetParent():IsHovered() then
		        self._Hover = self:GetParent():IsHovered()
		        self:SetVolume(self._Hover and self.SoundVolume or 0)
		    end
		end
	end

	Entity:SetAngles(self.Angles)
	Entity:SetPos(self.Pos)
end

function PANEL:SetEntity(ent)
	self._ent = ent

	self:SetModel(ent:GetModel())
	self.Entity:SetSkin(ent:GetSkin())
	for i, body in ipairs(ent:GetBodyGroups()) do
		self.Entity:SetBodyGroups(body.id, ent:GetBodygroup(body.id))
	end

	self.Entity.GetPlayerColor = ent.GetPlayerColor and function() return ent:GetPlayerColor() end or nil

	self.DefaultSequence = self.Entity:GetSequence()
end

function PANEL:ResetSequence()
	if self.DefaultSequence > 0 then
		self.Entity:ResetSequence(self.DefaultSequence)
		return
	end

    local sec_id = self.Entity:LookupSequence("idle_all_01")

    if sec_id <= 0 then sec_id = self.Entity:LookupSequence("walk_all") end
    if sec_id <= 0 then sec_id = self.Entity:LookupSequence("WalkUnarmed_all") end
    if sec_id <= 0 then sec_id = self.Entity:LookupSequence("walk_all_moderate") end

    if sec_id > 0 then
    	self.Entity:ResetSequence(sec_id)
    end
end

vgui.Register("gestures/preview", PANEL, "DModelPanel")