-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

local Clamp, FrameTime_, math_max, _Lerp, gui_MouseY = math.Clamp, FrameTime, math.max, Lerp, gui.MouseY
local draw_RoundedBox, input_IsMouseDown, LeftMoose, derma_SkinHook = draw.RoundedBox, input.IsMouseDown, MOUSE_LEFT, derma.SkinHook

local PANEL = {}

AccessorFunc(PANEL, "m_HideButtons", "HideButtons")

function PANEL:Init()
    self.Offset = 0
    self.Scroll = 0
    self.SmoothScroll = 0
    self.CanvasSize = 1
    self.BarSize = 1

    self.btnGrip = vgui.Create("DScrollBarGrip", self)
    self:SetSize(15, 15)
    self:SetHideButtons(false)
end

function PANEL:SetEnabled(b)
    if not b then
        self.Offset = 0
        self:SetScroll(0)
        self.HasChanged = true
    end

    self:SetMouseInputEnabled(b)
    self:SetVisible(b)

    if self.Enabled ~= b then
        self:GetParent():InvalidateLayout()

        if self:GetParent().OnScrollbarAppear then
            self:GetParent():OnScrollbarAppear()
        end
    end

    self.Enabled = b
end

function PANEL:Value()
    return self.Pos
end

function PANEL:BarScale()
    if self.BarSize == 0 then return 1 end

    return self.BarSize / (self.CanvasSize + self.BarSize)
end

function PANEL:SetUp(_barsize_, _canvassize_)
    self.BarSize = _barsize_
    self.CanvasSize = math_max(_canvassize_ - _barsize_, 1)
    self:SetEnabled(_canvassize_ > _barsize_)
    self:InvalidateLayout()
end

function PANEL:OnMouseWheeled(dlta)
    if not self:IsVisible() then return false end
    if self.Scroll < 0 or self.Scroll > self.CanvasSize then return self.SmoothScroll end
    local OldSmoothScroll = self.SmoothScroll
    local force = 2
    self.SmoothScroll = Clamp(self.SmoothScroll - dlta * force, -self.CanvasSize, self.CanvasSize)

    return OldSmoothScroll ~= self.SmoothScroll
end

function PANEL:Think()
    if self.SmoothScroll == 0 then return end
    local speed = FrameTime_() * 10

    if self.SmoothScroll > 0 then
        self.SmoothScroll = Clamp(self.SmoothScroll - speed, 0, self.CanvasSize)
    else
        self.SmoothScroll = Clamp(self.SmoothScroll + speed, -self.CanvasSize, 0)
    end

    self.Scroll = Clamp(self.Scroll + self.SmoothScroll, 0, self.CanvasSize)

    if self.SmoothScroll > 0 then
        if self.Scroll >= self.CanvasSize then
            self.SmoothScroll = 0
        end
    elseif self.Scroll <= 0 then
        self.SmoothScroll = 0
    end

    self:InvalidateLayout()
    local func = self:GetParent().OnVScroll

    if func then
        func(self:GetParent(), self:GetOffset())
    else
        self:GetParent():InvalidateLayout()
    end
end

function PANEL:AddScroll(dlta)
    local OldScroll = self:GetScroll()
    dlta = dlta * 25
    self:SetScroll(self:GetScroll() + dlta)

    return OldScroll ~= self:GetScroll()
end

function PANEL:SetScroll(scrll)
    if (not self.Enabled) then
        self.Scroll = 0

        return
    end

    self.Scroll = Clamp(scrll, 0, self.CanvasSize)
    self:InvalidateLayout()

    local func = self:GetParent().OnVScroll

    if func then
        func(self:GetParent(), self:GetOffset())
    else
        self:GetParent():InvalidateLayout()
    end
end

function PANEL:AnimateTo(scrll, length, delay, ease)
    local anim = self:NewAnimation(length, delay, ease)
    anim.StartPos = self.Scroll
    anim.TargetPos = scrll

    anim.Think = function(anim, pnl, fraction)
        pnl:SetScroll(_Lerp(fraction, anim.StartPos, anim.TargetPos))
    end
end

function PANEL:GetScroll()
    if (not self.Enabled) then
        self.Scroll = 0
    end

    return self.Scroll
end

function PANEL:GetOffset()
    if (not self.Enabled) then return 0 end

    return self.Scroll * -1
end

function PANEL:Paint(w, h)
    derma_SkinHook("Paint", "VScrollBar", self, w, h)

    return true
end

function PANEL:OnMousePressed()
    local _, y = self:CursorPos()
    local PageSize = self.BarSize
    self.SmoothScroll = 0

    if (y > self.btnGrip.y) then
        self:SetScroll(self:GetScroll() + PageSize)
    else
        self:SetScroll(self:GetScroll() - PageSize)
    end
end

function PANEL:OnMouseReleased()
    self.Dragging = false
    self.DraggingCanvas = nil
    self:MouseCapture(false)
    self.SmoothScroll = 0
    self.btnGrip.Depressed = false
end

function PANEL:OnCursorMoved(x, y)
    if (not self.Enabled) then return end
    if (not self.Dragging) then return end

    local _, y = self:ScreenToLocal(0, gui_MouseY())
    y = y - self.HoldPos

    local TrackSize = self:GetTall() - self.btnGrip:GetTall()
    y = y / TrackSize
    self.SmoothScroll = 0
    self:SetScroll(y * self.CanvasSize)
end

function PANEL:Grip()
    if (not self.Enabled) then return end
    if (self.BarSize == 0) then return end
    self:MouseCapture(true)
    self.Dragging = true
    local _, y = self.btnGrip:ScreenToLocal(0, gui_MouseY())
    self.HoldPos = y
    self.btnGrip.Depressed = true
end

function PANEL:PerformLayout()
    local Wide = self:GetWide()

    local Scroll = self:GetScroll() / self.CanvasSize
    local BarSize = math_max(self:BarScale() * self:GetTall(), 10)
    local Track = self:GetTall() -  BarSize
    Track = Track + 1
    Scroll = Scroll * Track
    self.btnGrip:SetPos(0, Scroll)
    self.btnGrip:SetSize(Wide, BarSize)
end

vgui.Register("gestures/scrollbar", PANEL, "Panel")

local PANEL = {}
AccessorFunc(PANEL, "Padding", "Padding")
AccessorFunc(PANEL, "pnlCanvas", "Canvas")

PANEL.Colors = {
    bg = Color(196, 196, 196),
    box = Color(81, 81, 81),
    hover = Color(50, 50, 50)
}

function PANEL:Init()
    self.pnlCanvas = vgui.Create("Panel", self)

    self.pnlCanvas.OnMousePressed = function(self, code)
        self:GetParent():OnMousePressed(code)
    end

    self.pnlCanvas:SetMouseInputEnabled(true)

    self.pnlCanvas.PerformLayout = function(pnl)
        self:PerformLayout()
        self:InvalidateParent()
    end

    self.VBar = vgui.Create("gestures/scrollbar", self)
    self.VBar:SetWide(29)
    self.VBar:Dock(RIGHT)
    self:SetPadding(0)
    self:SetMouseInputEnabled(true)
    -- This turns off the engine drawing
    self:SetPaintBackgroundEnabled(false)
    self:SetPaintBorderEnabled(false)
    self:SetPaintBackground(false)

    local scr = self:GetVBar()
    scr.Paint = function(_, w, h) end --draw_RoundedBox(4, 0, 0, w, h, self.Colors.bg)

    scr.btnGrip.Paint = function(this, w, h)
        draw_RoundedBox(self.RoundNum or 4, 0, 0, w, h, this:IsHovered() and self.Colors.hover or self.Colors.box)
        self.PaintBackground = true
    end
    scr.btnGrip:SetCursor("hand")
    scr:SetCursor("hand")

    self:SetWide(self:GetWide() * 0.75)
    scr:SetWide(scr:GetWide() * 0.75)
end

function PANEL:AddItem(pnl)
    pnl:SetParent(self:GetCanvas())
end

function PANEL:OnChildAdded(child)
    self:AddItem(child)
end

function PANEL:SizeToContents()
    self:SetSize(self.pnlCanvas:GetSize())
end

function PANEL:GetVBar()
    return self.VBar
end

function PANEL:GetCanvas()
    return self.pnlCanvas
end

function PANEL:InnerWidth()
    return self:GetCanvas():GetWide()
end

function PANEL:Rebuild()
    self:GetCanvas():SizeToChildren(false, true)

    -- Although this behaviour isn't exactly implied, center vertically too
    if (self.m_bNoSizing and self:GetCanvas():GetTall() < self:GetTall()) then
        self:GetCanvas():SetPos(0, (self:GetTall() - self:GetCanvas():GetTall()) * 0.5)
    end
end

function PANEL:OnMouseWheeled(dlta)
    return self.VBar:OnMouseWheeled(dlta)
end

function PANEL:OnVScroll(iOffset)
    self.pnlCanvas:SetPos(0, iOffset)
end

function PANEL:ScrollToChild(panel)
    self:PerformLayout()
    local x, y = self.pnlCanvas:GetChildPosition(panel)
    local w, h = panel:GetSize()
    y = y + h * 0.5
    y = y - self:GetTall() * 0.5
    self.VBar:AnimateTo(y, 0.5, 0, 0.5)
end

function PANEL:PerformLayout()
    local Tall = self.pnlCanvas:GetTall()
    local Wide = self:GetWide()
    local YPos = 0
    self:Rebuild()
    self.VBar:SetUp(self:GetTall(), self.pnlCanvas:GetTall())
    YPos = self.VBar:GetOffset()

    if (self.VBar.Enabled) then
        Wide = Wide - self.VBar:GetWide()
    end

    self.pnlCanvas:SetPos(0, YPos)
    self.pnlCanvas:SetWide(Wide)
    self:Rebuild()

    if (Tall ~= self.pnlCanvas:GetTall()) then
        self.VBar:SetScroll(self.VBar:GetScroll()) -- Make sure we are not too far down!
    end
end

function PANEL:Clear()
    return self.pnlCanvas:Clear()
end

local OldPerformLayout = function(self)
    local Tall = self.pnlCanvas:GetTall()
    local Wide = self:GetWide()
    local YPos = 0
    self:Rebuild()
    self.VBar:SetUp(self:GetTall(), self.pnlCanvas:GetTall())
    YPos = self.VBar:GetOffset()

    if (self.VBar.Enabled) then
        Wide = Wide - self.VBar:GetWide()
    end

    self.pnlCanvas:SetPos(0, YPos)
    self.pnlCanvas:SetWide(Wide)
    self:Rebuild()

    if (Tall ~= self.pnlCanvas:GetTall()) then
        self.VBar:SetScroll(self.VBar:GetScroll()) -- Make sure we are not too far down!
    end
end

local NewPerformLayout = function(self)
    local Tall = self.pnlCanvas:GetTall()
    local Wide = self:GetWide()
    local YPos = 0
    self:Rebuild()
    self.VBar:SetUp(self:GetTall(), self.pnlCanvas:GetTall())
    YPos = self.VBar:GetOffset()

    if self.VBar.Enabled then
        Wide = Wide - self.VBar:GetWide()
    end

    self.pnlCanvas:SetPos(self.VBar:GetWide(), YPos)
    self.pnlCanvas:SetWide(Wide)
    self:Rebuild()

    if Tall ~= self.pnlCanvas:GetTall() then
        self.VBar:SetScroll(self.VBar:GetScroll())
    end
end

local OldOnVScroll = function(self, iOffset)
    self.pnlCanvas:SetPos(0, iOffset)
end

local NewOnVScroll = function(self, iOffset)
    self.pnlCanvas:SetPos(self.VBar:GetWide(), iOffset)
end

function PANEL:SetLeft(b)
    local scr = self:GetVBar()
    scr:Dock(b and LEFT or RIGHT)
    self.PerformLayout = b and NewPerformLayout or OldPerformLayout
    self.OnVScroll = b and NewOnVScroll or OldOnVScroll
end

vgui.Register("gestures/scroll", PANEL, "DPanel")