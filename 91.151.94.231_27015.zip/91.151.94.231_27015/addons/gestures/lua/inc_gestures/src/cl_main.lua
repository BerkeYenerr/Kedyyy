-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

local bits = 8

local function PlayGesture(ply, id)
	local _, _, sections = INC_GESTURES:GetGestures(ply, true)

	local cfg = sections[id + 1]
	if not cfg then return end

	local sec_id = ply:LookupSequence(cfg.Sequence)
	local h_name = "Gestures/CalcSequence/".. ply:EntIndex()
	local start = CurTime()

	local function Start(station)
		local nodraw, active = {}

		local function Stop()
			hook.Remove("Think", h_name)
			hook.Remove("CalcMainActivity", h_name)
			if IsValid(station) then
				local volFade = SysTime() + 0.5
				local vol = station:GetVolume()
				timer.Create(h_name, 0, 0, function()
					if IsValid(station) then
						local progress = (volFade - SysTime()) * 2
						station:SetVolume(progress * vol)
						if progress <= 0 then
							station:Stop()
							timer.Remove(h_name)
						end
					else
						timer.Remove(h_name)
					end
				end)
			end
			for wep, bool in pairs(nodraw) do
				if IsValid(wep) then
					wep:SetNoDraw(bool)
				end
			end
		end

		if cfg.DoNotHideWeapon then
			hook.Add("Think", h_name, function()
				if not IsValid(ply) then return end

				if ply:GetVelocity():Length() >= 25 and CurTime() - start > 1 then
					Stop()
				end
			end)
		else
			hook.Add("Think", h_name, function()
				if not IsValid(ply) then return end

				if ply:GetVelocity():Length() >= 25 and CurTime() - start > 1 then
					return Stop()
				end

				active = ply:GetActiveWeapon()
				if IsValid(active) then
					if nodraw[active] == nil then
						nodraw[active] = active:GetNoDraw()
					end
					active:SetNoDraw(true)
				end
			end)
		end

		if not cfg.Infinitie then
			timer.Simple(ply:SequenceDuration(sec_id) + (cfg.StopDelay or 0), Stop)
		end

		hook.Add("CalcMainActivity", h_name, function(pl)
			if not IsValid(ply) or ply ~= pl then return end
			if not pl:Alive() then return Stop() end

			return ACT_IDLE, sec_id
		end)

		ply:ResetSequence(sec_id)
		ply:SetCycle(0)
		ply:SetPlaybackRate(1)
	end

	if cfg.SoundPath then
		sound.PlayFile(cfg.SoundPath, "3d", function(station)
			if IsValid(station) then
				station:SetPos(ply:GetPos())
				if cfg.SoundVolume then
					station:SetVolume(cfg.SoundVolume)
				end

				Start(station)
			end
		end)
	else
		Start()
	end
end

INC_GESTURES.Play = PlayGesture

net.Receive("INC_GESTURES/Play", function()
	local ply = net.ReadEntity()
	local id = net.ReadUInt(bits)

	if IsValid(ply) then
		PlayGesture(ply, id)
	end
end)

function INC_GESTURES:IsPurchased(ply, gesture)
	return ply:GetNWBool("INC_GESTURES:IsPurchased/".. gesture.uid, false)
end

net.Receive("INC_GESTURES/PrintToClient", function()
	local len = net.ReadUInt(32)
	local str = util.Decompress(net.ReadData(len))
	chat.AddText(str)
end)

local function findPlayer(info)
	if not info or info == "" then return end
	local pls = player.GetHumans()

	for k = 1, #pls do
		local v = pls[k]
		if tonumber(info) == v:UserID() then
			return v
		elseif info == v:SteamID() then
			return v
		elseif info == v:SteamID64() then
			return v
		elseif string.find(string.lower(v:Nick()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	end
end

concommand.Add("inc_gestures_list_clientside", function(ply, _, args)
	if not INC_GESTURES.IsAdmin(ply) then
		return print("You are not an admin!")
	end

	local target = ply
	if args[1] then
		target = findPlayer(args[1])
		if not target then
			return print("Target with the given name was not found!")
		end
	end

	local purchased, not_purchased, free = {}, {}, {}
	for i, sec in ipairs(INC_GESTURES.Sections) do
		if sec._IsFree then
			table.insert(free, (#free + 1) ..". ".. sec.Name)
		else
			local tbl = INC_GESTURES:IsPurchased(target, sec) and purchased or not_purchased
			table.insert(tbl, (#tbl + 1) ..". ".. sec.Name)
		end
	end

	print("My Gestures:")

	local function Print(tbl, name)
		print("  ".. name ..":\n      ".. (#tbl > 0 and table.concat(tbl, "\n      ") or "-"))
	end

	Print(free, "free")
	Print(purchased, "purchased")
	Print(not_purchased, "not purchased")

	if target.getJobTable == nil then return end
	if not target:getJobTable().gestures then return end

	local JobIndex = ply:Team()
	local jobName = team.GetName(JobIndex)

	local purchased, not_purchased, free = {}, {}, {}
	for i, sec in ipairs(target:getJobTable().gestures) do
		if sec._IsFree then
			table.insert(free, (#free + 1) ..". ".. sec.Name)
		else
			sec.uid = jobName .."/".. sec.Name
			local tbl = INC_GESTURES:IsPurchased(target, sec) and purchased or not_purchased
			table.insert(tbl, (#tbl + 1) ..". ".. sec.Name)
		end
	end

	Print(free, "free (job)")
	Print(purchased, "purchased (job)")
	Print(not_purchased, "not purchased (job)")
end)