-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

ENT.IconOverride = "data/inc_gestures/".. util.CRC("https://incredible-gmod.ru/gmodstore/gestures/content/vendor_spawnmenu_icon.png") .."_vendor_spawnmenu_icon.png"

local menu

local white_mat = Material("debug/debugvertexcolor")
local Ang90 = Angle(0, 0, 90)

local DIR_LIGHT_LEFT_COL = Color(255, 160, 80, 255)
local DIR_LIFT_RIGHT_COL = Color(80, 160, 255, 255)

local red = Color(255, 0, 0)

local maxDist = 512 ^ 2

local use_icon = Material("gui/e.png", "smooth mips")

function INC_GESTURES:RenderNpcOverhead(ply, npc, npcname)
	local pos = npc:LookupBone("ValveBiped.Bip01_Head1")
	if pos and pos > -1 then
		pos = npc:GetBonePosition(pos) + npc:GetAngles():Up() * 12
	else
		pos = npc:GetPos() + npc:GetAngles():Up() * (npc:OBBMaxs().z + 3)
	end

	local dist = ply:GetPos():DistToSqr(pos)

	if dist > maxDist then return end
	local alpha = 1 - dist / maxDist

	local ang = ply:EyeAngles()
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ang:Right(), 90)

	Ang90.y = ang.y

	cam.Start3D2D(pos, Ang90, 0.05)
	surface.SetAlphaMultiplier(alpha)
		surface.SetFont("GestureNpcOverhead")
		surface.SetDrawColor(INC_GESTURES.Colors.VendorDark or color_black)

		local press = INC_GESTURES._Lang.Press or "%Lang-Press%"

		local w, h = surface.GetTextSize(npcname)
		w, h = w + 16, h + 4
		surface.DrawRect(-w*0.5, -h, w, h)

		local w, h = surface.GetTextSize(press)
		w, h = w + 16 + h, h + 4
		surface.DrawRect(-w*0.5, 0, w, h)

		draw.SimpleText(npcname, "GestureNpcOverhead", 0, 0, INC_GESTURES.Colors.VendorWhite or red, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		local tW, tH = draw.SimpleText(press, "GestureNpcOverhead", -w*0.5 + 8, 0, INC_GESTURES.Colors.VendorGreen or red, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		surface.SetMaterial(use_icon)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawTexturedRect(-w*0.5 + 8 + tW + 8, 2, tH - 4, tH - 4)
	surface.SetAlphaMultiplier(1)
	cam.End3D2D()
end

hook.Add("PreDrawEffects", "GestureVendors", function()
	local ply = LocalPlayer()

	for i, npc in ipairs(ents.FindByClass("inc_gestures_npc")) do
		INC_GESTURES:RenderNpcOverhead(ply, npc, INC_GESTURES._Lang.NpcName or "%Lang-NpcName%")
	end

	for i, npc in ipairs(ents.FindByClass("inc_gestures_refund_npc")) do
		INC_GESTURES:RenderNpcOverhead(ply, npc, INC_GESTURES._Lang.NpcNameRefund or "%Lang-NpcNameRefund%")
	end
end)

local do_sorting = function() end
local sections_list = {}

hook.Add("INC_GESTURES/Purchases/OnSync", "SortSearch", do_sorting)

local function sort_sections(sections, is_search)
	local out = {[1] = {}, [2] = {}, [3] = {}}
	local localPlayer = LocalPlayer()

	for i, sec in ipairs(sections) do
		local info = sec
		if is_search then
			info = sec.cfg
		end

		if info.Price then
			table.insert(INC_GESTURES:IsPurchased(localPlayer, info) and out[2] or out[1], sec)
		else
			table.insert(out[3], sec)
		end
	end

	local sort = function(a, b)
		if is_search then
			a, b = a.cfg, b.cfg
		end

		if a.Price == b.Price then
			return a.Name < b.Name
		else
			return a.Price < b.Price
		end
	end

	table.sort(out[1], sort)
	table.sort(out[2], sort)
	table.sort(out[3], sort)

	return out
end

function INC_GESTURES.VendorMenu()
	local ply = LocalPlayer()
	local sections, sections_count = INC_GESTURES:GetGestures(ply, true)

	local HeaderTitle = INC_GESTURES.Colors.HeaderTitle or red
	local VendorGreen = INC_GESTURES.Colors.VendorGreen or red
	local VendorRed = INC_GESTURES.Colors.VendorRed or red
	local VendorDark = INC_GESTURES.Colors.VendorDark or red
	local VendorWhite = INC_GESTURES.Colors.VendorWhite or red
	local BackgroundColor = INC_GESTURES.Colors.BackgroundColor or red
	local HeaderColor = INC_GESTURES.Colors.HeaderColor or red
	local HeaderButtonColor = INC_GESTURES.Colors.HeaderButtonColor or red
	local HeaderButtonColor_Hovered = INC_GESTURES.Colors.HeaderButtonColor_Hovered or red
	local ScrollBackgroundColor = INC_GESTURES.Colors.ScrollBackgroundColor or red
	local SearchEntryBackground = INC_GESTURES.Colors.SearchEntryBackground or red
	local SearchEntryPlaceholder = INC_GESTURES.Colors.SearchEntryPlaceholder or red
	local SearchEntryText = INC_GESTURES.Colors.SearchEntryText or red
	local VendorSectionHovered = INC_GESTURES.Colors.VendorSectionHovered or red
	local VendorSectionIcon = INC_GESTURES.Colors.VendorSectionIcon or red
	local SectionWhiteText = INC_GESTURES.Colors.SectionWhiteText or red
	local ScrollGripColor = INC_GESTURES.Colors.ScrollGripColor or red
	local ScrollbarBackground = INC_GESTURES.Colors.ScrollbarBackground or red

	if IsValid(menu) then menu:Remove() end

	menu = vgui.Create("EditablePanel")
	menu:SetSize(INC_GESTURES.NpcMenuWide, INC_GESTURES.NpcMenuTall)
	menu:Center()
	menu:MakePopup()
	menu.Paint = function(me, w, h)
		if input.IsKeyDown(KEY_ESCAPE) then
			return me:Hide()
		end

		INC_GESTURES:Blur(me)
		surface.SetDrawColor(BackgroundColor)
		surface.DrawRect(0, 0, w, h)
	end

	local npcname = INC_GESTURES._Lang.NpcName or "%Lang-Purchased%"

	menu.header = menu:Add("EditablePanel")
	menu.header:Dock(TOP)
	menu.header:SetTall(24)
	menu.header.Paint = function(me, w, h)
		surface.SetDrawColor(HeaderColor)
		surface.DrawRect(0, 0, w, h)

		draw.SimpleText(npcname, "GestureNpcMenuTitle", 8, h * 0.5, HeaderTitle, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	menu.header:DockPadding(0, 6, 6, 6)

	menu.header.AddButton = function(me, paint, cback)
		local btn = me:Add("EditablePanel")
		btn:SetMouseInputEnabled(true)
		btn:SetCursor("hand")
		btn:SetWidth(12)
		btn:Dock(RIGHT)
		btn:DockMargin(12, 0, 0, 0)
		btn.Paint = function(me, w, h)
			surface.SetDrawColor(me:IsHovered() and HeaderButtonColor_Hovered or HeaderButtonColor)
			paint(me, w, h)
		end
		btn.DoClick = cback
		btn.OnMouseReleased = function(me, mcode)
			if mcode == MOUSE_LEFT and me.DoClick then
				me:DoClick()
			end
		end

		return btn
	end

	menu.header.btnClose = menu.header:AddButton(function(me, w, h)
		surface.SetMaterial(white_mat)
		surface.DrawTexturedRectRotated(w*0.5, h*0.5, w, 3, -45)
		surface.DrawTexturedRectRotated(w*0.5, h*0.5, w, 3, 45)
	end, function()
		menu:Hide()
	end)
	menu.header.btnMaxim = menu.header:AddButton(function(me, w, h)
		surface.DrawRect(3, 0, w, 3)
		surface.DrawRect(0, 0, 3, h)

		surface.DrawRect(0, h - 3, w, 3)
		surface.DrawRect(w - 3, 3, 3, h)
	end, function()
		menu._ToggleMax = not menu._ToggleMax

		if menu._ToggleMax then
			menu:SetSize(ScrW(), ScrH())
		else
			menu:SetSize(INC_GESTURES.NpcMenuWide, INC_GESTURES.NpcMenuTall)
		end

		menu.left:SetWide(menu:GetWide() * 0.6)

		menu:Center()
	end)
	menu.header.btnMinim = menu.header:AddButton(function(me, w, h)
		surface.DrawRect(0, h - 3, w, 3)
	end, function()
		menu:Hide()
	end)

	menu.left = menu:Add("DModelPanel")
	menu.left:Dock(LEFT)
	menu.left:SetWide(menu:GetWide() * 0.6)
	menu.left:SetModel(ply:GetModel())
	menu.left.Entity:SetSkin(ply:GetSkin())
	for i, body in ipairs(ply:GetBodyGroups()) do
		menu.left.Entity:SetBodyGroups(body.id, ply:GetBodygroup(body.id))
	end
	menu.left:SetFOV(32)
	menu.left:SetDirectionalLight(BOX_RIGHT, DIR_LIGHT_LEFT_COL)
	menu.left:SetDirectionalLight(BOX_LEFT, DIR_LIFT_RIGHT_COL)
	menu.left:SetAmbientLight(Vector(-64, -64, -64))
	menu.left:SetAnimated(true)
	menu.left.Entity.GetPlayerColor = function() return ply:GetPlayerColor() end
	local default_sequence = menu.left.Entity:GetSequence()
	menu.left.SetGesture = function(me, index)
		local cfg = sections[index + 1]
		local sec_id = me.Entity:LookupSequence(cfg.Sequence)
		if sec_id > 0 then
			me.Entity:ResetSequence(sec_id)
		else
			 me:ResetSequence()
		end

		me.Entity:SetCycle(0)
		me.Entity:SetPlaybackRate(1)

	end
	menu.left.ResetSequence = function(me)
		if default_sequence > 0 then
			me.Entity:ResetSequence(default_sequence)
			return
		end

		local sec_id = me.Entity:LookupSequence("idle_all_01")

		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("idle") end
		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("walk_all") end
		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("WalkUnarmed_all") end
		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("walk_all_moderate") end

		me.Entity:ResetSequence(sec_id)
	end

	menu.left.Angles = Angle(0, 60, 0)
	menu.left.Pos = Vector(-50, 0, -61)

	menu.left:SetCamPos( vector_origin )
	menu.left.Angles = angle_zero
	menu.left:SetLookAt( Vector( -100, 0, -22 ) )

	function menu.left:DragMousePress(button)
		self.PressX, self.PressY = gui.MousePos()
		self.Pressed = button
	end

	function menu.left:OnMouseWheeled(delta)
		self.WheelD = delta * -10
		self.Wheeled = true
	end

	function menu.left:DragMouseRelease()
		self.Pressed = false
	end

	function menu.left:LayoutEntity(Entity)
		if self.bAnimated then
			self:RunAnimation()

			if self.Entity:GetCycle() >= 1 then
				self.Entity:SetCycle(0)
				self:ResetSequence()
			end
		end

		if self.Pressed == MOUSE_LEFT then
			local mx, my = gui.MousePos()
			self.Angles = self.Angles - Angle(0, (self.PressX or mx) - mx, 0)
			self.PressX, self.PressY = gui.MousePos()
		elseif self.Pressed == MOUSE_RIGHT then
			local mx, my = gui.MousePos()
			self.Angles = self.Angles - Angle((self.PressY * (0.5) or my * (0.5)) - my * (0.5), 0, (self.PressX * (-0.5) or mx * (-0.5)) - mx * (-0.5))
			self.PressX, self.PressY = gui.MousePos()
		elseif self.Pressed == MOUSE_MIDDLE then
			local mx, my = gui.MousePos()
			self.Pos = self.Pos - Vector(0, (self.PressX * (0.5) or mx * (0.5)) - mx * (0.5), (self.PressY * (-0.5) or my * (-0.5)) - my * (-0.5))
			self.PressX, self.PressY = gui.MousePos()
		end

		if self.Wheeled then
			self.Wheeled = false
			self.Pos = self.Pos - Vector(self.WheelD, 0, 0)
		end

		Entity:SetAngles(self.Angles)
		Entity:SetPos(self.Pos)
	end

	menu.right = menu:Add("EditablePanel")
	menu.right:Dock(FILL)
	menu.right.Paint = function(me, w, h)
		surface.SetDrawColor(ScrollBackgroundColor)
		surface.DrawRect(0, 0, w, h)
	end

	local search_parent = menu.right:Add("EditablePanel")
	search_parent:SetTall(48)
	search_parent:Dock(TOP)
	search_parent.Paint = function(me, w, h)
		surface.SetDrawColor(BackgroundColor)
		surface.DrawRect(0, 0, w, h)
	end
	search_parent:DockPadding(0, 12, 12, 12)

	local scroll
	sections_list = {}

	local search = search_parent:Add("gestures/entry")
	search:Dock(FILL)
	search:SetTall(24)
	search.BackgroundColor = SearchEntryBackground
	search.FocusedBackgroundColor = search.BackgroundColor
	search:RoundedCorners(6)
	search:SetPlaceholderColor(SearchEntryPlaceholder)
	search:Dock(FILL)
	search:SetPlaceholderText("Search..")
	search:SetFont("GestureNpcMenuSearch")
	search:SetTextColor(SearchEntryText)
	search:SetDrawLanguageID(false)
	search.OnChange = function(me)
		local new = me:GetValue()

		local visible = {}

		for i, sec in ipairs(sections_list) do
			if sec.cfg.Name:lower():find(new:lower(), 1, true) then
				sec:Show()
				table.insert(visible, sec)
			else
				sec:Hide()
			end
		end

		local sort_i = 0
		for i, sorted in ipairs(sort_sections(visible, true)) do
			for i, sec in ipairs(sorted) do
				sort_i = sort_i + 1
				sec:SetZPos(sort_i)
			end
		end

		scroll:InvalidateLayout()
	end

	do_sorting = function()
		if IsValid(search) then search:OnChange() end
	end

	scroll = menu.right:Add("gestures/scroll")
	scroll:Dock(FILL)
	scroll.Colors.box = ScrollGripColor
	scroll.Colors.hover =
	scroll.VBar:SetWide(8)
	scroll.RoundNum = 4
	scroll:GetVBar().Paint = function(me, w, h)
		surface.SetDrawColor(ScrollbarBackground)
		surface.DrawRect(0, 0, w, h)
	end

	local last_hovered
	sections_list = {}
	local sctions_sorted = sort_sections(sections)

	local localPlayer = LocalPlayer()

	for i, sorted in ipairs(sctions_sorted) do
		for i, section in ipairs(sorted) do
			local sec = scroll:Add("EditablePanel")
			sections_list[section.id] = sec
			sec:SetCursor("hand")
			sec.id = section.id
			sec.cfg = section
			sec:Dock(TOP)
			sec:SetTall(44)
			sec.Paint = function(me, w, h)
				if me:IsHovered() and last_hovered ~= me then
					last_hovered = me
					menu.left:SetGesture(me.id - 1)
				end

				if me:IsHovered() or last_hovered == me then
					surface.SetDrawColor(VendorSectionHovered)
					surface.DrawRect(0, 0, w, h)
				end

				if section.Material then
					surface.SetDrawColor(VendorSectionIcon)
					surface.SetMaterial(section.Material)
					surface.DrawTexturedRect(6, 6, 32, 32)
				else
					INC_GESTURES:PrepareJob()
				end

				draw.SimpleText(section.Name, "GestureNpcMenuGestureName", 50, h*0.5, VendorWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)

				local text, col = "", VendorWhite

				if section.Price then
					if INC_GESTURES:IsPurchased(localPlayer, me.cfg) then
						text, col = INC_GESTURES._Lang.Purchased or "%Lang-Purchased%", VendorGreen
					else
						text, col = INC_GESTURES:FormatMoney(section.Price), SectionWhiteText

						if me.CantAfford and me.CantAfford > CurTime() then
							col = VendorRed
						end
					end
				else
					text, col = INC_GESTURES._Lang.Free or "%Lang-Free%", VendorGreen
				end

				if section.IsJobGesture then
					text = text .." (".. (INC_GESTURES._Lang.ForThisJobOnly or "%Lang-ForThisJobOnly%") ..")"
				end
				draw.SimpleText(text, "GestureNpcMenuGesturePrice", 50, h*0.5, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			sec.OnMouseReleased = function(me, mcode)
				if mcode ~= MOUSE_LEFT then return end
				if (me.cfg.Price or 0) < 1 or INC_GESTURES:IsPurchased(localPlayer, me.cfg) then return end

				if not INC_GESTURES:CanAfford(localPlayer, me.cfg.Price) then
					me.CantAfford = CurTime() + 1
					return
				end

				net.Start("INC_GESTURES/Purchases")
					net.WriteUInt(me.id, 8)
				net.SendToServer()

				do_sorting()
			end
		end
	end
end

ENT.OnUse = INC_GESTURES.VendorMenu

hook.Add("OnPlayerChat", "INC_GESTURES.VendorMenu", function(ply, text)
	if INC_GESTURES.EnableChatCommand and ply == LocalPlayer() and text:lower():StartWith(INC_GESTURES.ChatCommand) then
		INC_GESTURES.VendorMenu()
		return true
	end
end)