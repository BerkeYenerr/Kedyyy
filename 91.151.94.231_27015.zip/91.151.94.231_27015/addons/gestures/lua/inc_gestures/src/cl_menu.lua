-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

local find, lower, sub = string.find, string.lower, string.sub

local KEYS = {}

for key, val in pairs(_G) do
	if find(key, "KEY_", 1, true) then
		KEYS[lower(sub(key, 5))] = val
	end
end

local ContextMenuKey = KEY_C

local keybind = KEYS[lower(INC_GESTURES.Key)] and INC_GESTURES.Key or "c"
local cvar = CreateClientConVar("gestures_key", keybind, true, false)

INC_GESTURES._Key = KEYS[lower(cvar:GetString())] or 0
INC_GESTURES.BoundToContextMenu = INC_GESTURES._Key == ContextMenuKey

cvars.AddChangeCallback("gestures_key", function(_, _, key)
	local GM = GM or GAMEMODE or gmod.GetGamemode()

	INC_GESTURES._Key = KEYS[lower(key)] or ContextMenuKey
	if GM then
		INC_GESTURES.BoundToContextMenu = GM.IsSandboxDerived and INC_GESTURES._Key == ContextMenuKey
	else
		INC_GESTURES.BoundToContextMenu = INC_GESTURES.BoundToContextMenu or false
		timer.Create("gestures_key/cvar/w8/GM", 0, 0, function()
			GM = GM or GAMEMODE or gmod.GetGamemode()
			if GM then
				INC_GESTURES.BoundToContextMenu = GM.IsSandboxDerived and INC_GESTURES._Key == ContextMenuKey
				timer.Remove("gestures_key/cvar/w8/GM")
			end
		end)
	end
end, "gmod.store/market/view/gestures")

local function FollowConfig() -- Reset cvar if customer change INC_GESTURES.Key
	local keybind = KEYS[lower(INC_GESTURES.Key)] and INC_GESTURES.Key or "c"
	local path = "inc_gestures/last_config_key.txt"

	if file.Exists(path, "DATA") then
		if file.Read(path, "DATA") ~= keybind then
			file.Write(path, keybind)
			if cvar:GetString() ~= keybind then
				cvar:SetString(keybind)
			end
		end
	else
		file.Write(path, keybind)
	end
end

FollowConfig()
hook.Add("IncGestures/ConfigLoaded", "ResetCvarKeybind", FollowConfig)

INC_GESTURES.Opened = false

local function FadeGestureSound(force)
	local station = INC_GESTURES._PreviewGestureSound
	if not IsValid(station) then return end

	INC_GESTURES._PreviewGestureSoundBool = nil

	if force then
		return station:Stop()
	end

	local volFade = SysTime() + math.min(1, station:GetLength() - station:GetTime())
	local vol = station:GetVolume()
	timer.Create("Gestures/SelectionMenu/FadeGestureSound", 0, 0, function()
		if IsValid(station) then
			local progress = volFade - SysTime()
			station:SetVolume(progress * vol)
			if progress <= 0 then
				station:Stop()
				timer.Remove("Gestures/SelectionMenu/FadeGestureSound")
			end
		else
			timer.Remove("Gestures/SelectionMenu/FadeGestureSound")
		end
	end)
end

local function PlayGestureSound(cfg, cback)
	if not cfg then return end
	if not cfg.SoundPath then
		return cback()
	end

	INC_GESTURES._PreviewGestureSoundBool = true
	sound.PlayFile(cfg.SoundPath, "", function(station)
		if IsValid(station) then
			INC_GESTURES._PreviewGestureSound = station

			if cfg.SoundVolume then
				station:SetVolume(cfg.SoundVolume)
			end

			cback(station)
		else
			INC_GESTURES._PreviewGestureSoundBool = nil
			cback()
		end
	end)
end

INC_GESTURES.Parent = vgui.Create("EditablePanel")
INC_GESTURES.Parent.Close = function(me)
	FadeGestureSound(true)
	me:Hide()
end
INC_GESTURES.Parent:Dock(FILL)
INC_GESTURES.Parent:SetMouseInputEnabled(false)

local sections, sections_count = {}, 0

local lmb_icon = Material("gestures/lmb.png", "smooth mips")

function INC_GESTURES:SelectSegment(index)
	if self.selected ~= index then
		timer.Remove("Gestures/SelectionMenu/OnGestureStop")
		timer.Remove("Gestures/SelectionMenu/W8UntilLastSoundStops")

		if IsValid(self._PreviewGestureSound) or self._PreviewGestureSoundBool then
			timer.Create("Gestures/SelectionMenu/W8UntilLastSoundStops", 0, 1, function()
				if IsValid(self._PreviewGestureSound) then
					self._PreviewGestureSound:Stop()
					self._PreviewGestureSoundBool = nil
				end
				self:SelectSegment(index)
			end)
			return
		end

		PlayGestureSound(sections[index + 1], function()
			if IsValid(self.Model) then
				local dur, inf = self.Model:SetGesture(index)
				timer.Create("Gestures/SelectionMenu/OnGestureStop", dur, 1, function()
					FadeGestureSound()
					if not inf and self.selected == index and IsValid(self.Model) then
						self.Model:ResetSequence()
						self.Model.Entity:SetCycle(0)
						self.Model.Entity:SetPlaybackRate(0)
					end
				end)
			end
		end)
	end

	self.selected = index
end

function INC_GESTURES:CreateMenu()
	self.Menu = vgui.Create("EditablePanel")
	self.Menu:SetAlpha(0)
	self.Menu:Hide()
	self.Menu:SetCursor("hand")
	self.Menu.Think = function(me)
		me:SetMouseInputEnabled(me:GetAlpha() > 0)
	end
	self.Menu.Paint = function(me, w, h)
		if me:GetAlpha() <= 0 then return end
		INC_GESTURES:Blur(me)

		if sections_count < 1 then return end

		render.SetStencilEnable(true)
		render.ClearStencil()
		render.SetStencilTestMask(255)
		render.SetStencilWriteMask(255)
		render.SetStencilReferenceValue(1)
		render.SetStencilCompareFunction(STENCIL_NEVER)
		render.SetStencilFailOperation(STENCIL_REPLACE)
		render.SetStencilZFailOperation(STENCIL_REPLACE)
		render.SetStencilPassOperation(STENCIL_KEEP)

		draw.NoTexture()

		me:CalcHover()

		local sz = INC_GESTURES.Scale
		local sz_05 = sz * 0.5

		local x = me:GetParent():GetWide() * 0.5 - me:GetTall() * sz_05
		local y = me:GetParent():GetTall() * 0.5 - me:GetTall() * sz_05
		self:CutSegments(x, y, sections_count, h * sz, h * sz)

		render.SetStencilCompareFunction(STENCIL_EQUAL)
		render.SetStencilPassOperation(STENCIL_KEEP)
		render.SetStencilFailOperation(STENCIL_KEEP)

		self:DrawSegments(w, h)

		render.SetStencilCompareFunction(STENCIL_EQUAL)
		render.SetStencilPassOperation(STENCIL_REPLACE)
		render.SetStencilFailOperation(STENCIL_KEEP)
		render.SetStencilZFailOperation(STENCIL_KEEP)

		render.SetStencilEnable(false)

		local cfg = sections[self.selected + 1]
		if cfg == nil then return end

		local x, y = w * 0.5, h * 0.5

		draw.SimpleText(cfg.Name, "GestureName", x, y, INC_GESTURES.Colors.GestureName, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	self.Menu.OnMouseReleased = function(me, mcode)
		if mcode ~= MOUSE_LEFT then return end

		self:UseGesture(self.selected)
	end
	self.Menu.CalcHover = function(me)
		local hover = 0

		local mx, my = gui.MousePos()
		mx = me:GetWide() * 0.5 - mx
		my = me:GetTall() * 0.5 - my

		local ang = 180 - math.deg(math.atan2(my, mx))
		hover = math.floor(math.Remap(ang, 0, 360, 0, sections_count))

		if sections[hover + 1] then
			self:SelectSegment(hover)
			return hover
		else
			return false
		end
	end
	self.Menu.Close = function(me)
		me:AlphaTo(0, 0.25)
		self.Opened = false
		FadeGestureSound(true)
	end

	local ply = LocalPlayer()

	self.Menu.OnSizeChanged = function(me, w)
		self.Model:SetWide(w * 0.5)
		self.Model:SetModel(ply:GetModel())
		self.Model.Entity:SetAngles(Angle(0, 20, 0))
	end

	self.Model = self.Menu:Add("DModelPanel")
	self.Model:Dock(RIGHT)
	self.Model:SetModel(ply:GetModel())
	self.Model.Entity:SetSkin(ply:GetSkin())
	for i, body in ipairs(ply:GetBodyGroups()) do
		self.Model.Entity:SetBodyGroups(body.id, ply:GetBodygroup(body.id))
	end
	self.Model:SetFOV(50)
	self.Model.vLookatPos = self.Model.vLookatPos + Vector(18, 0, 4)
	self.Model:SetCursor("arrow")
	self.Model:SetMouseInputEnabled(false)
	self.Model.LayoutEntity = function(me)
		me:RunAnimation()
		if me.Entity:GetCycle() >= 1 and not me.Infinitie then
			me:ResetSequence()
			me.Entity:SetCycle(0)
			me.Entity:SetPlaybackRate(0)
		end
	end
	self.Model.Entity.GetPlayerColor = function() return ply:GetPlayerColor() end
	local default_sequence = self.Model.Entity:GetSequence()
	self.Model.SetGesture = function(me, index)
		local cfg = sections[index + 1]
		local sec_id = me.Entity:LookupSequence(cfg.Sequence)
		me.Infinitie = cfg.Infinitie
		if sec_id > 0 then
			me.Entity:ResetSequence(sec_id)
		else
			 me:ResetSequence()
		end

		me.Entity:SetCycle(0)
		me.Entity:SetPlaybackRate(1)
		return me.Entity:SequenceDuration(sec_id), cfg.Infinitie
	end
	self.Model.ResetSequence = function(me)
		if default_sequence > 0 then
			me.Entity:ResetSequence(default_sequence)
			return
		end

		local sec_id = me.Entity:LookupSequence("idle_all_01")

		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("walk_all") end
		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("WalkUnarmed_all") end
		if sec_id <= 0 then sec_id = me.Entity:LookupSequence("walk_all_moderate") end

		if sec_id > 0 then
			me.Entity:ResetSequence(sec_id)
		end
	end

	local old = self.Model.Paint
	self.Model.Paint = function(me, w, h)
		if self.Menu:GetAlpha() <= 0 then return end

		old(me, w, h)
	end
end

local red = Color(255, 0, 0)

function INC_GESTURES:DrawSegments(w, h)
	local spacer = sections_count > 1 and 3 or 0
	local rad_85 = self.Radius*0.85
	local w05, h05 = w * 0.5, h * 0.5

	local rad_73 = self.Radius*0.73

	for i = 0, sections_count - 1 do
		local cfg = sections[i + 1]
		if cfg == nil then continue end
		if cfg.Material == nil then INC_GESTURES:PrepareJob() if cfg.Material == nil then continue end end

		local hovered = self.Menu:GetParent():IsMouseInputEnabled() and i == self.selected or false

		local size = hovered and INC_GESTURES.IconSizeHovered or INC_GESTURES.IconSize
		local size_05 = size * 0.5

		local size2 = size * 0.25
		local size2_05 = size2 * 0.5

		render.SetStencilReferenceValue(i + 1)
		surface.SetDrawColor(35, 36, 35,150)
		surface.DrawRect(0, 0, w, h)

		local start = i * 360 / sections_count + spacer * 0.5
		local _end = start + 360 / sections_count - spacer * 0.5

		local mrad = math.rad(_end - (_end - start) * 0.5)
		local x, y = math.cos(mrad) * rad_85, -math.sin(mrad) * rad_85

		local x2, y2 = math.cos(mrad) * rad_73 + w05 - size2_05, -math.sin(mrad) * rad_73 + h05 - size2_05

		if cfg.SoundPath and INC_GESTURES.SoundMaterial then
			surface.SetDrawColor(INC_GESTURES.Colors.SoundIcon)
			surface.SetMaterial(INC_GESTURES.SoundMaterial)
			surface.DrawTexturedRect(x2, y2, size2, size2)
		end

		surface.SetDrawColor(hovered and INC_GESTURES.Colors.IconHovered or INC_GESTURES.Colors.Icon)
		surface.SetMaterial(cfg.Material)
		surface.DrawTexturedRect(x + w05 - size_05, y + h05 - size_05, size, size)
	end
end

function INC_GESTURES:CutSegments(x, y, sections_count, w, h)
	sections_count = math.max(sections_count, 1)

	local sections_360 = 360 / sections_count
	x, y = x + w * 0.5, y + h * 0.5
	local roughness = sections_count > 15 and 1 or 2

	for i = 0, sections_count - 1 do
		local spacer = sections_count > 1 and 3 or 0
		local start = i * sections_360 + spacer * 0.5

		render.SetStencilReferenceValue(i + 1)
		self.ArcLib.Draw(x, y, self.Radius, self.Thickness, start, start + sections_360 - spacer * 0.5, roughness, color_white)
	end
end

local enable = true

local function EnableInputs(b)
	enable = tobool(b)
end

hook.Add("CreateMove", "Gestures-EnableInputs", function(cmd)
	if enable then return end

	cmd:ClearButtons()
	cmd:ClearMovement()
	cmd:SetMouseX(0)
	cmd:SetMouseY(0)
end)

local bits = 8
local cooldown = 0

local function NewAnimation(length, ease, cback, onend, delay)
	ease = ease or -1
	delay = delay or 0

	local systime = SysTime()
	local starttime, endtime = systime + delay, systime + delay + length
	local h_name = "incredible-gmod.ru/NewAnimation/".. delay .."/".. debug.traceback()
	local fraction, frac

	hook.Add("Think", h_name, function()
		systime = SysTime()
		if starttime > systime then return end

		fraction = math.Clamp(math.TimeFraction(starttime, endtime, systime), 0, 1)

		if ease < 0 then
			frac = fraction ^ (1 - fraction - 0.5)
		elseif ease > 0 and ease < 1 then
			frac = 1 - (1 - fraction) ^ (1 / ease)
		end

		cback(frac)

		if fraction == 1 then
			if onend then onend() end
			hook.Remove("Think", h_name)
		end
	end)

	return function()
		hook.Remove("Think", h_name)
	end
end

INC_GESTURES.NewAnimation = NewAnimation

local function PlayGesture(ply, id, external)
	local cfg = sections[id]
	local sec_id = ply:LookupSequence(cfg.Sequence)

	local dur = ply:SequenceDuration(sec_id)
	cooldown = CurTime() + dur

	local h_name = "Gestures/CalcSequence/@me"
	local start = CurTime()

	EnableInputs(false)
	timer.Simple(1, function()
		EnableInputs(true)
	end)

	local function Start(station)
		local is_playing_music = IsValid(station)
		local fft_dollyzoom = 0
		local vol = cfg.SoundVolume or 1

		if cfg.DisableSoundEffect then
			is_playing_music = false
		end

		local CamDistance, ZoomInCamDistance = 0, 0

		local ZoomOutTime = 0.35
		local ZoomInTime = 0.2

		NewAnimation(ZoomOutTime, 0.5, function(fraction)
			CamDistance = 80 * fraction
			ZoomInCamDistance = CamDistance
		end)

		local calcview_hooks = {}

		for name, cback in pairs(hook.GetTable().CalcView or {}) do
			if name ~= h_name then
				calcview_hooks[name] = cback
				hook.Remove("CalcView", name)
			end
		end

		local nodraw, active = {}
		local function Stop()
			cooldown = CurTime() + 0.35
			hook.Remove("Think", h_name)
			hook.Remove("CalcMainActivity", h_name)
			hook.Remove("InputMouseApply", h_name)
			hook.Remove("PrePlayerDraw", h_name)
			hook.Remove("CreateMove", h_name)

			for name, cback in pairs(calcview_hooks) do
				hook.Add("CalcView", name, cback)
			end

			ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), Vector(1, 1, 1))

			if IsValid(station) then
				local volFade = SysTime() + 0.5
				local vol = station:GetVolume()
				timer.Create(h_name, 0, 0, function()
					if IsValid(station) then
						local progress = (volFade - SysTime()) * 2
						station:SetVolume(progress * vol)
						if progress <= 0 then
							station:Stop()
							timer.Remove(h_name)
						end
					else
						timer.Remove(h_name)
					end
				end)
			end
			for wep, bool in pairs(nodraw) do
				if IsValid(wep) then
					wep:SetNoDraw(bool)
				end
			end

			if external then return end

			if IsValid(INC_GESTURES.Menu) and INC_GESTURES.Menu:GetAlpha() == 0 then
				INC_GESTURES.Menu:AlphaTo(255, 0.25)
			end
		end

		hook.Add("CreateMove", h_name, function(cmd)
			cmd:RemoveKey(IN_ATTACK)
			cmd:RemoveKey(IN_ATTACK2)
			cmd:RemoveKey(IN_RELOAD)
		end)

		hook.Add("Think", h_name, function()
			if ply:GetVelocity():Length() >= 25 and CurTime() - start > 1 then
				NewAnimation(ZoomInTime, 0.5, function(fraction)
					CamDistance = ZoomInCamDistance - ZoomInCamDistance * fraction
				end, function()
					hook.Remove("CalcView", h_name)
				end)
				Stop()
				return
			end

			if not cfg.DoNotHideWeapon then
				active = ply:GetActiveWeapon()
				if IsValid(active) then
					if nodraw[active] == nil then
						nodraw[active] = active:GetNoDraw()
					end
					active:SetNoDraw(true)
				end
			end

			if is_playing_music then
				local fft = {}
				station:FFT(fft, FFT_512)
				if not fft[1] then return end

				local temp_fov = 0
				for i = 1, 256 do
					temp_fov = temp_fov + fft[i]
				end

				fft_dollyzoom = Lerp(FrameTime() * 10, fft_dollyzoom, temp_fov * vol * 10)
			end
		end)

		if not cfg.Infinitie then
			if cfg.FirstPerson then
				timer.Simple(dur + (cfg.StopDelay or 0), function()
					hook.Remove("CalcView", h_name)
					Stop()
				end)
			else
				NewAnimation(ZoomInTime, 0.5, function(fraction)
					CamDistance = ZoomInCamDistance - ZoomInCamDistance * fraction
				end, function()
					hook.Remove("CalcView", h_name)
					Stop()
				end, dur - ZoomInTime + (cfg.StopDelay or 0))
			end
		end

		hook.Add("CalcMainActivity", h_name, function(pl, vel)
			if ply ~= pl then return end
			if not ply:Alive() then
				hook.Remove("CalcView", h_name)
				Stop()
				return
			end

			return ACT_IDLE, sec_id
		end)

		local camBone = ply:LookupBone("ValveBiped.Bip01_Head1") -- todo: add the bone camera API, its looks so cool https://cdn.discordapp.com/attachments/716760709681381487/888910342158159882/funny.mp4

		if istable(cfg.camBoundToBone) then
			for i, cbone in ipairs(cfg.camBoundToBone) do
				if (cbone.delay or 0) == 0 then
					local bone = ply:LookupBone(cbone.bone)
					if bone then
						camBone = bone
					end
				else
					timer.Simple(cbone.delay, function()
						local bone = ply:LookupBone(cbone.bone)
						if bone then
							camBone = bone
						end
					end)
				end
			end
		elseif isstring(cfg.camBoundToBone) then
			local bone = ply:LookupBone(cfg.camBoundToBone)
			if bone then
				camBone = bone
			end
		end

		if cfg.FirstPerson then
			local MinVec, Vec1 = Vector(0.001, 0.001, 0.001), Vector(1, 1, 1)
			local CamAngles, AngleZero = Angle(0, 0, 0), Angle(0, 0, 0)

			hook.Add("CalcView", h_name, function(ply, _, angles, fov)
				if ply:GetViewEntity() ~= ply then return end

				return {
					drawviewer = true,
					origin = ply:GetAttachment(ply:LookupAttachment("eyes")).Pos,
					angles = angles + CamAngles,
					fov = fov,
					znear = 0.1
				}
			end)

			hook.Add("InputMouseApply", h_name, function(cmd, y, x, ang)
				CamAngles.x = math.Clamp(CamAngles.x + x * FrameTime(), -70, 50)
				CamAngles.y = math.Clamp(CamAngles.y - y * FrameTime(), -90, 90)

				cmd:SetMouseX(0)
				cmd:SetMouseY(0)

				return true
			end)

			ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), MinVec)

			hook.Add("PrePlayerDraw", h_name, function(pl)
				if pl ~= ply or ply:Alive() == false then return end
				ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), ply:GetViewEntity() ~= ply and Vec1 or MinVec)

				local angles = ply:GetRenderAngles()
				angles.y = ply:EyeAngles().y
				ply:SetRenderAngles(angles)
				ply:SetPoseParameter("aim_yaw", 0.5)
				ply:SetPoseParameter("body_yaw", 0.5)
				ply:SetPoseParameter("head_yaw", 0.5)
			end)
		else
			ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), Vector(1, 1, 1))

			local ang = ply:EyeAngles()
			ang.y = ang.y - 180

			hook.Add("InputMouseApply", h_name, function(cmd, x, y)
				ang.x = math.Clamp(ang.x + y * 0.05, -70, 100)
				ang.y = ang.y - x * 0.05

				cmd:SetMouseX(0)
				cmd:SetMouseY(0)
				return true
			end)

			hook.Add("CalcView", h_name, function(ply, pos, angles, fov)
				if ply:GetViewEntity() ~= ply then return end

				local traceData = {}
				traceData.start = ply:GetBonePosition(camBone)
				traceData.endpos = traceData.start + ang:Forward() * -CamDistance - (ang:Forward() * fft_dollyzoom * 2)
				traceData.filter = ply

				local trace = util.TraceLine(traceData)

				pos = trace.HitPos

				if trace.Fraction < 1.0 then
					pos = pos + trace.HitNormal * 5
				end

				local view = {
					origin = pos,
					angles = ang,
					fov = fov - fft_dollyzoom,
					drawviewer = true
				}

				return view
			end)
		end

		ply:ResetSequence(sec_id)
		ply:SetCycle(0)
		ply:SetPlaybackRate(1)
	end

	if cfg.SoundPath then
		sound.PlayFile(cfg.SoundPath, "mono", function(station)
			if IsValid(station) then
				if cfg.SoundVolume then
					station:SetVolume(cfg.SoundVolume)
				end

				Start(station)
			end
		end)
	else
		Start()
	end
end

function INC_GESTURES:UseGesture(index, external, by_name)
	if external and cooldown > CurTime() then return cooldown end

	local ply = LocalPlayer()
	if ply:Alive() == false or ply:GetObserverMode() ~= 0 then return end

	if by_name then
		index = self:FindByName(ply, index)
		if index then index = index - 1 end
	end

	if index == nil then return end
	local section = sections[index + 1]

	if section == nil then return end
	if section.CustomCheck and section.CustomCheck(ply) == false then return end

	FadeGestureSound(true)

	net.Start("INC_GESTURES/Play")
		net.WriteUInt(section.id - 1, bits)
	net.SendToServer()

	PlayGesture(ply, index + 1, external)

	if external then return cooldown end

	local parent = self.Menu:GetParent()
	if INC_GESTURES.BoundToContextMenu then
		parent:Close()
		hook.Run("ContextMenuClosed")
		self.Menu:SetAlpha(0)
		self.Menu:SetMouseInputEnabled(false)
	else
		parent:AlphaTo(0, 0.25, 0, function()
			parent:SetAlpha(255)
			parent:Close()
			self.Menu:SetAlpha(0)
			self.Menu:SetMouseInputEnabled(false)
		end)
	end
end

function INC_GESTURES:UpdateMenuGestures()
	sections, sections_count = INC_GESTURES:GetGestures(LocalPlayer())
	return sections, sections_count
end

concommand.Add("inc_gestures_use", function(_, _, _, argsStr)
	INC_GESTURES:UseGesture(argsStr, true, true)
end)

hook.Add("Think", "Gestures", function()
	if cooldown > CurTime() then return end

	local ply = LocalPlayer()
	if input.IsKeyDown(INC_GESTURES._Key) and ply:Alive() and ply:WaterLevel() < 2 and ply:GetObserverMode() == 0 and not (gui.IsGameUIVisible() or ply:InVehicle() or IsValid(vgui.GetKeyboardFocus())) then
		if INC_GESTURES.Opened then return end

		INC_GESTURES:UpdateMenuGestures()

		if not IsValid(INC_GESTURES.Menu) then
			INC_GESTURES:CreateMenu()
		end

		if not INC_GESTURES.BoundToContextMenu then
			INC_GESTURES.Parent:Show()
			INC_GESTURES.Parent:MakePopup()
			INC_GESTURES.Parent:SetKeyBoardInputEnabled(false)
		end

		local parent = INC_GESTURES.BoundToContextMenu and g_ContextMenu or INC_GESTURES.Parent

		INC_GESTURES.Menu:SetParent(parent)
		INC_GESTURES.Menu:SetSize(ScrW(), ScrH())
		INC_GESTURES.Menu:SetMouseInputEnabled(true)

		if INC_GESTURES.BoundToContextMenu then
			INC_GESTURES.Menu:SetZPos(-1)
		end

		INC_GESTURES.Menu:Show()
		INC_GESTURES.Menu:AlphaTo(255, 0.25)
		INC_GESTURES.Opened = true

		if not INC_GESTURES.BoundToContextMenu then
			RestoreCursorPosition()
		end

		INC_GESTURES.Menu:OnSizeChanged(INC_GESTURES.Menu:GetWide())
	elseif INC_GESTURES.Opened then
		if not INC_GESTURES.BoundToContextMenu then
			RememberCursorPosition()
			INC_GESTURES.Parent:SetMouseInputEnabled(false)
		end

		INC_GESTURES.Menu:Close()
		FadeGestureSound(true)
	end

	INC_GESTURES.Parent:SetMouseInputEnabled(INC_GESTURES.Opened)
end)