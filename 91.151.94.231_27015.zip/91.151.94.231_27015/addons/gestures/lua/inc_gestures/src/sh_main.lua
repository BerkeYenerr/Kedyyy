-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

local PLAYER = FindMetaTable("Player")

function INC_GESTURES:GetGestures(ply, is_vendor)
	local sections, sections_count, id, by_ids = {}, 0, 0, {}
	is_vendor = is_vendor or false

	for i, sec in ipairs(self.Sections) do
		id = id + 1

		sec.IsJobGesture = false

		if sec.Price and not is_vendor then
			if not INC_GESTURES:IsPurchased(ply, sec) then continue end
		end

		if sec.CustomCheck == nil then
			sections_count = sections_count + 1
			sections[sections_count] = sec
		elseif sec.CustomCheck(ply) ~= false then
			sections_count = sections_count + 1
			sections[sections_count] = sec
		end

		by_ids[sec.id] = sec
	end

	if ply.getJobTable == nil then return sections, sections_count, by_ids end

	local JobIndex = ply:Team()
	local jobName = team.GetName(JobIndex)

	for i, sec in ipairs(ply:getJobTable().gestures or {}) do
		id = id + 1

		sec.id = id
		sec.IsJobGesture = true
		sec.JobIndex = JobIndex
		sec.uid = jobName .."/".. sec.Name

		if sec.Price and not is_vendor then
			if not INC_GESTURES:IsPurchased(ply, sec) then continue end
		end

		sections_count = sections_count + 1
		sections[sections_count] = sec

		by_ids[sec.id] = sec
	end

	return sections, sections_count, by_ids
end

function INC_GESTURES:FindByName(ply, name)
    local id = 0

    for i, sec in ipairs(self.Sections) do
        id = id + 1

        if sec.Name == name then
            return sec.id, sec
        end
    end

    if not IsValid(ply) then return end

    if ply.getJobTable and id == nil then
        for i, sec in ipairs(ply:getJobTable().gestures or {}) do
            id = id + 1

            if sec.Name == name then
                return id, sec
            end
        end
    end
end