-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

local SET_SEQUENCE = 0
local SET_MODEL = 1

local function DrawScrollingText(text, y, texwide)
    local w, h = surface.GetTextSize(text)
    w = w + 64
    y = y - h * 0.5
    local x = RealTime() * 250 % w * -1

    while x < texwide do
        surface.SetTextColor(0, 0, 0, 255)
        surface.SetTextPos(x + 3, y + 3)
        surface.DrawText(text)

        surface.SetTextColor(225, 0, 0, 175 + 50 * math.sin(CurTime() * 5))
        surface.SetTextPos(x, y)
        surface.DrawText(text)
        x = x + w
    end
end

local is_admin = false
function TOOL:DrawToolScreen(w, h)    
	is_admin = INC_GESTURES.IsAdmin(LocalPlayer())

    render.Clear(0, 0, 0, 0)

    if INC_GESTURES.ToolBackground then
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(INC_GESTURES.ToolBackground)
        surface.DrawTexturedRect(0, 0, w, h)
    else
        surface.SetDrawColor(50, 50, 50)
        surface.DrawRect(0, 0, w, h)
    end

	if not is_admin then
		surface.SetFont("GModToolScreen")
		local _, textH = surface.GetTextSize("Tool available only for admins!")
		textH = textH + 16

		surface.SetDrawColor(0, 0, 0, 125)
		surface.DrawRect(0, 128 - textH * 0.5, w, textH)

		DrawScrollingText("Tool available only for admins!", 128, w)
	end
end

function TOOL:DrawHUD()
    surface.SetAlphaMultiplier(0)
end

local infoBoxOffset = Vector(26.5, -7.4, 2)

surface.CreateFont("IncGestures/ToolInfo", {
    font   = "Helvetica",
    size   = 32,
    weight = 600
})

surface.CreateFont("IncGestures/ToolInfoSmall", {
    font   = "Helvetica",
    size   = 24
})

local lmb, rmb, reload = Material("gui/lmb.png", "smooth mips"), Material("gui/rmb.png", "smooth mips"), Material("gui/r.png", "smooth mips")

local function DrawBox(text, icon, y)
    local x = 32

    surface.SetFont("IncGestures/ToolInfo")
    local w, h = surface.GetTextSize(text)
    w = w + 16 + 32
    h = h + 16

    surface.SetDrawColor(0, 0, 0, 175)
    surface.DrawRect(x, y, w, h)

    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(icon)
    surface.DrawTexturedRect(x + 4, y + h*0.5 - 16, 32, 32)

    draw.SimpleText(text, "IncGestures/ToolInfo", x + 4 + 32 + 4, y + h*0.5, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

local function drawTextBox(text, font, y)
    local x = 32

    surface.SetFont(font)
    local w, h = surface.GetTextSize(text)
    w = w + 16
    h = h + 16

    surface.SetDrawColor(0, 0, 0, 175)
    surface.DrawRect(x, y, w, h)

    draw.SimpleText(text, font, x + w * 0.5, y + h*0.5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

hook.Add("PostDrawViewModel", "IncGestures/DrawToolInfo", function()
    local ply = LocalPlayer()
    local swep = ply:GetActiveWeapon()

    if not (swep.Tool and swep.Mode == "inc_gestures") then return end

    local ang = EyeAngles()
    ang:RotateAroundAxis(ang:Right(), 90)
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), -30)

    local pos = ply:GetViewModel():LocalToWorld(infoBoxOffset)

    local trEntity = ply:GetEyeTrace().Entity
    local trVendor = IsValid(trEntity) and trEntity:GetClass() == "inc_gestures_npc"

    cam.Start3D2D(pos, ang, 0.015)
        local SpawnNPC = INC_GESTURES._Lang.SpawnNPC or "%Lang-SpawnNPC%"
        local ChangeModel = INC_GESTURES._Lang.ChangeModel or "%Lang-ChangeModel%"

        DrawBox(trVendor and ChangeModel or SpawnNPC, lmb, trVendor and 140 or 190)

        if trVendor then
            DrawBox(INC_GESTURES._Lang.ChangeAnimation or "%Lang-ChangeAnimation%", rmb, 195)
            DrawBox(INC_GESTURES._Lang.Remove or "%Lang-Remove%", reload, 250)
            drawTextBox("gmod.store/market/view/gestures", "IncGestures/ToolInfoSmall", 305)
        else
            drawTextBox("gmod.store/market/view/gestures", "IncGestures/ToolInfoSmall", 245)
        end
    cam.End3D2D()
end)

local white_mat = Material("debug/debugvertexcolor")
local DIR_LIGHT_LEFT_COL = Color(255, 160, 80, 255)
local DIR_LIFT_RIGHT_COL = Color(80, 160, 255, 255)
local red = Color(255, 0, 0)

local function MakeMenu(title)
    local ply = LocalPlayer()
    local trNpc = ply:GetEyeTrace().Entity

    local HeaderTitle = INC_GESTURES.Colors.HeaderTitle or red
    local VendorGreen = INC_GESTURES.Colors.VendorGreen or red
    local VendorRed = INC_GESTURES.Colors.VendorRed or red
    local VendorDark = INC_GESTURES.Colors.VendorDark or red
    local VendorWhite = INC_GESTURES.Colors.VendorWhite or red
    local BackgroundColor = INC_GESTURES.Colors.BackgroundColor or red
    local HeaderColor = INC_GESTURES.Colors.HeaderColor or red
    local HeaderButtonColor = INC_GESTURES.Colors.HeaderButtonColor or red
    local HeaderButtonColor_Hovered = INC_GESTURES.Colors.HeaderButtonColor_Hovered or red
    local ScrollBackgroundColor = INC_GESTURES.Colors.ScrollBackgroundColor or red
    local SearchEntryBackground = INC_GESTURES.Colors.SearchEntryBackground or red
    local SearchEntryPlaceholder = INC_GESTURES.Colors.SearchEntryPlaceholder or red
    local SearchEntryText = INC_GESTURES.Colors.SearchEntryText or red
    local VendorSectionHovered = INC_GESTURES.Colors.VendorSectionHovered or red
    local VendorSectionIcon = INC_GESTURES.Colors.VendorSectionIcon or red
    local SectionWhiteText = INC_GESTURES.Colors.SectionWhiteText or red
    local ScrollGripColor = INC_GESTURES.Colors.ScrollGripColor or red
    local ScrollbarBackground = INC_GESTURES.Colors.ScrollbarBackground or red

    local menu = vgui.Create("EditablePanel")
    menu:SetSize(INC_GESTURES.NpcMenuWide, INC_GESTURES.NpcMenuTall)
    menu:Center()
    menu:MakePopup()
    menu.Paint = function(me, w, h)
        if input.IsKeyDown(KEY_ESCAPE) then
            return me:Hide()
        end

        surface.SetDrawColor(BackgroundColor)
        surface.DrawRect(0, 0, w, h)
    end

    menu.title = title

    menu.header = menu:Add("EditablePanel")
    menu.header:Dock(TOP)
    menu.header:SetTall(24)
    menu.header.Paint = function(me, w, h)
        surface.SetDrawColor(HeaderColor)
        surface.DrawRect(0, 0, w, h)

        draw.SimpleText(menu.title, "GestureNpcMenuTitle", 8, h * 0.5, HeaderTitle, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    menu.header:DockPadding(0, 6, 6, 6)

    menu.header.AddButton = function(me, paint, cback)
        local btn = me:Add("EditablePanel")
        btn:SetMouseInputEnabled(true)
        btn:SetCursor("hand")
        btn:SetWidth(12)
        btn:Dock(RIGHT)
        btn:DockMargin(12, 0, 0, 0)
        btn.Paint = function(me, w, h)
            surface.SetDrawColor(me:IsHovered() and HeaderButtonColor_Hovered or HeaderButtonColor)
            paint(me, w, h)
        end
        btn.DoClick = cback
        btn.OnMouseReleased = function(me, mcode)
            if mcode == MOUSE_LEFT and me.DoClick then
                me:DoClick()
            end
        end

        return btn
    end

    menu.header.btnClose = menu.header:AddButton(function(me, w, h)
        surface.SetMaterial(white_mat)
        surface.DrawTexturedRectRotated(w*0.5, h*0.5, w, 3, -45)
        surface.DrawTexturedRectRotated(w*0.5, h*0.5, w, 3, 45)
    end, function()
        menu:Hide()
    end)
    menu.header.btnMaxim = menu.header:AddButton(function(me, w, h)
        surface.DrawRect(3, 0, w, 3)
        surface.DrawRect(0, 0, 3, h)

        surface.DrawRect(0, h - 3, w, 3)
        surface.DrawRect(w - 3, 3, 3, h)
    end, function()
        menu._ToggleMax = not menu._ToggleMax

        if menu._ToggleMax then
            menu:SetSize(ScrW(), ScrH())
        else
            menu:SetSize(INC_GESTURES.NpcMenuWide, INC_GESTURES.NpcMenuTall)
        end

        menu.left:SetWide(menu:GetWide() * 0.6)

        menu:Center()
    end)
    menu.header.btnMinim = menu.header:AddButton(function(me, w, h)
        surface.DrawRect(0, h - 3, w, 3)
    end, function()
        menu:Hide()
    end)

    menu.header.OnMousePressed = function(me, mcode)
        if mcode ~= MOUSE_LEFT then return end

        local screenX, screenY = menu:LocalToScreen(0, 0)
        menu.Dragging = {x = gui.MouseX() - menu.x, y = gui.MouseY() - menu.y}
        menu:MouseCapture(true)
    end

    menu.Think = function(me)
        if me.NPC and me:IsVisible() and not IsValid(me.NPC) then
            me:Hide()
            return
        end

        if me.Dragging == nil then return end

        if not input.IsMouseDown(MOUSE_LEFT) then
            menu.Dragging = nil
            menu:MouseCapture(false)
            return
        end

        local mouseX = math.Clamp(gui.MouseX(), 1, ScrW() - 1)
        local mouseY = math.Clamp(gui.MouseY(), 1, ScrH() - 1)

        me.x = math.Clamp(mouseX - me.Dragging.x, 0, ScrW() - me:GetWide())
        me.y = math.Clamp(mouseY - me.Dragging.y, 0, ScrH() - me:GetTall())
    end

    menu.left = menu:Add("DModelPanel")
    menu.left:Dock(LEFT)
    menu.left:SetWide(menu:GetWide() * 0.6)
    menu.left:SetModel(trNpc:GetModel())
    menu.left.Entity:SetSkin(trNpc:GetSkin())
    for i, body in ipairs(trNpc:GetBodyGroups()) do
        menu.left.Entity:SetBodyGroups(body.id, trNpc:GetBodygroup(body.id))
    end
    menu.left:SetFOV(32)
    menu.left:SetDirectionalLight(BOX_RIGHT, DIR_LIGHT_LEFT_COL)
    menu.left:SetDirectionalLight(BOX_LEFT, DIR_LIFT_RIGHT_COL)
    menu.left:SetAmbientLight(Vector(-64, -64, -64))
    menu.left:SetAnimated(true)
    local default_sequence = menu.left.Entity:GetSequence()
    menu.left.Entity:ResetSequence(trNpc:GetSequence())
    menu.left.ResetSequence = function(me)
        if default_sequence > 0 then
            me.Entity:ResetSequence(default_sequence)
            return
        end

        local sec_id = me.Entity:LookupSequence("idle_all_01")

        if sec_id <= 0 then sec_id = self:LookupSequence("idle") end
        if sec_id <= 0 then sec_id = me.Entity:LookupSequence("walk_all") end
        if sec_id <= 0 then sec_id = me.Entity:LookupSequence("WalkUnarmed_all") end
        if sec_id <= 0 then sec_id = me.Entity:LookupSequence("walk_all_moderate") end

        me.Entity:ResetSequence(sec_id)
    end

    menu.left.Angles = Angle(0, 60, 0)
    menu.left.Pos = Vector(-50, 0, -61)

    menu.left:SetCamPos( vector_origin )
    menu.left.Angles = angle_zero
    menu.left:SetLookAt( Vector( -100, 0, -22 ) )

    function menu.left:DragMousePress(button)
        self.PressX, self.PressY = gui.MousePos()
        self.Pressed = button
    end

    function menu.left:OnMouseWheeled(delta)
        self.WheelD = delta * -10
        self.Wheeled = true
    end

    function menu.left:DragMouseRelease()
        self.Pressed = false
    end

    function menu.left:LayoutEntity(Entity)
        if self.bAnimated then
            self:RunAnimation()

            if self.Entity:GetCycle() >= 1 then
                self.Entity:SetCycle(0)
                self:ResetSequence()
            end
        end

        if self.Pressed == MOUSE_LEFT then
            local mx, my = gui.MousePos()
            self.Angles = self.Angles - Angle(0, (self.PressX or mx) - mx, 0)
            self.PressX, self.PressY = gui.MousePos()
        elseif self.Pressed == MOUSE_RIGHT then
            local mx, my = gui.MousePos()
            self.Angles = self.Angles - Angle((self.PressY * (0.5) or my * (0.5)) - my * (0.5), 0, (self.PressX * (-0.5) or mx * (-0.5)) - mx * (-0.5))
            self.PressX, self.PressY = gui.MousePos()
        elseif self.Pressed == MOUSE_MIDDLE then
            local mx, my = gui.MousePos()
            self.Pos = self.Pos - Vector(0, (self.PressX * (0.5) or mx * (0.5)) - mx * (0.5), (self.PressY * (-0.5) or my * (-0.5)) - my * (-0.5))
            self.PressX, self.PressY = gui.MousePos()
        end

        if self.Wheeled then
            self.Wheeled = false
            self.Pos = self.Pos - Vector(self.WheelD, 0, 0)
        end

        Entity:SetAngles(self.Angles)
        Entity:SetPos(self.Pos)
    end

    menu.right = menu:Add("EditablePanel")
    menu.right:Dock(FILL)
    menu.right.Paint = function(me, w, h)
        surface.SetDrawColor(ScrollBackgroundColor)
        surface.DrawRect(0, 0, w, h)
    end

    local search_parent = menu.right:Add("EditablePanel")
    search_parent:SetTall(48)
    search_parent:Dock(TOP)
    search_parent.Paint = function(me, w, h)
        surface.SetDrawColor(BackgroundColor)
        surface.DrawRect(0, 0, w, h)
    end
    search_parent:DockPadding(0, 12, 12, 12)

    local search = search_parent:Add("gestures/entry")
    search:Dock(FILL)
    search:SetTall(24)
    search.BackgroundColor = SearchEntryBackground
    search.FocusedBackgroundColor = search.BackgroundColor
    search:RoundedCorners(6)
    search:SetPlaceholderColor(SearchEntryPlaceholder)
    search:Dock(FILL)
    search:SetPlaceholderText("Search..")
    search:SetFont("GestureNpcMenuSearch")
    search:SetTextColor(SearchEntryText)
    search:SetDrawLanguageID(false)
    menu.search = search

    local scroll = menu.right:Add("gestures/scroll")
    scroll:Dock(FILL)
    scroll.Colors.box = ScrollGripColor
    scroll.Colors.hover = 
    scroll.VBar:SetWide(8)
    scroll.RoundNum = 4
    scroll:GetVBar().Paint = function(me, w, h)
        surface.SetDrawColor(ScrollbarBackground)
        surface.DrawRect(0, 0, w, h)
    end
    menu.scroll = scroll

    local menu_items = {}

    search.OnChange = function(me)
        local new = me:GetValue():lower()

        local visible = 0
        for i, item in ipairs(menu_items) do
            if item.uid:find(new, 1, true) or (item.uid2 and item.uid2:find(new, 1, true)) then
                item:Show()
                visible = visible + 1
                item:SetZPos(visible)
            else
                item:Hide()
            end
        end

        scroll:InvalidateLayout()
    end

    menu.CreateItem = function(self, uid, paint, onclick, onhover, onclick_rmb)
        local item = scroll:Add("EditablePanel")
        item.uid = uid:lower()
        table.insert(menu_items, item)
        item:SetCursor("hand")
        item:Dock(TOP)
        item:SetTall(44)
        item.Paint = function(me, w, h)
            if me:IsHovered() and menu.last_hovered ~= me then
                menu.last_hovered = me
                onhover(me)
            end

            if me:IsHovered() or menu.last_hovered == me then
                surface.SetDrawColor(VendorSectionHovered)
                surface.DrawRect(0, 0, w, h)
            end

            paint(me, w, h)
        end
        item.OnMouseReleased = function(me, mcode)
            if mcode == MOUSE_LEFT then
                onclick(me)
            elseif onclick_rmb and mcode == MOUSE_RIGHT then
                onclick_rmb(me)
            end
        end
        return item
    end

    return menu
end

local function firstCharUpper(str)
    return (str:gsub("^%l", string.upper))
end

local ValidModels = {}
hook.Add("HUDPaint", "IncGestures/CollectModels", function() -- on first frame render
    hook.Remove("HUDPaint", "IncGestures/CollectModels")
    if not INC_GESTURES.IsAdmin(LocalPlayer()) then return end

    local count = 0

    for name, mdl in pairs(player_manager.AllValidModels()) do
        count = count + 1
        ValidModels[count] = {
            name = firstCharUpper(player_manager.TranslateToPlayerModelName(mdl)),
            mdl = mdl
        }
    end

    for class, data in pairs(list.Get("NPC")) do
        local mdl = data.Model
        if mdl == nil then
            local path = "models/".. class:sub(5) ..".mdl"
            if util.IsValidModel(path) then
                mdl = path
            end
        end

        if mdl then
            count = count + 1

            local name = data.Name
            if name == nil then
                name = mdl:sub(8)
                if #name > 23 then
                    name = name:sub(1, 22) ..".."
                end
            end

            ValidModels[count] = {
                name = firstCharUpper(name),
                mdl = mdl
            }
        end
    end
end)

local lower = string.lower

local menu, menu2
function TOOL:ChangeModelMenu()
    local ply = LocalPlayer()
    local trNpc = ply:GetEyeTrace().Entity

    local VendorWhite = INC_GESTURES.Colors.VendorWhite or red

    if IsValid(menu) then
        menu.left:SetModel(trNpc:GetModel())
        menu.left.Entity:ResetSequence(trNpc:GetSequence())
        menu.title = INC_GESTURES._Lang.ModelSelector or "%Lang-ModelSelector%"
        menu.NPC = trNpc
        menu:Show()
        return
    end

    hook.Remove("HUDPaint", "IncGestures/BuildChangeModelMenu")

    menu = MakeMenu(INC_GESTURES._Lang.ModelSelector or "%Lang-ModelSelector%")
    menu.NPC = trNpc
    menu:Show()

    local function ApplyModel(mdl)
        self:Action(SET_MODEL, menu.NPC, mdl)
    end

    local SelectedGreen = INC_GESTURES.Colors.SelectedGreen or red

    local function CreateIcon(model)
        local name = model.name
        local mdl = model.mdl

        local item = menu:CreateItem(mdl, function(me, w, h) -- paint
            if lower(menu.NPC:GetModel()) == lower(mdl) then
                surface.SetDrawColor(SelectedGreen) 
                surface.DrawRect(0, 0, 2, h)
            end
            draw.SimpleText(name, "GestureNpcMenuGestureName", 44, h*0.5, VendorWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end, function(me) -- onclick
            menu.left:SetModel(mdl)
            ApplyModel(mdl)
        end,
        function(me) -- onhover
            menu.left:SetModel(mdl)

            local afterSecond = CurTime() + 1
            me.Think = function(me)
                if menu.last_hovered ~= me then
                    me.Think = nil
                    return
                end

                if CurTime() < afterSecond then return end

                me.Think = nil
                ApplyModel(mdl)
            end
        end, function(me) -- rmb lick
            local menu = DermaMenu() 
            menu:AddOption("Copy to Clipboard", function()
                SetClipboardText(mdl)
            end):SetIcon("icon16/page_copy.png")
            menu:Open()
        end)

        item.uid2 = name
        item:SetTooltip(mdl)

        local icon = item:Add("SpawnIcon")
        icon:SetSize(36, 36)
        icon:SetPos(4, 4)
        icon:SetModel(mdl)
        icon:SetMouseInputEnabled(false)
    end
    
    local index = 0

    local function Make()
        index = index + 1
        local mdl = ValidModels[index]

        if mdl == nil then
            return hook.Remove("HUDPaint", "IncGestures/BuildChangeModelMenu")
        end

        CreateIcon(mdl)
    end

    hook.Add("HUDPaint", "IncGestures/BuildChangeModelMenu", function()
        for i = 1, 4 do
            Make()
        end

        if menu.search:GetValue() ~= "" then
            menu.search:OnChange()
        end
    end)
end

function TOOL:ChangeAnimationsMenu()
    local ply = LocalPlayer()
    local trNpc = ply:GetEyeTrace().Entity

    local VendorWhite = INC_GESTURES.Colors.VendorWhite or red

    if IsValid(menu2) then
        local diff = menu2.left:GetModel() ~= trNpc:GetModel()
        menu2.left.Entity:ResetSequence(trNpc:GetSequence())
        menu2.title = INC_GESTURES._Lang.AnimationSelector or "%Lang-AnimationSelector%"
        menu2.NPC = trNpc
        if diff then
            menu2:MakeSequenceItems(menu2.NPC)
            menu2.left:SetModel(trNpc:GetModel())
        end
        menu2:Show()
        return
    end

    hook.Remove("HUDPaint", "IncGestures/BuildChangeAnimationsMenu")

    menu2 = MakeMenu(INC_GESTURES._Lang.AnimationSelector or "%Lang-AnimationSelector%")
    menu2.NPC = trNpc
    menu2:Show()

    local function ApplySequence(seq)
        self:Action(SET_SEQUENCE, menu2.NPC, seq)
    end

    local SelectedGreen = INC_GESTURES.Colors.SelectedGreen or red

    local list = {}
    function menu2:MakeSequenceItems(npc)
        if (self.SequenceItems or "") == npc:GetModel() then return end
        self.SequenceItem = npc:GetModel()

        for seq, item in pairs(list) do
            if IsValid(item) then
                item:Remove()
            end
        end
        list = {}

        local function CreateSequence(seq)
            if list[seq] or not IsValid(npc) then return end
            
            local seq_id = npc:LookupSequence(seq)
            if not seq_id then return end

            local item = menu2:CreateItem(seq, function(me, w, h) -- paint
                if menu2.NPC:GetSequence() == seq_id then
                    surface.SetDrawColor(SelectedGreen)
                    surface.DrawRect(0, 0, 2, h)
                end
                draw.SimpleText(seq, "GestureNpcMenuGestureName", 6, h*0.5, VendorWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end, function(me) -- onclick
                menu2.left.Entity:ResetSequence(seq_id)
                menu2.left.Entity:SetCycle(0)
                ApplySequence(seq)
            end,
            function(me) -- onhover
                menu2.left.Entity:ResetSequence(seq_id)
                menu2.left.Entity:SetCycle(0)

                local afterSecond = CurTime() + 1
                me.Think = function(me)
                    if menu2.last_hovered ~= me then
                        me.Think = nil
                        return
                    end

                    if CurTime() < afterSecond then return end

                    me.Think = nil
                    ApplySequence(seq)
                end
            end, function(me) -- rmb lick
                local menu3 = DermaMenu() 
                menu3:AddOption(INC_GESTURES._Lang.CopyToClipboard or "%Lang-CopyToClipboard%", function()
                    SetClipboardText(seq)
                end):SetIcon("icon16/page_copy.png")
                menu3:Open()
            end)

            item:SetTall(24)
            list[seq] = item
        end

        local Sequences = npc:GetSequenceList()
        local index = 0

        local function Make()
            index = index + 1
            local seq = Sequences[index]

            if seq == nil then
                return hook.Remove("HUDPaint", "IncGestures/BuildChangeAnimationsMenu")
            end

            CreateSequence(seq)
        end

        hook.Add("HUDPaint", "IncGestures/BuildChangeAnimationsMenu", function()
             for i = 1, 4 do
                Make()
            end

            if menu2.search:GetValue() ~= "" then
                menu2.search:OnChange()
            end
        end)
    end

    menu2:MakeSequenceItems(menu2.NPC)
end