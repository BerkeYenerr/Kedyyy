-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

TOOL.Information = {}
language.Add("tool.inc_gestures.name", TOOL.Name)

function TOOL:LeftClick(trace)
	if not INC_GESTURES.IsAdmin(self.SWEP.Owner) then return end

	if IsValid(trace.Entity) and trace.Entity:GetClass() == "inc_gestures_npc" then
		self:ChangeModelMenu()
	elseif IsFirstTimePredicted() then
		RunConsoleCommand("gm_spawnsent", "inc_gestures_npc")
		return true
	end
end

function TOOL:RightClick(trace)
	if not INC_GESTURES.IsAdmin(self.SWEP.Owner) then return end

	if IsValid(trace.Entity) and trace.Entity:GetClass() == "inc_gestures_npc" then
		self:ChangeAnimationsMenu()
	end
end

function TOOL:Reload(trace)
	if not INC_GESTURES.IsAdmin(self.SWEP.Owner) or not IsFirstTimePredicted() then return end

	if IsValid(trace.Entity) and trace.Entity:GetClass() == "inc_gestures_npc" then
		return true
	end
end

local function RunAnimation(ent, anim)
	ent:ResetSequence(
		ent:LookupSequence(anim)
	)
	ent:SetCycle(0)
	ent:SetPlaybackRate(1)
end

function TOOL:UpdateGhostNPC(ent, ply)
	if not IsValid(ent)  then return end

	local trace = ply:GetEyeTrace()
	if (not trace.Hit or IsValid(trace.Entity)) and (trace.Entity:GetClass() == "inc_gestures_npc" or trace.Entity:IsPlayer()) then
		ent:SetNoDraw(true)
		return
	end

	local ang = trace.HitNormal:Angle()
	ang:RotateAroundAxis(ang:Right(), -90)
	ang.y = ply:EyeAngles().y - 180
	ent:SetAngles(ang)

	ent:SetPos(trace.HitPos - trace.HitNormal * ent:OBBMins().z - ent:GetAngles():Up() * 6)

	ent:SetNoDraw(false)
end

local ghostColor = Color(255, 255, 255, 150)

function TOOL:CreateGhostNPC(model, pos, angle)
    util.PrecacheModel(model)

    if game.SinglePlayer() or not IsFirstTimePredicted() then return end

    self:ReleaseGhostEntity()

    self.GhostEntity = ents.CreateClientProp(model)

    if not IsValid(self.GhostEntity) then
        self.GhostEntity = nil
        return
    end

    self.GhostEntity:SetModel(model)
    self.GhostEntity:SetPos(pos)
    self.GhostEntity:SetAngles(angle)
    self.GhostEntity:Spawn()

    self.GhostEntity:PhysicsDestroy()

    self.GhostEntity:SetMoveType(MOVETYPE_NONE)
    self.GhostEntity:SetNotSolid(true)
    self.GhostEntity:SetRenderMode(RENDERMODE_TRANSCOLOR)
    self.GhostEntity:SetColor(ghostColor)

    RunAnimation(self.GhostEntity, "menu_combine")
end


function TOOL:Think()
	if not IsValid(self.GhostEntity) then
		self:CreateGhostNPC("models/player/barney.mdl", vector_origin, angle_zero)
	end

	self:UpdateGhostNPC(self.GhostEntity, self:GetOwner())
end

function TOOL:Action(id, npc, extra)
	net.Start("INC_GESTURES/Tool")
		net.WriteUInt(id, 1)
		net.WriteEntity(npc)
		net.WriteString(extra)
	net.SendToServer()
end