-- developed for gmod.store
-- from incredible-gmod.ru with love <3
-- https://www.gmodstore.com/market/view/gestures

hook.Run("IncGestures/ConfigIncluded") -- do not touch this line

-- INC_GESTURES:Add(*string* "Custom Name", {*string* Sequence = "sequence_here", *string* Icon = "path/to/icon.png" or "https://website.com/image.png", *function optional* CustomCheck = function(ply) return ply:IsSuperAdmin() end})

INC_GESTURES:Add("Meditasyon", {
	Sequence = "sit_zen",
	Icon = "kedimoryenikey.png",
	Infinitie = true  -- the gesture will continue indefinitely until the player interrupts it with a movement
})

for i = 1, 4 do
	INC_GESTURES:Add("Poz Ver #".. i, {
		Sequence = "pose_standing_0".. i,
		Icon = "kedimoryenikey.png",
		Infinitie = true
	})
end

INC_GESTURES:Add("Onayla", {
	Sequence = "gesture_agree_original", -- Use sequence viewer https://steamcommunity.com/sharedfiles/filedetails/?id=2493778309 for list all player animations (some custom models may include custom animations, so make sure that the animation will work on default player models. there are also addons that add custom animations to all models, you should also make sure that they work correctly.)
	Icon = "kedimoryenikey.png", -- You can use path or url. Best icons can be found here: https://www.flaticon.com/search?word=lamp&license=selection&color=1&stroke=1&order_by=4&type=icon (free + black filled = :cool:)
 -- FFT Dolly Zoom effect (a cool effect that increases the fun from dances, but may not be suitable for specific gestures) - it also does not affect anything if the gesture does not have a sound
})
INC_GESTURES:Add("Reddet", {
	Sequence = "gesture_disagree_original",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Selamla", {
	Sequence = "gesture_bow_original",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Çağır", {
	Sequence = "gesture_becon_original",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Selam Dur", {
	Sequence = "gesture_salute_original",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("El Salla", {
	Sequence = "gesture_wave_original",
	Icon = "kedimoryenikey.png",
})

INC_GESTURES:Add("Eller Yukarı", {
	Sequence = "taunt_cheer_base",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Gül", {
	Sequence = "taunt_laugh_base",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Poz ver", {
	Sequence = "taunt_persistence_base",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Zombi", {
	Sequence = "taunt_zombie_original",
	Icon = "kedimoryenikey.png",
})

INC_GESTURES:Add("Kravat Düzelt", {
	Sequence = "menu_gman",
	Icon = "kedimoryenikey.png",
})

INC_GESTURES:Add("Dans", {
	Sequence = "taunt_dance_base",
	Icon = "kedimoryenikey.png", -- the price for which players can buy gesture (do not set if your gesture should be free)
})
INC_GESTURES:Add("Kaslar", {
	Sequence = "taunt_muscle_base",
	Icon = "kedimoryenikey.png",
})

INC_GESTURES:Add("Robot Dansı", {
	Sequence = "taunt_robot_base",
	Icon = "kedimoryenikey.png",
})

-- the following gestures uses custom animations! please make sure that you have installed their content correctly if you want to use them! You can find more information about installing content for these animations in the"🔧 Configulartion" tab of the addon presentation.
INC_GESTURES:Add("Dans 1", {
	Sequence = "wos_fn_twist",
	Icon = "kedimoryenikey.png",-- Volume to set. 1 meaning 100% volume, 0.5 is 50%, 3 is 300%, etc. this property is 1 by default
})
INC_GESTURES:Add("Dans 2 ", {
	Sequence = "wos_fn_fresh",
	Icon = "kedimoryenikey.png",
	camBoundToBone = "ValveBiped.Bip01_Spine", -- a new way to make gestures more interesting, specify the name of the bone and the camera will follow it. (bone list: https://wiki.facepunch.com/gmod/Entity:LookupBone)
})
INC_GESTURES:Add("Dans 3 ", {
	Sequence = "wos_fn_discofever",
	Icon = "kedimoryenikey.png",
-- 1500% the sound volume in this file is very quiet
	camBoundToBone = { -- you can change the bones with a delay
		{delay = 0, bone = "ValveBiped.Bip01_R_Hand"}, -- the camera starts following the right hand at the beginning of the gesture
		{delay = 4, bone = "ValveBiped.Bip01_L_Hand"} -- 4 seconds after the animation starts, the camera starts following the left hand.
	}
})
INC_GESTURES:Add("Dans 4", {
	Sequence = "wos_fn_intensity",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 5", {
	Sequence = "wos_fn_dancemoves",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 6", {
	Sequence = "wos_fn_fresh",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 7", {
	Sequence = "wos_fn_floss",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 8", {
	Sequence = "wos_fn_jubilation",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 9", {
	Sequence = "wos_fn_livinglarge",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 10", {
	Sequence = "wos_fn_zany",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 11", {
	Sequence = "wos_fn_hype",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 12", {
	Sequence = "wos_fn_takethel",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 13", {
	Sequence = "wos_fn_wiggle",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 14", {
	Sequence = "wos_fn_twist",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 15", {
	Sequence = "wos_fn_trueheart",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 16", {
	Sequence = "wos_fn_reanimated",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 17", {
	Sequence = "wos_fn_rambunctious",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 18", {
	Sequence = "wos_fn_swipeit",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 19", {
	Sequence = "wos_fn_electroshuffle",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 20", {
	Sequence = "wos_fn_poplock",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Dans 21", {
	Sequence = "wos_fn_starpower",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Takla At", {
	Sequence = "vanguard_a_s1_t1",
	Icon = "kedimoryenikey.png",
})
INC_GESTURES:Add("Selam Ver", {
	Sequence = "ws_clone_salute",
	Icon = "kedimoryenikey.png",
        Infinitie = true
})
INC_GESTURES:Add("Durus-1", {
	Sequence = "vanguard_f_idle",
	Icon = "kedimoryenikey.png",
        Infinitie = true
})

INC_GESTURES:Add("Durus-2", {
	Sequence = "phalanx_r_left_charge_running",
	Icon = "kedimoryenikey.png",
        Infinitie = true
})
INC_GESTURES:Add("Durus-3", {
	Sequence = "phalanx_r_s2_charge",
	Icon = "kedimoryenikey.png",
        Infinitie = true
})


INC_GESTURES:Add("Gel Gel", {
	Sequence = "vanguard_taunt_reverse",
	Icon = "kedimoryenikey.png",
        Infinitie = true
})
INC_GESTURES:Add("Eğil", {
	Sequence = "flourish_bow_basic",
	Icon = "kedimoryenikey.png",
})






-- Also you can add specific gestures for darkrp job
--[[ Example:
TEAM_EXAMPLE = DarkRP.createJob("Example team", {
    gestures = {
		{Name = "Cover", Sequence = "seq_cower", Icon = "gestures/cover.png", Price = 1337}
    },
    ...
})


also, if you have experience in developing on lua, you can add support for the job of your gamemode by ediing: INC_GESTURES:GetGestures in garrysmod/addons/gestures/lua/inc_gestures/src/sh_main.lua

or simply by using the CustomCheck(ply) property
Example:

CustomCheck = function(ply)
	return ply:GetJob() == "Mayor"
end
]]--

INC_GESTURES.Theme = "discord" -- regular/military/discord/shendow/e.t.c themes can be found here: garrysmod/addons/gestures/lua/gestures/themes (you can also create your own color theme - it's easy)

-- servers/gamemodes use different currencies, use ready-made compatibility with your preferred currency or create your own compatibility (create ticket if you need help).
INC_GESTURES.CurrencyCompatibility = "helix_money" -- darkrp_money/helix_money/pointshop/e.t.c - compatibilities can be found here: garrysmod/addons/gestures/lua/gestures/currency_compatibilities

INC_GESTURES.Lang = "en" -- en/ru/fr/e.t.c langs can be found here: garrysmod/addons/gestures/lua/gestures/langs

INC_GESTURES.Key = "g" -- Default keybind (players also can change keybind with 'gestures_key' cvar locally. the local bind has no priority over this variable since 1.1.3, so cvar will be reset to the config value when the keybind is changed in the config.)

INC_GESTURES.Fonts = {
	GestureName = { -- center text in radial menu
		font = "Roboto Bold",
		size = 44
	},
	GestureNpcMenuTitle = { -- title in vendor menu header
		font = "Roboto Bold",
		size = 20
	},
	GestureNpcMenuSearch = { -- search-bar font
		font = "Roboto",
		size = 15
	},
	GestureNpcMenuGestureName = { -- gesture name
		font = "Roboto Bold",
		size = 18
	},
	GestureNpcMenuGesturePrice = { -- gesture price
		font = "Roboto",
		size = 16
	},
	GestureNpcOverhead = { -- text above the npc head
		font = "Roboto Bold",
		size = 32
	}
}

-- Radial menu properties
INC_GESTURES.Radius = 350 -- how far the sections will be from the center of the screen
INC_GESTURES.Thickness = 90 -- sections thickness
INC_GESTURES.Scale = 0.6 -- radial menu scale
INC_GESTURES.IconSize = 32
INC_GESTURES.IconSizeHovered = 36

-- Npc menu size
INC_GESTURES.NpcMenuWide = 600
INC_GESTURES.NpcMenuTall = 640

INC_GESTURES.IsAdmin = function(ply) -- Who can use admin commands?
	return ply:IsSuperAdmin()
end

INC_GESTURES.EnableChatCommand = false -- opens the vendor menu (can be used anywhere without using a vendor npc)
INC_GESTURES.ChatCommand = "/gestures"

hook.Run("IncGestures/ConfigLoaded")  -- do not touch this line