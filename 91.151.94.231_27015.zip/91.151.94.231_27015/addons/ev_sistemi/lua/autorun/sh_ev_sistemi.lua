function ev_print(msg)
	MsgC(Color(255,0,255),"[FexaEv] ",color_white,msg.."\n")
end