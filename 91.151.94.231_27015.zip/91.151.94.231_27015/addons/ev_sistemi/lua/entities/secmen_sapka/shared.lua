ENT.Base = "base_gmodentity"
ENT.PrintName = "Seçmen Şapka"
ENT.Author = "fexa"
ENT.Category = "fx - Ev Sistemi"

ENT.Spawnable = true
ENT.AdminOnly = false