ev_sistemi = ev_sistemi or {} -- buraya ellemeyin

ev_sistemi.evsiz = TEAM_CITIZEN -- buraya evsizin teamını gir

ev_sistemi.gryffindor = TEAM_GRYFFINDOR -- buraya gryffindorun teamını yaz
ev_sistemi.hufflepuff = TEAM_HUFFLEPUFF -- buraya hufflepuffun teamını yaz
ev_sistemi.slytherin = TEAM_SLYTHERIN -- buraya slytherinin teamını yaz
ev_sistemi.ravenclaw = TEAM_RAVENCLAW -- buraya ravenclaw teamını yazs