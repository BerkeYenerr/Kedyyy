fx_d = fx_d or {} -- buna ellemeyin

fx_d.kacsaniyekalabuyudagitilabilir = 90; -- kendini açıklıyor.
fx_d.siraliderstenefusu = 300; -- saniye cinsinden sıralı dersler arası tenefüs süresi
fx_d.profsiraliderslimiti = 3; -- 1 prof kaç ders sıraya koyabilir

fx_d.xp_araligi = 60 -- saniye cinsinden XP verme aralığı
fx_d.xp_miktari = 300 -- belirlenen aralıkta verilecek XP miktarı

fx_d.default_logo = "hogwartsrp/classes/subjects/classes_subject_history_of_magic.png" -- ders logosu boş olursa bu logo kullanılır.

fx_d.dersler = { -- Dersler
	["Eski Tılsımlar"] = {logo = "hogwartsrp/classes/subjects/classes_subject_charms.png"},
	["Büyücülük"] = {logo = "hogwartsrp/classes/subjects/classes_ico_hat.png"},
	["Muggle Bilimleri"] = {logo = "hogwartsrp/classes/subjects/classes_subject_muggle_studies.png"},
	["Kehanet ve Geleceği Yorumlama"] = {logo = "hogwartsrp/classes/subjects/classes_ico_book.png"},
	["Karanlık Sanatlara Karşı Savunma"] = {logo = "hogwartsrp/classes/subjects/classes_subject_dada.png"},
	["Astronomi ve Uzay Bilimleri"] = {logo = "hogwartsrp/classes/subjects/classes_subject_astronomy.png"},
	["Sihirli Yaratıkların Bakımı"] = {logo = "hogwartsrp/classes/subjects/classes_subject_freetime.png"},
	["Quidditch ve Uçuş"] = {logo = "hogwartsrp/classes/subjects/classes_subject_quiditch.png"},
	["Düello"] = {logo = "hogwartsrp/classes/subjects/classes_subject_lockdown.png"},
	["Iksir"] = {logo = "hogwartsrp/classes/subjects/classes_subject_potions.png"},
	["Botanik"] = {logo = "hogwartsrp/classes/subjects/classes_subject_herbology.png"},
	["Tarih"] = {logo = "hogwartsrp/classes/subjects/classes_subject_history_of_magic.png"},
	["Büyük Salonda Yemek"] = {logo = "hogwartsrp/classes/subjects/classes_subject_greathall.png"},
	["Metamorfoz"] = {logo = "hogwartsrp/classes/subjects/classes_subject_transfiguration.png"},
	["Simya"] = {logo = "hogwartsrp/classes/subjects/classes_subject_charms.png"},
	["Büyü Tarihi"] = {logo = "hogwartsrp/classes/subjects/classes_subject_history_of_magic.png"},
	["Metafiziksel Büyüler"] = {logo = "hogwartsrp/classes/subjects/classes_subject_dueling_club.png"},
	["Rün"] = {logo = "hogwartsrp/classes/subjects/classes_ico_book.png"},
	["Müzik"] = {logo = "hogwartsrp/classes/subjects/classes_subject_curfew.png"},
	["Gezi"] = {logo = "hogwartsrp/classes/subjects/classes_subject_charms.png"},
	["Ödül Töreni"] = {logo = "hogwartsrp/classes/subjects/classes_subject_greathall.png"},
	["Cisimsiz Varlıklar"] = {logo = "hogwartsrp/classes/subjects/classes_subject_greathall.png"},
	["Okul Karanlığın"] = {logo = "hogwartsrp/classes/subjects/classes_subject_dueling_club.png"},
	["Ateş Kadehi"] = {logo = "hogwartsrp/classes/subjects/classes_subject_greathall.png"},
	["Quidditch Antrenmanı"] = {logo = "hogwartsrp/classes/subjects/classes_subject_quiditch.png"},
	["Gezi"] = {logo = "hogwartsrp/classes/subjects/classes_subject_freetime.png"},
	["3 Büyücü Turnuvası"] = {logo = "hogwartsrp/classes/subjects/classes_subject_greathall.png"},
	["SBD"] = {logo = "hogwartsrp/classes/subjects/classes_subject_history_of_magic.png"},
	["Ziyafet"] = {logo = "hogwartsrp/classes/subjects/classes_subject_greathall.png"},
	["Sığınakta Ders"] = {logo = "hogwartsrp/classes/subjects/classes_subject_lockdown.png"},
	["Seherbaz Eğitimi"] = {logo = "hogwartsrp/classes/subjects/classes_subject_lockdown.png"}
}

--[[
	Örnek sınıf:

	["Sınıf 1"] = {
		konum = {min = Vector(-383.97, -1023.96, -12799.91), max = Vector(383.97, 1023.94, -12544)}
		renk = Color(255,128,0) -- tercihen, size kalmış. çok fazla şeyi etkilemiyor sadece toolda ve biraz hudda gözüküyor. koymazsanız default renk olan mor u kullanır.
	},
]]--
-- benim editlediğim maptaki sınıflar

/* 
	rp_hogwarts_community haritası için sınıflar
 	https://steamcommunity.com/sharedfiles/filedetails/?id=2170599335

 	harita yapımcısından: 
 		ravenclaw kulesine çıkan merdivenin yürüyüşü bozmasını istemiyorlarsa o entitynin açısını değiştirmeleri lazım
*/
fx_d.siniflar = { -- Sınıflar
	["KSKS Sınıfı"] = {
		--konum = {min = Vector(x,x,x), max = Vector(x,x,x)}
		konum = {min = Vector(-1354.23, -9312.77, -9719.58), max = Vector(-2131.22, -9883.27, -9434.3)},
		renk = Color(255,191,0),
	},
	["İksir Sınıfı"] = {
		konum = {min = Vector(-2160.57, -8821.03, -9720.03), max = Vector(-3400.94, -9192.84, -9339.03)},
		renk = Color(255,0,0),
	},
	["Düello Kulubü"] = {
		konum = {min = Vector(-12215.97, -4032.05, -9456.04), max = Vector(-11355.12, -5479.97, -9840.81)},
		renk = Color(0,63,255),
	},
	["Sınıf 4"] = {
		--konum = {min = Vector(x,x,x), max = Vector(x,x,x)}
		konum = {min = Vector(-936.03, -8512.53, -9750.31), max = Vector(-1782.64, -9205.01, -9442.16)},
		renk = Color(255,191,0),
	},
	["Sınıf 5"] = {
		konum = {min = Vector(-494.4, -4329.03, -9723.29), max = Vector(256.97, -5230.8, -9416.94)},
		renk = Color(0,63,255),
	},
	["Tılsım Sınıfı"] = {
		konum = {min = Vector(-4758.82, -4051.47, -9731.97), max = Vector(-3805.53, -4573.65, -9444.53)},
		renk = Color(127,159,255),
	},
	["Kehanet Sınıfı"] = {
	
		konum = {min = Vector(-2191.391113, -4245.069336, -8926.013672), max = Vector(-3051.796631, -3193.812500, -10490.150391)},
		renk = Color(255,128,128),
	},
	["Sınıf 3"] = {
		konum = {min = Vector(-3950.82, -9661.33, -9723.97), max = Vector(-2798.97, -10202.77, -9333.55)},
		renk = Color(127,0,95),
	},

	["Büyük Salon"] = {
		konum = {min = Vector(-12472.03, -5192.06, -9952.65), max = Vector(-13390.2, -3093.97, -8572.09)},
	},
	["Botanik"] = {
		konum = {min = Vector(1038.15, -10977.34, -9695.89), max = Vector(1399.97, -9127.03, -9550.99)},
		renk = Color(0,0,0)
	},
	["Astronomi"] = {
		konum = {min = Vector(-2660.05, -5837.29, -3608.85), max = Vector(-3416.16, -7813.64, -3254.96)},
		renk = Color(255,255,255),
	},
	["Quidditch"] = {
		konum = {min = Vector(-10895.57, 8102.95, -8270.24), max = Vector(-12443.76, 9776.08, -9652.83)},
		renk = Color(255,255,255)
	},
	["Sinif 6"] = {
	konum = {min = Vector(-9814.33, -5723.31, -9672.97), max = Vector(-9407.63, -4721.03, -9461.94)},
		renk = Color(0,63,255),
	},
	["SYB Alanı"] = {
	konum = {min = Vector(13544.235352, -8289.862305, -12037.139648), max = Vector(12292.869141, -6854.891113, -11142.518555)},
		renk = Color(0,63,255)
	},
	["Sinif 2"] = {
	konum = {min = Vector(-11389.896484, -5348.518066, -9372.791992), max = Vector(-12351.107422, -4667.968262, -8922.453125)},
		renk = Color(0,63,255),
	},
	["Sahne"] = {
	konum = {min = Vector(-11947.97, -4011.09, -11000.47), max = Vector(-11052.03, -4713.65, -10586.49)},
		renk = Color(0,63,255),
	},
	["Sinif 7"] = {
	konum = {min = Vector(-4520.81, -5113.03, -9384.28), max = Vector(-5260.68, -6377.51, -9722.98)},
		renk = Color(0,63,255),
	},
	["Rün Sınıfı"] = {
		konum = {min = Vector(-7607.66, -4608.03, -9723.63), max = Vector(-8462.31, -3624.85, -9343.67)},
			renk = Color(0,63,255),
	}
	
}

fx_d.acabilecekler = { -- Menüyü açabilecekler
	"Profesor",
	"Ksks",
	"Tilsim",
	"Brave",
	"Jhonsen",
	"Morgan",
	"Stanley",
	"Tılsım",
	"Profesör",
	"Hagrid",
	"Bekçi",
	"Prof",
	"Profesörü",
	"Koçu",
	"Moody",
	"Umbridge",
	"Dumbledore"
}