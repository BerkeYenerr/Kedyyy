fx_kutuphane = fx_kutuphane or {};

fx_kutuphane.varsayilangerekenbuyuadedi = 2; // bir büyüyü öğrenmek için aşağıdaki tabloda yoksa varsayılan olarak gereken adet
fx_kutuphane.varsayilanbuyufiyati = 500; // bir büyüyü satarken aşağıdaki tabloda yoksa varsayılan olarak satış fiyatı

fx_kutuphane = fx_kutuphane or {};

fx_kutuphane.varsayilangerekenbuyuadedi = 100; // bir büyüyü öğrenmek için aşağıdaki tabloda yoksa varsayılan olarak gereken adet
fx_kutuphane.varsayilanbuyufiyati = 1; // bir büyüyü satarken aşağıdaki tabloda yoksa varsayılan olarak satış fiyatı

fx_kutuphane.buyubilgileri = { // bir büyüyü kütüphaneden alabilmek için gereken sayı
["Leverio"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Speedom"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Anguish"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Aeternum"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Sanitatem"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Soulstra"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Agleures Tears"] = {
    gerekenadet = 10,
    satisfiyati = 5
},
["Aeri Protegat"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Bombarda Maxima"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Legimmio"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Accio"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Accio Maxima"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Aguamenti"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Alarte Ascendare"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Apparition"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Arresto Momentum"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Arrow-shooting spell"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Multa Sagitta"] = {
    gerekenadet = 6,
    satisfiyati = 5
},
["Ascendio"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Avis"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Bombarda"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Colloshoo"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Colovaria"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Conjunctivitis Curse"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Crucio"] = {
    gerekenadet = 7,
    satisfiyati = 7
},
["Depulso"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Engorgio"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Reducio"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Episkey"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Everte Statum"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Expecto Patronum"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Expulso"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Extinguishing Spell"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Faaf"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Feather-light Charm"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Flipendo"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Fumos"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Green Sparks"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Immobulus"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Impedimenta"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Imperius"] = {
    gerekenadet = 7,
    satisfiyati = 7
},
["Levicorpus"] = {
    gerekenadet = 5,
    satisfiyati = 6
},
["Lumos"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Mimblewimble"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Mobilicorpus"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Obscuro"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Occulto"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Petrificus Totalus"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Protego"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Reducto"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Rennervate"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Rictusempra"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Salvio Hexia"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Shield Penetration"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Spongify"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Stupefy"] = {
    gerekenadet = 2,
    satisfiyati = 2
},
["Tarantallegra"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Verdimillious"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Wingardium Leviosa"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Alium Cores"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Amoris Igne"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Anteoculatia"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Aqua Erecto"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Arania Exumai"] = {
    gerekenadet = 4,
    satisfiyati = 2
},
["Auxilium"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Auxilium Sanitatem"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Babbling Curse"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Titillando"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Steleus"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Blue Solis"] = {
    gerekenadet = 2,
    satisfiyati = 500
},
["Blue Sparks"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Bubblius"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Candy Avis"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Capriole"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Caulis"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Chillus"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Confetti Charm"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Claves Tacet"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Confringo"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Confundo"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Confusione Nigrum"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Contritum"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Coso Freeze"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Cranium"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Crepitus Inpulsa"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Cultrum Fricta"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Custos Flamma"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Damna"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Damnare Anguis"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Damnum Fortis"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Descendo"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Detoxify"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Devotion"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Dies Tenebrarum"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Episkey Duo"] = {
    gerekenadet = 2,
    satisfiyati = 2
},
["Episkey Maxima"] = {
    gerekenadet = 5,
    satisfiyati = 3
},
["Expelliarmus"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Fallaciae"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Ferula"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Firecracker Charm"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Fire Solis"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Firno Tarnis"] = {
    gerekenadet = 3,
    satisfiyati = 1
},
["Flatso"] = {
    gerekenadet = 4,
    satisfiyati = 2
},
["Fluctus Clade"] = {
    gerekenadet = 4,
    satisfiyati = 2
},
["Fulgur Caritate"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Fulgur Solis"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Gelida"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Glacies Pila"] = {
    gerekenadet = 4,
    satisfiyati = 2
},
["Glacius"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Glacius Duo"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Gonfiare Infernum"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Heal"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Heal Reducto"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Healstorm"] = {
    gerekenadet = 6,
    satisfiyati = 5
},
["Helios"] = {
    gerekenadet = 10,
    satisfiyati = 10
},
["Herbifors"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Homonculous"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Human To ArmChair"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Human To Cup"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Human To Gnome"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Humenum Revelio"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Igne Damnum"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Ignis Inpulsa"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Ignis Solis"] = {
    gerekenadet = 4,
    satisfiyati = 2
},
["Impetus Aquarum"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Incarcerous"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Incendio"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Inepta"] = {
    gerekenadet = 4,
    satisfiyati = 2
},
["Infernum"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Infinitum"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Insectum"] = {
    gerekenadet = 7,
    satisfiyati = 6
},
["Perfectium"] = {
    gerekenadet = 10,
    satisfiyati = 8
},
["Irae Luminis"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Labellum"] = {
    gerekenadet = 5,
    satisfiyati = 3
},
["Langlock"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Larvatus Sopor"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Legilimens"] = {
    gerekenadet = 7,
    satisfiyati = 7
},
["Lencover"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Lente"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Levita"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Levitante"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Lightborne"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Love Charm"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Magicus Penetrum"] = {
    gerekenadet = 5,
    satisfiyati = 3
},
["Matando Piedra"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Morietur"] = {
    gerekenadet = 6,
    satisfiyati = 5
},
["Mors Acidum"] = {
    gerekenadet = 6,
    satisfiyati = 4
},
["Mors Glacius"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Mors Icelen"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Mors Lenco"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Mors Mortem"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Mortalis"] = {
    gerekenadet = 7,
    satisfiyati = 7
},
["Mostro Maxima"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Mostro Maxima Sponsor"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Obliviate"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Ossa Cerent"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Ossa Peccatum"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Parvus Tactus"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Protego Totalum"] = {
    gerekenadet = 6,
    satisfiyati = 5
},
["Protego Verde"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Protestatem Magnam"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Protestatem Magnam Specialis"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Purpura Solis"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Red Solis"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Relashio"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Revelio"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Riddikulus"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Rosea Venas"] = {
    gerekenadet = 6,
    satisfiyati = 5
},
["Rossires Maxima"] = {
    gerekenadet = 6,
    satisfiyati = 4
},
["Senitatem"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Scourgify"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Serpensortia"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Solis"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Solis Maxima"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Stella"] = {
    gerekenadet = 7,
    satisfiyati = 6
},
["Stonestorm"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Subsisto"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Talionis"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Tembra"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Tetovo"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Tres Impetus"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Ubi Vulneribus"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Umbra Imppulsum"] = {
    gerekenadet = 4,
    satisfiyati = 4
},
["Ventus"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Ventus Duo"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Venuste Subsisto Maxima"] = {
    gerekenadet = 7,
    satisfiyati = 7
},
["Venuste Subsisto Ultimo"] = {
    gerekenadet = 6,
    satisfiyati = 6
},
["Veraverto"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Viridi Solis"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Virtus"] = {
    gerekenadet = 3,
    satisfiyati = 3
},
["Vivet"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Lumos Maxima"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Redactum Skullus"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Ear Shrivelling Curse"] = {
    gerekenadet = 5,
    satisfiyati = 5
},
["Flavo Solis"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Lux Sphera"] = {
    gerekenadet = 5,
    satisfiyati = 3
},
["Bubble-Head Charm"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Dwisp"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Purple Firecrackers"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Armis Glacies"] = {
    gerekenadet = 5,
    satisfiyati = 4
},
["Lux Vitae"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Red Spark"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Lux Bulbus"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Speedavec"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Suppression"] = {
    gerekenadet = 8,
    satisfiyati = 7
},
["Lumos Solem"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Color Lumos"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Orbitus"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Mostro"] = {
    gerekenadet = 2,
    satisfiyati = 1
},
["Yellow Fireworks"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Vulpecula"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Wasp"] = {
    gerekenadet = 4,
    satisfiyati = 3
},
["Wintify"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Winborium"] = {
    gerekenadet = 7,
    satisfiyati = 6
},
["Fireball"] = {
    gerekenadet = 3,
    satisfiyati = 2
},
["Collect Spell"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Leafola"] = {
    gerekenadet = 1,
    satisfiyati = 1
},
["Notinesta"] = {
    gerekenadet = 1,
    satisfiyati = 1
}
};

fx_kutuphane.dil = fx_kutuphane.dil or {};
fx_kutuphane.dil["learn"] = "%s isimli buyu icin gerekli kagitlari kutuphaneden aldin. Ogrenmeye baslayabilirsin.";
fx_kutuphane.dil["notfound"] = "Belirtilen Steam ID'ye sahip oyuncu bulunamadi veya sunucuya hic girmemis.";
fx_kutuphane.dil["notenough"] = "Yeteri kadar kagida sahip degilsin.";
fx_kutuphane.dil["addbuyu"] = "Kutuphanene %s isimli buyu kagidindan %d tane eklendi.";
fx_kutuphane.dil["subtractbuyu"] = "Kutuphanenden %s isimli buyu kagidindan %d tane eksildi.";
fx_kutuphane.dil["btransfersuccess"] = "%s isimli oyuncu sana %s isimli buyu kagidindan %d tane gonderdi!";
fx_kutuphane.dil["atransfersuccess"] = "Islem basarili! %s buyu kagidindan %d tane gonderdin!";
fx_kutuphane.dil["alreadylearned"] = "Zaten bu buyuyu ogrenebilirsin!";
fx_kutuphane.dil["sold"] = "%s buyusunu satarak %s kazandin."