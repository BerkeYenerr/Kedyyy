ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.AutomaticFrameAdvance = true
ENT.PrintName = "Hogwarts Kutuphane NPC"
ENT.Category = "fexa"
ENT.Author = "fexa"
ENT.Spawnable = true
ENT.AdminSpawnable = false