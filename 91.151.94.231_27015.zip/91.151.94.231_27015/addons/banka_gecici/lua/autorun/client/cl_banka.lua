surface.CreateFont( "lemonymilk", {
    font		= "LEMON MILK",
    size		= 15,
    weight		= 0,
    light = true,
} )

surface.CreateFont( "lemonymilk1", {
    font		= "LEMON MILK",
    size		= 20,
    weight		= 0,
    light = true,
} )

galleon = nil
sickle = nil
knut = nil
local birincibasilan = "galleon"
local ikincibasilan = "galleon"
local parasec
local parasec1 

local function dicon(mat, x, y, w, h)
    surface.SetDrawColor( 255, 255, 255, 255 )
    surface.SetMaterial( Material(mat) )
    surface.DrawTexturedRect( x, y, w, h)
end

/*hook.Add("HUDPaint", "gringotsparacartcurt", function()
    --lyric4l
    if galleon then
        dicon("gringotts_ui_elements/galleon.png", 10, ScrH()-146, 25, 25)
        dicon("gringotts_ui_elements/sickle.png", 10, ScrH()-126, 25, 25)
        dicon("gringotts_ui_elements/knut.png", 10, ScrH()-105, 25, 25)

        draw.DrawText(galleon.." GL", "ahud_17", 42, ScrH()-146, Color(255,255,255,255), TEXT_ALIGN_LEFT)
        draw.DrawText(sickle.." SC", "ahud_17", 42, ScrH()-126, Color(255,255,255,255), TEXT_ALIGN_LEFT)
        draw.DrawText(knut.." KN", "ahud_17", 42, ScrH()-105, Color(255,255,255,255), TEXT_ALIGN_LEFT)
    end
    local yuzde = math.Round((LocalPlayer():GetNWInt( "guthlevelsystem:XP", 0 ) / LocalPlayer():GetNWInt( "guthlevelsystem:NXP", 0 ))* 100)
    draw.DrawText("%"..yuzde, "ahud_17", 72, ScrH()-85, Color(255,255,255,255), TEXT_ALIGN_LEFT)
    draw.DrawText("Level "..LocalPlayer():GetNWInt( "guthlevelsystem:LVL", 0 ), "ahud_17", 13, ScrH()-85, Color(255,255,255,255), TEXT_ALIGN_LEFT)
    draw.DrawText("|", "ahud_17", 110, ScrH()-85, Color(255,255,255,255), TEXT_ALIGN_LEFT)

    surface.SetFont("ahud_18")
    surface.SetTextPos( 120 , ScrH()-85 )
    surface.SetTextColor(255, 255 ,255 ,255)
    surface.DrawText(GetGlobalString("saat", "HATA"))
    draw.DrawText("|", "ahud_17", 162, ScrH()-85, Color(255,255,255,255), TEXT_ALIGN_LEFT)
end)*/

net.Receive("bankaacilsin", function()
    galleon = net.ReadString()
    sickle = net.ReadString()
    knut = net.ReadString()
    genelmenu()
end)

net.Receive("girisguncellemesi", function()
    galleon = net.ReadString()
    sickle = net.ReadString()
    knut = net.ReadString()
end)

function genelmenu()
    local m1 = Material("gringotts_ui_elements/anamenusu.png")

    local menupara = vgui.Create("DFrame")
    menupara:SetSize(1139*.5,648*.5)
    menupara:Center()
    menupara:SetTitle("")
    menupara:SetDraggable(false)
    menupara:ShowCloseButton(false)
    menupara:MakePopup()
    menupara.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(m1)
        surface.DrawTexturedRect(0,0,w,h)

        draw.DrawText(galleon.." GL", "lemonymilk", 435, 276, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(sickle.." SC", "lemonymilk", 435, 290, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(knut.." KN", "lemonymilk", 435, 304, Color(255,255,255,255), TEXT_ALIGN_CENTER)
    end

    for i=1,3 do
        local paracekmenubtn = vgui.Create("DButton", menupara)
        paracekmenubtn:SetSize(200,30)
        paracekmenubtn:SetPos(90,170+i*30)
        paracekmenubtn:SetText(" ")
        paracekmenubtn.Paint = function() end
        paracekmenubtn.DoClick = function()
            menupara:Close()
            if i == 1 then
                paradonustur()
            elseif i == 2 then
                paracekmenu()
            elseif i == 3 then
                parayatirmenu()
            end
        end
    end

    local dbutton = vgui.Create("DImageButton", menupara)
    dbutton:SetSize(192*.1,192*.1)
    dbutton:SetPos(15,120)
    dbutton:SetImage("gringotts_ui_elements/kapa.png")
    dbutton.DoClick = function()
        menupara:Close()
    end

end

function paracekmenu()
    local mwithdraw = Material("gringotts_ui_elements/paracek.png")

    local menucek = vgui.Create("DFrame")
    menucek:SetSize(1139*.5,648*.5)
    menucek:Center()
    menucek:SetTitle("")
    menucek:MakePopup()
    menucek:SetDraggable(false)
    menucek:ShowCloseButton(false)
    menucek.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(mwithdraw)
        surface.DrawTexturedRect(0,0,w,h)

        draw.DrawText(galleon.." GL", "lemonymilk1", 60, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(sickle.." SC", "lemonymilk1", 170, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(knut.." KN", "lemonymilk1", 280, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)

        draw.DrawText("Cekilecek miktar:", "lemonymilk1", 170, 180, Color(255,255,255,255), TEXT_ALIGN_CENTER)
    end

    local dbutton = vgui.Create("DImageButton", menucek)
    dbutton:SetSize(192*.2,192*.2)
    dbutton:SetPos(10,menucek:GetTall()-(dbutton:GetTall()+10))
    dbutton:SetImage("gringotts_ui_elements/geri.png")
    dbutton.DoClick = function()
        menucek:Close()
        genelmenu()
    end

    local dtextentry = vgui.Create("DTextEntry", menucek)
    dtextentry:SetPos(100,200)
    dtextentry:SetSize(135,30)
    dtextentry:SetFont("lemonymilk1")
    dtextentry:SetValue("    (Sadece GL)")
    dtextentry:SetNumeric(true)
    dtextentry.Paint = function(self)
        surface.SetDrawColor(255,255,255)
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
        self:DrawTextEntryText(Color(0,0,0), Color(255, 255, 255), Color(255, 255, 255))
    end

    local yatir = vgui.Create("DImageButton", menucek)
    yatir:SetImage("gringotts_ui_elements/cek.png")
    yatir:SetSize(79,27)
    yatir:SetPos(127,250)
    yatir.DoClick = function()
        if string.find(dtextentry:GetValue(), "-") then 
            dtextentry:SetValue("Negatif değer girilemez.")
        else
            if tonumber(galleon) >= tonumber(dtextentry:GetValue()) then
                galleon = tonumber(galleon) - tonumber(dtextentry:GetValue())
                net.Start("paracek")
                net.WriteString(tonumber(dtextentry:GetValue()))
                net.SendToServer()
            end
        end
    end
end

function parayatirmenu()
    local mwithdraw = Material("gringotts_ui_elements/parayatir.png")

    local menuyatir = vgui.Create("DFrame")
    menuyatir:SetSize(1139*.5,648*.5)
    menuyatir:Center()
    menuyatir:SetTitle("")
    menuyatir:MakePopup()
    menuyatir:ShowCloseButton(false)
    menuyatir:SetDraggable(false)
    menuyatir.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(mwithdraw)
        surface.DrawTexturedRect(0,0,w,h)

        draw.DrawText(galleon.." GL", "lemonymilk1", 60, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(sickle.." SC", "lemonymilk1", 170, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(knut.." KN", "lemonymilk1", 280, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)

        draw.DrawText("Yatirilacak miktar:", "lemonymilk1", 170, 180, Color(255,255,255,255), TEXT_ALIGN_CENTER)
    end

    local dbutton = vgui.Create("DImageButton", menuyatir)
    dbutton:SetSize(192*.2,192*.2)
    dbutton:SetPos(10,menuyatir:GetTall()-(dbutton:GetTall()+10))
    dbutton:SetImage("gringotts_ui_elements/geri.png")
    dbutton.DoClick = function()
        menuyatir:Close()
        genelmenu()
    end

    local dtextentry = vgui.Create("DTextEntry", menuyatir)
    dtextentry:SetPos(100,200)
    dtextentry:SetSize(135,30)
    dtextentry:SetFont("lemonymilk1")
    dtextentry:SetValue("             ")
    dtextentry:SetNumeric(true)
    dtextentry.Paint = function(self)
        surface.SetDrawColor(255,255,255)
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
        self:DrawTextEntryText(Color(0,0,0), Color(255, 255, 255), Color(255, 255, 255))
    end

    local yatir = vgui.Create("DImageButton", menuyatir)
    yatir:SetImage("gringotts_ui_elements/yatir.png")
    yatir:SetSize(79,27)
    yatir:SetPos(127,250)
    yatir.DoClick = function()
        if tonumber(dtextentry:GetValue()) > 0 then
            if LocalPlayer():GetCharacter():GetMoney() >= tonumber(dtextentry:GetValue()) then
                galleon = galleon + tonumber(dtextentry:GetValue())
                net.Start("parayatir")
                net.WriteString(tonumber(dtextentry:GetValue()))
                net.SendToServer()
                menuyatir:Close()
                genelmenu()
            else
                dtextentry:SetValue("Yetersiz para.")
            end
        end
    end
end

function paradonustur()
    birincibasilan = "galleon"
    ikincibasilan = "galleon"

    local mwithdraw = Material("gringotts_ui_elements/paracevir.png")

    paracevir = vgui.Create("DFrame")
    paracevir:SetSize(1139*.5,648*.5)
    paracevir:Center()
    paracevir:SetTitle("")
    paracevir:MakePopup()
    paracevir:SetDraggable(false)
    paracevir:ShowCloseButton(false)
    paracevir.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(mwithdraw)
        surface.DrawTexturedRect(0,0,w,h)

        draw.DrawText(galleon.." GL", "lemonymilk1", 60, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(sickle.." SC", "lemonymilk1", 170, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
        draw.DrawText(knut.." KN", "lemonymilk1", 280, 120, Color(255,255,255,255), TEXT_ALIGN_CENTER)
    end

    local para1 = vgui.Create("DImage", paracevir)
    para1:SetSize(38,38)
    para1:SetPos(87,193)
    para1.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(Material("gringotts_ui_elements/"..birincibasilan..".png"))
        surface.DrawTexturedRect(0,0,w,h)
    end

    local para2 = vgui.Create("DImage", paracevir)
    para2:SetSize(38,38)
    para2:SetPos(264,193)
    para2.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(Material("gringotts_ui_elements/"..ikincibasilan..".png"))
        surface.DrawTexturedRect(0,0,w,h)
    end

    local butoncurencychange = vgui.Create("DButton", paracevir)
    butoncurencychange:SetSize(30,10)
    butoncurencychange:SetPos(90,242)
    butoncurencychange:SetText(" ")
    butoncurencychange.Paint = function() end
    butoncurencychange.DoClick = function()
        birincicurrencychangemenu()
    end

    local butoncurencychange1 = vgui.Create("DButton", paracevir)
    butoncurencychange1:SetSize(30,10)
    butoncurencychange1:SetPos(270,242)
    butoncurencychange1:SetText(" ")
    butoncurencychange1.Paint = function() end
    butoncurencychange1.DoClick = function()
        ikincicurrencychangemenu()
    end

    
    local cevirr = vgui.Create("DImageButton", paracevir)
    cevirr:SetImage("gringotts_ui_elements/cevir.png")
    cevirr:SetSize(79,27)
    cevirr:SetPos(158,270)
    cevirr.DoClick = function()
       net.Start("paracevir")
       net.WriteString(birincibasilan)
       net.WriteString(ikincibasilan)
       net.SendToServer()
       paracevirr(1,birincibasilan,ikincibasilan)
    end

    local dbutton = vgui.Create("DImageButton", paracevir)
    dbutton:SetSize(192*.2,192*.2)
    dbutton:SetPos(10,paracevir:GetTall()-(dbutton:GetTall()+10))
    dbutton:SetImage("gringotts_ui_elements/geri.png")
    dbutton.DoClick = function()
        if IsValid(parasec) then parasec:Close() end
        if IsValid(parasec1) then parasec1:Close() end
        paracevir:Close()
        genelmenu()
    end
end

function birincicurrencychangemenu()

    if IsValid(parasec) then parasec:Close() return end
    local mwithdraw = Material("gringotts_ui_elements/parasec.png")
    local posx,posy = paracevir:GetPos()

    parasec = vgui.Create("DFrame")
    parasec:SetSize(90,129)
    parasec:SetPos(posx+62,posy+270)
    parasec:SetTitle("")
    parasec:MakePopup()
    parasec:SetDraggable(false)
    parasec:ShowCloseButton(false)
    parasec.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(mwithdraw)
        surface.DrawTexturedRect(0,0,w,h)
    end

    local galleonbtn = vgui.Create("DButton", parasec)
    galleonbtn:SetSize(60,30)
    galleonbtn:SetPos(15,15)
    galleonbtn:SetText(" ")
    galleonbtn.Paint = function() end
    galleonbtn.DoClick = function()
        birincibasilan = "galleon"
        parasec:Close()
    end

    local sicklebtn = vgui.Create("DButton", parasec)
    sicklebtn:SetSize(60,30)
    sicklebtn:SetPos(15,50)
    sicklebtn:SetText(" ")
    sicklebtn.Paint = function() end
    sicklebtn.DoClick = function()
        birincibasilan = "sickle"
        parasec:Close()
    end

    local knuttbtn = vgui.Create("DButton", parasec)
    knuttbtn:SetSize(60,30)
    knuttbtn:SetPos(15,85)
    knuttbtn:SetText(" ")
    knuttbtn.Paint = function() end
    knuttbtn.DoClick = function()
        birincibasilan = "knut"
        parasec:Close()
    end

end

function ikincicurrencychangemenu()

    if IsValid(parasec1) then parasec1:Close() return end
    local mwithdraw = Material("gringotts_ui_elements/parasec.png")
    local posx,posy = paracevir:GetPos()

    parasec1 = vgui.Create("DFrame")
    parasec1:SetSize(90,129)
    parasec1:SetPos(posx+242,posy+270)
    parasec1:SetTitle("")
    parasec1:MakePopup()
    parasec1:SetDraggable(false)
    parasec1:ShowCloseButton(false)
    parasec1.Paint = function(s,w,h)
        surface.SetDrawColor(255, 255, 255)
        surface.SetMaterial(mwithdraw)
        surface.DrawTexturedRect(0,0,w,h)
    end

    local galleonbtn = vgui.Create("DButton", parasec1)
    galleonbtn:SetSize(60,30)
    galleonbtn:SetPos(15,15)
    galleonbtn:SetText(" ")
    galleonbtn.Paint = function() end
    galleonbtn.DoClick = function()
        ikincibasilan = "galleon"
        parasec1:Close()
    end

    local sicklebtn = vgui.Create("DButton", parasec1)
    sicklebtn:SetSize(60,30)
    sicklebtn:SetPos(15,50)
    sicklebtn:SetText(" ")
    sicklebtn.Paint = function() end
    sicklebtn.DoClick = function()
        ikincibasilan = "sickle"
        parasec1:Close()
    end

    local knuttbtn = vgui.Create("DButton", parasec1)
    knuttbtn:SetSize(60,30)
    knuttbtn:SetPos(15,85)
    knuttbtn:SetText(" ")
    knuttbtn.Paint = function() end
    knuttbtn.DoClick = function()
        ikincibasilan = "knut"
        parasec1:Close()
    end

end


function paracevirr(para,neyinden,neyine)
    if !isnumber(tonumber(para)) or tonumber(para) < 0 then return end
    galleon = tonumber(galleon)
    sickle = tonumber(sickle)
    knut = tonumber(knut)

    if neyinden == "galleon" then
        if neyine == "knut" then
            if galleon > 0 then
                galleon = galleon - 1
                knut = knut + 493
            end
        elseif neyine == "sickle" then
            if galleon > 0 then
                galleon = galleon - 1
                sickle = sickle + 17
            end
        end
    elseif neyinden == "sickle" then
        if neyine == "galleon" then
            if sickle > 16 then
                sickle = sickle - 17 
                galleon = galleon + 1
            end
        elseif neyine == "knut" then
            if sickle > 0 then
                sickle = sickle - 1
                knut = knut + 29
            end
        end
    elseif neyinden == "knut" then
        if neyine == "galleon" then
            if knut > 492 then
                knut = knut - 493
                galleon = galleon + 1
            end
        elseif neyine == "sickle" then
            if knut > 28 then
                knut = knut - 29
                sickle = sickle + 1
            end
        end
    end

end