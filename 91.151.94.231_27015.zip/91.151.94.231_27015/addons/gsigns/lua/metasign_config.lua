--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.config = {

  useWorkshop = true,


  spawnable = true,


  adminOnly = false,


  limits = {
    maxBrushLength = 50,
    maxObjects = 50
  },


  messages = {
    maxBrush = "Max brush length reached!",
    maxObjects = "Max objects reached!",
    fileNameEmpty = "File name cannot be empty!",
    settingsRejected = "You are not allowed to edit this sign's settings!",
    userNotFound = "User was not found!",
    userExists = "User already has access!",
    userRejected = "You are not allowed to edit this sign!",
    userAddOwner = "User is already the owner of the sign!",
    userAdded = "User was added!",
    userRemoved = "User was removed!",
    isEditing = "Someone else is already editing that sign!"
  }
}
