--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

AddCSLuaFile()
local BaseClass = baseclass.Get("gsign_normal")

ENT.Type = "anim"
ENT.PrintName = "Blackboard"
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.Spawnable = MetaSign.config.spawnable
ENT.AdminOnly = MetaSign.config.adminOnly

ENT.Model = "models/metamist/blackboard.mdl"
ENT.SignMaterial = "models/metamist/blackboard"

local matChalk = Material("models/metamist/chalk")

function ENT:Initialize()
  BaseClass.Initialize(self)

  if CLIENT then
    self.uvResolver = function(self, x, y)
      return x / 512, y / 256
    end

    for k, v in pairs(self.tools) do
      self:GetTool(k):SetMaterial(matChalk)
      self:GetTool(k):SetUVResolver(self.uvResolver)
    end

    self:SetDrawColor(Color(255, 255, 255))
  end
end

if CLIENT then
  local matWhite = CreateMaterial("MetaSignTemp1Material", "UnlitGeneric", {
    ["$basetexture"] = "white",
    ["$vertexcolor"] = 1
  })

  function ENT:OnObjectAdded(obj)
    obj:SetMaterial(matChalk)
    obj:SetUVResolver(self.uvResolver)
  end

  function ENT:GetRawCursorPos(origin, direction)
    local dat = self:GetWorkPlaneData()
    local pos = MetaSign.utils.IntersectGUIPane(origin, direction, self:GetForward(), self:GetUp(), self:LocalToWorld(dat.offset), dat.bounds)

    if not pos then return end

    return pos.x, pos.y
  end

  function ENT:Think()
    BaseClass.Think(self)
  end

  function ENT:GetGUIWorkArea()
    local gScale = self.guiScale
    local obbMin = self:OBBMins()
    local obbMax = self:OBBMaxs()

    return {
      left = obbMin.y / gScale,
      right = obbMax.y / gScale,
      top = obbMin.z / gScale,
      bottom = obbMax.z / gScale
    }
  end

  function ENT:GetWorkPlaneData()
    local obbMin = self:OBBMins()
    local obbMax = self:OBBMaxs()

    local padding = 1.6
    return {
      bounds = {
        left = obbMin.y + padding,
        right = obbMax.y - padding,
        top = obbMax.z - padding,
        bottom = obbMin.z + padding
      },
      offset = Vector(0.04 * 15, 0, 0)
    }
  end

  function ENT:GetCameraData()
    return {
      zoom = 55
    }
  end

  function ENT:Draw()
    BaseClass.Draw(self)
  end
end
