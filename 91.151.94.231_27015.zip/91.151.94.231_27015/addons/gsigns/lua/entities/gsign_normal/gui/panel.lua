--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

local drawRoundedRect = MetaSign.surface.DrawRoundedRect

local GUIPanel
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIPanel",
    __base = GUIObject.__base,
    Paint = function(self, w, h)
      surface.SetDrawColor(255, 255, 255)
      drawRoundedRect(16, self.x, self.y, w, h, 24)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIPanel.__parent.__init(self, x, y, width, height)
    end,
    __base = _base_0,
    __name = "GUIPanel",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIPanel = _class_0
end

MetaSign.gui.Register("Panel", GUIPanel)

return GUIPanel
