--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

local colGray = MetaSign.utils.Hex2RGB("#EEEEEE")
local colHighlight = MetaSign.utils.Hex2RGB("#1E88E5")

local utf8sub = MetaSign.utf8.sub
local utf8len = MetaSign.utf8.len

surface.CreateFont("MetaSign_GUI_TextEntry", {
  font = "Tahoma",
  antialias = true,
  size = 24,
  weight = 500
})

local GUITextEntry
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUITextEntry",
    __base = GUIObject.__base,
    SetText = function(self, text)
      self.text = text

      self:InvalidateLayout()
    end,
    SetPlaceholder = function(self, text)
      self.placeholder = text

      self:InvalidateLayout()
    end,
    SetFont = function(self, font)
      self.font = font end,
    SetTextColor = function(self, col)
      self.colorText = col end,
    SetPlaceholderColor = function(self, col)
      self.colorPlaceholder = col end,
    SetFocusColor = function(self, col)
      self.colorFocus = col end,
    SetBackgroundColor = function(self, col)
      self.colorBackground = col end,
    SetInset = function(self, value)
      self.inset = value end,
    InsertText = function(self, text, index)
      local currText = self:GetText()
      self:SetText(utf8sub(currText, 1, index - 1) .. text .. utf8sub(currText, index))
    end,
    DeleteAt = function(self, index, count)
      if count == nil then count = 1
      end
      if count == 0 then return end
      if count < 0 and index == 1 then return end

      local currText = self:GetText()
      if count > 0 and index == utf8len(currText) + 1 then return end

      if count > 0 then
        self:SetText(utf8sub(currText, 1, index - 1) .. utf8sub(currText, index + count))
      elseif count < 0 then
        self:SetText(utf8sub(currText, 1, index + count - 1) .. utf8sub(currText, index))
      end
    end,
    SetCursor = function(self, index)
      self.cursor = math.Clamp(index, 1, utf8len(self:GetText()) + 1)

      self:ResetBlinkTime()
      self:InvalidateLayout()
    end,
    MoveCursor = function(self, steps)
      self:SetCursor(self.cursor + steps)
    end,
    GetText = function(self)
      return self.text end,
    GetPlaceholder = function(self)
      return self.placeholder end,
    GetFont = function(self)
      return self.font end,
    GetTextColor = function(self)
      return self.colorText end,
    GetFocusColor = function(self)
      return self.colorFocus end,
    GetBackgroundColor = function(self)
      return self.colorBackground end,
    GetInset = function(self)
      return self.inset end,
    GetCursor = function(self)
      return self.cursor end,
    ResetBlinkTime = function(self)
      self.blinkTime = 0
    end,
    TickBlinkTime = function(self)
      self.blinkTime = self.blinkTime + RealFrameTime()
    end,
    OnKeyCodeTyped = function(self, code)
      if code == KEY_LEFT then
        self:MoveCursor(-1)
      elseif code == KEY_RIGHT then
        self:MoveCursor(1)
      elseif code == KEY_END then
        self:SetCursor(utf8len(self:GetText()) + 1)
      elseif code == KEY_HOME then
        self:SetCursor(1)
      elseif code == KEY_BACKSPACE then
        self:DeleteAt(self.cursor, -1)
        self:MoveCursor(-1)
      elseif code == KEY_DELETE then
        self:DeleteAt(self.cursor, 1)
      end
    end,
    OnTextTyped = function(self, text)
      self:InsertText(text, self.cursor)

      self:MoveCursor(utf8len(text))
    end,
    OnClick = function(self)
      local cx, cy = self:GetLocalCursorPos()
      local inset = self.inset

      surface.SetFont(self:GetFont())

      local index = 1
      for i = self.visualMin, self.visualMax + 1 do
        local sub = utf8sub(self.text, self.visualMin, i - 1)
        local tw, th = surface.GetTextSize(sub)

        local lastIndex = math.min(i, self.visualMax)
        local tcw, tch = surface.GetTextSize(utf8sub(self.text, lastIndex, lastIndex))

        if cx - inset + tcw / 2 > tw then
          index = i
        end
      end

      self:SetCursor(index)
    end,
    PerformLayout = function(self, w, h)
      local text = self:GetText()
      surface.SetFont(self:GetFont())

      for i = self.cursor, self.visualMin, -1 do
        local sub = utf8sub(text, i, self.cursor - 1)
        local tw, th = surface.GetTextSize(sub)

        if tw <= self.width - self.inset * 2 then
          self.visualMin = i
        else
          break
        end
      end

      self.visualMin = math.min(self.visualMin, self.cursor)
      for i = self.visualMin, utf8len(self.text) do
        local sub = utf8sub(text, self.visualMin, i)
        local tw, th = surface.GetTextSize(sub)

        if tw <= self.width - self.inset * 2 then
          self.visualMax = i
        else
          break
        end
      end

      if self.visualMax == utf8len(self.text) then
        for i = self.visualMax, 1, -1 do
          local sub = utf8sub(text, i, self.visualMax)
          local tw, th = surface.GetTextSize(sub)

          if tw <= self.width - self.inset * 2 then
            self.visualMin = i
          else
            break
          end
        end
      end

      self.visualMax = math.min(self.visualMax, utf8len(self.text))
    end,
    Think = function(self)
      self:TickBlinkTime()
    end,
    PaintBackgroundFocus = function(self, w, h)
      local cx, cy = self:GetCenter()

      surface.SetDrawColor(self.colorFocusBackground)
      local fw, fh = w + 8 * self.animFocusFraction, h + 8 * self.animFocusFraction
      drawRoundedRect(fh / 2, cx - fw / 2, cy - fh / 2, fw, fh, 20)
    end,
    PaintBackground = function(self, w, h)
      local cx, cy = self:GetCenter()

      surface.SetDrawColor(self.colorBackground)
      drawRoundedRect(h / 2, self.x, self.y, w, h, 20)

      surface.SetFont(self.font)
      local tw, th = surface.GetTextSize(self.text)

      local bw = (w - self.inset * 2) * self.animFocusFraction

      surface.SetDrawColor(self:GetFocusColor())
      drawRoundedRect(1.5, cx - bw / 2, self.y + h - 3 - 4, bw, 3, 20)
    end,
    Paint = function(self, w, h)
      local cx, cy = self:GetCenter()
      local text = self:GetText()
      local placeholder = self:GetPlaceholder()
      local cursor = self.cursor

      surface.SetFont(self.font)

      if text ~= "" then
        local textTilCursor = utf8sub(text, self.visualMin, cursor - 1)
        local tcw, tch = surface.GetTextSize(textTilCursor)

        local sub = utf8sub(text, self.visualMin, self.visualMax)
        draw.DrawText(sub, self.font, self.x + self.inset, cy - tch / 2, self.colorText, TEXT_ALIGN_LEFT)

        if self:IsFocused() then
          if math.floor(self.blinkTime * 2) % 2 == 0 then
            surface.SetDrawColor(self.colorText)
            surface.DrawRect(self.x + tcw + self.inset, cy - tch / 2, 1, tch)
          end
        end
      elseif placeholder ~= "" then
        local tw, th = surface.GetTextSize(placeholder)
        draw.DrawText(placeholder, self.font, self.x + self.inset, cy - th / 2, self.colorPlaceholder, TEXT_ALIGN_LEFT)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUITextEntry.__parent.__init(self, x, y, width, height)

      self.text = ""
      self.placeholder = ""
      self.font = "MetaSign_GUI_TextEntry"
      self.colorText = Color(0, 0, 0)
      self.colorPlaceholder = Color(150, 150, 150)
      self.colorFocus = Color(0, 0, 0)
      self.colorBackground = Color(255, 255, 255)

      self.interactable = true

      self.animDuration = 0.15
      self.animTime = 0
      self.animFraction = 0

      self.cursor = 1
      self.visualMin = 1
      self.visualMax = 1

      self.inset = 20

      self.blinkTime = 0
    end,
    __base = _base_0,
    __name = "GUITextEntry",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUITextEntry = _class_0
end

MetaSign.gui.Register("TextEntry", GUITextEntry)

return GUITextEntry
