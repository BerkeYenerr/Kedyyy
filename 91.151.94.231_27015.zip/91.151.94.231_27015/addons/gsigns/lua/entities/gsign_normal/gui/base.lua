--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local drawCircle = MetaSign.surface.DrawCircle

surface.CreateFont("MetaSign_GUI_Tooltip", {
  font = "Tahoma",
  antialias = true,
  size = 30,
  weight = 500
})

local AnimationData
do
  local _class_0
  local _base_0 = {
    __name = "AnimationData",
    SetIdentifier = function(self, id)
      self.id = id
    end,
    SetOnEndCallback = function(self, func)
      self.cbOnEnd = func
    end,
    SetOnThinkCallback = function(self, func)
      self.cbOnThink = func
    end,
    GetIdentifier = function(self, id)
      return self.id
    end,
    GetStartTime = function(self)
      return self.startTime
    end,
    GetEndTime = function(self)
      return self.endTime
    end,
    GetEasing = function(self)
      return self.easing
    end,
    GetOnEndCallback = function(self)
      return self.cbOnEnd
    end,
    GetOnThinkCallback = function(self)
      return self.cbOnThink
    end
  }
  _base_0.__index = _base_0
  _class_0 = setmetatable({
    __init = function(self, startTime, endTime, easing, callback)
      self.startTime = startTime
      self.endTime = endTime
      self.easing = easing
      self.cbOnEnd = callback
    end,
    __base = _base_0,
    __name = "AnimationData"
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  AnimationData = _class_0
end
local GUIObject
do
  local _class_0
  local _base_0 = {
    __name = "GUIObject",
    QueueNextAnimation = function(self)
      self.animQueue = true
    end,
    AnimTail = function(self)
      local last = SysTime()

      for i, anim in pairs(self.animList) do
        last = math.max(last, anim:GetEndTime())
      end

      return last
    end,
    ThinkAnimations = function(self)
      if #self.animList == 0 then return end

      local time = SysTime()

      for i, anim in pairs(self.animList) do
        local startTime, endTime = anim:GetStartTime(), anim:GetEndTime()

        if time < startTime then continue end

        local f = math.Clamp((time - startTime) / (endTime - startTime), 0, 1)
        local fe = f

        if anim:GetEasing() < 0 then
          fe = MetaSign.easing.CubicInOut(f, 0, 1, 1)
        end

        local cbOnThink = anim:GetOnThinkCallback()
        if cbOnThink then
          cbOnThink(self, anim, fe)
        end

        if f == 1 then
          local cbOnEnd = anim:GetOnEndCallback()

          if cbOnEnd then cbOnEnd(self, anim)end

          table.remove(self.animList, i)
        end
      end

      if #self.animList == 0 then
        self.animating = false
      end
    end,
    StopAnimations = function(self)
      self.animList = {}
    end,
    StopAnimationsByIdentifier = function(self, id)
      if id == nil then return end

      for i, anim in pairs(self.animList) do
        if anim:GetIdentifier() == id then
          table.remove(self.animList, i)
        end
      end
    end,
    NewUniqueAnimation = function(self, id, duration, delay, easing, callback)
      if delay == nil then delay = 0
      end
      if easing == nil then easing = -1
      end
      local startTime
      if self.animQueue then
        startTime = delay + self:AnimTail()
        self.animQueue = false
      else
        startTime = delay + SysTime()
      end

      local endTime = startTime + duration
      local anim = AnimationData(startTime, endTime, easing, callback)

      if id ~= nil then
        self:StopAnimationsByIdentifier(id)
        anim:SetIdentifier(id)
      end

      self.animList[#self.animList + 1] = anim

      self.animating = true

      return anim
    end,
    NewAnimation = function(self, duration, delay, easing, callback)
      if delay == nil then delay = 0
      end
      if easing == nil then easing = -1
      end
      return self:NewUniqueAnimation(nil, duration, delay, easing, callback)
    end,
    ThinkMoveAnimation = function(self, anim, f)
      local newX = Lerp(f, anim.fromX, anim.destX)
      local newY = Lerp(f, anim.fromY, anim.destY)

      self:SetPos(newX, newY)
    end,
    MoveTo = function(self, destX, destY, duration, delay, easing, callback)
      if delay == nil then delay = 0
      end
      if easing == nil then easing = -1
      end
      local fromX, fromY = self:GetPos()
      local anim = self:NewUniqueAnimation("MoveAnim", duration, delay, easing, callback)

      anim.fromX = fromX
      anim.fromY = fromY
      anim.destX = destX or fromX
      anim.destY = destY or fromY
      anim:SetOnThinkCallback(self.ThinkMoveAnimation)
    end,
    Initialize = function(self) end,
    PerformLayout = function(self, w, h) end,
    PerformLayoutInternal = function(self)
      self:PerformLayout(self:GetSize())

      for i, v in ipairs(self:GetChildren()) do
        v:PerformLayoutInternal()
      end
    end,
    InvalidateLayout = function(self, now)
      if now == nil then now = false
      end
      if now then
        self:PerformLayoutInternal()
      end

      self.layoutInvalid = true
    end,
    SetPos = function(self, x, y)
      if not x and not y then return end

      local changed = false
      if x and self.x ~= x then
        self.x = x
        changed = true
      end
      if y and self.y ~= y then
        self.y = y
        changed = true
      end

      if changed then
        self:InvalidateLayout()
      end
    end,
    SetSize = function(self, width, height)
      if not width and not height then return end

      local changed = false
      if width and self.width ~= width then
        self.width = width
        changed = true
      end
      if height and self.height ~= height then
        self.height = height
        changed = true
      end

      if changed then
        self:InvalidateLayout()
      end
    end,
    SetWidth = function(self, width)
      self:SetSize(width, nil)end,
    SetHeight = function(self, height)
      self:SetSize(nil, height)end,
    SetHoverBorder = function(self, value)
      self.hoverBorder = value end,
    SetAlpha = function(self, alpha)
      self.alpha = alpha
    end,
    SetVisible = function(self, visible)
      self.visible = visible
    end,
    SetFocusBackgroundColor = function(self, col)
      self.colorFocusBackground = col end,
    SetParent = function(self, obj, isAdded)
      if self.parent then
        self.parent:RemoveChild(self)
      end

      self.parent = obj

      if obj and not isAdded then
        obj:AddChild(self)
      end
    end,
    SetFocus = function(self, bool)
      self.focused = bool
    end,
    RequestFocus = function(self)
      self:GetContainer():SetFocus(self)
    end,
    ClearFocus = function(self)
      self:GetContainer():ClearFocus()
    end,
    GetPos = function(self)
      return self.x, self.y end,
    GetSize = function(self)
      return self.width, self.height end,
    GetWidth = function(self)
      return self.width end,
    GetHeight = function(self)
      return self.height end,
    GetAlpha = function(self)
      return self.alpha end,
    GetFocusBackgroundColor = function(self, col)
      return self.colorFocusBackground end,
    GetParent = function(self)
      return self.parent end,
    IsFocused = function(self)
      return self.focused end,
    AddChild = function(self, obj)
      local hasChild = self:HasChild(obj)
      if hasChild then return end

      self.children[#self.children + 1] = obj
      obj.container = self.container
      obj:SetParent(self, true)
      self:InvalidateLayout()

      return obj
    end,
    RemoveChild = function(self, obj)
      local hasChild, index = self:HasChild(obj)
      if not hasChild then return end

      return table.remove(self.children, index)
    end,
    Remove = function(self)
      self.removed = true

      local parent = self:GetParent()
      if parent then
        self:SetParent(nil)
      end

      self:RemoveInternal()
    end,
    OnRemove = function(self) end,
    RemoveInternal = function(self)
      self:RemoveChildren()
      self:OnRemove()
    end,
    RemoveChildren = function(self)
      local children = self.children
      for i = #children, 1, -1 do
        local child = children[i]

        child:RemoveInternal()
      end
    end,
    HasChild = function(self, obj)
      for i = 1, #self.children do
        local child = self.children[i]

        if child == obj then
          return true, i
        end
      end

      return false
    end,
    GetChildren = function(self)
      return self.children
    end,
    GetContainer = function(self)
      return self.container
    end,
    GetCursorPos = function(self)
      return self:GetContainer():GetCursorPos()
    end,
    GetLocalCursorPos = function(self)
      local x, y = self:GetPos()
      local cPos = self:GetCursorPos()

      return cPos.x - x, cPos.y - y
    end,
    GetRadius = function(self)
      return math.min(self.width, self.height) / 2
    end,
    GetCenter = function(self)
      return self.x + self.width / 2, self.y + self.height / 2
    end,
    GetHoverBorder = function(self)
      return self.hoverBorder end,
    GetHoverRadius = function(self)
      return self:GetRadius() + self:GetHoverBorder()end,
    GetHoverOrigin = function(self)
      return self:GetCenter()end,
    GetHoverRelativeClickPos = function(self, cPos)
      local hox, hoy = self:GetHoverOrigin()
      return cPos.x - hox, cPos.y - hoy
    end,
    ProcessFormattedTextData = function(self, data)
      local lines = {}
      local currLine = 1
      lines[currLine] = {}
      for j = 1, #data do
        local v = data[j]

        if v == nil then continue end

        if type(v) == "table" then
          lines[currLine] = lines[currLine] or {}
          lines[currLine][#lines[currLine] + 1] = v
        else
          local split = string.Explode("\n", tostring(v))
          for i, str in ipairs(split) do
            lines[currLine] = lines[currLine] or {}

            if #str > 0 then
              lines[currLine][#lines[currLine] + 1] = str
            end

            if i ~= #split then
              currLine = currLine + 1
            end
          end
        end
      end

      return lines
    end,
    BuildTooltipData = function(self, ...)
      local tooltip = {
        ...}
      local tooltipData = self:ProcessFormattedTextData(tooltip)
      local tooltipString = ""
      for _, dat in ipairs(tooltip) do
        if type(dat) ~= "table" then
          tooltipString = tooltipString .. tostring(dat)
        end
      end

      return {
        data = tooltipData,
        text = tooltipString
      }
    end,
    SetTooltip = function(self, var, ...)
      if not var then
        self.tooltipData = nil
        return
      end

      self.tooltipData = self:BuildTooltipData(var, ...)
    end,
    GetTooltip = function(self)
      return self.tooltipData
    end,
    SetTooltipAlignment = function(self, num)
      self.tooltipAlignX = (num - 1) % 3 - 1
      self.tooltipAlignY = -(math.ceil(num / 3) - 2)
    end,
    SetTooltipOffset = function(self, offset)
      self.tooltipOffset = offset
    end,
    GetTooltipPosition = function(self)
      return self:GetCenter()
    end,
    GetTooltipOffset = function(self)
      return self.width / 2, self.height / 2
    end,
    SetDisabled = function(self, bool)
      self.disabled = bool
    end,
    OnFocusChangedInternal = function(self, focus)
      self:OnFocusChanged(focus)

      if focus then
        self:OnFocusGained()
      else
        self:OnFocusLost()
      end

      self:PlayFocusAnimation(focus)
    end,
    OnClick = function(self) end,
    OnClickPressed = function(self) end,
    OnClickReleased = function(self) end,
    OnHover = function(self) end,
    OnHoverEnter = function(self) end,
    OnHoverExit = function(self) end,
    OnFocusChanged = function(self, focus) end,
    OnFocusGained = function(self) end,
    OnFocusLost = function(self) end,
    OnMouseWheeled = function(self, delta) end,
    FindParents = function(self, callback)
      local parent = self:GetParent()
      while parent do
        local ret = callback(parent)

        if ret then break end

        parent = parent:GetParent()
      end
    end,
    PlayFocusAnimation = function(self, focused)
      local anim = self:NewUniqueAnimation("FocusAnim", self.animFocusDuration)
      anim.startAnimFraction = self.animFocusFraction or 0

      anim:SetOnThinkCallback(function(pnl, anim, f)
        self.animFocusFraction = Lerp(f, anim.startAnimFraction, focused and 1 or 0)
      end)
    end,
    IsHovering = function(self)
      local cPos = self:GetCursorPos()
      local cx, cy = self:GetCenter()

      local cursorInrange = cPos.x >= self.x and cPos.y >= self.y and cPos.x < self.x + self.width and cPos.y < self.y + self.height
      return (self.circular and cPos:Distance(Vector(cx, cy, 0)) < self:GetHoverRadius()) or (not self.circular and cursorInrange)
    end,
    IsAnimating = function(self)
      return self.animating end,
    IsDisabled = function(self)
      return self.disabled end,
    IsVisible = function(self)
      return self.visible end,
    ShouldPlayHoverSound = function(self)
      return false
    end,
    Think = function(self) end,
    ThinkHover = function(self)
      local elapsed = FrameTime()
      if self.hovering and self.showTooltip then
        self.hoverTime = self.hoverTime + (1 - self.hoverTime) * 8 * elapsed

        if self.showTooltip then
          self.tooltipTime = self.tooltipTime + (1 - self.tooltipTime) * 8 * elapsed
        end
      else
        self.tooltipTime = self.tooltipTime + (0 - self.tooltipTime) * 8 * elapsed
        self.hoverTime = self.hoverTime + (0 - self.hoverTime) * 8 * elapsed
      end
    end,
    ThinkInternal = function(self)
      self:ThinkHover()
      self:ThinkAnimations()

      if self.layoutInvalid then
        self:PerformLayoutInternal()

        self.layoutInvalid = false
      end

      self:Think()
    end,
    ThinkChildren = function(self, parentAlpha)
      if parentAlpha == nil then parentAlpha = 1
      end
      local children = self.children
      local lp = LocalPlayer()

      local container = self:GetContainer()
      local keyUseDown = container:IsUseKeyDown()

      local isClicking = keyUseDown and not self.prevKeyUseDown

      local cPos = self:GetCursorPos()
      local isHoveringContainer = self:GetContainer():IsHovering()
      for i = #children, 1, -1 do
        local child = children[i]

        if not child.visible or child.disabled then
          child.hovering = false

          child:ThinkInternal()

          continue
        end

        local hoveringThrough = isHoveringContainer and child:IsHovering()
        if hoveringThrough then
          container.hoverElement = child
        end

        child:ThinkChildren(parentAlpha * child.alpha)

        local hovering = false
        if parentAlpha * child.alpha > 0.01 then
          local cx, cy = child:GetCenter()
          hovering = (child.interactable or child.blocksHover) and not container.didHover and hoveringThrough

          if child.interactable and hovering and not child.hovering then
            if child:ShouldPlayHoverSound() then
              surface.PlaySound("garrysmod/ui_hover.wav")
            end
          end

          if hovering then
            child:OnHover()
          end

          if hoveringThrough then
            if not child.hoveringThrough then child:OnHoverEnter()end
          else
            if child.hoveringThrough then child:OnHoverExit()end
          end

          child.hovering = hovering
          child.hoveringThrough = hoveringThrough

          if child.interactable and hovering and not container.didClick and isClicking then
            local hradius = child:GetHoverRadius()
            local rx, ry = child:GetHoverRelativeClickPos(cPos)

            child.clicks[#child.clicks + 1] = {
              time = CurTime(),
              x = math.Clamp(rx, -hradius, hradius),
              y = math.Clamp(ry, -hradius, hradius)
            }

            child:RequestFocus()

            child:OnClick(cPos)
            local shouldPlaySound = child:OnClickPressed(cPos)
            if shouldPlaySound ~= false then
              surface.PlaySound("garrysmod/ui_click.wav")
            end

            child.clicked = true
            container.didClick = true
          end

          if not keyUseDown and child.clicked then
            child:OnClickReleased(cPos)

            child.clicked = false
          end
        elseif parentAlpha * child.alpha < 0.01 or not self.interactable then
          if child.hoveringThrough then child:OnHoverExit()end

          child.hovering = false
          child.hoveringThrough = false
        end

        child:ThinkInternal()

        if hovering then container.didHover = true end
      end

      self.prevKeyUseDown = keyUseDown
    end,
    PrePaintChildren = function(self, over) end,
    PostPaintChildren = function(self, over) end,
    PaintFormattedTextData = function(self, data, x, y, alpha, alignment)
      local tCurY = y
      local _, lineHeight = surface.GetTextSize("\n")
      local currColor = Color(255, 255, 255)
      for _, line in ipairs(data) do
        local totalStr = ""
        for _, dat in ipairs(line) do
          if type(dat) == "string" then
            totalStr = totalStr .. dat
          end
        end

        local tSubWidth, tSubHeight = surface.GetTextSize(totalStr)
        if alignment == TEXT_ALIGN_CENTER then
          surface.SetTextPos(x - tSubWidth / 2, tCurY)
        elseif alignment == TEXT_ALIGN_RIGHT then
          surface.SetTextPos(x - tSubWidth, tCurY)
        else
          surface.SetTextPos(x, tCurY)
        end

        for _, dat in ipairs(line) do
          if type(dat) == "string" then
            surface.SetTextColor(ColorAlpha(currColor, alpha))
            surface.DrawText(dat)
          else
            currColor = dat
          end
        end

        tCurY = tCurY + lineHeight / 2
      end
    end,
    PaintTooltip = function(self)
      local dat = self.tooltipData
      if not dat then return end

      if self.tooltipTime > 0.01 then
        local x, y = self:GetCenter()
        local tox, toy = self:GetTooltipOffset()

        local a = self.tooltipTime * self.alpha

        local tpAlignNum = self.tooltipAlignment
        local alignment = TEXT_ALIGN_CENTER
        if self.tooltipAlignX == 1 then
          alignment = TEXT_ALIGN_LEFT
        elseif self.tooltipAlignX == -1 then
          alignment = TEXT_ALIGN_RIGHT
        end

        surface.SetFont("MetaSign_GUI_Tooltip")

        local tw, th = surface.GetTextSize(dat.text)
        surface.SetDrawColor(0, 0, 0, 200 * a)

        local offX = -tw / 2 - 15
        local offY = -th / 2 - 2.5
        if alignment == TEXT_ALIGN_LEFT then
          offX = tox + self.tooltipOffset
        elseif alignment == TEXT_ALIGN_RIGHT then
          offX = -tox - tw - 30 - self.tooltipOffset
        end

        if self.tooltipAlignY == 1 then
          offY = toy + self.tooltipOffset
        elseif self.tooltipAlignY == -1 then
          offY = -toy - th - 2.5 - self.tooltipOffset
        end

        local tpx, tpy = self:GetTooltipPosition()

        local tx = tpx + offX
        local ty = tpy + offY
        surface.DrawRect(tx, ty, tw + 30, th + 5)

        self:PaintFormattedTextData(dat.data, tx + tw / 2 + 15, ty + 2.5, a * 255, TEXT_ALIGN_CENTER)
      end
    end,
    PaintChildren = function(self, parentAlpha)
      if parentAlpha == nil then parentAlpha = 1
      end
      local children = self.children

      self:PrePaintChildren(false)
      for i = 1, #children do
        local child = children[i]

        if not child.visible then continue end
        if child.alpha < 0.01 then continue end
        if child.manualPainting then continue end

        surface.SetAlphaMultiplier(parentAlpha * child.alpha)
        child:PaintInternal(child.width, child.height)
        child:PaintChildren(parentAlpha * child.alpha)
      end
      self:PostPaintChildren(false)

      surface.SetAlphaMultiplier(parentAlpha)
    end,
    PaintOverChildren = function(self)
      local children = self.children

      self:PrePaintChildren(true)
      for i = 1, #children do
        local child = children[i]

        if not child.visible then continue end
        if child.alpha < 0.01 then continue end
        if child.manualPainting then continue end

        surface.SetAlphaMultiplier(child.alpha)
        child:PaintOverInternal(child.width, child.height)
        child:PaintOverChildren()
      end
      self:PostPaintChildren(true)

      surface.SetAlphaMultiplier(1)
    end,
    PaintBackgroundFocus = function(self, w, h) end,
    PaintBackground = function(self, w, h) end,
    Paint = function(self, w, h) end,
    PaintOverHoverEffect = function(self, w, h)
      local hradius = self:GetHoverRadius()
      local hox, hoy = self:GetHoverOrigin()

      surface.SetDrawColor(Color(255, 255, 255, self.alpha * 20 * self.hoverTime))
      drawCircle(hox, hoy, hradius, 16)
    end,
    PaintOver = function(self, w, h)
      local cx, cy = self:GetCenter()

      local hradius = self:GetHoverRadius()
      local hox, hoy = self:GetHoverOrigin()

      if self.interactable and self.showHover and self.hoverTime > 0.01 then
        self:PaintOverHoverEffect(w, h)
      end

      if self.showClicks and #self.clicks > 0 then
        for i, click in ipairs(self.clicks) do
          local clickFract = math.Clamp((CurTime() - click.time) / self.clickDuration, 0, 1)
          local animX = click.x + (-click.x) * clickFract
          local animY = click.y + (-click.y) * clickFract

          surface.SetDrawColor(Color(255, 255, 255, self.alpha * 50 * (1 - math.max(clickFract * 2 - 1, 0))))
          drawCircle(hox + animX, hoy + animY, hradius * clickFract, 24)

          if CurTime() - click.time >= self.clickDuration then
            table.remove(self.clicks, i)
          end
        end
      end

      self:PaintTooltip()
    end,
    PaintInternal = function(self, w, h)
      self:PaintBackgroundFocus(w, h)
      self:PaintBackground(w, h)
      self:Paint(w, h)
    end,
    PaintOverInternal = function(self, w, h)
      self:PaintOver(w, h)

      if MetaSign.gui.debug and self.hoveringThrough then
        surface.SetDrawColor(255, 0, 0)
        surface.DrawOutlinedRect(self.x, self.y, w, h)
      end
    end
  }
  _base_0.__index = _base_0
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      self.x = x
      self.y = y
      self.width = width
      self.height = height

      self.startX = x
      self.startY = y
      self.startWidth = width
      self.startHeight = height

      self.clicks = {}
      self.alpha = 1
      self.hoverTime = 0
      self.clickTime = 0
      self.clickDuration = 0.3

      self.hoverBorder = 16

      self.tooltipTime = 0
      self.tooltipAlignX = 0
      self.tooltipAlignY = 0
      self.tooltipOffset = 16

      self.disabled = false

      self.interactable = false
      self.blocksHover = false
      self.circular = false

      self.showTooltip = true
      self.showHover = false
      self.showClicks = false

      self.children = {}

      self.removed = false
      self.visible = true

      self.animating = false
      self.animList = {}
      self.animQueue = false

      self.animFocusDuration = 0.2
      self.animFocusFraction = 0

      self.colorFocusBackground = Color(255, 255, 255, 50)

      self.focused = false
    end,
    __base = _base_0,
    __name = "GUIObject"
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  GUIObject = _class_0
end
MetaSign.gui.Register("BaseObject", GUIObject)

return GUIObject
