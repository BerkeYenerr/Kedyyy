--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local hsl2color = MetaSign.utils.HSLToColor

local GUIObject = include("base.lua")

local matGradient = Material("gui/metamist/gradient_up_light")
local matHueRing = Material("gui/metamist/hue_ring")
local matPicker = Material("gui/metamist/picker")
local matHuePicker = Material("gui/metamist/hue_picker")

local GUIColorPicker
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIColorPicker",
    __base = GUIObject.__base,
    OnClickPressed = function(self, cursorPos)
      local cx, cy = self:GetCenter()
      local cursorPos = self:GetCursorPos()
      local center = Vector(cx, cy, 0)

      local radius = self:GetRadius()
      local triRadius = self:GetTriangleRadius()

      if cursorPos:Distance(center) > triRadius then
        self.pressedWheel = true
      else
        self.pressedTriangle = true
      end

      self.pressed = true
    end,
    OnClickReleased = function(self, cursorPos)
      self.pressed = false
      self.pressedWheel = false
      self.pressedTriangle = false
    end,
    IsHovering = function(self)
      local cx, cy = self:GetCenter()
      local cursorPos = self:GetCursorPos()
      local center = Vector(cx, cy, 0)

      local radius = self:GetRadius()
      local triRadius = self:GetTriangleRadius()

      return cursorPos:Distance(center) <= radius
    end,
    ShouldPlayHoverSound = function(self)
      return not self.dragging
    end,
    OnChange = function(self, value) end,
    GetRingThickness = function(self)
      return self:GetRadius() * 0.2
    end,
    GetTriangleRadius = function(self)
      return self:GetRadius() * 0.8
    end,
    GetHoverOrigin = function(self)
      local cursorPos = self:GetCursorPos()
      local cx, cy = self:GetCenter()
      local radius = self:GetRadius()
      local triangleRadius = self:GetTriangleRadius()
      local thick = self:GetRingThickness()
      local cPos = Vector(cx, cy, 0)

      if cPos:Distance(cursorPos) > triangleRadius then
        return cx + math.cos(self.hue) * (radius - thick / 2), cy + math.sin(self.hue) * (radius - thick / 2)
      else
        return cx + self.triX * triangleRadius, cy + self.triY * triangleRadius
      end
    end,
    GetHoverRelativeClickPos = function(self)
      return 0, 0
    end,
    GetHoverRadius = function(self)
      local cursorPos = self:GetCursorPos()
      local cx, cy = self:GetCenter()
      local radius = self:GetRadius()
      local triangleRadius = self:GetTriangleRadius()
      local thick = self:GetRingThickness()
      local cPos = Vector(cx, cy, 0)

      if cPos:Distance(cursorPos) > triangleRadius then
        return 8
      else
        return 4
      end
    end,
    UpdateColor = function(self)
      self.color = hsl2color(self.hue, self.saturation, self.lightness)
      self:OnChange(self.color)
    end,
    UpdatePositions = function(self)
      local r = self:GetTriangleRadius()
      local hue = self.hue
      local third = (2 / 3) * math.pi
      local saturation = self.saturation
      local lightness = 1 - self.lightness

      local hx = math.cos(hue)
      local hy = math.sin(hue)

      local sx = math.cos(hue - third)
      local sy = math.sin(hue - third)

      local vx = math.cos(hue + third)
      local vy = math.sin(hue + third)

      local mx = (sx + vx) / 2
      local my = (sy + vy) / 2
      local a = (1 - 2 * math.abs(lightness - 0.5)) * saturation
      self.triX = sx + (vx - sx) * lightness + (hx - mx) * a
      self.triY = sy + (vy - sy) * lightness + (hy - my) * a
    end,
    Think = function(self)
      local cursorPos = self:GetCursorPos()
      local cx, cy = self:GetCenter()
      local center = Vector(cx, cy, 0)

      local radius = self:GetRadius()
      local triRadius = self:GetTriangleRadius()

      if self.pressed then
        local diffX = cursorPos.x - cx
        local diffY = cursorPos.y - cy
        local rad = math.atan2(diffY, diffX)

        if rad < 0 then rad = rad + (2 * math.pi)
        end

        if self.pressedWheel then
          self.hue = rad

          self:UpdatePositions()
          self:UpdateColor()
        elseif self.pressedTriangle then
          local rad0 = (rad + 2 * math.pi - self.hue) % (2 * math.pi)
          local rad1 = rad0 % ((2 / 3) * math.pi) - (math.pi / 3)
          local a = 0.5 * triRadius
          local b = math.tan(rad1) * a
          local r = math.sqrt(diffX * diffX + diffY * diffY)
          local maxR = math.sqrt(a * a + b * b)

          if r > maxR then
            local dx = math.tan(rad1) * r
            local rad2 = math.Clamp(math.atan(dx / maxR), -math.pi / 3, math.pi / 3)
            rad = rad + (rad2 - rad1)

            rad0 = (rad + 2 * math.pi - self.hue) % (2 * math.pi)
            rad1 = rad0 % ((2 / 3) * math.pi) - (math.pi / 3)
            b = math.tan(rad1) * a
            maxR = math.sqrt(a * a + b * b)
            r = maxR
          end

          self.rad0 = rad0
          self.rad1 = rad1
          self.rad2 = rad2

          self.triX = math.cos(rad) * r / triRadius
          self.triY = math.sin(rad) * r / triRadius

          local triSideLen = math.sqrt(3) * triRadius
          local lightness = ((math.sin(rad0) * r) / triSideLen) + 0.5

          local widthShare = 1.0 - math.abs(lightness - 0.5) * 2.0
          local saturation = (((math.cos(rad0) * r) + (triRadius / 2)) / (1.5 * triRadius)) / widthShare
          saturation = math.Clamp(saturation, 0, 1)

          self.lightness = 1 - lightness
          self.saturation = saturation

          self:UpdateColor()
        end
      end

      local shortestHue = ((((self.hue - self.smoothHue) % (2 * math.pi)) + (3 * math.pi)) % (2 * math.pi)) - math.pi self.smoothHue = self.smoothHue + (shortestHue * 0.1)
    end,
    GetColor = function(self)
      return self.color
    end,
    GetHueColor = function(self)
      return hsl2color(self.hue, 1, 0.5)
    end,
    Paint = function(self)
      local cx, cy = self:GetCenter()

      local radius = self:GetRadius()
      local triRadius = self:GetTriangleRadius()

      draw.NoTexture()

      local triAng = self.hue
      local triOff = math.pi * 2 / 3
      local vertices = {
        {
          x = cx + math.cos(triAng - triOff) * triRadius,
          y = cy + math.sin(triAng - triOff) * triRadius,
          u = 0.5,
          v = 0.99
        },
        {
          x = cx + math.cos(triAng) * triRadius,
          y = cy + math.sin(triAng) * triRadius,
          u = 0.99,
          v = 0.01
        },
        {
          x = cx + math.cos(triAng + triOff * 1) * triRadius,
          y = cy + math.sin(triAng + triOff * 1) * triRadius,
          u = 0.01,
          v = 0.01
        }
      }

      local col = self:GetHueColor()
      surface.SetDrawColor(col)
      surface.DrawPoly(vertices)

      surface.SetDrawColor(255, 255, 255)
      surface.SetMaterial(matGradient)
      surface.DrawPoly(vertices)

      vertices[1].u = 0.99
      vertices[1].v = 0.01

      vertices[2].u = 0.01
      vertices[2].v = 0.01

      vertices[3].u = 0.5
      vertices[3].v = 0.99

      surface.SetDrawColor(0, 0, 0)
      surface.SetMaterial(matGradient)
      surface.DrawPoly(vertices)
      surface.DrawPoly(vertices)

      surface.SetDrawColor(255, 255, 255)
      surface.SetMaterial(matHueRing)
      surface.DrawTexturedRect(cx - radius, cy - radius, radius * 2, radius * 2)

      local pickerVerts = {
        {
          x = cx + self.triX * triRadius + 2,
          y = cy + self.triY * triRadius + 2,
          u = 1,
          v = 1
        },
        {
          x = cx + self.triX * triRadius - 2,
          y = cy + self.triY * triRadius + 2,
          u = 0,
          v = 1
        },
        {
          x = cx + self.triX * triRadius - 2,
          y = cy + self.triY * triRadius - 2,
          u = 0,
          v = 0
        },
        {
          x = cx + self.triX * triRadius + 2,
          y = cy + self.triY * triRadius - 2,
          u = 1,
          v = 0
        }
      }

      surface.SetDrawColor(255, 255, 255)
      surface.SetMaterial(matPicker)
      surface.DrawPoly(pickerVerts)

      local hpx = cx + math.cos(self.hue) * (radius - self:GetRingThickness() / 2)
      local hpy = cy + math.sin(self.hue) * (radius - self:GetRingThickness() / 2)

      local size = 8
      local huePickerVerts = {
        {
          x = hpx + size / 2,
          y = hpy + size / 2,
          u = 1,
          v = 1
        },
        {
          x = hpx - size / 2,
          y = hpy + size / 2,
          u = 0,
          v = 1
        },
        {
          x = hpx - size / 2,
          y = hpy - size / 2,
          u = 0,
          v = 0
        },
        {
          x = hpx + size / 2,
          y = hpy - size / 2,
          u = 1,
          v = 0
        }
      }
      surface.SetDrawColor(255, 255, 255)
      surface.SetMaterial(matPicker)
      surface.DrawPoly(huePickerVerts)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIColorPicker.__parent.__init(self, x, y, width, height)

      self.circular = true
      self.hue = 0
      self.smoothHue = 0

      self.interactable = true
      self.blocksHover = true

      self.lightness = 0
      self.saturation = 0

      self.triX = 0
      self.triY = 0

      self:UpdateColor()
      self:UpdatePositions()
    end,
    __base = _base_0,
    __name = "GUIColorPicker",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIColorPicker = _class_0
end

MetaSign.gui.Register("ColorPicker", GUIColorPicker)

return GUIColorPicker
