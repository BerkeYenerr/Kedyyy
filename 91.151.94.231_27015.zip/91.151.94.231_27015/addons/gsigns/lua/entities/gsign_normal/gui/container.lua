--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

do
  local PANEL = {}
  function PANEL:Init()
    local this = self

    self:Dock(FILL)
    self:SetVisible(false)
    self:SetPopupStayAtBack(true)

    self.text = vgui.Create("DTextEntry", self)
    self.text:SetVisible(false)

    self.text:RequestFocus()
    self.text.OnFocusChanged = function(self)
      self:RequestFocus()
    end
    self.text.OnChange = function(self)
      local text = self:GetText()
      self:SetText("")

      local focus = this:GetContainer():GetFocus()
      if focus then
        if focus.OnTextTyped then focus:OnTextTyped(text)end
      end
    end
    self.text.OnKeyCodeTyped = function(self, code)
      local focus = this:GetContainer():GetFocus()
      if focus then
        if focus.OnKeyCodeTyped then focus:OnKeyCodeTyped(code)end
      end
    end
  end

  function PANEL:AssignContainer(container)
    self.container = container
  end

  function PANEL:GetContainer()
    return self.container
  end

  function PANEL:OnMousePressed(code)
    if not self.container then return end

    self.container:OnPanelMousePressed(code)
  end

  function PANEL:OnMouseReleased(code)
    if not self.container then return end

    self.container:OnPanelMouseReleased(code)
  end

  function PANEL:OnMouseWheeled(delta)
    local element = self:GetContainer():GetHoveredElement()
    if element then
      element:OnMouseWheeled(delta)

      element:FindParents(function(parent)
        parent:OnMouseWheeled(delta)
      end)
    end
  end

  function PANEL:Think()
    if not self.container or not self.container:IsValid() then
      self:Remove()
      return
    end

    self:MoveToBack()
  end

  vgui.Register("MetaSign_OverlayPanel", PANEL, "EditablePanel")
end

local GUIContainer
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIContainer",
    __base = GUIObject.__base,
    IsValid = function(self)
      return self.removed or IsValid(self.entity)
    end,
    DialogOpened = function(self, element)
      if self.currentDialog then
        self.currentDialog:Close()
      end

      self.currentDialog = element
      self:OnDialogOpened(element)
    end,
    DialogClosed = function(self, element)
      self.currentDialog = nil

      self:OnDialogClosed(element)
    end,
    CloseDialog = function(self)
      if self.currentDialog then
        self.currentDialog:Close()
      end
    end,
    CreateMessageDialog = function(self, title, message, callback, width)
      if width == nil then width = 400
      end
      local dialog = MetaSign.gui.Create("MessageDialog", self, width, 0)
      dialog:SetTitle(title)
      dialog:SetText(message)
      dialog:SetDeleteOnClose(true)

      if callback then
        dialog.OnDialogResult = function(pnl, bool)
          callback(bool)
        end
      end

      return dialog
    end,
    OpenMessageDialog = function(self, title, message, callback, width)
      local dialog = self:CreateMessageDialog(title, message, callback, width)

      dialog:Open()

      return dialog
    end,
    ClearFocus = function(self)
      if self.currentFocus then
        self.currentFocus:SetFocus(false)
        self.currentFocus:OnFocusChangedInternal(false)
        self.currentFocus = nil
      end
    end,
    SetFocus = function(self, obj)
      if self.currentFocus ~= obj then
        self:ClearFocus()

        self.currentFocus = obj
        self.currentFocus:SetFocus(true)
        self.currentFocus:OnFocusChangedInternal(true)
      end
    end,
    GetFocus = function(self)
      return self.currentFocus
    end,
    EnableScreenClicker = function(self, bool)
      self.screenClicker = bool

      if IsValid(self.panel) then
        if bool then
          self.panel:SetVisible(bool)
          self.panel:MakePopup()
        else
          self.panel:Hide()
          self.mouseUseDown = false
        end
      end
    end,
    OnPanelMousePressed = function(self, code)
      if code == MOUSE_LEFT then
        self.mouseUseDown = true
      end
    end,
    OnPanelMouseReleased = function(self, code)
      if code == MOUSE_LEFT then
        self.mouseUseDown = false
      end
    end,
    OnClick = function(self) end,
    OnDialogOpened = function(self) end,
    OnDialogClosed = function(self) end,
    GetAimVector = function(self)
      if self.screenClicker then
        return gui.ScreenToVector(gui.MousePos())
      end

      local lp = LocalPlayer()
      return IsValid(lp) and lp:GetAimVector()
    end,
    ShouldPlayHoverSound = function(self)
      return false
    end,
    GetContainer = function(self)
      return self end,
    GetDialog = function(self)
      return self.currentDialog end,
    GetCursorPos = function(self)
      return self.entity.guiCursorPos
    end,
    GetHoveredElement = function(self)
      return self.hoverElement
    end,
    IsHovering = function(self)
      local focus = system.HasFocus()
      return focus and self.entity.guiIsHovering
    end,
    IsGUIHovered = function(self)
      return self.didHover
    end,
    IsScreenClickerEnabled = function(self)
      return self.screenClicker
    end,
    IsUseKeyDown = function(self)
      local lp = LocalPlayer()
      if not IsValid(lp) then return false end

      if not self.screenClicker then
        return lp:KeyDown(IN_USE) and not input.IsMouseDown(MOUSE_LEFT) and not input.IsMouseDown(MOUSE_RIGHT)

      else
        return self.mouseUseDown
      end
    end,
    AddChild = function(self, obj)
      local hasChild = self:HasChild(obj)
      if hasChild then return end

      self.children[#self.children + 1] = obj
      obj.container = self
      obj:SetParent(self, true)

      return obj
    end,
    RemoveInternal = function(self)
      GUIContainer.__parent.RemoveInternal(self)

      if self.screenClicker then
        self:EnableScreenClicker(false)
        if IsValid(self.panel) then
          self.panel:Remove()
        end
      end
    end,
    Think = function(self)
      if not self:IsValid() then
        self:Remove()
        return
      end

      local keyUseDown = self:IsUseKeyDown()
      local isClicking = keyUseDown and not self.prevKeyUseDown
      local prevDialog = self:GetDialog()

      self.didHover = false
      self.didClick = false
      self.hoverElement = nil

      if isClicking then
        self:OnClick()
      end

      self:ThinkChildren()

      if isClicking and not self.didClick then
        self:ClearFocus()
      end

      if isClicking then
        local dialog = self:GetDialog()
        if prevDialog and dialog and prevDialog == dialog and not dialog:IsHovering() then
          local shouldClose = true

          local hoveredElement = self:GetHoveredElement()
          if hoveredElement then
            hoveredElement:FindParents(function(parent)
              if parent == dialog then
                shouldClose = false

                return true
              end
            end)
          end

          if shouldClose then
            self:CloseDialog()
          end
        end
      end

      self.prevKeyUseDown = keyUseDown
    end,
    Paint = function(self)
      self:PaintChildren(self:GetAlpha())
      self:PaintOverChildren(self:GetAlpha())
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, entity)
      GUIContainer.__parent.__init(self, 0, 0, 0, 0)

      self.entity = entity

      self.didHover = false
      self.didClick = false

      self.screenClicker = false
      self.mouseUseDown = false

      self.panel = vgui.Create("MetaSign_OverlayPanel")
      self.panel:AssignContainer(self)

      self.currentFocus = nil
    end,
    __base = _base_0,
    __name = "GUIContainer",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIContainer = _class_0
end

MetaSign.gui.Register("Container", GUIContainer)

return GUIContainer
