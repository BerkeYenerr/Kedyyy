--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUIText = include("text.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

surface.CreateFont("MetaSign_GUI_ButtonText", {
  font = "Tahoma",
  antialias = true,
  size = 22,
  weight = 500
})

local GUIButton
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIButton",
    __base = GUIObject.__base,
    SetBackgroundColor = function(self, color)
      self.backgroundColor = color
    end,
    SetBorder = function(self, thickness)
      self.border = thickness
    end,
    GetBackgroundColor = function(self)
      return self.backgroundColor
    end,
    GetBorder = function(self)
      return self.border
    end,
    ShouldPlayHoverSound = function(self)
      return true
    end,
    Paint = function(self, w, h)
      self:PaintBackground(w, h)
    end,
    PaintBackgroundFocus = function(self, w, h)
      local cx, cy = self:GetCenter()
      local rad = self:GetRadius()

      surface.SetDrawColor(self.colorFocusBackground)
      drawCircle(cx, cy, rad + 8 * self.animFocusFraction, 24)
    end,
    PaintBackground = function(self, w, h)
      local cx, cy = self:GetCenter()
      local rad = self:GetRadius()
      local border = self:GetBorder()

      if border > 0 then
        surface.SetDrawColor(255, 255, 255)
        drawCircle(cx, cy, rad, 24)
      end

      surface.SetDrawColor(self:GetBackgroundColor())
      drawCircle(cx, cy, rad - border, 24)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIButton.__parent.__init(self, x, y, width, height)

      self.showClicks = true
      self.showHover = true
      self.interactable = true
      self.blocksHover = true
      self.circular = true

      self:SetBackgroundColor(Color(0, 0, 0))
      self:SetBorder(10)
    end,
    __base = _base_0,
    __name = "GUIButton",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIButton = _class_0
end

MetaSign.gui.Register("Button", GUIButton)

local GUITextButton
do
  local _class_0
  local _parent_0 = GUIText
  local _base_0 = {
    __name = "GUITextButton",
    __base = GUIText.__base,
    SetBackgroundColor = function(self, color)
      self.backgroundColor = color
    end,
    SetBorder = function(self, thickness)
      self.border = thickness
    end,
    GetBackgroundColor = function(self)
      return self.backgroundColor
    end,
    GetBorder = function(self)
      return self.border
    end,
    ShouldPlayHoverSound = function(self)
      return true
    end,
    PaintBackground = function(self, w, h)
      local border = self:GetBorder()

      local border = self:GetBorder()

      if border > 0 then
        surface.SetDrawColor(255, 255, 255)
        drawRoundedRect(h / 2, self.x, self.y, w, h, 16)
      end

      surface.SetDrawColor(self:GetBackgroundColor())
      drawRoundedRect(h / 2, self.x + border, self.y + border, w - border * 2, h - border * 2, 24)
    end,
    PaintBackgroundFocus = function(self, w, h)
      local cx, cy = self:GetCenter()
      local rad = self:GetRadius()

      local offset = 8 * self.animFocusFraction

      surface.SetDrawColor(self.colorFocusBackground)
      drawRoundedRect(h / 2, self.x - offset / 2, self.y - offset / 2, w + offset, h + offset, 24)
    end,
    PaintOverHoverEffect = function(self, w, h)
      local hborder = self:GetHoverBorder()
      local hox, hoy = self:GetHoverOrigin()
      local hw, hh = w + hborder, h + hborder

      surface.SetDrawColor(Color(255, 255, 255, self.alpha * 20 * self.hoverTime))
      drawRoundedRect(h / 2, hox - hw / 2, hoy - hh / 2, hw, hh, 16)
    end,
    Paint = function(self, w, h)
      local padding = self.padding

      local posX = self.x + w / 2
      if self.textAlign == TEXT_ALIGN_LEFT then
        posX = self.x + padding
      elseif self.textAlign == TEXT_ALIGN_RIGHT then
        posX = self.x + w - padding
      end

      local cx, cy = self:GetCenter()
      local tw, th = self:GetTextSize()

      draw.DrawText(self.visualText, self.font, posX, cy - th / 2, self.textColor, self.textAlign)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUITextButton.__parent.__init(self, x, y, "Button")

      self.showClicks = true
      self.showHover = true
      self.interactable = true
      self.blocksHover = true

      self:SetFont("MetaSign_GUI_ButtonText")
      self:SetPadding(10)
      self:SetTextAlignment(TEXT_ALIGN_CENTER)
      self:SetSize(width, height)
      self:SetBackgroundColor(Color(0, 0, 0))
      self:SetBorder(10)
    end,
    __base = _base_0,
    __name = "GUITextButton",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUITextButton = _class_0
end

MetaSign.gui.Register("TextButton", GUITextButton)

local GUIImageButton
do
  local _class_0
  local _parent_0 = GUIButton
  local _base_0 = {
    __name = "GUIImageButton",
    __base = GUIButton.__base,
    SetImage = function(self, img)
      self.image = img
      self:SetMaterial(Material(img))
    end,
    SetMaterial = function(self, mat)
      self.material = mat
    end,
    SetColor = function(self, color)
      self.color = color
    end,
    SetPadding = function(self, padding)
      self.padding = padding
    end,
    GetImage = function(self)
      return self.image
    end,
    GetMaterial = function(self)
      return self.material
    end,
    GetColor = function(self)
      return self.color
    end,
    GetPadding = function(self)
      return self.padding
    end,
    Paint = function(self, w, h)
      GUIImageButton.__parent.Paint(self, w, h)

      self:PaintImage(w, h)
    end,
    PaintBackground = function(self, w, h)
      GUIImageButton.__parent.PaintBackground(self, w, h)
    end,
    PaintImage = function(self, w, h)
      local mat = self:GetMaterial()

      if mat then
        local p = self.padding
        local cx, cy = self:GetCenter()

        surface.SetDrawColor(self.color)
        surface.SetMaterial(mat)
        surface.DrawTexturedRectRotated(cx, cy, w - p * 2, h - p * 2, self.rotation)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIImageButton.__parent.__init(self, x, y, width, height)

      self.padding = 0
      self.rotation = 0
      self:SetColor(Color(0, 0, 0))
    end,
    __base = _base_0,
    __name = "GUIImageButton",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIImageButton = _class_0
end

MetaSign.gui.Register("ImageButton", GUIImageButton)

return GUIButton, GUIImageButton
