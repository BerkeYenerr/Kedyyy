--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUIPanel = include("panel.lua")

surface.CreateFont("MetaSign_GUI_DialogText", {
  font = "Tahoma",
  antialias = true,
  size = 22,
  weight = 500
})

surface.CreateFont("MetaSign_GUI_DialogTitle", {
  font = "Tahoma",
  antialias = true,
  size = 26,
  weight = 500
})

local GUIDialog
do
  local _class_0
  local _parent_0 = GUIPanel
  local _base_0 = {
    __name = "GUIDialog",
    __base = GUIPanel.__base,
    SetDeleteOnClose = function(self, bool)
      self.deleteOnClose = bool
    end,
    Open = function(self)
      if self.opened then return end

      self:SetAlpha(0)
      self:SetVisible(true)

      self.opened = true

      local anim = self:NewUniqueAnimation("ShowAnim", self.animShowDuration)
      anim.prevFraction = self.animShowFraction
      anim:SetOnThinkCallback(function(self, anim, f)
        self.animShowFraction = Lerp(f, anim.prevFraction, 1)
        self:ThinkShowAnimation(anim, f)
      end)
      anim:SetOnEndCallback(function(self, anim)
        self:OnOpened()
      end)

      self:GetContainer():DialogOpened(self)
      self:OnOpening()
    end,
    Close = function(self)
      if not self.opened then return end

      self.opened = false

      local anim = self:NewUniqueAnimation("ShowAnim", self.animShowDuration)
      anim.prevFraction = self.animShowFraction
      anim:SetOnThinkCallback(function(self, anim, f)
        self.animShowFraction = Lerp(f, anim.prevFraction, 0)
        self:ThinkShowAnimation(anim, f)
      end)
      anim:SetOnEndCallback(function(self, anim)
        self:SetVisible(false)

        if self.deleteOnClose then
          self:Remove()
        end

        self:OnClosed()
      end)

      self:GetContainer():DialogClosed(self)
      self:OnClosing()
    end,
    OnOpening = function(self) end,
    OnOpened = function(self) end,
    OnClosed = function(self) end,
    OnClosing = function(self) end,
    ThinkShowAnimation = function(self, anim, f)
      local cx, cy = self:GetCenter()
      local f = self.animShowFraction

      local endX = -self:GetWidth() / 2
      local endY = -self:GetHeight() / 2

      local py = Lerp(f, endX, endY)

      self:SetPos(endX, math.Round(py * 100) / 100)

      self:SetAlpha(f)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, width, height)
      GUIDialog.__parent.__init(self, 0, 0, width, height)

      self:SetVisible(false)

      self.animShowDuration = 0.25
      self.animShowFraction = 0
      self.blocksHover = true

      self.deleteOnClose = false
    end,
    __base = _base_0,
    __name = "GUIDialog",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIDialog = _class_0
end

MetaSign.gui.Register("Dialog", GUIDialog)

local GUIMessageDialog
do
  local _class_0
  local _parent_0 = GUIDialog
  local _base_0 = {
    __name = "GUIMessageDialog",
    __base = GUIDialog.__base,
    Initialize = function(self)
      self.btnClose = MetaSign.gui.Create("ImageButton", self, 0, 0, 25, 25)
      self.btnClose:SetImage("gui/metamist/icons/delete")
      self.btnClose:SetPadding(4)
      self.btnClose:SetBorder(0)
      self.btnClose:SetBackgroundColor(Color(198, 40, 40))
      self.btnClose:SetColor(Color(255, 255, 255))
      self.btnClose:SetTooltip("Close")
      self.btnClose:SetTooltipAlignment(8)
      self.btnClose:SetVisible(false)
      self.btnClose:SetHoverBorder(4)
      self.btnClose.OnClick = function(btn, pos)
        self:Close()
      end

      self.btnConfirm = MetaSign.gui.Create("ImageButton", self, 0, 0, 40, 40)
      self.btnConfirm:SetImage("gui/metamist/icons/check")
      self.btnConfirm:SetPadding(4)
      self.btnConfirm:SetBorder(0)
      self.btnConfirm:SetBackgroundColor(MetaSign.utils.Hex2RGB("#7CB342"))
      self.btnConfirm:SetColor(Color(255, 255, 255))
      self.btnConfirm:SetTooltipAlignment(8)
      self.btnConfirm:SetVisible(false)
      self.btnConfirm:SetHoverBorder(5)
      self.btnConfirm.OnClick = function(pnl, pos)
        self:OnDialogResult(true)
        self:Close()
      end

      self.btnCancel = MetaSign.gui.Create("ImageButton", self, 0, 0, 40, 40)
      self.btnCancel:SetImage("gui/metamist/icons/delete")
      self.btnCancel:SetPadding(4)
      self.btnCancel:SetBorder(0)
      self.btnCancel:SetBackgroundColor(MetaSign.utils.Hex2RGB("#D32F2F"))
      self.btnCancel:SetColor(Color(255, 255, 255))
      self.btnCancel:SetTooltipAlignment(8)
      self.btnCancel:SetVisible(false)
      self.btnCancel:SetHoverBorder(5)
      self.btnCancel.OnClick = function(pnl, pos)
        self:OnDialogResult(false)
        self:Close()
      end

      self.label = MetaSign.gui.Create("Text", self, 0, 0)
      self.label:SetText("Dialog")
      self.label:SetTextColor(Color(0, 0, 0))
      self.label:SizeToContents()
      self.label:SetFont("MetaSign_GUI_DialogTitle")

      self.text = MetaSign.gui.Create("Text", self, 0, 0)
      self.text:SetTextColor(Color(0, 0, 0))
      self.text:SetWrap(true)
      self.text:SetText("text")
      self.text:SetFont("MetaSign_GUI_DialogText")

      self:SetHasConfirmButton(true)
      self:SetHasCloseButton(true)
    end,
    SetTitle = function(self, text)
      self.label:SetText(text)
    end,
    SetText = function(self, text)
      self.text:SetText(text)
    end,
    SetHasConfirmButton = function(self, bool)
      self.btnConfirm:SetVisible(bool)end,
    SetHasCancelButton = function(self, bool)
      self.btnCancel:SetVisible(bool)end,
    SetHasCloseButton = function(self, bool)
      self.btnClose:SetVisible(bool)end,
    SetConfirmTooltip = function(self, text)
      self.btnConfirm:SetTooltip(text)end,
    SetCancelTooltip = function(self, text)
      self.btnCancel:SetTooltip(text)end,
    GetTitle = function(self)
      return self.label:GetText()end,
    GetText = function(self)
      return self.text:GetText()end,
    OnDialogResult = function(self, bool) end,
    PerformLayout = function(self, w, h)
      local padding = self.padding

      local y = padding

      self.label:SizeToContents()
      self.label:SetPos(self.x + padding, self.y + y)

      if self.btnClose:IsVisible() then
        self.btnClose:SetPos(self.x + w - self.btnClose:GetWidth() - padding, self.y + y)
        y = y + math.max(self.btnClose:GetHeight(), self.label:GetHeight())
      else
        y = y + self.label:GetHeight()
      end

      y = y + 10

      self.text:SetPos(self.x + padding, self.y + y)
      self.text:SetWidth(w - padding * 2)
      self.text:SizeToContentsY()
      y = y + self.text:GetHeight()

      if self.btnCancel:IsVisible() or self.btnConfirm:IsVisible() then y = y + 10
      end

      self.btnConfirm:SetPos(self.x + w - self.btnConfirm:GetWidth() - padding, self.y + y)
      self.btnCancel:SetPos(self.btnConfirm.x - 10 - self.btnCancel:GetWidth(), self.y + y)

      if self.btnCancel:IsVisible() or self.btnConfirm:IsVisible() then y = y + math.max(self.btnCancel:GetHeight(), self.btnConfirm:GetHeight())
      end

      y = y + padding

      self:SetHeight(y)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, width, height)
      GUIMessageDialog.__parent.__init(self, width, height)

      self.padding = 15
    end,
    __base = _base_0,
    __name = "GUIMessageDialog",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIMessageDialog = _class_0
end

MetaSign.gui.Register("MessageDialog", GUIMessageDialog)

return GUIDialog
