--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUIDialog = include("dialog.lua")
local GUIText = include("text.lua")

local GUISettingsDialog
do
  local _class_0
  local _parent_0 = GUIDialog
  local _base_0 = {
    __name = "GUISettingsDialog",
    __base = GUIDialog.__base,
    Initialize = function(self)
      self.btnClose = MetaSign.gui.Create("ImageButton", self, 0, 0, 25, 25)
      self.btnClose:SetImage("gui/metamist/icons/delete")
      self.btnClose:SetPadding(4)
      self.btnClose:SetBorder(0)
      self.btnClose:SetBackgroundColor(MetaSign.utils.Hex2RGB("#D32F2F"))
      self.btnClose:SetColor(Color(255, 255, 255))
      self.btnClose:SetTooltip("Close")
      self.btnClose:SetTooltipAlignment(8)
      self.btnClose:SetHoverBorder(4)
      self.btnClose.OnClick = function(btn, pos)
        self:Close()
      end

      self.title = MetaSign.gui.Create("Text", self, 0, 0)
      self.title:SetText("Settings")
      self.title:SetFont("MetaSign_GUI_DialogTitle")
      self.title:SetTextColor(Color(0, 0, 0))
      self.title:SizeToContents()

      self.userLabel = MetaSign.gui.Create("Text", self, 0, 0)
      self.userLabel:SetText("Additional users")
      self.userLabel:SetFont("MetaSign_GUI_DialogText")
      self.userLabel:SetTextColor(Color(0, 0, 0))
      self.userLabel:SizeToContents()

      self.userList = MetaSign.gui.Create("List", self, 0, 0, 0, 0)
      self.userList:SetScrollColor(MetaSign.utils.Hex2RGB("#1E88E5"))
      self.userList:SetScrollBarColor(MetaSign.utils.Hex2RGB("#EDF1FB"))
      self.userList.OnSelectedItem = function(pnl, index, item)
        self.btnRemoveUser:SetDisabled(false)
      end
      self.userList.OnDeselect = function(pnl, index, item)
        self.btnRemoveUser:SetDisabled(true)
      end

      self.btnAddUser = MetaSign.gui.Create("TextButton", self, 0, 0, 130, 40)
      self.btnAddUser:SetBorder(0)
      self.btnAddUser:SetText("Add user")
      self.btnAddUser:SetBackgroundColor(MetaSign.utils.Hex2RGB("#1E88E5"))
      self.btnAddUser.OnClick = function(pnl)
        local text = self.userTextEntry:GetText()

        self:OnAddUser(text)
        self.userTextEntry:SetText("")
      end

      self.btnRemoveUser = MetaSign.gui.Create("ImageButton", self, 0, 0, 30, 30)
      self.btnRemoveUser:SetImage("gui/metamist/icons/clear")
      self.btnRemoveUser:SetPadding(4)
      self.btnRemoveUser:SetBorder(0)
      self.btnRemoveUser:SetBackgroundColor(MetaSign.utils.Hex2RGB("#D32F2F"))
      self.btnRemoveUser:SetColor(Color(255, 255, 255))
      self.btnRemoveUser:SetTooltip("Delete selected")
      self.btnRemoveUser:SetTooltipAlignment(8)
      self.btnRemoveUser:SetDisabled(true)
      self.btnRemoveUser:SetHoverBorder(0)
      self.btnRemoveUser.OnClick = function(pnl)
        local selected = self.userList:GetSelected()
        if selected then
          local user = selected._user
          if not user then return end

          self:OnRemoveUser(user)
        end
      end

      self.userTextEntry = MetaSign.gui.Create("TextEntry", self, 0, 0, 130, 40)
      self.userTextEntry:SetFocusColor(MetaSign.utils.Hex2RGB("#1E88E5"))
      self.userTextEntry:SetFocusBackgroundColor(ColorAlpha(MetaSign.utils.Hex2RGB("#EDF1FB"), 100))
      self.userTextEntry:SetBackgroundColor(MetaSign.utils.Hex2RGB("#EDF1FB"))
      self.userTextEntry:SetPlaceholder("User name...")
    end,
    SetUsers = function(self, users)
      self.userList:Clear()
      for k, user in pairs(users) do
        local node = self.userList:AddNode(user.name)
        node._user = user
      end
      self.btnRemoveUser:SetDisabled(true)
    end,
    OnAddUser = function(self, user) end,
    OnRemoveUser = function(self, user) end,
    Open = function(self)
      GUISettingsDialog.__parent.Open(self)
      self.userTextEntry:SetText("")
      self.btnRemoveUser:SetDisabled(true)
    end,
    PerformLayout = function(self, w, h)
      local padding = 10

      local y = padding

      self.btnClose:SetPos(self.x + w - self.btnClose:GetWidth() - padding, self.y + y)
      self.title:SetPos(self.x + padding, self.y + y)

      y = y + (math.max(self.title:GetHeight(), self.btnClose:GetHeight()) + 10)

      self.userLabel:SetPos(self.x + padding + 4, self.y + y)

      y = y + (self.userLabel:GetHeight() + 5)

      self.userList:SetPos(self.x + padding, self.y + y)
      self.userList:SetSize(w - padding * 2, h - y - 10 - self.btnAddUser:GetHeight() - padding)

      y = y + (self.userList:GetHeight() + 10)

      self.userTextEntry:SetPos(self.x + padding, self.y + y)
      self.userTextEntry:SetWidth(w - padding * 2 - self.btnAddUser:GetWidth() - self.btnRemoveUser:GetWidth() - 10 * 2)

      self.btnAddUser:SetPos(self.x + w - self.btnAddUser:GetWidth() - padding, self.y + y)
      self.btnRemoveUser:SetPos(self.btnAddUser.x - self.btnRemoveUser:GetWidth() - padding, self.y + y + 5)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, width, height)
      GUISettingsDialog.__parent.__init(self, width, height)
    end,
    __base = _base_0,
    __name = "GUISettingsDialog",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUISettingsDialog = _class_0
end

MetaSign.gui.Register("SettingsDialog", GUISettingsDialog)

return GUISettingsDialog
