--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

surface.CreateFont("MetaSign_GUI_Text", {
  font = "Tahoma",
  antialias = true,
  size = 26,
  weight = 500
})

local GUIText
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIText",
    __base = GUIObject.__base,
    SetText = function(self, text)
      self.text = text

      self:UpdateVisualText()
    end,
    GetText = function(self)
      return self.text
    end,
    SetFont = function(self, font)
      self.font = font

      self:UpdateVisualText()
    end,
    GetFont = function(self)
      return self.font
    end,
    SetWrap = function(self, bool)
      self.wrap = bool
    end,
    GetWrap = function(self)
      return self.wrap
    end,
    SetPadding = function(self, padding)
      self.padding = padding

      self:InvalidateLayout()
    end,
    GetPadding = function(self)
      return self.padding
    end,
    SetTextAlignment = function(self, align)
      self.textAlign = align
    end,
    GetTextAlignment = function(self)
      return self.textAlign
    end,
    SetTextColor = function(self, color)
      self.textColor = color
    end,
    GetTextColor = function(self)
      return self.textColor
    end,
    GetTextSize = function(self)
      surface.SetFont(self.font)
      return surface.GetTextSize(self.wrap and self.visualText or self.text)
    end,
    SizeToContents = function(self)
      self:SizeToContentsX()
      self:SizeToContentsY()
    end,
    SizeToContentsX = function(self)
      self:InvalidateLayout(true)

      local tw, th = self:GetTextSize()
      self:SetWidth(tw + self.padding * 2)
    end,
    SizeToContentsY = function(self)
      self:InvalidateLayout(true)

      local tw, th = self:GetTextSize()
      self:SetHeight(th + self.padding * 2)
    end,
    WrapWords = function(self, text)
      surface.SetFont(self.font)

      local tbl, len, Start, End = {}, string.len(text), 1, 1
      local iterations = 0

      while End < len and iterations < 10000 do
        End = End + 1
        iterations = iterations + 1

        if surface.GetTextSize(string.sub(text, Start, End)) > self.width - self.padding * 2 then
          local n = string.sub(text, End, End)
          local I = 0

          for i = 1, 15 do
            I = i
            if n ~= " " and n ~= "," and n ~= "." and n ~= "\n" then
              End = End - 1
              n = string.sub(text, End, End)
            else
              break
            end
          end

          if I == 15 then
            End = End + 14
          end

          local fnlStr = string.Trim(string.sub(text, Start, End))
          table.insert(tbl, fnlStr)
          Start = End + 1
        end
      end

      table.insert(tbl, string.sub(text, Start, End))
      return table.concat(tbl, "\n")
    end,
    ClipWords = function(self, text)
      surface.SetFont(self.font)

      local tw, th = surface.GetTextSize(text)
      if tw > self.width then
        for i = 1, #text - 1 do
          local sub = string.sub(text, 1, i + 1)
          if i < #text - 1 then sub = sub .. "..."
          end

          local tw, th = surface.GetTextSize(sub)

          if tw > self.width - self.padding * 2 then
            if i < #text - 1 then
              return string.sub(text, 1, i) .. "..."
            else
              return string.sub(text, 1, i)
            end
          end
        end
      end

      return text
    end,
    UpdateVisualText = function(self)
      if self.wrap then
        self.visualText = self:WrapWords(self.text)
      else
        self.visualText = self:ClipWords(self.text)
      end
    end,
    GetTextPos = function(self, w, h)
      local padding = self.padding

      local posX = self.x + w / 2
      if self.textAlign == TEXT_ALIGN_LEFT then
        posX = self.x + padding
      elseif self.textAlign == TEXT_ALIGN_RIGHT then
        posX = self.x + w - padding
      end

      return posX, self.y + padding
    end,
    PerformLayout = function(self, w, h)
      local padding = self.padding

      if w ~= self.prevW or h ~= self.prevH or padding ~= self.prevPadding then
        self:UpdateVisualText()

        self.prevW = w
        self.prevH = h
        self.prevPadding = padding
      end
    end,
    Paint = function(self, w, h)
      local posX, posY = self:GetTextPos(w, h)

      if self.text ~= "" then
        draw.DrawText(self.visualText, self.font, posX, posY, self.textColor, self.textAlign)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, text)
      if text == nil then text = ""
      end
      GUIText.__parent.__init(self, x, y, 0, 0)

      self.text = text
      self.font = "MetaSign_GUI_Text"
      self.wrap = false
      self.padding = 0
      self.textAlign = TEXT_ALIGN_LEFT
      self.textColor = Color(255, 255, 255)

      self:SizeToContentsY()
      self:UpdateVisualText()
    end,
    __base = _base_0,
    __name = "GUIText",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIText = _class_0
end

MetaSign.gui.Register("Text", GUIText)

return GUIText
