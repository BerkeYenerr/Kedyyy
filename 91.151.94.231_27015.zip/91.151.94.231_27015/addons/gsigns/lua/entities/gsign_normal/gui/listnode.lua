--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

local colGray = MetaSign.utils.Hex2RGB("#EEEEEE")
local colHighlight = MetaSign.utils.Hex2RGB("#1E88E5")

surface.CreateFont("MetaSign_GUI_ListEntry", {
  font = "Tahoma",
  antialias = true,
  size = 16,
  weight = 1000
})

local GUIListNode
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIListNode",
    __base = GUIObject.__base,
    Initialize = function(self)
      self.label = MetaSign.gui.Create("Text", self, 0, 0)
      self.label:SetText(self.text)
      self.label:SetFont("MetaSign_GUI_ListEntry")
      self.label:SetTextColor(Color(0, 0, 0))
      self.label:SizeToContentsY()
    end,
    SetText = function(self, text)
      self.text = text
      self.label:SetText(text)
      self.label:SizeToContentsY()
    end,
    SetIndex = function(self, index)
      self.index = index
    end,
    SetSelected = function(self, bool)
      self.selected = bool

      self:PlayAnimation()
    end,
    PlayAnimation = function(self)
      local anim = self:NewUniqueAnimation("SelectAnim", self.animDuration)
      anim.startAnimFraction = self.animFraction

      anim:SetOnThinkCallback(function(pnl, anim, f)
        self.animFraction = Lerp(f, anim.startAnimFraction, pnl.selected and 1 or 0)
      end)
    end,
    GetText = function(self, text)
      return self.text
    end,
    GetIndex = function(self)
      return self.index
    end,
    GetSelected = function(self)
      return self.selected
    end,
    PerformLayout = function(self, w, h)
      local cx, cy = self:GetCenter()

      self.label:SetPos(self.x + 10, cy - self.label:GetHeight() / 2)
      self.label:SetWidth(w - 20)
    end,
    Paint = function(self, w, h)
      if self:GetIndex() > 1 then
        surface.SetDrawColor(colGray)
        surface.DrawRect(self.x + 10, self.y, w - 20, 1)
      end
    end,
    PaintOver = function(self, w, h)
      local cx, cy = self:GetCenter()
      local sw = self.animFraction * w
      local sh = self.animFraction * h
      local rad = self.animFraction * 4
      surface.SetDrawColor(ColorAlpha(colHighlight, self.animFraction * 100))
      drawRoundedRect(rad, cx - sw / 2, cy - sh / 2, sw, sh, 20)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height, text)
      GUIListNode.__parent.__init(self, x, y, width, height)

      self.text = text or ""
      self.index = 0
      self.interactable = true

      self.animDuration = 0.15
      self.animTime = 0
      self.animFraction = 0
    end,
    __base = _base_0,
    __name = "GUIListNode",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIListNode = _class_0
end

MetaSign.gui.Register("ListNode", GUIListNode)

return GUIListNode
