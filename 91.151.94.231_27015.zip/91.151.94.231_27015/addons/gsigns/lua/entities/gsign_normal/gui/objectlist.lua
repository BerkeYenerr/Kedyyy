--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

surface.CreateFont("MetaSign_GUI_ObjectEntry", {
  font = "Tahoma",
  antialias = true,
  size = 16,
  weight = 1000
})

local GUIObjectEntry
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIObjectEntry",
    __base = GUIObject.__base,
    Initialize = function(self)
      self.btnDelete = MetaSign.gui.Create("ImageButton", self, 0, 0, 20, 20)
      self.btnDelete:SetImage("gui/metamist/icons/delete")
      self.btnDelete:SetPadding(2)
      self.btnDelete:SetColor(Color(255, 255, 255))
      self.btnDelete:SetHoverBorder(4)
      self.btnDelete.PaintBackground = function(btn, w, h)
        local cx, cy = btn:GetCenter()

        surface.SetDrawColor(198, 40, 40)
        drawCircle(cx, cy, btn:GetRadius(), 18)
      end
    end,
    PerformLayout = function(self, w, h)
      self.btnDelete:SetSize(h - 8, h - 8)
      self.btnDelete:SetPos(self.x + w - h + 4, self.y + 4)
    end,
    Paint = function(self, w, h)
      surface.SetDrawColor(255, 255, 255)
      drawRoundedRect(h / 2, self.x, self.y, w, h, 20)

      if self.text then
        draw.DrawText(self.text, "MetaSign_GUI_ObjectEntry", self.x + 10, self.y + h / 2 - 8, Color(0, 0, 0), TEXT_ALIGN_LEFT)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height, text)
      GUIObjectEntry.__parent.__init(self, x, y, width, height)

      self.text = text
    end,
    __base = _base_0,
    __name = "GUIObjectEntry",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIObjectEntry = _class_0
end

MetaSign.gui.Register("ObjectEntry", GUIObjectEntry)

local GUIObjectList
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIObjectList",
    __base = GUIObject.__base,
    Initialize = function(self)
      self.scrollBar = MetaSign.gui.Create("ScrollBar", self, self.x, self.y, 12, self.height, true)
      self.scrollBar:SetMinMax(0, 1)
      self.scrollBar.OnChange = function(scrollBar, value)
        self:InvalidateLayout()
      end
    end,
    SetObjects = function(self, tbl)
      self:ClearObjects()

      for i, v in ipairs(tbl) do
        self:AddObject(v)
      end
    end,
    AddObject = function(self, obj)
      local names = {
        spline = "Brush",
        line = "Line",
        rectangle = "Rectangle",
        ellipse = "Ellipse",
        text = "Text"
      }

      local index = #self.list + 1
      local entry = MetaSign.gui.Create("ObjectEntry", self, self.x, self.y, 40, 40, names[obj.type])
      entry.OnHover = function(btn)
        self:OnHoverItem(self:GetObjectIndex(obj), entry, obj)
      end
      entry.OnHoverEnter = function(btn)
        self:OnHoverEnterItem(self:GetObjectIndex(obj), entry, obj)
      end
      entry.OnHoverExit = function(btn)
        self:OnHoverExitItem(self:GetObjectIndex(obj), entry, obj)
      end

      entry.btnDelete.OnClick = function(btn)
        self:OnClickItemDelete(self:GetObjectIndex(obj), entry, obj)
      end

      entry.btnDelete.OnHover = function(btn)
        self:OnHoverItem(self:GetObjectIndex(obj), entry, obj)
      end
      entry.btnDelete.OnHoverEnter = function(btn)
        self:OnHoverEnterItem(self:GetObjectIndex(obj), entry, obj)
      end
      entry.btnDelete.OnHoverExit = function(btn)
        self:OnHoverExitItem(self:GetObjectIndex(obj), entry, obj)
      end

      self.list[index] = {
        entry = entry,
        obj = obj
      }

      self:InvalidateLayout()
    end,
    RemoveObject = function(self, index)
      local item = self.list[index]
      if not item then return end

      self:RemoveChild(item.entry)

      table.remove(self.list, index)

      self:InvalidateLayout()
    end,
    ClearObjects = function(self)
      for i, v in ipairs(self.list) do
        self:RemoveChild(v.entry)
      end

      self.list = {}
      self:InvalidateLayout()
    end,
    GetObjectIndex = function(self, obj)
      for i, v in ipairs(self.list) do
        if v.obj == obj then
          return i
        end
      end
    end,
    ShouldPlayHoverSound = function(self)
      return false
    end,
    OnClickPressed = function(self)
      return false
    end,
    OnHoverItem = function(self, index, item, obj) end,
    OnHoverEnterItem = function(self, index, item, obj) end,
    OnHoverExitItem = function(self, index, item, obj) end,
    OnClickItemDelete = function(self, index, item, obj) end,
    OnMouseWheeled = function(self, delta)
      self.scrollBar:AddLinearScroll(-delta * 20)
    end,
    PerformLayout = function(self, w, h)
      local totalHeight = #self.list * (self.itemHeight + self.itemOffset)
      local scrollHeight = math.max(totalHeight - self:GetHeight(), 0)
      local scroll = self.scrollBar:GetScroll()

      self.scrollBar:SetContentHeight(totalHeight)

      local y = 0
      for i, v in ipairs(self.list) do
        local entry = v.entry
        entry:SetPos(self.x + self.padding, self.padding + -scroll * scrollHeight + self.y + y)
        entry:SetSize(w - self.scrollBar:GetWidth() - self.padding * 2, self.itemHeight)

        local a = 1
        if entry.y < self.y then
          a = 1 - math.Clamp((self.y - entry.y) / self.itemHeight / 1.5, 0, 1)
        end
        if entry.y + entry:GetHeight() > self.y + self:GetHeight() then
          a = 1 - math.Clamp(((entry.y + entry:GetHeight()) - (self.y + self:GetHeight())) / self.itemHeight / 1.5, 0, 1)
        end
        entry:SetAlpha(a)

        y = y + (self.itemHeight + self.itemOffset)
      end

      self.scrollBar:SetPos(self.x + w - self.scrollBar:GetWidth(), self.y)
      self.scrollBar:SetHeight(h)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIObjectList.__parent.__init(self, x, y, width, height)

      self.list = {}
      self.itemHeight = 25
      self.itemOffset = 10
      self.padding = 5
    end,
    __base = _base_0,
    __name = "GUIObjectList",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIObjectList = _class_0
end

MetaSign.gui.Register("ObjectList", GUIObjectList)

return GUIObjectList
