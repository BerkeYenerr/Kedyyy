--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUISlider = include("slider.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

local GUIScrollBar
do
  local _class_0
  local _parent_0 = GUISlider
  local _base_0 = {
    __name = "GUIScrollBar",
    __base = GUISlider.__base,
    SetContentHeight = function(self, value)
      self.contentHeight = value
      self:InvalidateLayout()
    end,
    SetScroll = function(self, value)
      self:SetValue(value)
    end,
    AddLinearScroll = function(self, value)
      self:SetScroll(self:GetScroll() + value / self:GetContentHeight())
    end,
    GetScroll = function(self)
      return self.sliderVal end,
    GetContentHeight = function(self)
      return self.contentHeight end,
    GetScrollBarFraction = function(self)
      local contentHeight = self:GetContentHeight()
      return self:GetHeight() / contentHeight
    end,
    PerformLayout = function(self, w, h)
      local contentHeight = self:GetContentHeight()

      self.grabHeight = math.Clamp(h / contentHeight, 0, 1) * h

      if self:GetScrollBarFraction() >= 1 then
        self:SetScroll(0)
      end
    end,
    Think = function(self)
      GUIScrollBar.__parent.Think(self)

      local fract = self:GetScrollBarFraction()

      if fract >= 1 then
        self:SetGrabAlpha(Lerp(0.1, self:GetGrabAlpha(), 0))
      else
        self:SetGrabAlpha(Lerp(0.1, self:GetGrabAlpha(), 1))
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIScrollBar.__parent.__init(self, x, y, width, height, true)

      self.contentHeight = 0

      self:SetMinMax(0, 1)
    end,
    __base = _base_0,
    __name = "GUIScrollBar",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIScrollBar = _class_0
end

MetaSign.gui.Register("ScrollBar", GUIScrollBar)

return GUIScrollBar
