--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")

local drawCircle = MetaSign.surface.DrawCircle

local GUIList
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUIList",
    __base = GUIObject.__base,
    Initialize = function(self)
      self.scrollBar = MetaSign.gui.Create("ScrollBar", self, self.x, self.y, 12, self.height, true)
      self.scrollBar.OnChange = function(scrollBar, value)
        self:InvalidateLayout()
      end
    end,
    SetScrollColor = function(self, color)
      self.scrollBar:SetColor(color)end,
    SetScrollBarColor = function(self, color)
      self.scrollBar:SetBarColor(color)end,
    SetSelectable = function(self, bool)
      self.selectable = bool end,
    GetScrollColor = function(self)
      return self.scrollBar:GetColor()end,
    GetScrollBarColor = function(self)
      return self.scrollBar:GetBarColor()end,
    GetNodeIndex = function(self, node)
      for i, v in ipairs(self.list) do
        if v == node then
          return i
        end
      end
    end,
    GetSelected = function(self)
      return self.lastSelected end,
    IsSelectable = function(self)
      return self.selectable end,
    OnHoverNode = function(self, index, node) end,
    OnHoverEnterNode = function(self, index, node) end,
    OnHoverExitNode = function(self, index, node) end,
    OnClickNode = function(self, index, node)
      if not self.selectable then return end

      if self.lastSelected and self.lastSelected ~= node then
        self.lastSelected:SetSelected(false)
      end

      local selected = not node:GetSelected()
      node:SetSelected(not node:GetSelected())

      if selected then
        self:OnSelectedItem(index, node)
        self.lastSelected = node
      else
        self:OnDeselect()
        self.lastSelected = nil
      end
    end,
    OnSelectedItem = function(self, index, item) end,
    OnDeselect = function(self) end,
    OnMouseWheeled = function(self, delta)
      self.scrollBar:AddLinearScroll(-delta * 20)

    end,
    Deselect = function(self)
      if self.lastSelected then
        self.lastSelected:SetSelected(false)
      end

      self.lastSelected = nil
    end,
    Clear = function(self)
      self:Deselect()

      for i, node in pairs(self.list) do
        node:Remove()
      end

      self.list = {}
    end,
    AddNode = function(self, text)
      local index = #self.list + 1
      local node = MetaSign.gui.Create("ListNode", self, self.x, self.y, 40, 40, text)
      node:SetIndex(index)

      node.OnHover = function(node)
        self:OnHoverNode(self:GetNodeIndex(node), node)
      end
      node.OnHoverEnter = function(node)
        self:OnHoverEnterNode(self:GetNodeIndex(node), node)
      end
      node.OnHoverExit = function(node)
        self:OnHoverExitNode(self:GetNodeIndex(node), node)
      end
      node.OnClick = function(node)
        self:OnClickNode(self:GetNodeIndex(node), node)
      end

      self.list[index] = node

      self:InvalidateLayout()

      return node
    end,
    GetTotalHeight = function(self)
      return #self.list * (self.itemHeight + self.itemOffset)
    end,
    PerformLayout = function(self, w, h)
      local iMargin = self.itemMargin

      local scrollHeight = math.max(self:GetTotalHeight() - self.scrollBar:GetHeight(), 0)
      local scroll = self.scrollBar:GetScroll()

      self.scrollBar:SetContentHeight(self:GetTotalHeight())

      local y = 0
      for i, node in ipairs(self.list) do
        node:SetPos(self.x + iMargin.left, iMargin.top + -scroll * scrollHeight + self.y + y + self.itemHeight)
        node:SetSize(w - self.scrollBar:GetWidth() - iMargin.left - iMargin.right, self.itemHeight)

        local a = 1
        if node.y < self.y + self.itemHeight then
          a = 1 - math.Clamp((self.y - node.y + self.itemHeight) / self.itemHeight, 0, 1)
        end
        if node.y + node:GetHeight() > self.y + self:GetHeight() - self.itemHeight then
          a = 1 - math.Clamp(((node.y + node:GetHeight()) - (self.y + self:GetHeight() - self.itemHeight)) / self.itemHeight, 0, 1)
        end
        node:SetAlpha(a)

        y = y + (self.itemHeight + self.itemOffset)
      end

      self.scrollBar:SetPos(self.x + w - self.scrollBar:GetWidth(), self.y + self.itemHeight)
      self.scrollBar:SetHeight(h - self.itemHeight * 2)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height)
      GUIList.__parent.__init(self, x, y, width, height)

      self.list = {}
      self.itemHeight = 25
      self.itemOffset = 0
      self.selectable = true
      self.itemMargin = {
        top = 0,
        right = 5,
        bottom = 0,
        left = 0
      }
    end,
    __base = _base_0,
    __name = "GUIList",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIList = _class_0
end

MetaSign.gui.Register("List", GUIList)

return GUIList
