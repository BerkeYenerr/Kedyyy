--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUIDialog = include("dialog.lua")

local GUIFileDialog
do
  local _class_0
  local _parent_0 = GUIDialog
  local _base_0 = {
    __name = "GUIFileDialog",
    __base = GUIDialog.__base,
    Initialize = function(self)
      self.list = MetaSign.gui.Create("List", self, 0, 0, 0, 0)
      self.list:SetScrollColor(MetaSign.utils.Hex2RGB("#1E88E5"))
      self.list:SetScrollBarColor(MetaSign.utils.Hex2RGB("#EDF1FB"))
      self.list.OnSelectedItem = function(pnl, index, item)
        self.textEntry:SetText(item:GetText())
        self.btnDelete:SetDisabled(false)
      end
      self.list.OnDeselect = function(pnl, index, item)
        self.btnDelete:SetDisabled(true)
      end

      self.btnClose = MetaSign.gui.Create("ImageButton", self, 0, 0, 25, 25)
      self.btnClose:SetImage("gui/metamist/icons/delete")
      self.btnClose:SetPadding(4)
      self.btnClose:SetBorder(0)
      self.btnClose:SetBackgroundColor(MetaSign.utils.Hex2RGB("#D32F2F"))
      self.btnClose:SetColor(Color(255, 255, 255))
      self.btnClose:SetTooltip("Close")
      self.btnClose:SetTooltipAlignment(8)
      self.btnClose:SetHoverBorder(4)
      self.btnClose.OnClick = function(btn, pos)
        self:Close()
      end

      self.btnConfirm = MetaSign.gui.Create("ImageButton", self, 0, 0, 40, 40)
      self.btnConfirm:SetImage("gui/metamist/icons/check")
      self.btnConfirm:SetPadding(4)
      self.btnConfirm:SetBorder(0)
      self.btnConfirm:SetBackgroundColor(MetaSign.utils.Hex2RGB("#7CB342"))
      self.btnConfirm:SetColor(Color(255, 255, 255))
      self.btnConfirm:SetTooltip("Confirm")
      self.btnConfirm:SetTooltipAlignment(8)
      self.btnConfirm:SetHoverBorder(5)
      self.btnConfirm.OnClick = function(pnl, pos)
        local text = self.textEntry:GetText()

        local result = self:OnConfirm(text, self.save)
        if result ~= false then self:Close()end
      end

      self.btnDelete = MetaSign.gui.Create("ImageButton", self, 0, 0, 30, 30)
      self.btnDelete:SetImage("gui/metamist/icons/clear")
      self.btnDelete:SetPadding(4)
      self.btnDelete:SetBorder(0)
      self.btnDelete:SetBackgroundColor(MetaSign.utils.Hex2RGB("#D32F2F"))
      self.btnDelete:SetColor(Color(255, 255, 255))
      self.btnDelete:SetTooltip("Delete selected")
      self.btnDelete:SetTooltipAlignment(8)
      self.btnDelete:SetDisabled(true)
      self.btnDelete:SetHoverBorder(0)
      self.btnDelete.OnClick = function(pnl, pos)
        local selected = self.list:GetSelected()
        if selected then
          self:OnDelete(selected:GetText(), self.save)
          self:Close()
        end
      end

      self.label = MetaSign.gui.Create("Text", self, 0, 0)
      self.label:SetText("File Browser")
      self.label:SetFont("MetaSign_GUI_DialogTitle")
      self.label:SetTextColor(Color(0, 0, 0))
      self.label:SizeToContents()

      self.textEntry = MetaSign.gui.Create("TextEntry", self, 0, 0, 200, 40)
      self.textEntry:SetFocusColor(MetaSign.utils.Hex2RGB("#1E88E5"))
      self.textEntry:SetFocusBackgroundColor(ColorAlpha(MetaSign.utils.Hex2RGB("#EDF1FB"), 100))
      self.textEntry:SetBackgroundColor(MetaSign.utils.Hex2RGB("#EDF1FB"))
    end,
    Open = function(self, save)
      self.save = save

      self:LoadFiles()

      self.textEntry:SetVisible(save)
      self.textEntry:SetText("")
      self.label:SetText(save and "Save drawing" or "Load drawing")
      self.label:SizeToContents()
      self.list.scrollBar:SetScroll(0)

      self.btnDelete:SetDisabled(true)
      self.list:Deselect()

      GUIFileDialog.__parent.Open(self)
    end,
    OnConfirm = function(self, text, saving) end,
    OnDelete = function(self, text, saving) end,
    LoadFiles = function(self)
      local files = MetaSign.saving.GetFiles()

      self.list:Clear()
      for i, file in pairs(files) do
        local extIndex = string.find(file, ".", -string.len(file), true)
        local name = string.sub(file, 1, extIndex - 1)

        self.list:AddNode(name)
      end
    end,
    PerformLayout = function(self, w, h)
      local padding = 10
      self.list:SetPos(self.x + padding, self.y + padding + self.btnClose:GetHeight() + 4)
      self.list:SetSize(w - padding * 2, h - padding * 2 - self.btnClose:GetHeight() - self.btnConfirm:GetHeight() - 4 * 2)

      self.btnClose:SetPos(self.x + w - self.btnClose:GetWidth() - padding, self.y + padding)
      self.btnConfirm:SetPos(self.x + w - self.btnConfirm:GetWidth() - padding, self.y + h - self.btnConfirm:GetHeight() - padding)
      self.btnDelete:SetPos(self.btnConfirm.x - 10 - self.btnDelete:GetWidth(), self.y + h - self.btnDelete:GetHeight() - padding - 5)

      self.label:SetPos(self.x + padding, self.y + padding)

      self.textEntry:SetPos(self.x + padding, self.y + h - self.textEntry:GetHeight() - padding)
      self.textEntry:SetSize(w - padding * 2 - self.btnDelete:GetWidth() - 10 - self.btnConfirm:GetWidth() - 10)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, width, height)
      GUIFileDialog.__parent.__init(self, width, height)
    end,
    __base = _base_0,
    __name = "GUIFileDialog",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUIFileDialog = _class_0
end

MetaSign.gui.Register("FileDialog", GUIFileDialog)

return GUIFileDialog
