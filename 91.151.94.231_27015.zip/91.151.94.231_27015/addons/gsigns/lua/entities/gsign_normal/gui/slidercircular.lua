--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUIButton = include("button.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

local GUISliderCircular
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUISliderCircular",
    __base = GUIObject.__base,
    SetMinMax = function(self, min, max)
      self.minValue = min
      self.maxValue = max

      self:OnChange(self:GetValue())
    end,
    SetValue = function(self, val)
      local fract = (val - self.minValue) / (self.maxValue - self.minValue)
      self:SetFraction(fract)
    end,
    SetFraction = function(self, fract)
      self.sliderVal = math.Clamp(fract, 0, 1)
      self:OnChange(self:GetValue())
    end,
    SetGrabberColor = function(self, col)
      self.grabberColor = col
    end,
    GetMinValue = function(self)
      return self.minValue end,
    GetMaxValue = function(self)
      return self.maxValue end,
    GetFraction = function(self)
      return self.sliderVal
    end,
    GetValue = function(self)
      return self.minValue + self.sliderVal * (self.maxValue - self.minValue)
    end,
    GetGrabberColor = function(self)
      return self.grabberColor
    end,
    GetSliderGrabPos = function(self)
      local cx, cy = self:GetCenter()

      if self.vertical then
        return Vector(cx, self.y + self.sliderVal * self.height, 0)
      else
        return Vector(self.x + self.sliderVal * self.width, cy, 0)
      end
    end,
    GetSliderGrabPosSmooth = function(self)
      local cx, cy = self:GetCenter()

      if self.vertical then
        return Vector(cx, self.y + self.smoothVal * self.height, 0)
      else
        return Vector(self.x + self.smoothVal * self.width, cy, 0)
      end
    end,
    OnClickPressed = function(self, cursorPos)
      local cx, cy = self:GetCenter()
      local grabPos = self:GetSliderGrabPos()

      if cursorPos:Distance(grabPos) < self.grabberSize then
        self.dragStart = cursorPos
        self.dragging = true
        self.sliderValStart = self:GetFraction()
      else
        if self.vertical then
          self:SetFraction((cursorPos.y - self.y) / self.height)
        else
          self:SetFraction((cursorPos.x - self.x) / self.width)
        end
      end
    end,
    OnClickReleased = function(self, cursorPos)
      self.dragging = false
    end,
    IsHovering = function(self)
      local cursorPos = self:GetCursorPos()
      local grabPos = self:GetSliderGrabPos()

      if self.dragging then return true end
      if cursorPos:Distance(grabPos) < self.grabberSize + 16 then
        return true
      end

      return GUISliderCircular.__parent.IsHovering(self)
    end,
    ShouldPlayHoverSound = function(self)
      return not self.dragging
    end,
    GetTooltipPosition = function(self)
      local cx, cy = self:GetCenter()
      local grabPos = self:GetSliderGrabPosSmooth()

      return grabPos.x, grabPos.y
    end,
    GetTooltipOffset = function(self)
      return self.grabberSize, self.grabberSize
    end,
    OnChange = function(self, value) end,
    Think = function(self)
      local cursorPos = self:GetCursorPos()

      if self.dragging then
        local diff = cursorPos - self.dragStart

        if self.vertical then
          self:SetFraction(math.Clamp(self.sliderValStart + diff.y / self.height, 0, 1))
        else
          self:SetFraction(math.Clamp(self.sliderValStart + diff.x / self.width, 0, 1))
        end
      end

      self.smoothVal = Lerp(0.2, self.smoothVal, self.sliderVal)
    end,
    GetHoverOrigin = function(self)
      local grabPos = self:GetSliderGrabPosSmooth()

      return grabPos.x, grabPos.y
    end,
    GetHoverRadius = function(self)
      local grabPos = self:GetSliderGrabPosSmooth()
      local cx, cy = self:GetCenter()

      return self.grabberSize + 16
    end,
    PaintBackgroundFocus = function(self, w, h)
      local radius = self.grabberSize
      local grabPos = self:GetSliderGrabPosSmooth()

      surface.SetDrawColor(self.colorFocusBackground)
      drawCircle(grabPos.x, grabPos.y, radius + 8 * self.animFocusFraction, 24)
    end,
    PaintBackground = function(self, w, h)
      local cx, cy = self:GetCenter()
      local thickness = 12

      surface.SetDrawColor(255, 255, 255)

      if self.vertical then
        drawRoundedRect(thickness / 2, cx - thickness / 2, self.y, thickness, self.height)
      else
        drawRoundedRect(thickness / 2, self.x, cy - thickness / 2, self.width, thickness)
      end
    end,
    Paint = function(self, w, h)
      local radius = self.grabberSize
      local grabPos = self:GetSliderGrabPosSmooth()

      surface.SetDrawColor(255, 255, 255)
      drawCircle(grabPos.x, grabPos.y, radius, 24)
      surface.SetDrawColor(self:GetGrabberColor())
      drawCircle(grabPos.x, grabPos.y, radius - 10, 24)
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height, vertical)
      if vertical == nil then vertical = false
      end
      GUISliderCircular.__parent.__init(self, x, y, width, height)

      self.vertical = vertical

      self.sliderVal = 0

      self.maxValue = 100
      self.minValue = 0

      self.interactable = true
      self.blocksHover = true

      self.smoothVal = 0
      self.showHover = true
      self.showClicks = true

      if self.vertical then
        self.grabberSize = self.width / 2
        self:SetTooltipAlignment(6)
      else
        self.grabberSize = self.height / 2
        self:SetTooltipAlignment(2)
      end

      self:SetGrabberColor(Color(0, 0, 0))
      self:OnChange(0)
    end,
    __base = _base_0,
    __name = "GUISliderCircular",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUISliderCircular = _class_0
end

MetaSign.gui.Register("SliderCircular", GUISliderCircular)

return GUISliderCircular
