--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local GUIObject = include("base.lua")
local GUIButton = include("button.lua")

local drawCircle = MetaSign.surface.DrawCircle
local drawRoundedRect = MetaSign.surface.DrawRoundedRect

local GUISlider
do
  local _class_0
  local _parent_0 = GUIObject
  local _base_0 = {
    __name = "GUISlider",
    __base = GUIObject.__base,
    SetColor = function(self, color)
      self.color = color end,
    SetBarColor = function(self, color)
      self.colorBar = color end,
    SetGrabAlpha = function(self, alpha)
      self.alphaGrab = alpha end,
    SetMinMax = function(self, min, max)
      self.minValue = min
      self.maxValue = max

      self:InvalidateLayout()
      self:OnChange(self:GetValue())
    end,
    GetColor = function(self)
      return self.color end,
    GetBarColor = function(self)
      return self.colorBar end,
    GetGrabAlpha = function(self)
      return self.alphaGrab end,
    GetMinValue = function(self)
      return self.minValue end,
    GetMaxValue = function(self)
      return self.maxValue end,
    GetFraction = function(self)
      return self.sliderVal
    end,
    GetValue = function(self)
      return self.minValue + self.sliderVal * (self.maxValue - self.minValue)
    end,
    SetValue = function(self, val)
      local fract = (val - self.minValue) / (self.maxValue - self.minValue)
      self:SetFraction(fract)
    end,
    SetFraction = function(self, fract)
      self.sliderVal = math.Clamp(fract, 0, 1)
      self:InvalidateLayout()
      self:OnChange(self:GetValue())
    end,
    GetSliderGrabPos = function(self)
      local cx, cy = self:GetCenter()

      if self.vertical then
        return Vector(cx, self.y + self.sliderVal * (self.height - self.grabHeight), 0)
      else
        return Vector(self.x + self.sliderVal * (self.width - self.grabWidth), cy, 0)
      end
    end,
    GetSliderGrabPosSmooth = function(self)
      local cx, cy = self:GetCenter()

      if self.vertical then
        return Vector(cx, self.y + self.smoothVal * (self.height - self.grabHeight), 0)
      else
        return Vector(self.x + self.smoothVal * (self.width - self.grabWidth), cy, 0)
      end
    end,
    OnClickPressed = function(self, cursorPos)
      local cx, cy = self:GetCenter()
      local grabPos = self:GetSliderGrabPos()

      if self:IsHoveringGrabber() then
        self.dragStart = cursorPos
        self.dragging = true
        self.sliderValStart = self:GetFraction()
      else
        if self.vertical then
          self:SetFraction((cursorPos.y - self.y - self.grabHeight / 2) / (self.height - self.grabHeight))
        else
          self:SetFraction((cursorPos.x - self.x - self.grabWidth / 2) / (self.width - self.grabWidth))
        end
      end
    end,
    OnClickReleased = function(self, cursorPos)
      self.dragging = false
    end,
    IsHovering = function(self)
      local cursorPos = self:GetCursorPos()
      local grabPos = self:GetSliderGrabPos()

      if self.dragging then return true end

      if self:IsHoveringGrabber() then
        return true
      end

      return GUISlider.__parent.IsHovering(self)
    end,
    IsHoveringGrabber = function(self)
      local cursorPos = self:GetCursorPos()
      local grabPos = self:GetSliderGrabPos()
      local w, h = self.grabWidth, self.grabHeight

      return cursorPos.x >= grabPos.x - w / 2 and cursorPos.x < grabPos.x + w / 2 and cursorPos.y >= grabPos.y and cursorPos.y < grabPos.y + h
    end,
    ShouldPlayHoverSound = function(self)
      return not self.dragging
    end,
    GetTooltipPosition = function(self)
      local cx, cy = self:GetCenter()
      local grabPos = self:GetSliderGrabPosSmooth()

      return grabPos.x + self.grabWidth / 2, grabPos.y + self.grabHeight / 2
    end,
    GetTooltipOffset = function(self)
      return 0, 0
    end,
    OnChange = function(self, value) end,
    Think = function(self)
      local cursorPos = self:GetCursorPos()

      if self.dragging then
        local diff = cursorPos - self.dragStart

        if self.vertical then
          local max = self.height - self.grabHeight
          if max > 0 then
            self:SetFraction(math.Clamp(self.sliderValStart + diff.y / max, 0, 1))
          end
        else
          local max = self.width - self.grabWidth
          if max > 0 then
            self:SetFraction(math.Clamp(self.sliderValStart + diff.x / max, 0, 1))
          end
        end
      end
    end,
    GetHoverOrigin = function(self)
      local grabPos = self:GetSliderGrabPosSmooth()

      return grabPos.x + self.grabWidth / 2, grabPos.y + self.grabHeight / 2
    end,
    GetHoverRadius = function(self)
      local grabPos = self:GetSliderGrabPosSmooth()
      local cx, cy = self:GetCenter()

      return math.sqrt(self.grabWidth * self.grabWidth + self.grabHeight * self.grabHeight) / 2 + 16
    end,
    GetHoverRelativeClickPos = function(self)
      return 0, 0
    end,
    PaintInternal = function(self, w, h)
      GUISlider.__parent.PaintInternal(self, w, h)

      local elapsed = RealFrameTime()

      self.smoothVal = Lerp(20 * elapsed, self.smoothVal, self.sliderVal)
      self.smoothGrabWidth = Lerp(20 * elapsed, self.smoothGrabWidth, self.grabWidth)
      self.smoothGrabHeight = Lerp(20 * elapsed, self.smoothGrabHeight, self.grabHeight)

      self:PaintGrabber(w, h)
    end,
    Paint = function(self, w, h)
      local cx, cy = self:GetCenter()

      surface.SetDrawColor(self:GetBarColor())
      drawRoundedRect(4, self.x, self.y, self.width, self.height)
    end,
    PaintGrabber = function(self, w, h)
      local grabPos = self:GetSliderGrabPosSmooth()
      local gw, gh = self.smoothGrabWidth, self.smoothGrabHeight

      surface.SetDrawColor(ColorAlpha(self:GetColor(), self:GetGrabAlpha() * 255))
      if self.vertical then
        drawRoundedRect(4, grabPos.x - gw / 2, grabPos.y, gw, gh)
      else
        drawRoundedRect(4, grabPos.x, grabPos.y - gh, gw, gh)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height, vertical)
      if vertical == nil then vertical = false
      end
      GUISlider.__parent.__init(self, x, y, width, height)

      self.vertical = vertical

      self.sliderVal = 0

      self.maxValue = 100
      self.minValue = 0

      self.interactable = true
      self.blocksHover = true

      self.smoothVal = 0
      self.showHover = false
      self.showClicks = false

      if self.vertical then
        self.grabWidth = self.width
        self.grabHeight = self.height / 10
        self:SetTooltipAlignment(6)
      else
        self.grabWidth = self.width / 10
        self.grabHeight = self.height
        self:SetTooltipAlignment(2)
      end

      self.smoothGrabWidth = self.grabWidth
      self.smoothGrabHeight = self.grabHeight

      self:SetGrabAlpha(1)
      self:SetColor(Color(255, 255, 255))
      self:SetBarColor(Color(255, 255, 255, 40))
      self:InvalidateLayout()
      self:OnChange(0)
    end,
    __base = _base_0,
    __name = "GUISlider",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  GUISlider = _class_0
end

MetaSign.gui.Register("Slider", GUISlider)

return GUISlider
