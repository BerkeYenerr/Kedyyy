--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.surface = MetaSign.surface or {}

local oldRT, oldScrW, oldScrH, oldTex

local matLogo = Material("gui/metamist/logo-white")

surface.CreateFont("MDevTemp1", {
  font = "Tahoma",
  antialias = true,
  size = 80,
  weight = 500
})

function MetaSign.surface.DrawEllipse(sx, sy, sw, sh, vertexCount, bOutline, thickness, angle)
  local vertices = {}
  local ang = -math.rad(angle or 0)
  local c = math.cos(ang)
  local s = math.sin(ang)
  for i = 0, 360, 360 / vertexCount do
    local radd = math.rad(i)
    local x = math.cos(radd)
    local y = math.sin(radd)

    local tempx = x * sw / 2 * c - y * sh * s + sx
    y = x * sw * s + y * sh / 2 * c + sy
    x = tempx

    vertices[#vertices + 1] = {
      x = x, y = y, u = u, v = v}
  end

  if bOutline == true then
    local n = #vertices
    for i = 1, n do
      local v = vertices[i]
      if i + 1 <= n then
        local x, y = v.x, v.y
        local x2, y2 = vertices[i + 1].x, vertices[i + 1].y
        drawLine(x, y, x2, y2, thickness)
      end
    end

    drawLine(vertices[n].x, vertices[n].y, vertices[1].x, vertices[1].y, thickness)
  else
    if vertices and #vertices > 0 then
      draw.NoTexture()
      surface.DrawPoly(vertices)
    end
  end
end

function MetaSign.surface.DrawCircle(sx, sy, radius, vertexCount, bOutline, thickness, angle)
  MetaSign.surface.DrawEllipse(sx, sy, radius * 2, radius * 2, vertexCount, bOutline, thickness, angle)
end

function MetaSign.surface.DrawRoundedRect(radius, x, y, w, h, vertexCount)
  if vertexCount == nil then vertexCount = 4
  end
  if w <= 0 or h <= 0 then return end

  vertexCount = math.max(math.ceil(vertexCount / 4), 3)
  radius = math.Clamp(radius, 0, math.min(w, h))
  radius = math.min(radius, math.min(w, h) / 2)

  local verts = {}

  for i = 0, vertexCount do
    local a = (1 - (i / vertexCount)) * math.pi / 2

    verts[#verts + 1] = {
      x = x + w - radius + math.cos(a) * radius,
      y = y + radius - math.sin(a) * radius
    }
  end


  for i = 0, vertexCount do
    local a = (-(i / vertexCount)) * math.pi / 2

    verts[#verts + 1] = {
      x = x + w - radius + math.cos(a) * radius,
      y = y + h - radius - math.sin(a) * radius
    }
  end


  for i = 0, vertexCount do
    local a = (3 - (i / vertexCount)) * math.pi / 2

    verts[#verts + 1] = {
      x = x + radius + math.cos(a) * radius,
      y = y + h - radius - math.sin(a) * radius
    }
  end


  for i = 0, vertexCount do
    local a = (2 - (i / vertexCount)) * math.pi / 2

    verts[#verts + 1] = {
      x = x + radius + math.cos(a) * radius,
      y = y + radius - math.sin(a) * radius
    }
  end

  draw.NoTexture()
  surface.DrawPoly(verts)
end

local drawEllipse = MetaSign.surface.DrawEllipse
local drawCircle = MetaSign.surface.DrawCircle

function MetaSign.GetMaterial(name)
  return MetaSign.materials[name]
end

function MetaSign.ClearMaterials()
  MetaSign.materials = {}
end

function MetaSign.CreateMaterial(name, path)
  path = path or "models/metamist/sign"

  local mat = MetaSign.GetMaterial(name)
  if mat then

    mat.result:SetTexture("$bumpmap", path .. "_bump")
    mat.target:SetTexture("$basetexture", path)
    return mat
  end

  local matResult = CreateMaterial(name, "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$bumpmap"] = path .. "_bump",
    ["$vertexcolor"] = 1,
    ["$halflambert"] = 1





  })

  local matTarget = CreateMaterial(name .. "_target", "UnlitGeneric", {
    ["$basetexture"] = path,
    ["$model"] = 1,
    ["$ignorez"] = 1,
    ["$translucent"] = 1
  })

  local rt = GetRenderTarget(name .. "_rt", MetaSign.RENDER_WIDTH, MetaSign.RENDER_HEIGHT, false)

  local dat = {
    result = matResult,
    target = matTarget,
    rt = rt,
    time = CurTime()
  }

  MetaSign.materials[name] = dat

  net.Start("metasign_created_material")
  net.WriteString(name)
  net.SendToServer()

  return dat
end

function MetaSign.RenderMaterial(name, ent)
  if not IsValid(ent) then return end

  local ply = LocalPlayer()
  local cursorPos, isHovering = ent:GetCachedCursorPos()

  local matData = MetaSign.CreateMaterial(name, ent.SignMaterial)

  oldScrW, oldScrH = ScrW(), ScrH()
  if not IsValid(ent) then return end

  local w, h = MetaSign.RENDER_WIDTH, MetaSign.RENDER_HEIGHT

  local mat = Matrix()
  mat:Scale(Vector(oldScrW / w, oldScrH / h, 1))

  render.PushRenderTarget(matData.rt)
  render.SetViewPort(0, 0, w, h)

  MetaSign.currentMatrix = mat
  cam.PushModelMatrix(mat)

  render.Clear(0, 0, 0, 255)
  render.ClearRenderTarget(matData.rt, Color(0, 0, 0, 255))

  local succ, err = pcall(function()
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(matData.target)
    surface.DrawTexturedRect(0, 0, w, h)

    draw.NoTexture()
    surface.SetDrawColor(255, 255, 255, 255)

    ent:DrawObjects()

    if ent.splash > 0 then
      local t = ent.splash
      local ts = t * t
      local tc = ts * t
      local f = (-2 * ts * ts + 10 * tc + -15 * ts + 8 * t)

      local area = ent:GetTextureDrawArea()
      local size = math.min(area.width, area.height) * 0.9 * f

      surface.SetDrawColor(255, 255, 255, 255)
      surface.SetMaterial(matLogo)
      surface.DrawTexturedRect(area.x + (area.width - size) / 2, area.y + (area.height - size) / 2, size, size)
    end

    draw.NoTexture()

    if ent.PostDrawMaterial then
      ent:PostDrawMaterial(w, h, matData)
    end

    local t = CurTime()

    if cursorPos and MetaSign.debug >= 1 then
      surface.SetDrawColor(0, 255, 255, 255)
      drawCircle(cursorPos.x, cursorPos.y, 5, 12)

      if ent.cursorDir then
        surface.DrawLine(cursorPos.x, cursorPos.y, cursorPos.x + ent.cursorDir.x * 10, cursorPos.y + ent.cursorDir.y * 10)
      end
    end
  end)


  if not succ then
    MetaSign.log.error("Something went wrong!\n> " .. err .. "\n> Please report this to the author!\n")

    if CurTime() - ent.lastRenderError > 1 then
      ent.lastRenderError = CurTime()
      ent:AddNotification("An error occured, please check console!", 1, MetaSign.NOTIFICATION_ERROR)
    end
  end

  cam.PopModelMatrix()
  MetaSign.currentMatrix = nil

  render.SetViewPort(0, 0, oldScrW, oldScrH)
  render.PopRenderTarget()

  oldTex = matData.result:GetTexture("$basetexture")
  matData.result:SetTexture("$basetexture", matData.rt)



  matData.time = CurTime()

  ent.matReady = true
end

local matDisplay = CreateMaterial("MetaSign_display", "UnlitGeneric", {
  ["$basetexture"] = path,
  ["$model"] = 1,
  ["$ignorez"] = 1,
  ["$translucent"] = 1
})

surface.CreateFont("MetaSign_display", {
  font = "Tahoma",
  antialias = true,
  size = 10,
  weight = 500
})

surface.CreateFont("MetaSign_3D2D", {
  font = "Tahoma",
  antialias = true,
  size = 100,
  weight = 500
})

hook.Add("HUDPaint", "MetaSign_RT", function()
  for name, ent in pairs(MetaSign.dirty) do
    MetaSign.RenderMaterial(name, ent)
    MetaSign.dirty[name] = nil
  end

  if MetaSign.debug < 3 then return end

  local x = 0
  local y = 0
  local size = 24
  local maxSize = 0
  for name, matData in pairs(MetaSign.materials) do
    surface.SetFont("MetaSign_display")
    local tw, th = surface.GetTextSize(name)

    if y + size + 4 > ScrH() then x = x + (maxSize + 4)
      y = 0
      maxSize = 0
    end

    matDisplay:SetTexture("$basetexture", matData.result:GetTexture("$basetexture"))

    local a = 1 - math.Clamp((CurTime() - matData.time) / 2, 0, 1)
    if a > 0.01 then
      local padding = math.ceil(10 * a / 2) * 2
      surface.SetDrawColor(255, 0, 0, 255 * a)
      surface.DrawRect(20 + x - padding, 20 + y - padding, size + padding * 2, size + padding * 2)
    end

    surface.SetMaterial(matDisplay)
    surface.SetDrawColor(255, 255, 255)
    surface.DrawTexturedRect(20 + x, 20 + y, size, size)

    surface.SetDrawColor(0, 0, 0, 200)
    surface.DrawRect(20 + x + size + 4, 20 + y + size / 2 - th / 2, tw + 8, th)
    draw.DrawText(name, "MetaSign_display", 20 + x + size + 4 + 4, 20 + y + size / 2 - th / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT)

    y = y + (size + 4)
    maxSize = math.max(maxSize, size + tw + 4 + 8)

  end
end)


function MetaSign.GetColorLightness(color)
  local uiColors = {
    color.r / 255, color.g / 255, color.b / 255}
  for i, c in ipairs(uiColors) do
    if c <= 0.03928 then
      uiColors[i] = c / 12.92
    else
      uiColors[i] = math.pow((c + 0.055) / 1.055, 2.4)
    end
  end
  return 0.2126 * uiColors[1] + 0.7152 * uiColors[2] + 0.0722 * uiColors[3]
end

function MetaSign.GetContrastColor(bgColor, colLight, colDark)
  colLight = colLight or Color(255, 255, 255)
  colDark = colDark or Color(0, 0, 0)

  if MetaSign.GetColorLightness(bgColor) > 0.41 then
    return colDark
  end

  return colLight
end
