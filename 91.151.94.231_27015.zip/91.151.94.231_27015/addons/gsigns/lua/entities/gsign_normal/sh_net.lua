--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.objects.netHandlers = MetaSign.objects.netHandlers or {}

function MetaSign.RegisterObjectNetHandler(objType, tbl)
  if not tbl.Read or not tbl.Write then
    error("Networked object type \"" .. tostring(objType) .. "\" is missing Read or Write function.")
    return
  end

  MetaSign.objects.netHandlers[objType] = tbl
end

function MetaSign.WriteNetworkedObject(obj)
  local netObj = MetaSign.objects.netHandlers[obj.type]
  if not netObj then
    error("Tried to write nonexistant object type \"" .. tostring(obj.type) .. "\"")
  end

  net.WriteString(obj.type)
  netObj.Write(obj)
end

function MetaSign.ReadNetworkedObject()
  local objType = net.ReadString()

  local netObj = MetaSign.objects.netHandlers[objType]
  if not netObj then
    error("Tried to read nonexistant object type \"" .. tostring(objType) .. "\"")
  end

  local obj = netObj.Read()
  obj.type = objType

  return obj
end

MetaSign.RegisterObjectNetHandler("spline", {
  Write = function(obj)
    net.WriteUInt(obj.thickness, 8)
    net.WriteColor(obj.color)
    net.WriteUInt(#obj.points, 16)

    for i = 1, #obj.points do
      local point = obj.points[i]

      net.WriteVector(point.pos)
      net.WriteVector(point.dir)
    end
  end,
  Read = function()
    local tbl = {
      thickness = net.ReadUInt(8),
      color = net.ReadColor(),
      points = {}
    }

    local pointsLen = net.ReadUInt(16)
    for i = 1, pointsLen do
      tbl.points[i] = {
        pos = net.ReadVector(),
        dir = net.ReadVector()
      }
    end

    return tbl
  end
})

MetaSign.RegisterObjectNetHandler("rectangle", {
  Write = function(obj)
    net.WriteFloat(obj.x)
    net.WriteFloat(obj.y)
    net.WriteFloat(obj.width)
    net.WriteFloat(obj.height)
    net.WriteColor(obj.color)
  end,
  Read = function()
    return {
      x = net.ReadFloat(),
      y = net.ReadFloat(),
      width = net.ReadFloat(),
      height = net.ReadFloat(),
      color = net.ReadColor()
    }
  end
})

MetaSign.RegisterObjectNetHandler("ellipse", {
  Write = function(obj)
    net.WriteFloat(obj.x)
    net.WriteFloat(obj.y)
    net.WriteFloat(obj.width)
    net.WriteFloat(obj.height)
    net.WriteUInt(obj.vertexCount, 8)
    net.WriteColor(obj.color)
  end,
  Read = function()
    return {
      x = net.ReadFloat(),
      y = net.ReadFloat(),
      width = net.ReadFloat(),
      height = net.ReadFloat(),
      vertexCount = net.ReadUInt(8),
      color = net.ReadColor()
    }
  end
})

MetaSign.RegisterObjectNetHandler("text", {
  Write = function(obj)
    net.WriteString(obj.text)
    net.WriteString(obj.font)
    net.WriteFloat(obj.x)
    net.WriteFloat(obj.y)
    net.WriteUInt(obj.fontSize, 8)
    net.WriteColor(obj.color)
    net.WriteUInt(obj.alignment, 4)
    net.WriteFloat(obj.rotation)
  end,
  Read = function()
    return {
      text = net.ReadString(),
      font = net.ReadString(),
      x = net.ReadFloat(),
      y = net.ReadFloat(),
      fontSize = net.ReadUInt(8),
      color = net.ReadColor(),
      alignment = net.ReadUInt(4),
      rotation = net.ReadFloat()
    }
  end
})

MetaSign.RegisterObjectNetHandler("line", {
  Write = function(obj)
    net.WriteFloat(obj.x)
    net.WriteFloat(obj.y)
    net.WriteFloat(obj.endX)
    net.WriteFloat(obj.endY)
    net.WriteUInt(obj.thickness, 8)
    net.WriteColor(obj.color)
  end,
  Read = function()
    return {
      x = net.ReadFloat(),
      y = net.ReadFloat(),
      endX = net.ReadFloat(),
      endY = net.ReadFloat(),
      thickness = net.ReadUInt(8),
      color = net.ReadColor()
    }
  end
})
