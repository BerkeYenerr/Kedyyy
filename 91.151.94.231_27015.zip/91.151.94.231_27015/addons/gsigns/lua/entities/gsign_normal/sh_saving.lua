--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local function __lau_concat_0(...)
  local arr = {
    ...
  }
  local result = {}
  for _, obj in ipairs(arr) do
    for i = 1, #obj do
      result[#result + 1] = obj[i]
    end
    for k, v in pairs(obj) do
      if type(k) == "number" and k > #obj then result[k] = v
      elseif type(k) ~= "number" then
        result[k] = v
      end
    end
  end
  return result
end
MetaSign.saving = MetaSign.saving or {}

MetaSign.saving.format = "version_1"
MetaSign.saving.header = "MetaSign Format "
MetaSign.saving.formats = {}
MetaSign.saving.objectRemapHandlers = {}

MetaSign.saving.root = "metasign/"

MetaSign.saving.folders = {}
MetaSign.saving.folders.userFiles = "files/"
MetaSign.saving.folders.autoSave = "autosave/"

local StringBuffer
do
  local _class_0
  local _base_0 = {
    __name = "StringBuffer",
    Get = function(self)
      return self.string end,
    Write = function(self, s)
      if not s then return end

      self.string = self.string .. s
    end
  }
  _base_0.__index = _base_0
  _class_0 = setmetatable({
    __init = function(self)
      self.string = ""
    end,
    __base = _base_0,
    __name = "StringBuffer"
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  StringBuffer = _class_0
end

function MetaSign.saving.RegisterObjectRemapHandler(type, handler)
  MetaSign.saving.objectRemapHandlers[type] = handler
end

function MetaSign.saving.GetObjectRemapHandler(type)
  local handler = MetaSign.saving.objectRemapHandlers[type]

  return handler
end

function MetaSign.saving.GetFiles(subPath)
  if subPath == nil then subPath = MetaSign.saving.folders.userFiles
  end
  local this = MetaSign.saving

  local files, folders = file.Find(this.root .. subPath .. "*.txt", "DATA")
  return files
end

MetaSign.saving.GetFiles()

function MetaSign.saving.EnsureFolders()
  local this = MetaSign.saving

  if not file.Exists(this.root, "DATA") then
    file.CreateDir(this.root)
  end

  for k, path in pairs(this.folders) do
    if not file.Exists(this.root .. path, "DATA") then
      file.CreateDir(this.root .. path)
    end
  end
end

function MetaSign.saving.AddFormat(format)
  local name = format.name
  MetaSign.saving.formats[name] = format

  format.GetHeader = function()
    return MetaSign.saving.header .. format.name
  end
end

function MetaSign.saving.GetFormat(name)
  return MetaSign.saving.formats[name]
end

function MetaSign.saving.GetFormatFromHeader(header)
  return header:sub(string.len(MetaSign.saving.header) + 1):Trim()
end

function MetaSign.saving.Exists(path, subPath)
  if subPath == nil then subPath = MetaSign.saving.folders.userFiles
  end
  local this = MetaSign.saving

  if not string.EndsWith(path, ".txt") then
    path = path .. ".txt"
  end

  return file.Exists(this.root .. subPath .. path, "DATA")
end

function MetaSign.saving.Delete(path, subPath)
  if subPath == nil then subPath = MetaSign.saving.folders.userFiles
  end
  local this = MetaSign.saving

  if not string.EndsWith(path, ".txt") then
    path = path .. ".txt"
  end

  file.Delete(this.root .. subPath .. path)
end

function MetaSign.saving.ToString(bounds, objects)
  local this = MetaSign.saving

  local format = this.GetFormat(this.format)
  if not format then
    error("Format " .. tostring(this.format) .. " is not valid.")
    return
  end

  local buf = StringBuffer()
  local res = format:Save(buf, bounds, objects)

  return buf, res
end

function MetaSign.saving.Save(bounds, path, objects, subPath)
  if subPath == nil then subPath = MetaSign.saving.folders.userFiles
  end
  local this = MetaSign.saving

  if not string.EndsWith(path, ".txt") then
    path = path .. ".txt"
  end

  this:EnsureFolders()

  local format = this.GetFormat(this.format)
  if not format then
    error("Error while attempting to save " .. tostring(path) .. ", format " .. tostring(this.format) .. " is not valid.")
    return
  end

  local p = this.root .. subPath .. path
  local f = file.Open(p, "w", "DATA")

  local res = format:Save(f, bounds, objects)

  f:Close()

  return res
end

function MetaSign.saving.Load(bounds, path, subPath)
  if subPath == nil then subPath = MetaSign.saving.folders.userFiles
  end
  local this = MetaSign.saving

  if not string.EndsWith(path, ".txt") then
    path = path .. ".txt"
  end

  local str = file.Read(this.root .. subPath .. path)

  if not str then return end

  return this.LoadString(bounds, str)
end

function MetaSign.saving.GetRemappedObjects(objects, fromBounds, toBounds)
  local this = MetaSign.saving
  local remappedObjects = {}

  for i, obj in pairs(objects) do
    local handler = this.GetObjectRemapHandler(obj.type)
    local remapped = handler(obj, fromBounds, toBounds)

    remappedObjects[i] = remapped
  end

  return remappedObjects
end

function MetaSign.saving.LoadString(bounds, str)
  local this = MetaSign.saving
  local arr = string.Explode("\n", str)

  local header = arr[1]
  if not header then return end

  local formatStr = this.GetFormatFromHeader(header:sub(3))
  local format = this.GetFormat(formatStr)
  if not format then
    error("Error while attempting to load string with unknown format \"" .. tostring(formatStr) .. "\"")
    return
  end

  local savedBounds, objects = format:Load(arr)

  local remapped = this.GetRemappedObjects(objects, savedBounds, bounds)

  return remapped
end

MetaSign.saving.RegisterObjectRemapHandler("rectangle", function(obj, fromBounds, toBounds)
  return __lau_concat_0(obj, {
    x = math.Remap(obj.x, fromBounds.x, fromBounds.x + fromBounds.width, toBounds.x, toBounds.x + toBounds.width),
    y = math.Remap(obj.y, fromBounds.y, fromBounds.y + fromBounds.height, toBounds.y, toBounds.y + toBounds.height),
    width = obj.width / fromBounds.width * toBounds.width,
    height = obj.height / fromBounds.height * toBounds.height
  })
end)

MetaSign.saving.RegisterObjectRemapHandler("ellipse", MetaSign.saving.GetObjectRemapHandler("rectangle"))

MetaSign.saving.RegisterObjectRemapHandler("line", function(obj, fromBounds, toBounds)
  return __lau_concat_0(obj, {
    x = math.Remap(obj.x, fromBounds.x, fromBounds.x + fromBounds.width, toBounds.x, toBounds.x + toBounds.width),
    y = math.Remap(obj.y, fromBounds.y, fromBounds.y + fromBounds.height, toBounds.y, toBounds.y + toBounds.height),
    endX = math.Remap(obj.endX, fromBounds.x, fromBounds.x + fromBounds.width, toBounds.x, toBounds.x + toBounds.width),
    endY = math.Remap(obj.endY, fromBounds.y, fromBounds.y + fromBounds.height, toBounds.y, toBounds.y + toBounds.height)
  })
end)

MetaSign.saving.RegisterObjectRemapHandler("spline", function(obj, fromBounds, toBounds)
  local points = {}

  for i, p in pairs(obj.points) do
    points[i] = {
      pos = Vector(math.Remap(p.pos.x, fromBounds.x, fromBounds.x + fromBounds.width, toBounds.x, toBounds.x + toBounds.width), math.Remap(p.pos.y, fromBounds.y, fromBounds.y + fromBounds.height, toBounds.y, toBounds.y + toBounds.height), 0),
      dir = Vector(math.Remap(p.dir.x, fromBounds.x, fromBounds.x + fromBounds.width, toBounds.x, toBounds.x + toBounds.width), math.Remap(p.dir.y, fromBounds.y, fromBounds.y + fromBounds.height, toBounds.y, toBounds.y + toBounds.height), 0)
    }
  end

  return __lau_concat_0(obj, {
    thickness = obj.thickness * toBounds.width / fromBounds.width * toBounds.height / fromBounds.height,
    points = points
  })
end)

MetaSign.saving.RegisterObjectRemapHandler("text", function(obj, fromBounds, toBounds)
  return __lau_concat_0(obj, {
    x = math.Remap(obj.x, fromBounds.x, fromBounds.x + fromBounds.width, toBounds.x, toBounds.x + toBounds.width),
    y = math.Remap(obj.y, fromBounds.y, fromBounds.y + fromBounds.height, toBounds.y, toBounds.y + toBounds.height),
    fontSize = obj.fontSize * toBounds.width / fromBounds.width * toBounds.height / fromBounds.height
  })
end)

include("formats/version_1.lua")
include("formats/spon.lua")
