--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign = MetaSign or {}

MetaSign.NOTIFICATION_NOTICE = 1
MetaSign.NOTIFICATION_WARNING = 2
MetaSign.NOTIFICATION_TIP = 3
MetaSign.NOTIFICATION_ERROR = 4
MetaSign.NOTIFICATION_ADMIN = 5

MetaSign.colors = {
  primary = Color(30, 136, 229),
  secondary = Color(67, 160, 71),
  success = Color(76, 175, 80),
  error = Color(244, 81, 30),
  notifications = {
    [MetaSign.NOTIFICATION_NOTICE] = Color(3, 169, 244, 200),
    [MetaSign.NOTIFICATION_WARNING] = Color(255, 152, 0, 200),
    [MetaSign.NOTIFICATION_TIP] = Color(139, 195, 74, 200),
    [MetaSign.NOTIFICATION_ERROR] = Color(255, 87, 34, 200),
    [MetaSign.NOTIFICATION_ADMIN] = Color(103, 58, 183, 200)
  }
}

MetaSign.objects = MetaSign.objects or {}

include("sh_utf8.lua")
include("sh_util.lua")
include("sh_net.lua")
include("sh_saving.lua")

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Sign"
ENT.Author = "Metamist"
ENT.Spawnable = MetaSign.config.spawnable
ENT.AdminOnly = MetaSign.config.adminOnly
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.MaxDistance = 200

ENT.Model = "models/metamist/sign.mdl"
ENT.SignMaterial = "models/metamist/sign"
ENT.SubMaterialIndex = 0

function ENT:SetupDataTables()
  self:NetworkVar("String", 0, "MaterialID")
  self:NetworkVar("String", 1, "SignOwnerID")

  self:NetworkVar("Bool", 0, "Splash")

  self:NetworkVar("Entity", 0, "PlayerEditing")
  self:NetworkVar("Entity", 1, "owning_ent")
end

function ENT:InitializeShared()
  self.users = {}
end

function ENT:GetTextureDrawArea()
  return {
    x = 0,
    y = 0,
    width = 512,
    height = 256
  }
end

function ENT:GetSignOwner()
  if not self.Getowning_ent and not self.CPPIGetOwner then
    return nil, true
  end

  local owner = self.Getowning_ent and self:Getowning_ent() or self.CPPIGetOwner and self:CPPIGetOwner()
  if IsValid(owner) then return owner end

  local id = self:GetSignOwnerID()
  return id and player.GetBySteamID(id)
end




function ENT:IsSignPublic()
  local owner, signPublic = self:GetSignOwner()

  return signPublic == true
end

function ENT:HasUser(ply)
  if not IsValid(ply) then return false end

  for k, dat in pairs(self.users) do
    local id = dat.id
    local user = player.GetBySteamID(id)

    if IsValid(user) and user == ply then return true end
  end

  return false
end

function ENT:HasUserAccess(ply)
  if not IsValid(ply) then return false end
  return self:IsSignPublic() or ply == self:GetSignOwner() or self:HasUser(ply)
end


function ENT:OnObjectAdded(obj) end
