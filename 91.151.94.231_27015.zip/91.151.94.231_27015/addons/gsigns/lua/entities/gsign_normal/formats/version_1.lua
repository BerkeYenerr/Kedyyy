--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local FormatBase = include("base.lua")
local spon = include("entities/gsign_normal/sh_spon.lua")

local string_sub = string.sub
local string_len = string.len
local string_find = string.find
local string_trimRight = string.TrimRight

local FormatVersion1
do
  local _class_0
  local _parent_0 = FormatBase
  local _base_0 = {
    __name = "FormatVersion1",
    __base = FormatBase.__base,
    WriteObject = function(self, f, obj)
      f:Write("o " .. tostring(obj.type) .. " ")

      local handler = self:GetObjectHandler(obj.type)
      handler.Write(f, obj)

      f:Write("\n")
    end,
    ReadObject = function(self, objType, data, arr)
      local handler = self:GetObjectHandler(objType)
      local obj = handler.Read(data, arr)

      obj.type = objType

      return obj
    end,
    Save = function(self, f, bounds, objects)
      if f == nil then return false end

      local header = self:GetHeader()
      f:Write("# " .. tostring(header) .. "\n")

      f:Write("b ")
      f:Write(string.format("%x", bounds.x) .. " ")
      f:Write(string.format("%x", bounds.y) .. " ")
      f:Write(string.format("%x", bounds.width) .. " ")
      f:Write(string.format("%x", bounds.height))
      f:Write("\n")

      f:Write("\n")
      self:WriteComment(f, "Objects")

      for i, obj in pairs(objects) do
        self:WriteObject(f, obj)
      end

      return true
    end,
    Load = function(self, lines)
      local bounds = {}
      local objects = {}

      for i, line in pairs(lines) do
        line = string.TrimRight(line, "\r")

        if line == "" then continue end
        local op = line:sub(1, 1)

        if op == "#" then continue end

        local arr = string.Explode(" ", line)
        table.remove(arr, 1)

        if op == "b" then
          bounds = {
            x = tonumber(arr[1], 16),
            y = tonumber(arr[2], 16),
            width = tonumber(arr[3], 16),
            height = tonumber(arr[4], 16)
          }
        elseif op == "o" then
          local objType = table.remove(arr, 1)

          local object = self:ReadObject(objType, string_sub(line, string_len(objType) + 4), arr)
          objects[#objects + 1] = object
        end
      end

      return bounds, objects
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self)
      self.separator = "\n"
      FormatVersion1.__parent.__init(self, "version_1")

      self:RegisterObjectHandler("spline", {
        Write = function(f, obj)
          f:Write(string.format("%x", obj.thickness) .. " ")
          f:Write(string.format("%x", obj.color.r) .. " ")
          f:Write(string.format("%x", obj.color.g) .. " ")
          f:Write(string.format("%x", obj.color.b) .. " ")
          f:Write(string.format("%x", obj.color.a) .. " ")

          for i, p in pairs(obj.points) do
            f:Write(tostring(p.dir.x) .. " " .. tostring(p.dir.y) .. " ")
            f:Write(tostring(p.pos.x) .. " " .. tostring(p.pos.y) .. " ")
          end
        end,
        Read = function(data, arr)
          local points = {}

          for i = 6, #arr - 1, 4 do
            points[#points + 1] = {
              dir = Vector(tonumber(arr[i + 0]), tonumber(arr[i + 1]), 0),
              pos = Vector(tonumber(arr[i + 2]), tonumber(arr[i + 3]), 0)
            }
          end

          return {
            thickness = tonumber(arr[1], 16),
            color = Color(tonumber(arr[2], 16), tonumber(arr[3], 16), tonumber(arr[4], 16), tonumber(arr[5], 16)),
            points = points
          }
        end
      })

      self:RegisterObjectHandler("rectangle", {
        Write = function(f, obj)
          f:Write(tostring(obj.x) .. " " .. tostring(obj.y) .. " " .. tostring(obj.width) .. " " .. tostring(obj.height) .. " ")
          f:Write(string.format("%x", obj.color.r) .. " ")
          f:Write(string.format("%x", obj.color.g) .. " ")
          f:Write(string.format("%x", obj.color.b) .. " ")
          f:Write(string.format("%x", obj.color.a))
        end,
        Read = function(data, arr)
          return {
            x = tonumber(arr[1]),
            y = tonumber(arr[2]),
            width = tonumber(arr[3]),
            height = tonumber(arr[4]),
            color = Color(tonumber(arr[5], 16), tonumber(arr[6], 16), tonumber(arr[7], 16), tonumber(arr[8], 16))
          }
        end
      })

      self:RegisterObjectHandler("ellipse", {
        Write = function(f, obj)
          f:Write(tostring(obj.x) .. " " .. tostring(obj.y) .. " " .. tostring(obj.width) .. " " .. tostring(obj.height) .. " ")

          f:Write(string.format("%x", obj.vertexCount) .. " ")

          f:Write(string.format("%x", obj.color.r) .. " ")
          f:Write(string.format("%x", obj.color.g) .. " ")
          f:Write(string.format("%x", obj.color.b) .. " ")
          f:Write(string.format("%x", obj.color.a))
        end,
        Read = function(data, arr)
          return {
            x = tonumber(arr[1]),
            y = tonumber(arr[2]),
            width = tonumber(arr[3]),
            height = tonumber(arr[4]),
            vertexCount = tonumber(arr[5], 16),
            color = Color(tonumber(arr[6], 16), tonumber(arr[7], 16), tonumber(arr[8], 16), tonumber(arr[9], 16))
          }
        end
      })

      self:RegisterObjectHandler("line", {
        Write = function(f, obj)
          f:Write(tostring(obj.x) .. " " .. tostring(obj.y) .. " " .. tostring(obj.endX) .. " " .. tostring(obj.endY) .. " ")

          f:Write(string.format("%x", obj.thickness) .. " ")

          f:Write(string.format("%x", obj.color.r) .. " ")
          f:Write(string.format("%x", obj.color.g) .. " ")
          f:Write(string.format("%x", obj.color.b) .. " ")
          f:Write(string.format("%x", obj.color.a))
        end,
        Read = function(data, arr)
          return {
            x = tonumber(arr[1]),
            y = tonumber(arr[2]),
            endX = tonumber(arr[3]),
            endY = tonumber(arr[4]),
            thickness = tonumber(arr[5], 16),
            color = Color(tonumber(arr[6], 16), tonumber(arr[7], 16), tonumber(arr[8], 16), tonumber(arr[9], 16))
          }
        end
      })

      self:RegisterObjectHandler("text", {
        Write = function(f, obj)
          f:Write(tostring(obj.x) .. " " .. tostring(obj.y) .. " " .. tostring(obj.font) .. " " .. tostring(obj.alignment) .. " " .. tostring(obj.rotation) .. " ")

          f:Write(string.format("%x", obj.fontSize) .. " ")

          f:Write(string.format("%x", obj.color.r) .. " ")
          f:Write(string.format("%x", obj.color.g) .. " ")
          f:Write(string.format("%x", obj.color.b) .. " ")
          f:Write(string.format("%x", obj.color.a) .. " ")

          f:Write(obj.text)
        end,
        Read = function(data, arr)
          local text = ""
          for i = 11, #arr do
            text = text .. arr[i]
            if i < #arr then text = text .. " "
            end
          end

          return {
            x = tonumber(arr[1]),
            y = tonumber(arr[2]),
            text = text,
            font = arr[3],
            alignment = tonumber(arr[4]),
            rotation = tonumber(arr[5]),
            fontSize = tonumber(arr[6], 16),
            color = Color(tonumber(arr[7], 16), tonumber(arr[8], 16), tonumber(arr[9], 16), tonumber(arr[10], 16))
          }
        end
      })
    end,
    __base = _base_0,
    __name = "FormatVersion1",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  FormatVersion1 = _class_0
end

MetaSign.saving.AddFormat(FormatVersion1())

return FormatVersion1
