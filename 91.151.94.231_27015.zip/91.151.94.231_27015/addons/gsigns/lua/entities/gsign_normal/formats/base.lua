--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local FormatBase
do
  local _class_0
  local _base_0 = {
    __name = "FormatBase",
    WriteComment = function(self, f, comment)
      f:Write("# " .. tostring(comment) .. "\n")
    end,
    RegisterObjectHandler = function(self, type, handler)
      if not handler.Read or not handler.Write then
        error("Object save handler type \"" .. tostring(objType) .. "\" is missing Read or Write function.")
        return
      end

      self.saveHandlers[type] = handler
    end,
    GetObjectHandler = function(self, type)
      local handler = self.saveHandlers[type]

      if not handler then
        error("Tried to get nonexistant object save handler from type \"" .. tostring(type) .. "\"")
      end

      return handler
    end,
    Save = function(self, f, bounds, objects)
      error("Save method not implemented for format \"" .. tostring(self.name) .. "\"")
    end,
    Load = function(self, lines)
      error("Load method not implemented for format \"" .. tostring(self.name) .. "\"")
    end
  }
  _base_0.__index = _base_0
  _class_0 = setmetatable({
    __init = function(self, name)
      self.saveHandlers = {}
      self.name = name
    end,
    __base = _base_0,
    __name = "FormatBase"
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  FormatBase = _class_0
end

return FormatBase
