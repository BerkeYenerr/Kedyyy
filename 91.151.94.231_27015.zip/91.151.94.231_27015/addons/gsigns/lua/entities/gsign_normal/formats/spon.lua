--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local FormatBase = include("base.lua")
local spon = include("entities/gsign_normal/sh_spon.lua")

local FormatSPON
do
  local _class_0
  local _parent_0 = FormatBase
  local _base_0 = {
    __name = "FormatSPON",
    __base = FormatBase.__base,
    WriteObject = function(self, f, obj)
      f:Write("o " .. tostring(obj.type) .. " ")

      local handler = self:GetObjectHandler(obj.type)
      handler.Write(f, obj)

      f:Write("\n")
    end,
    ReadObject = function(self, objType, data)
      local handler = self:GetObjectHandler(objType)
      local obj = handler.Read(data)

      obj.type = objType

      return obj
    end,
    Save = function(self, f, bounds, objects)
      if f == nil then return false end

      local header = self:GetHeader()
      f:Write("# " .. tostring(header) .. "\n")

      f:Write("b " .. spon.encode({
        bounds.x, bounds.y, bounds.width, bounds.height
      }))
      f:Write("\n")

      f:Write("\n")
      self:WriteComment(f, "Objects")

      for i, obj in pairs(objects) do
        self:WriteObject(f, obj)
      end

      return true
    end,
    Load = function(self, lines)
      local bounds = {}
      local objects = {}

      for i, line in pairs(lines) do
        if line == "" then continue end
        local op = line:sub(1, 1)

        if op == "#" then continue end

        local arr = string.Explode(" ", line)
        if op == "b" then
          local decodedBounds = spon.decode(arr[2])
          bounds = {
            x = decodedBounds[1],
            y = decodedBounds[2],
            width = decodedBounds[3],
            height = decodedBounds[4]
          }
        elseif op == "o" then
          local objType = arr[2]

          local object = self:ReadObject(objType, arr[3])
          objects[#objects + 1] = object
        end
      end

      return bounds, objects
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self)
      self.separator = "\n"
      FormatSPON.__parent.__init(self, "spon")

      self:RegisterObjectHandler("spline", {
        Write = function(f, obj)
          local points = {}
          for i, p in pairs(obj.points) do
            points[#points + 1] = {
              p.dir, p.pos}
          end

          f:Write(spon.encode({
            obj.thickness,
            obj.color.r,
            obj.color.g,
            obj.color.b,
            obj.color.a,
            points
          }))
        end,
        Read = function(data)
          local data = spon.decode(data)
          local points = {}

          for i, p in pairs(data[6]) do
            points[#points + 1] = {
              dir = p[1],
              pos = p[2]
            }
          end

          return {
            thickness = data[1],
            color = Color(data[2], data[3], data[4], data[5]),
            points = points
          }
        end
      })

      self:RegisterObjectHandler("rectangle", {
        Write = function(f, obj)
          f:Write(spon.encode({
            obj.x,
            obj.y,
            obj.width,
            obj.height,
            obj.color.r,
            obj.color.g,
            obj.color.b,
            obj.color.a
          }))
        end,
        Read = function(data)
          local data = spon.decode(data)
          return {
            x = data[1],
            y = data[2],
            width = data[3],
            height = data[4],
            color = Color(data[5], data[6], data[7], data[8])
          }
        end
      })

      self:RegisterObjectHandler("ellipse", {
        Write = function(f, obj)
          f:Write(spon.encode({
            obj.x,
            obj.y,
            obj.width,
            obj.height,
            obj.vertexCount,
            obj.color.r,
            obj.color.g,
            obj.color.b,
            obj.color.a
          }))
        end,
        Read = function(data)
          local data = spon.decode(data)
          return {
            x = data[1],
            y = data[2],
            width = data[3],
            height = data[4],
            vertexCount = data[5],
            color = Color(data[6], data[7], data[8], data[9])
          }
        end
      })

      self:RegisterObjectHandler("line", {
        Write = function(f, obj)
          f:Write(spon.encode({
            obj.x,
            obj.y,
            obj.endX,
            obj.endY,
            obj.thickness,
            obj.color.r,
            obj.color.g,
            obj.color.b,
            obj.color.a
          }))
        end,
        Read = function(data)
          local data = spon.decode(data)
          return {
            x = data[1],
            y = data[2],
            endX = data[3],
            endY = data[4],
            thickness = data[5],
            color = Color(data[6], data[7], data[8], data[9])
          }
        end
      })

      self:RegisterObjectHandler("text", {
        Write = function(f, obj)
          f:Write(spon.encode({
            obj.x,
            obj.y,
            obj.text,
            obj.font,
            obj.alignment,
            obj.rotation,
            obj.fontSize,
            obj.color.r,
            obj.color.g,
            obj.color.b,
            obj.color.a
          }))
        end,
        Read = function(data)
          local data = spon.decode(data)
          return {
            x = data[1],
            y = data[2],
            text = data[3],
            font = data[4],
            alignment = data[5],
            rotation = data[6],
            fontSize = data[7],
            color = Color(data[8], data[9], data[10], data[11])
          }
        end
      })
    end,
    __base = _base_0,
    __name = "FormatSPON",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  FormatSPON = _class_0
end

MetaSign.saving.AddFormat(FormatSPON())

return FormatSPON
