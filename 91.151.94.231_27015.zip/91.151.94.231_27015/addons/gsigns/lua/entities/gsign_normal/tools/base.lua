--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local ToolBase
do
  local _class_0
  local _base_0 = {
    __name = "ToolBase",
    SetUVResolver = function(self, resolver)
      self.uvResolver = resolver
    end,
    SetMaterial = function(self, material)
      self.material = material
    end,
    IsSelected = function(self)
      return self.selected
    end,
    GetEntity = function(self)
      return self.entity
    end,
    Reset = function(self) end,
    Think = function(self) end
  }
  _base_0.__index = _base_0
  _class_0 = setmetatable({
    __init = function(self)
      self.selected = false
      self.selectTime = 0
    end,
    __base = _base_0,
    __name = "ToolBase"
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  ToolBase = _class_0
end

return ToolBase
