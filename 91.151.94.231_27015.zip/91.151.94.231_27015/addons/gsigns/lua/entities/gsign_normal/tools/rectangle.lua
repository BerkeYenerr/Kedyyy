--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local ToolBase = include("base.lua")

local ToolRectangle
do
  local _class_0
  local _parent_0 = ToolBase
  local _base_0 = {
    __name = "ToolRectangle",
    __base = ToolBase.__base,
    Reset = function(self) end,
    NewObject = function(self, x, y)
      local ent = self:GetEntity()
      if not IsValid(ent) then return end
      if not ent:CanCreateObject("rectangle") then
        self.entity:OnLimitReached()
        return
      end

      self:Reset()

      self.object = MetaSign.CreateObject("rectangle", x, y, 10, 10, ent.currentColor)
      self.object:SetUVResolver(self.uvResolver)
      self.object:SetMaterial(self.material)
      ent:SetTemporaryObject(self.object)
    end,
    FinishObject = function(self)
      local ent = self:GetEntity()
      if not ent:CanCreateObject("rectangle") then return end

      self.entity:AddObject(self.object)
      self.object = nil
      self.entity:SetTemporaryObject(nil)
    end,
    Think = function(self, selected)
      local lp = LocalPlayer()
      local ent = self:GetEntity()
      if not IsValid(ent) then return end

      if not selected then return end

      local cursorPos, isHovering = ent:GetCachedCursorPos()

      if ent.editing then
        if cursorPos and isHovering then
          local down = ent:IsUseKeyDown()
          if down and not self.prevDown and not self.entity.guiDidHover then
            self.startPos = cursorPos
            self:NewObject(self.startPos.x, self.startPos.y)
          end

          local keyControlDown = input.IsKeyDown(KEY_LCONTROL)
          local keyShiftDown = input.IsKeyDown(KEY_LSHIFT)
          if keyControlDown then self.keyControlTime = CurTime()end
          if keyShiftDown then self.keyShiftTime = CurTime()end

          if down and self.object and self.startPos then
            local isControlDown = self.keyControlTime and (CurTime() - self.keyControlTime) < 0.1
            local isShiftDown = self.keyShiftTime and (CurTime() - self.keyShiftTime) < 0.1

            local min = Vector(math.min(cursorPos.x, self.startPos.x), math.min(cursorPos.y, self.startPos.y), 0)

            local max = Vector(math.max(cursorPos.x, self.startPos.x), math.max(cursorPos.y, self.startPos.y), 0)

            local diff = max - min

            local w, h = diff.x, diff.y
            if isShiftDown then
              w = math.min(diff.x, diff.y)
              h = w
            end

            local posDiff = cursorPos - self.startPos

            if isControlDown then
              if posDiff.x >= 0 then
                self.object.x = min.x - w
              else
                self.object.x = min.x - (w - diff.x)
              end

              if posDiff.y >= 0 then
                self.object.y = min.y - h
              else
                self.object.y = min.y - (h - diff.y)
              end

              self.object.width = w * 2
              self.object.height = h * 2
            else
              if posDiff.x < 0 and isShiftDown then
                self.object.x = min.x - (w - diff.x)
              else
                self.object.x = min.x
              end

              if posDiff.y < 0 and isShiftDown then
                self.object.y = min.y - (h - diff.y)
              else
                self.object.y = min.y
              end

              self.object.width = w
              self.object.height = h
            end

            ent:MarkDirty()
          else
            if self.prevDown and self.object then
              self:FinishObject()
            end
          end

          self.prevDown = down
        end
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self)
      ToolRectangle.__parent.__init(self)
    end,
    __base = _base_0,
    __name = "ToolRectangle",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  ToolRectangle = _class_0
end

return ToolRectangle
