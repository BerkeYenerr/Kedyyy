--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local ToolBase = include("base.lua")

local ToolBrush
do
  local _class_0
  local _parent_0 = ToolBase
  local _base_0 = {
    __name = "ToolBrush",
    __base = ToolBase.__base,
    Reset = function(self)
      self.prevPos = nil
      self.prevDir = nil
      self.cursorDir = nil
      self.lastId = 0
    end,
    SetThickness = function(self, value)
      self.thickness = value
    end,
    NewObject = function(self)
      local ent = self:GetEntity()
      if not IsValid(ent) then return end
      if not ent:CanCreateObject("spline") then
        self.entity:OnLimitReached()
        return
      end

      self:Reset()

      self.object = MetaSign.CreateObject("spline", self.thickness, ent.currentColor)
      self.object:SetUVResolver(self.uvResolver)
      self.object:SetMaterial(self.material)
      ent:SetTemporaryObject(self.object)
    end,
    FinishObject = function(self)
      local ent = self:GetEntity()
      if not ent:CanCreateObject("spline") then return end

      self.entity:AddObject(self.object)
      self.object = nil
      self.entity:SetTemporaryObject(nil)
    end,
    Think = function(self, selected)
      local lp = LocalPlayer()
      local ent = self:GetEntity()
      if not IsValid(ent) then return end

      if not selected then return end

      local cursorPos, isHovering = ent:GetCachedCursorPos()

      if ent.editing then
        if not cursorPos or not isHovering then
          self.prevDown = false

          if self.object then
            self:FinishObject()
          end

          return
        end

        local maxPoints = 150

        if not self.prevCursorPos then
          self.prevCursorPos = cursorPos
        end

        if self.prevCursorPos:Distance(cursorPos) >= 2 then
          self.cursorDir = (cursorPos - self.prevCursorPos):GetNormalized()

          self.prevCursorPos = cursorPos
        end

        if cursorPos then
          local pointDir = Vector(0, 0, 0)
          if self.prevPos then
            pointDir = (cursorPos - self.prevPos):GetNormalized()
          end

          local down = ent:IsUseKeyDown()
          if down and not self.prevDown and not self.entity.guiDidHover then
            self:NewObject()
          end

          if down and self.object then
            local diff = Vector(0, 0, 0)
            if self.prevPos then
              diff = cursorPos - self.prevPos
            end

            local dist = diff:Length()
            local isTurn = false
            local isHardTurn = false
            if self.cursorDir and self.prevDir then
              local dot = self.cursorDir:Dot(self.prevDir)
              local dot2 = (cursorPos - self.prevPos):GetNormalized():Dot(self.prevDir)
              if dot < 0.0 then
                isHardTurn = true
              elseif dot < 0.94 then
                isTurn = true
              end
            end


            if self.lastId then
              self.object:SetPoint(self.lastId + 1, {
                pos = cursorPos,
                dir = pointDir
              })

              self.object:BuildPath()
              ent:MarkDirty()

              if #self.object:GetPoints() >= MetaSign.config.limits.maxBrushLength then
                self.entity:AddNotification(MetaSign.config.messages.maxBrush, 2, MetaSign.NOTIFICATION_WARNING)
                self:FinishObject()
              end
            end

            if self.object then
              local isFirst = self.lastId == 1 and dist > 5

              if isFirst or not self.prevPos or dist > 120 or (isTurn and dist > 10 + self.thickness / 2) or (isHardTurn and dist > 2) then
                self.lastId = #self.object:GetPoints()

                if self.prevPos then
                  self.prevDir = pointDir
                end

                self.prevPos = cursorPos
              end
            end

          else
            if self.prevDown then
              if self.object then
                if self.prevPos and self.prevPos:Distance(cursorPos) <= 5 then

                  local a = self.object.points[#self.object.points]

                  self.object:RemovePoint(#self.object:GetPoints())

                  local b = self.object.points[#self.object.points]
                  local prev = self.object.points[#self.object.points - 1]
                  self.object:SetPoint(#self.object:GetPoints(), {
                    pos = a.pos,
                    dir = prev and (a.pos - prev.pos):GetNormalized() or a.dir
                  })

                  self.prevPos = a.pos

                  self.object:BuildPath()
                  ent:MarkDirty()

                end

                self.lastId = #self.object:GetPoints()
                self:FinishObject()
              end
            end
          end

          self.prevDown = down
        end
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self)
      ToolBrush.__parent.__init(self)

      self.lastId = 0
      self.thickness = 10
    end,
    __base = _base_0,
    __name = "ToolBrush",
    __parent = _parent_0
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  ToolBrush = _class_0
end

return ToolBrush
