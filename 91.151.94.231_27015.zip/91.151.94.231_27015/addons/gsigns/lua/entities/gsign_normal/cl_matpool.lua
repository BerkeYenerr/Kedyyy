--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.pool = MetaSign.pool or {
  locked = {},
  released = {},
  counter = 0
}

function MetaSign.pool.IsMaterialLocked(name)
  local mats = MetaSign.pool
  for i, mat in ipairs(mats.locked) do
    if mat == name then
      return true, i
    end
  end

  return false
end

function MetaSign.pool.LockMaterial(name)
  if MetaSign.pool.IsMaterialLocked(name) then return end

  local mats = MetaSign.pool
  mats.locked[#mats.locked + 1] = name
end

function MetaSign.pool.ReleaseMaterial(name)
  local mats = MetaSign.pool
  local isLocked, index = MetaSign.pool.IsMaterialLocked(name)

  if isLocked then
    table.remove(mats.locked, index)
  end

  mats.released[#mats.released + 1] = name
end

function MetaSign.pool.AssignMaterial()
  local mats = MetaSign.pool
  local name
  local wasAssigned = false

  if #mats.released > 0 then
    name = table.remove(mats.released, 1)
  else
    name = MetaSign.pool.GenerateMaterialName()
    wasAssigned = true
  end

  MetaSign.pool.LockMaterial(name)

  return name, true
end

function MetaSign.pool.GenerateMaterialName()
  local mat = "MetaSign_Mat_" .. MetaSign.pool.counter

  MetaSign.pool.counter = MetaSign.pool.counter + 1

  return mat
end
