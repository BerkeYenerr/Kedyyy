--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

if SERVER then AddCSLuaFile()end


local select = select
local format_string = string.format
local concat = table.concat
local len = string.len
local string_find = string.find
local string_sub = string.sub
local string_len = string.len
local tonumber = tonumber
local tostring = tostring
local math_log = math.log
local math_ceil = math.ceil
local next = next
local ipairs = ipairs
local pairs = pairs
local Angle = Angle
local Vector = Vector


local spon = {}
if _G then _G.spon = spon end





local hex_cache = {}for i = 0, 15 do
  hex_cache[format_string('%x', i)] = i end

local cache = {}
local cache_size = 0
local output_buffer = setmetatable({}, {
  __mode = 'v'})

local function empty_cache(hashy, a)
  cache_size = 0
  for k, v in pairs(hashy) do
    hashy[k] = nil end
  return a
end

local function empty_output_buffer(buffer, a)
  for k, v in ipairs(buffer) do
    buffer[k] = nil end
  return a
end





local compatibility = {}
if false then
  do
    local function safeload(lib)
      local _, a = pcall(require, lib)if not _ then return nil else
        return a end end


    _G.von = _G.von or safeload('von')
    if von and von.serialize then compatibility.vonDeserialize = von.deserialize end


    _G.pon = _G.pon or safeload('pon')
    if pon and pon.decode then compatibility.ponDecode = pon.decode end


    if util and util.JSONToTable then compatibility.JSONToTable = util.JSONToTable end
  end
end




local encoder = {}

local log16 = math_log(16)

local function encoder_write_pointer(index)
  return format_string('@%x%x', math_ceil(math_log(index + 1) / log16), index)
end

encoder['number'] = function(value, output, index)
  if value % 1 == 0 then
    if value == 0 then
      output[index] = 'I0'
    elseif value < 0 then
      output[index] = format_string('i%x%x', math_ceil(math_log(-value + 1) / log16), -value)
    else
      output[index] = format_string('I%x%x', math_ceil(math_log(value + 1) / log16), value)
    end
  else

    local dstr = tostring(math.abs(value))
    local len = string_len(dstr)
    if value < 0 then
      output[index] = format_string("d%.2x%s", len, -value)
    else
      output[index] = format_string("D%.2x%s", len, dstr)
    end
  end

  return index + 1
end
local encode_number = encoder['number']

encoder['string'] = function(value, output, index)
  if cache[value] then
    output[index] = encoder_write_pointer(cache[value])
  end
  cache_size = cache_size + 1
  cache[value] = cache_size

  local len = len(value)
  if len >= 16 * 16 then
    output[index] = format_string('T%06X%s', len, value)
  else
    output[index] = format_string('S%02X%s', len, value)
  end
  return index + 1
end

encoder['boolean'] = function(value, output, index)
  output[index] = value and 't' or 'f'
  return index + 1
end

encoder['table'] = function(value, output, index)
  if cache[value] then
    output[index] = encoder_write_pointer(cache[value])
    return index + 1
  end


  cache_size = cache_size + 1
  cache[value] = cache_size

  local table_size = #value
  local has_kv_component = next(value, table_size ~= 0 and table_size or nil)

  if table_size > 0 then
    if has_kv_component then
      output[index] = '('
    else
      output[index] = '<'
    end

    index = index + 1

    for k, v in ipairs(value) do
      index = encoder[type(v)](v, output, index)
    end

    if has_kv_component then
      output[index] = '~'
      index = index + 1
    else
      output[index] = '>'
      return index + 1
    end
  else
    output[index] = '['
    index = index + 1
  end

  for k, v in next, value, (table_size ~= 0 and table_size or nil) do
    index = encoder[type(k)](k, output, index)
    index = encoder[type(v)](v, output, index)
  end

  output[index] = ')'

  return index + 1
end

encoder['nil'] = function(value, output, index)
  output[index] = '-'
  return index + 1
end


if IsValid and FindMetaTable then
  local IsValid = IsValid
  local FindMetaTable = FindMetaTable
  local EntIndex = FindMetaTable('Entity').EntIndex

  encoder['Vector'] = function(value, output, index)
    output[index] = 'V'
    index = encode_number(value.x, output, index + 1)
    index = encode_number(value.y, output, index)
    return encode_number(value.z, output, index)
  end

  encoder['Angle'] = function(value, output, index)
    output[index] = 'A'
    index = encode_number(value.p, output, index + 1)
    index = encode_number(value.y, output, index)
    return encode_number(value.r, output, index)
  end

  encoder['Entity'] = function(value, output, index)
    if IsValid(value) then
      output[index] = 'E'
      return encode_number(EntIndex(value), output, index + 1)
    else
      return '#'
    end
  end

  encoder['Player'] = encoder['Entity']
  encoder['Vehicle'] = encoder['Entity']
  encoder['Weapon'] = encoder['Entity']
  encoder['NPC'] = encoder['Entity']
  encoder['NextBot'] = encoder['Entity']

end

local decoder = {}

decoder['S'] = function(str, index, cache)
  local strlen = tonumber(string_sub(str, index + 1, index + 2), 16)
  local str = string_sub(str, index + 3, index + (3 - 1) + strlen)
  cache_size = cache_size + 1
  cache[cache_size] = str
  return str, index + 3 + strlen
end

decoder['T'] = function(str, index, cache)
  local strlen = tonumber(string_sub(str, index + 1, index + 6), 16)
  return string_sub(str, index + 7, index + (7 - 1) + strlen), index + 7 + strlen
end

decoder['I'] = function(str, index, cache)
  local digitCount = hex_cache[string_sub(str, index + 1, index + 1)]
  if digitCount == 0 then return 0, index + 2 end
  return tonumber(string_sub(str, index + 2, index + 1 + digitCount), 16), index + (2 + digitCount)
end
decoder['i'] = function(str, index, cache)
  local digitCount = hex_cache[string_sub(str, index + 1, index + 1)]
  if digitCount == 0 then return 0, index + 2 end
  return -tonumber(string_sub(str, index + 2, index + 1 + digitCount), 16), index + (2 + digitCount)
end

decoder['D'] = function(str, index, cache)
  local digitCount = tonumber(string_sub(str, index + 1, index + 2), 16)
  if digitCount == 0 then return 0, index + 3 end
  return tonumber(string_sub(str, index + 3, index + 2 + digitCount)), index + 3 + digitCount
end
decoder['d'] = function(str, index, cache)
  local digitCount = tonumber(string_sub(str, index + 1, index + 2), 16)
  if digitCount == 0 then return 0, index + 3 end
  return -tonumber(string_sub(str, index + 3, index + 2 + digitCount)), index + 3 + digitCount
end

decoder['t'] = function(str, index)
  return true, index + 1 end
decoder['f'] = function(str, index)
  return false, index + 1 end
decoder['@'] = function(str, index)
  local digitCount = hex_cache[string_sub(str, index + 1, index + 1)]
  return cache[tonumber(string_sub(str, index + 2, index + 1 + digitCount), 16)], index + (2 + digitCount)
end

decoder['A'] = function(str, index)
  local p, y, r, char


  char = string_sub(str, index + 1, index + 1)
  p, index = decoder[char](str, index + 1)

  char = string_sub(str, index, index)
  y, index = decoder[char](str, index)

  char = string_sub(str, index, index)
  r, index = decoder[char](str, index)

  return Angle(p, y, r), index
end

decoder['V'] = function(str, index)
  local x, y, z, char


  char = string_sub(str, index + 1, index + 1)
  x, index = decoder[char](str, index + 1)

  char = string_sub(str, index, index)
  y, index = decoder[char](str, index)

  char = string_sub(str, index, index)
  z, index = decoder[char](str, index)

  return Vector(x, y, z), index
end

decoder['E'] = function(str, index)
  local entid, char


  char = string_sub(str, index + 1, index + 1)
  entid, index = decoder[char](str, index + 1)

  return Entity(entid), index
end

decoder['('] = function(str, index)
  local table = {}
  cache_size = cache_size + 1
  cache[cache_size] = table

  index = index + 1


  local i = 1
  while true do
    local c = string_sub(str, index, index)
    if c == '~' or c == ')' or c == nil then break end
    table[i], index = decoder[c](str, index, cache)
    i = i + 1
  end

  if string_sub(str, index, index) == '~' then

    index = index + 1
    local k
    while true do
      local c = string_sub(str, index, index)
      if c == ')' or c == nil then break end
      k, index = decoder[c](str, index, cache)
      c = string_sub(str, index, index)
      table[k], index = decoder[c](str, index, cache)
    end
  end

  return table, index + 1
end

decoder['['] = function(str, index)
  local table = {}
  cache_size = cache_size + 1
  cache[cache_size] = table


  index = index + 1
  local k
  while true do
    local c = string_sub(str, index, index)
    if c == ')' or c == nil then break end
    k, index = decoder[c](str, index, cache)
    c = string_sub(str, index, index)
    table[k], index = decoder[c](str, index, cache)
  end

  return table, index + 1
end

decoder['<'] = function(str, index)
  local table = {}
  cache_size = cache_size + 1
  cache[cache_size] = table

  index = index + 1


  local i = 1
  while true do
    local c = string_sub(str, index, index)
    if c == '>' or c == nil then break end
    table[i], index = decoder[c](str, index, cache)
    i = i + 1
  end

  return table, index + 1
end

decoder['-'] = function(str, index)
  return nil, index + 1
end


spon.encode = function(table)

  empty_output_buffer(output_buffer)
  empty_cache(cache)
  encoder.table(table, output_buffer, 1)
  return concat(output_buffer)
end

spon.decode = function(str)
  empty_cache(cache)

  local firstChar = string_sub(str, 1, 1)
  local decoderFunc = decoder[firstChar]

  if spon.noCompat then
    return decoderFunc(str, 1)
  end

  if not decoderFunc then
    return spon._decodeInCompatibilityMode(str, 'did not find a decoder function to handle the string beginning with \'' .. tostring(firstChar) .. '\'')
  end

  local succ, val = pcall(decoderFunc, str, 1)
  if succ then return val end

  return spon._decodeInCompatibilityMode(str, 'spon encountered error: ' .. tostring(val))
end

spon._decodeInCompatibilityMode = function(str, message)
  local firstChar = string_sub(str, 1, 1)
  if firstChar == '{' then
    message = message .. '\nthis looks like it may be a pon1 encoded object, please make sure you have pon1 installed for compatibility mode to work with it'
  end
  for k, decoder in pairs(compatibility) do
    local succ, val = pcall(decoder, str)
    if succ then return val end
    message = message .. '\ntrying decoder: ' .. k .. '\n\terror: ' .. tostring(val)
  end
  error('[spon] failed to decode string and was unable to resolve the problem in compatibility mode!\n' .. message .. '\n\nthe encoded object: ' .. tostring(str:sub(1, 100)))
end

spon.printtable = function(tbl, indent, cache)
  if indent == nil then
    return spon.printtable(tbl, 0, {})
  end
  if cache[tbl] then return end
  cache[tbl] = true
  local lpad = string.format('%' .. indent .. 's', '')

  for k, v in pairs(tbl) do
    print(lpad .. '- ' .. string_sub(type(k), 1, 1) .. ':' .. tostring(k) .. ' = ' .. string_sub(type(v), 1, 1) .. ':' .. tostring(v))
    if type(v) == 'table' then
      spon.printtable(v, indent + 4, cache)
    end
  end
end



return spon
