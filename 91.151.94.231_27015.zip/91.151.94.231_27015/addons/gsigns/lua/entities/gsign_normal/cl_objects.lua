--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.objects.registry = MetaSign.objects.registry or {}

function MetaSign.RegisterObject(obj)
  if not obj or not obj.type then return end

  MetaSign.objects.registry[obj.type] = obj
end

function MetaSign.CreateObject(type, ...)
  local ctor = MetaSign.objects.registry[type]
  if not ctor then error("Tried to create nonexistant object type " .. tostring(type))end

  return ctor(...)
end

function MetaSign.CreateObjectFromTable(tbl)
  if not tbl.type then return end

  local clazz = MetaSign.objects.registry[tbl.type]
  if not clazz then error("Tried to create nonexistant object type " .. tostring(type))end

  local obj = MetaSign.CreateObject(tbl.type)

  for k, v in pairs(tbl) do
    obj[k] = v
  end

  obj:Update()

  return obj
end

include("objects/ellipse.lua")
include("objects/rectangle.lua")
include("objects/spline.lua")
include("objects/text.lua")
include("objects/line.lua")
