--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.utils = MetaSign.utils or {}
MetaSign.easing = MetaSign.easing or {}

function MetaSign.utils.CheckParam(obj, param, name, typeStr)
  local typeFlag = false
  if typeStr then typeFlag = type(param) ~= typeStr end

  typeStr = typeStr or "any"
  local paramType = type(param)
  if param == nil or typeFlag then error("Class \"" .. tostring(obj.__name) .. "\" expected parameter \"" .. tostring(name) .. "\" of type <" .. tostring(typeStr) .. ">, got <" .. tostring(paramType) .. ">")end
end

function MetaSign.utils.DecToHex(d, zeros)
  return string.format("%0" .. (zeros or 2) .. "x", d)
end

function MetaSign.utils.RGB2HEX(color)
  return "#" .. MetaSign.utils.DecToHEX(math.max(math.min(color.r, 255), 0)) .. MetaSign.utils.DecToHEX(math.max(math.min(color.g, 255), 0)) .. MetaSign.utils.DecToHEX(math.max(math.min(color.b, 255), 0))
end

function MetaSign.utils.Hex2RGB(hex)
  hex = hex:gsub("#", "")

  if #hex == 3 then
    local r, g, b = hex:sub(1, 1), hex:sub(2, 2), hex:sub(3, 3)
    return Color(tonumber("0x" .. r .. r), tonumber("0x" .. g .. g), tonumber("0x" .. b .. b))
  end

  return Color(tonumber("0x" .. hex:sub(1, 2)), tonumber("0x" .. hex:sub(3, 4)), tonumber("0x" .. hex:sub(5, 6)))
end

function MetaSign.utils.HueToRGB(p, q, t)
  if t < 0 then t = t + 1 end
  if t > 1 then t = t - 1 end
  if t < 1 / 6 then return p + (q - p) * 6 * t end
  if t < 1 / 2 then return q end
  if t < 2 / 3 then return p + (q - p) * (2 / 3 - t) * 6 end
  return p
end

local hue2rgb = MetaSign.utils.HueToRGB

function MetaSign.utils.HSLToColor(h, s, l, a)
  local r, g, b
  local t = h / (2 * math.pi)

  if s == 0 then
    r, g, b = l, l, l
  else
    local q
    if l < 0.5 then q = l * (1 + s)else
      q = l + s - l * s end
    local p = 2 * l - q

    r = hue2rgb(p, q, t + 1 / 3)
    g = hue2rgb(p, q, t)
    b = hue2rgb(p, q, t - 1 / 3)
  end

  return Color(r * 255, g * 255, b * 255, (a or 1) * 255)
end

function MetaSign.utils.IntersectGUIPane(origin, dir, normal, up, pos, bounds)
  local intersection = util.IntersectRayWithPlane(origin, dir, pos, normal)
  if not intersection then return end

  local width, height = bounds.right - bounds.left, bounds.top - bounds.bottom

  local diff = pos - intersection
  local right = normal:Cross(up)

  local rightDot = diff:Dot(right)
  local upDot = diff:Dot(up)

  local x = (rightDot - bounds.left) / width
  local y = (upDot - bounds.bottom) / height

  return Vector(x, y, 0)
end


function MetaSign.utils.Ease(time, beginning, change, duration)
  time = time / duration
  local timeSquared = time * time
  local timeCubed = timeSquared * time
  return beginning + change * (timeCubed + -3 * timeSquared + 3 * time)
end

function MetaSign.easing.CubicInOut(time, beginning, change, duration)
  time = time / duration
  local timeSquared = time * time
  local timeCubed = timeSquared * time
  return beginning + change * (-2 * timeCubed + 3 * timeSquared)
end

function MetaSign.utils.FuzzySearch(needle, haystack)
  if not needle or not haystack then return false end

  needle = string.lower(needle)
  haystack = string.lower(haystack)

  local hlen = string.len(haystack)
  local nlen = string.len(needle)

  if nlen > hlen then
    return false
  end

  if nlen == hlen then
    return needle == haystack
  end

  local last = 1
  for i = 1, nlen do
    local nch = needle[i]

    local index = 0
    local found = false
    for j = last, hlen do
      last = j + 1
      if nch == haystack[j] then
        found = true
        break
      end
    end

    if not found then return false end
  end

  return true
end

function MetaSign.utils.FuzzySearchPlayer(str)
  local players = player.GetAll()
  for i = 1, #players do
    local ply = players[i]

    if MetaSign.utils.FuzzySearch(str, ply:Nick()) then
      return ply
    end
  end
end
