--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

include("shared.lua")

local convarNoGui = CreateClientConVar("gsigns_nogui", "0", true, false)

MetaSign.dirty = MetaSign.dirty or {}
MetaSign.materials = MetaSign.materials or {}

MetaSign.RENDER_WIDTH = 512
MetaSign.RENDER_HEIGHT = 512

include("cl_lib.lua")
include("cl_matpool.lua")
include("cl_vgui.lua")
include("cl_objects.lua")

local ToolBrush = include("tools/brush.lua")
local ToolRectangle = include("tools/rectangle.lua")
local ToolEllipse = include("tools/ellipse.lua")
local ToolLine = include("tools/line.lua")
local ToolText = include("tools/text.lua")

local GUIButton, GUIImageButton = include("gui/button.lua")

local drawEllipse = MetaSign.surface.DrawEllipse
local drawCircle = MetaSign.surface.DrawCircle

surface.CreateFont("MetaSign_GUI_Notification", {
  font = "Tahoma",
  antialias = true,
  size = 26,
  weight = 500
})

surface.CreateFont("MetaSign_GUI_Debug", {
  font = "Tahoma",
  antialias = true,
  size = 40,
  weight = 500
})

local matEdit = Material("gui/metamist/icons/edit")
local matEditStop = Material("gui/metamist/icons/edit_stop")

function ENT:Initialize()
  self:InitializeShared()

  self.lastRenderError = 0

  self.objects = {}
  self.objectHistory = {}
  self.hasAccess = false

  self.editing = false
  self.guiFadeTime = 0

  self.guiEditFadeTime = 0

  self.tools = {}
  self.currentTool = nil
  self.currentColor = Color(255, 255, 255)

  self.notifications = {}

  self.splash = 0

  self.matReady = false

  local matName, wasAssigned = MetaSign.pool.AssignMaterial()
  self.materialId = matName



  self:AddTool("brush", ToolBrush())
  self:AddTool("rectangle", ToolRectangle())
  self:AddTool("ellipse", ToolEllipse())
  self:AddTool("line", ToolLine())
  self:AddTool("text", ToolText())

  self.colorNormal = MetaSign.utils.Hex2RGB("#455A64")
  self.colorHightlight = Color(174, 213, 129)

  self.guiScale = 0.1

  self:SetupGUI()
  self:MarkDirty()

  self:SetDrawColor(Color(255, 255, 255))

  net.Start("metasign_initialize")
  net.WriteEntity(self)
  net.SendToServer()
end

function ENT:GetGUIWorkArea()
  local gScale = self.guiScale
  local obbMin = self:OBBMins()
  local obbMax = self:OBBMaxs()

  return {
    left = obbMin.y / gScale,
    right = obbMax.y / gScale,
    top = obbMin.z / gScale - 10,
    bottom = obbMax.z / gScale - 10
  }
end

function ENT:GetWorkPlaneData()
  local obbMin = self:OBBMins()
  local obbMax = self:OBBMaxs()

  local padding = 1.6
  return {
    bounds = {
      left = obbMin.y + padding,
      right = obbMax.y - padding,
      top = obbMax.z - padding,
      bottom = obbMin.z + padding
    },
    offset = Vector(0.04 * 15, 0, 0)
  }
end

function ENT:GetCameraData()
  return {
    zoom = 50
  }
end

function ENT:SetupGUI()
  if self.container then
    self.container:Remove()
  end

  self.container = MetaSign.gui.CreateContainer(self)
  self.container:EnableScreenClicker(self:IsEditing())
  self.container.OnDialogOpened = function(pnl, dialog)
    self.btnColor:CollapsePicker()

    if not dialog.keepTool then
      self:SelectTool(nil)
    end
  end

  local area = self:GetGUIWorkArea()
  local aWidth = area.right - area.left
  local aHeight = area.bottom - area.top

  local aRight = math.Round(area.right)
  local aLeft = math.Round(area.left)
  local aTop = math.Round(area.top)
  local aBottom = math.Round(area.bottom)

  self.btnEdit = MetaSign.gui.Create("ImageButton", self.container, 0 - 40, aBottom + 50 - 40, 80, 80)
  self.btnEdit:SetMaterial(matEdit)
  self.btnEdit:SetPadding(20)
  self.btnEdit:SetColor(Color(255, 255, 255))
  self.btnEdit:SetTooltip("Edit sign")
  self.btnEdit:SetTooltipAlignment(2)
  self.btnEdit.OnClick = function(btn, pos)
    net.Start("metasign_toggle_edit")
    net.WriteEntity(self)
    net.SendToServer()

    self:SelectTool(nil)
  end
  self.btnEdit.Think = function(btn)
    local f = self.guiFadeTime
    local newR = Lerp(f, self.colorNormal.r, self.colorHightlight.r)
    local newG = Lerp(f, self.colorNormal.g, self.colorHightlight.g)
    local newB = Lerp(f, self.colorNormal.b, self.colorHightlight.b)
    btn:SetBackgroundColor(Color(newR, newG, newB))
  end

  self.btnSave = MetaSign.gui.Create("ImageButton", self.container, 0, aTop - 60 - 40, 70, 70)
  self.btnSave:SetImage("gui/metamist/icons/save")
  self.btnSave:SetPadding(20)
  self.btnSave:SetColor(Color(255, 255, 255))
  self.btnSave:SetBackgroundColor(MetaSign.utils.Hex2RGB("#039BE5"))
  self.btnSave:SetTooltip("Save")
  self.btnSave:SetTooltipAlignment(6)
  self.btnSave:SetHoverBorder(8)
  self.btnSave.OnClick = function(btn, pos)
    self.fileDialog:Close()
    self.fileDialog:Open(true)
    self.btnMenu:Collapse()
  end

  self.btnLoad = MetaSign.gui.Create("ImageButton", self.container, 0, aTop - 60 - 40, 70, 70)
  self.btnLoad:SetImage("gui/metamist/icons/load")
  self.btnLoad:SetPadding(20)
  self.btnLoad:SetColor(Color(255, 255, 255))
  self.btnLoad:SetBackgroundColor(MetaSign.utils.Hex2RGB("#7CB342"))
  self.btnLoad:SetTooltip("Load")
  self.btnLoad:SetTooltipAlignment(6)
  self.btnLoad:SetHoverBorder(8)
  self.btnLoad.OnClick = function(btn, pos)
    self.fileDialog:Close()
    self.fileDialog:Open(false)
    self.btnMenu:Collapse()
  end

  self.btnSettings = MetaSign.gui.Create("ImageButton", self.container, 0, aTop - 60 - 40, 70, 70)
  self.btnSettings:SetImage("gui/metamist/icons/settings")
  self.btnSettings:SetPadding(20)
  self.btnSettings:SetColor(Color(255, 255, 255))
  self.btnSettings:SetBackgroundColor(MetaSign.utils.Hex2RGB("#7CB342"))
  self.btnSettings:SetTooltip("Settings")
  self.btnSettings:SetTooltipAlignment(6)
  self.btnSettings:SetHoverBorder(8)
  self.btnSettings.OnClick = function(btn, pos)
    self.settingsDialog:Open()
  end

  self.btnMenu = MetaSign.gui.Create("ImageButton", self.container, -200 - 40, aTop - 60 - 40, 80, 80)
  self.btnMenu:SetImage("gui/metamist/icons/menu")
  self.btnMenu:SetPadding(20)
  self.btnMenu:SetColor(Color(255, 255, 255))
  self.btnMenu:SetBackgroundColor(MetaSign.utils.Hex2RGB("#263238"))
  self.btnMenu:SetTooltip("Menu")
  self.btnMenu:SetTooltipAlignment(8)
  self.btnMenu.animDuration = 0.25
  self.btnMenu.animFraction = 0
  self.btnMenu.toggled = false
  self.btnMenu.PlayAnimation = function(btn)
    local anim = btn:NewUniqueAnimation("MenuAnim", btn.animDuration)
    anim.startRot = btn.rotation
    anim.startAnimFraction = btn.animFraction

    anim:SetOnThinkCallback(function(pnl, anim, f)
      btn.animFraction = Lerp(f, anim.startAnimFraction, btn.expanded and 1 or 0)
      pnl.rotation = btn.animFraction * -90
    end)
  end
  self.btnMenu.Expand = function(btn)
    if btn.expanded then return end

    btn.expanded = true
    btn.animTime = CurTime() + btn.animDuration

    self.btnLoad:SetDisabled(false)
    self.btnSave:SetDisabled(false)

    btn:PlayAnimation()
  end
  self.btnMenu.Collapse = function(btn)
    if not btn.expanded then return end

    btn.expanded = false
    btn.animTime = CurTime() + btn.animDuration

    self.btnLoad:SetDisabled(true)
    self.btnSave:SetDisabled(true)

    btn:PlayAnimation()
  end
  self.btnMenu.OnClick = function(btn, pos)
    if btn.expanded then
      btn:Collapse()
    else
      btn:Expand()
    end
  end
  self.btnMenu.Think = function(btn, w, h)
    local cx, cy = btn:GetCenter()

    self.btnLoad:SetPos(cx - self.btnLoad.width / 2, cy - self.btnLoad.height / 2 + (btn.height / 2 + 10 + self.btnLoad.height / 2) * btn.animFraction)
    self.btnLoad:SetAlpha(btn.animFraction)

    self.btnSave:SetPos(cx - self.btnSave.width / 2, self.btnLoad.y + (self.btnLoad.height + 10) * btn.animFraction)
    self.btnSave:SetAlpha(btn.animFraction)

    self.btnSettings:SetPos(cx - self.btnSettings.width / 2, self.btnSave.y + (self.btnSave.height + 10) * btn.animFraction)
    self.btnSettings:SetAlpha(btn.animFraction)
  end
  self.btnMenu.OnFocusLost = function(self)
    self:Collapse()
  end




  self.btnColor = MetaSign.gui.Create("ImageButton", self.container, -100 - 40, aBottom + 50 - 40, 80, 80)
  self.btnColor:SetImage("gui/metamist/icons/palette")
  self.btnColor:SetPadding(20)
  self.btnColor.editing = false
  self.btnColor.animTime = 0
  self.btnColor.animDuration = 0.25
  self.btnColor:SetTooltip("Color")
  self.btnColor:SetTooltipAlignment(8)
  self.btnColor.ExpandPicker = function(btn)
    if btn.editing then return end

    btn.editing = true
    btn.circular = false
    btn.interactable = false
    btn.showTooltip = false
    btn:ClearFocus()

    self.container:CloseDialog()

    local anim = btn:NewUniqueAnimation("MenuAnim", btn.animDuration)
    anim.prevTime = btn.animTime
    anim:SetOnThinkCallback(function(pnl, anim, f)
      pnl.animTime = Lerp(f, anim.prevTime, 1)
    end)
  end
  self.btnColor.CollapsePicker = function(btn)
    if not btn.editing then return end

    btn.editing = false
    btn.circular = true
    btn.interactable = true
    btn.showTooltip = true

    local anim = btn:NewUniqueAnimation("MenuAnim", btn.animDuration)
    anim.prevTime = btn.animTime
    anim:SetOnThinkCallback(function(pnl, anim, f)
      pnl.animTime = Lerp(f, anim.prevTime, 0)
    end)
  end
  self.btnColor.OnClick = function(btn, pos)
    btn:ExpandPicker()
  end
  self.btnColor.PaintBackgroundFocus = function(btn, w, h)
    local cx, cy = btn:GetCenter()
    local rad = btn:GetRadius()

    surface.SetDrawColor(btn.colorFocusBackground)

    local rectRad = Lerp(btn.animTime, rad, 16)
    local fw, fh = w + 8 * btn.animFocusFraction, h + 8 * btn.animFocusFraction
    MetaSign.surface.DrawRoundedRect(rectRad, cx - fw / 2, cy - fh / 2, fw, fh, 24)
  end

  self.btnColor.PaintBackground = function(btn, w, h)
    local cx, cy = btn:GetCenter()
    local rad = btn:GetRadius()

    surface.SetDrawColor(255, 255, 255)

    local rectRad = Lerp(btn.animTime, rad, 16)
    MetaSign.surface.DrawRoundedRect(rectRad, cx - w / 2, cy - h / 2, w, h, 24)

    local f = math.Clamp(btn.animTime / 0.2, 0, 1)
    surface.SetDrawColor(ColorAlpha(self.currentColor, (1 - f) * 255))

    MetaSign.surface.DrawRoundedRect(Lerp(btn.animTime, rad - 10, 16), cx - w / 2 + 10, cy - h / 2 + 10, w - 20, h - 20, 24)
  end
  self.btnColor.PaintImage = function(btn, w, h)
    local mat = btn:GetMaterial()
    if mat then
      local p = btn.padding

      surface.SetDrawColor(ColorAlpha(btn.color, (1 - btn.animTime) * 255))
      surface.SetMaterial(mat)
      surface.DrawTexturedRect(btn.x + p, btn.y + p, w - p * 2, h - p * 2)
    end
  end

  self.color = MetaSign.gui.Create("ColorPicker", self.btnColor, 100 - 50, -50, 100, 100)
  self.color.OnChange = function(obj, color)
    self:SetDrawColor(color)
  end

  self.btnColorAccept = MetaSign.gui.Create("ImageButton", self.btnColor, 0, 0, 80, 80)
  self.btnColorAccept:SetImage("gui/metamist/icons/confirm")
  self.btnColorAccept:SetPadding(16)
  self.btnColorAccept:SetColor(Color(255, 255, 255))
  self.btnColorAccept:SetTooltip("Confirm")
  self.btnColorAccept:SetTooltipAlignment(6)
  self.btnColorAccept.Think = function(btn)
    btn:SetBackgroundColor(self.currentColor)
  end
  self.btnColorAccept.OnClick = function(btn, pos)
    self.btnColor:CollapsePicker()
  end



  self.slider = MetaSign.gui.Create("SliderCircular", self.container, 100, aBottom + 50 - 20, aRight - 100 - 20, 40, false)
  self.slider:SetGrabberColor(MetaSign.utils.Hex2RGB("#263238"))
  self.slider.UpdateTooltip = function(slider)
    local tooltips = {
      brush = "Brush Thickness",
      line = "Line Thickness",
      text = "Font Size"
    }

    local txt = tooltips[self.currentTool] or ""

    slider:SetTooltip(txt, "\n", Color(0, 255, 0), math.Round(slider:GetValue()))
  end
  self.slider.OnChange = function(slider, value)
    slider:UpdateTooltip()
    self:GetTool("brush"):SetThickness(value)
    self:GetTool("line"):SetThickness(value)
    self:GetTool("text"):SetFontSize(value)
  end
  self.slider:SetValue(20)
  self.slider:SetMinMax(5, 80)


  self.objectList = MetaSign.gui.Create("ObjectList", self.container, aRight + 10, aTop + 30, 200, aHeight - 60)
  self.objectList:SetObjects(self.objects)
  self.objectList.OnClickItemDelete = function(list, index, item)
    self:RemoveObject(index)
  end
  self.objectList.OnHoverEnterItem = function(list, index, item, obj)
    obj.hovering = true
    self:MarkDirty()
  end
  self.objectList.OnHoverExitItem = function(list, index, item, obj)
    obj.hovering = false
    self:MarkDirty()
  end


  self.btnUndo = MetaSign.gui.Create("ImageButton", self.container, 180 - 40, aTop - 60 - 40, 80, 80)
  self.btnUndo:SetImage("gui/metamist/icons/undo")
  self.btnUndo:SetPadding(20)
  self.btnUndo:SetColor(Color(255, 255, 255))
  self.btnUndo:SetBackgroundColor(MetaSign.utils.Hex2RGB("#455A64"))
  self.btnUndo:SetTooltip("Undo")
  self.btnUndo:SetTooltipAlignment(8)
  self.btnUndo.OnClick = function(btn, pos)
    self:UndoObject()
  end


  self.btnClear = MetaSign.gui.Create("ImageButton", self.container, 280 - 40, aTop - 60 - 40, 80, 80)
  self.btnClear:SetImage("gui/metamist/icons/clear")
  self.btnClear:SetPadding(20)
  self.btnClear:SetColor(Color(255, 255, 255))
  self.btnClear:SetBackgroundColor(Color(198, 40, 40))
  self.btnClear:SetTooltip("Clear")
  self.btnClear:SetTooltipAlignment(8)
  self.btnClear.OnClick = function(btn, pos)
    local dialog = self.container:CreateMessageDialog("Are you sure?", "This cannot be undone!", function(bool)
      if bool then
        self:Clear()
      end
    end)
    dialog.keepTool = true
    dialog:SetHasCancelButton(true)
    dialog:Open()
  end

  self.btnToolBrush = MetaSign.gui.Create("ImageButton", self.container, aLeft - 50 - 35, -160 - 35, 70, 70)
  self.btnToolBrush:SetImage("gui/metamist/icons/tool_brush")
  self.btnToolBrush:SetPadding(16)
  self.btnToolBrush:SetColor(Color(255, 255, 255))
  self.btnToolBrush.tool = "brush"
  self.btnToolBrush:SetTooltip("Brush Tool")
  self.btnToolBrush:SetTooltipAlignment(4)
  self.btnToolBrush.OnClick = function(btn, pos)
    if self.currentTool == btn.tool then
      self:SelectTool(nil)
    else
      self:SelectTool(btn.tool)
    end
  end
  self.btnToolBrush.Think = function(btn)
    local tool = self:GetTool(btn.tool)
    local f = tool.selectTime
    local newR = Lerp(f, self.colorNormal.r, self.colorHightlight.r)
    local newG = Lerp(f, self.colorNormal.g, self.colorHightlight.g)
    local newB = Lerp(f, self.colorNormal.b, self.colorHightlight.b)
    btn:SetBackgroundColor(Color(newR, newG, newB))
  end

  self.btnToolRectangle = MetaSign.gui.Create("ImageButton", self.container, aLeft - 50 - 35, -80 - 35, 70, 70)
  self.btnToolRectangle:SetImage("gui/metamist/icons/tool_rectangle")
  self.btnToolRectangle:SetPadding(16)
  self.btnToolRectangle:SetColor(Color(255, 255, 255))
  self.btnToolRectangle.tool = "rectangle"
  self.btnToolRectangle:SetTooltip("Rectangle Tool")
  self.btnToolRectangle:SetTooltipAlignment(4)
  self.btnToolRectangle.OnClick = function(btn, pos)
    if self.currentTool == btn.tool then
      self:SelectTool(nil)
    else
      self:SelectTool(btn.tool)
    end
  end
  self.btnToolRectangle.Think = function(btn)
    local tool = self:GetTool(btn.tool)
    local f = tool.selectTime
    local newR = Lerp(f, self.colorNormal.r, self.colorHightlight.r)
    local newG = Lerp(f, self.colorNormal.g, self.colorHightlight.g)
    local newB = Lerp(f, self.colorNormal.b, self.colorHightlight.b)
    btn:SetBackgroundColor(Color(newR, newG, newB))
  end

  self.btnToolEllipse = MetaSign.gui.Create("ImageButton", self.container, aLeft - 50 - 35, 0 - 35, 70, 70)
  self.btnToolEllipse:SetImage("gui/metamist/icons/tool_ellipse")
  self.btnToolEllipse:SetPadding(16)
  self.btnToolEllipse:SetColor(Color(255, 255, 255))
  self.btnToolEllipse.tool = "ellipse"
  self.btnToolEllipse:SetTooltip("Ellipse Tool")
  self.btnToolEllipse:SetTooltipAlignment(4)
  self.btnToolEllipse.OnClick = function(btn, pos)
    if self.currentTool == btn.tool then
      self:SelectTool(nil)
    else
      self:SelectTool(btn.tool)
    end
  end
  self.btnToolEllipse.Think = function(btn)
    local tool = self:GetTool(btn.tool)
    local f = tool.selectTime
    local newR = Lerp(f, self.colorNormal.r, self.colorHightlight.r)
    local newG = Lerp(f, self.colorNormal.g, self.colorHightlight.g)
    local newB = Lerp(f, self.colorNormal.b, self.colorHightlight.b)
    btn:SetBackgroundColor(Color(newR, newG, newB))
  end

  self.btnToolLine = MetaSign.gui.Create("ImageButton", self.container, aLeft - 50 - 35, 80 - 35, 70, 70)
  self.btnToolLine:SetImage("gui/metamist/icons/tool_line")
  self.btnToolLine:SetPadding(16)
  self.btnToolLine:SetColor(Color(255, 255, 255))
  self.btnToolLine.tool = "line"
  self.btnToolLine:SetTooltip("Line Tool")
  self.btnToolLine:SetTooltipAlignment(4)
  self.btnToolLine.OnClick = function(btn, pos)
    if self.currentTool == btn.tool then
      self:SelectTool(nil)
    else
      self:SelectTool(btn.tool)
    end
  end
  self.btnToolLine.Think = function(btn)
    local tool = self:GetTool(btn.tool)
    local f = tool.selectTime
    local newR = Lerp(f, self.colorNormal.r, self.colorHightlight.r)
    local newG = Lerp(f, self.colorNormal.g, self.colorHightlight.g)
    local newB = Lerp(f, self.colorNormal.b, self.colorHightlight.b)
    btn:SetBackgroundColor(Color(newR, newG, newB))
  end

  self.btnToolText = MetaSign.gui.Create("ImageButton", self.container, aLeft - 50 - 35, 160 - 35, 70, 70)
  self.btnToolText:SetImage("gui/metamist/icons/tool_text")
  self.btnToolText:SetPadding(16)
  self.btnToolText:SetColor(Color(255, 255, 255))
  self.btnToolText.tool = "text"
  self.btnToolText:SetTooltip("Text Tool")
  self.btnToolText:SetTooltipAlignment(4)
  self.btnToolText.OnClick = function(btn, pos)
    if self.currentTool == btn.tool then
      self:SelectTool(nil)
    else
      self:SelectTool(btn.tool)
    end
  end
  self.btnToolText.Think = function(btn)
    local tool = self:GetTool(btn.tool)
    local f = tool.selectTime
    local newR = Lerp(f, self.colorNormal.r, self.colorHightlight.r)
    local newG = Lerp(f, self.colorNormal.g, self.colorHightlight.g)
    local newB = Lerp(f, self.colorNormal.b, self.colorHightlight.b)
    btn:SetBackgroundColor(Color(newR, newG, newB))
  end

  self.btnToolTextEdit = MetaSign.gui.Create("ImageButton", self.container, aLeft + 25, aBottom + 50 - 25, 50, 50)
  self.btnToolTextEdit:SetImage("gui/metamist/icons/edit")
  self.btnToolTextEdit:SetPadding(16)
  self.btnToolTextEdit:SetBorder(6)
  self.btnToolTextEdit:SetColor(Color(255, 255, 255))
  self.btnToolTextEdit:SetBackgroundColor(MetaSign.utils.Hex2RGB("#263238"))
  self.btnToolTextEdit:SetTooltip("Edit Text")
  self.btnToolTextEdit:SetTooltipAlignment(2)
  self.btnToolTextEdit.OnClick = function(btn, pos)
    self.toolEditTextDialog:Open()
  end

  self.fileDialog = MetaSign.gui.Create("FileDialog", self.container, 400, 300)
  self.fileDialog.OnDelete = function(pnl, file, saving)
    local dialog = self.container:OpenMessageDialog("Are you sure?", "This cannot be undone!", function(bool)
      if bool then
        MetaSign.saving.Delete(file)

        self.container:OpenMessageDialog("Success", "File was removed!")
      end
    end)
    dialog:SetHasCancelButton(true)
  end
  self.fileDialog.OnConfirm = function(pnl, file, saving)
    if file == "" then
      self:AddNotification(MetaSign.config.messages.fileNameEmpty, 2, MetaSign.NOTIFICATION_ERROR)
      return false
    end

    if saving then
      local saveFunc = function()
        local success = MetaSign.saving.Save(self:GetTextureDrawArea(), file, self.objects)

        if success then
          self.container:OpenMessageDialog("Success", "File has been saved!")
        else
          self.container:OpenMessageDialog("Error", "Failed to save file\nMake sure the name is valid.")
        end
      end

      if MetaSign.saving.Exists(file) then
        local dialog = self.container:OpenMessageDialog("File already exists!", "Are you sure you want to overwrite it?", function(bool)
          if bool then
            saveFunc()
          end
        end)
        dialog:SetHasCancelButton(true)
      else
        saveFunc()
      end
    else
      local selected = pnl.list:GetSelected()
      if selected then
        local name = selected:GetText()

        local loadedObjects = MetaSign.saving.Load(self:GetTextureDrawArea(), name)

        local objects = {}
        for i, obj in pairs(loadedObjects) do
          local o = MetaSign.CreateObjectFromTable(obj)

          objects[i] = o
        end

        self:SetObjectsAndSync(objects)
      end
    end
  end

  self.toolEditTextDialog = MetaSign.gui.Create("Dialog", self.container, 400, 155)
  self.toolEditTextDialog.keepTool = true
  self.toolEditTextDialog.OnOpening = function(pnl)
    local tool = self:GetTool("text")
    self.toolEditTextDialog.textEntry:SetText(tool:GetText())
  end

  self.toolEditTextDialog.label = MetaSign.gui.Create("Text", self.toolEditTextDialog, 0, 0)
  self.toolEditTextDialog.label:SetText("Edit text")
  self.toolEditTextDialog.label:SetTextColor(Color(0, 0, 0))
  self.toolEditTextDialog.label:SizeToContents()

  self.toolEditTextDialog.btnClose = MetaSign.gui.Create("ImageButton", self.toolEditTextDialog, 0, 0, 25, 25)
  self.toolEditTextDialog.btnClose:SetImage("gui/metamist/icons/delete")
  self.toolEditTextDialog.btnClose:SetPadding(4)
  self.toolEditTextDialog.btnClose:SetBorder(0)
  self.toolEditTextDialog.btnClose:SetBackgroundColor(Color(198, 40, 40))
  self.toolEditTextDialog.btnClose:SetColor(Color(255, 255, 255))
  self.toolEditTextDialog.btnClose:SetTooltip("Close")
  self.toolEditTextDialog.btnClose:SetTooltipAlignment(8)
  self.toolEditTextDialog.btnClose.OnClick = function(btn, pos)
    self.toolEditTextDialog:Close()
  end

  self.toolEditTextDialog.textEntry = MetaSign.gui.Create("TextEntry", self.toolEditTextDialog, 0, 0, 100, 40)
  self.toolEditTextDialog.textEntry:SetFocusColor(MetaSign.utils.Hex2RGB("#1E88E5"))
  self.toolEditTextDialog.textEntry:SetFocusBackgroundColor(ColorAlpha(MetaSign.utils.Hex2RGB("#EDF1FB"), 100))
  self.toolEditTextDialog.textEntry:SetBackgroundColor(MetaSign.utils.Hex2RGB("#EDF1FB"))

  self.toolEditTextDialog.btnConfirm = MetaSign.gui.Create("ImageButton", self.toolEditTextDialog, 0, 0, 40, 40)
  self.toolEditTextDialog.btnConfirm:SetImage("gui/metamist/icons/check")
  self.toolEditTextDialog.btnConfirm:SetPadding(4)
  self.toolEditTextDialog.btnConfirm:SetBorder(0)
  self.toolEditTextDialog.btnConfirm:SetBackgroundColor(MetaSign.utils.Hex2RGB("#7CB342"))
  self.toolEditTextDialog.btnConfirm:SetColor(Color(255, 255, 255))
  self.toolEditTextDialog.btnConfirm:SetTooltip("Confirm")
  self.toolEditTextDialog.btnConfirm:SetTooltipAlignment(8)
  self.toolEditTextDialog.btnConfirm.OnClick = function(pnl, pos)
    local text = self.toolEditTextDialog.textEntry:GetText()
    local tool = self:GetTool("text")

    tool:SetText(text)

    self.toolEditTextDialog:Close()
  end

  self.toolEditTextDialog.PerformLayout = function(self, w, h)
    local padding = 10

    self.btnClose:SetPos(self.x + w - self.btnClose:GetWidth() - padding, self.y + padding)
    self.btnConfirm:SetPos(self.x + w - self.btnConfirm:GetWidth() - padding, self.y + h - self.btnConfirm:GetHeight() - padding)

    self.label:SetPos(self.x + padding, self.y + padding)

    self.textEntry:SetPos(self.x + padding, self.btnClose.y + self.btnClose:GetHeight() + 15)
    self.textEntry:SetWidth(w - padding * 2)
  end

  self.settingsDialog = MetaSign.gui.Create("SettingsDialog", self.container, 500, 300)
  self.settingsDialog.OnAddUser = function(dialog, user)
    self:AddUser(user)
  end
  self.settingsDialog.OnRemoveUser = function(dialog, user)
    self:RemoveUser(user.id)
  end
  self.settingsDialog:SetUsers(self.users)

  self:SetDrawColor(self.currentColor)
end

function ENT:SetDrawColor(color)
  self.currentColor = color

  self.btnColorAccept:SetColor(MetaSign.GetContrastColor(color))
  self.btnColor:SetColor(MetaSign.GetContrastColor(color))
end

function ENT:AddTool(name, tool)
  if not name or not tool then return end

  self.tools[name] = tool
  tool.entity = self
end

function ENT:GetTool(name)
  return self.tools[name]
end

function ENT:SelectTool(name)
  if self.currentTool then
    local prevTool = self:GetTool(self.currentTool)
    prevTool.selected = false
  end

  if name then
    local newTool = self:GetTool(name)
    if not newTool then return end

    newTool.selected = true
  end

  self.currentTool = name

  self.slider:UpdateTooltip()
end

function ENT:AddGUIObject(obj)
  obj.entity = self


  return obj
end

function ENT:ClearGUIObjects()
  self.guiObjects = {}
end

function ENT:GetGUIDistanceFade()
  local lp = LocalPlayer()
  local off = math.min(self.MaxDistance * 0.75, 50)
  local f = 1 - math.Clamp((EyePos():Distance(self:GetPos()) - (self.MaxDistance - off)) / off, 0, 1)

  local dotCenter = self:LocalToWorld(Vector(0, 0, -(self.btnEdit.y + self.btnEdit:GetHeight() / 2) * self.guiScale))

  local df = lp:GetAimVector()
  local diff = (dotCenter - lp:GetShootPos()):GetNormalized()
  local dot = math.Clamp((df:Dot(diff) - 0.9) / 0.1, 0, 1)

  if self.editing then
    return f
  else
    if lp:GetNW2Bool("MetaSign_Editing") then
      return 0
    end

    return f * dot
  end
end

function ENT:GetCursorAimVector()
  return self.container:GetAimVector()
end

function ENT:IsUseKeyDown()
  return self.container:IsUseKeyDown()
end

function ENT:GetRawCursorPos(origin, direction)
  local intersection = util.IntersectRayWithPlane(origin, direction, self:LocalToWorld(Vector(0.03 * 15, 0, 0)), self:GetForward())

  if not intersection then return end

  local lcl = self:WorldToLocal(intersection)
  local obbMin = self:OBBMins()
  local obb = self:OBBMaxs() - obbMin

  local x = (lcl.y - obbMin.y + 0.5) / (obb.y + 1)
  local y = 1 - (lcl.z - obbMin.z + 1.0) / (obb.z + 1.5)

  return x, y
end

function ENT:GetCursorPos(origin, direction)
  local rawX, rawY = self:GetRawCursorPos(origin, direction)
  if not rawX or not rawY then return end

  local x, y = math.Clamp(rawX, 0, 1), math.Clamp(rawY, 0, 1)

  local drawArea = self:GetTextureDrawArea()

  self._cursorPos = Vector(drawArea.x + x * drawArea.width, drawArea.y + y * drawArea.height, 0)
  self._cursorHovering = rawX >= 0 and rawX <= 1 and rawY >= 0 and rawY <= 1

  return self._cursorPos, self._cursorHovering
end

function ENT:GetCachedCursorPos()
  return self._cursorPos, self._cursorHovering
end

function ENT:MarkDirty()
  MetaSign.dirty[self.materialId] = self
end

function ENT:ResetTools()
  for _, tool in pairs(self.tools) do
    tool:Reset()
  end
end

function ENT:Clear(noNetwork)
  self:ResetTools()

  for _, obj in pairs(self.objects) do
    obj:Clear()
  end

  self.objects = {}
  self.objectHistory = {}
  self:MarkDirty()

  self.objectList:ClearObjects()

  if noNetwork then return end
  net.Start("metasign_objects_clear")
  net.WriteEntity(self)
  net.SendToServer()
end

local pon = include("sh_pon.lua")
function ENT:AddObject(obj, noNetwork)
  if noNetwork == nil then noNetwork = false
  end
  if not obj then return end

  self.objects[#self.objects + 1] = obj
  self:MarkDirty()

  self.objectList:AddObject(obj)

  table.insert(self.objectHistory, 1, #self.objects)

  self:OnObjectAdded(obj)

  if noNetwork then return end

  net.Start("metasign_objects_add")
  net.WriteEntity(self)
  obj:WriteNetwork()
  net.SendToServer()
end

function ENT:CanCreateObject(type)
  local count = #self.objects
  if count >= MetaSign.config.limits.maxObjects then
    return false
  end

  return true
end

function ENT:SetObjects(objects)
  self.objects = objects
  self.objectList:SetObjects(objects)

  for i, o in pairs(objects) do
    self:OnObjectAdded(o)
  end

  self.objectHistory = {}
  self:MarkDirty()
end

function ENT:SetObjectsAndSync(objects)
  self:SetObjects(objects)

  net.Start("metasign_objects")
  net.WriteEntity(self)
  net.WriteUInt(#objects, 16)

  for i, obj in pairs(objects) do
    obj:WriteNetwork()
  end

  net.SendToServer()
end

function ENT:RemoveObject(index, noNetwork)
  if noNetwork == nil then noNetwork = false
  end
  self.objectList:RemoveObject(index)

  table.remove(self.objects, index)
  self:MarkDirty()

  if noNetwork then return end

  net.Start("metasign_objects_remove")
  net.WriteEntity(self)
  net.WriteUInt(index, 8)
  net.SendToServer()
end

function ENT:UndoObject()
  if #self.objectHistory == 0 then return end

  local i = table.remove(self.objectHistory, 1)

  self:RemoveObject(i)
end

function ENT:SetTemporaryObject(obj)
  self.tempObj = obj
end

function ENT:IsEditing()
  return self:GetPlayerEditing() == LocalPlayer()
end

function ENT:OnRemove()
  self.container:Remove()

  MetaSign.pool.ReleaseMaterial(self.materialId)
end

function ENT:Think()
  local lp = LocalPlayer()
  local keyUseDown = self:IsUseKeyDown()

  local cursorPos, isHovering = self:GetCursorPos(EyePos(), self:GetCursorAimVector(), self.guiScale)

  local editing = self:IsEditing()
  if self.editing and not editing then
    self.container:EnableScreenClicker(false)

    self:SelectTool(nil)
    self.btnColor:CollapsePicker()
    self.container:CloseDialog()

    self.btnMenu:Collapse()
    self.btnEdit:SetTooltip("Edit sign")
    self.btnEdit:SetMaterial(matEdit)

    MetaSign.view.Stop()
  elseif not self.editing and editing then
    self.container:EnableScreenClicker(true)

    self.btnEdit:SetTooltip("Stop editing sign")
    self.btnEdit:SetMaterial(matEditStop)

    MetaSign.view.Start(self)
  end

  self.editing = editing

  if input.IsKeyDown(KEY_F6) then
    self:MarkDirty()
  end


  local guiCursorPos, isHovering = self:GetGUICursorPos(EyePos(), self:GetCursorAimVector(), self.guiScale)
  self.guiCursorPos = guiCursorPos
  self.guiIsHovering = isHovering

  local area = self:GetGUIWorkArea()
  local aWidth = area.right - area.left
  local aHeight = area.bottom - area.top

  local aRight = math.Round(area.right)
  local aLeft = math.Round(area.left)
  local aTop = math.Round(area.top)
  local aBottom = math.Round(area.bottom)

  local ntY = aBottom - 20
  local time = CurTime()
  for i = #self.notifications, 1, -1 do
    local nt = self.notifications[i]
    local element = nt.element
    if not element then continue end

    local tf = 1 - math.Clamp((nt.startTime + nt.time - time) / nt.time, 0, 1)
    local inDur = math.min(0.2, nt.time / 2) / nt.time
    local fIn = MetaSign.utils.Ease(math.Clamp(tf / inDur, 0, 1), 0, 1, 1)
    local outDur = math.min(0.2, nt.time / 2) / nt.time
    local fOut = MetaSign.utils.Ease(math.Clamp((tf - 1 + outDur) / outDur, 0, 1), 0, 1, 1)

    element.smoothY = Lerp(10 * RealFrameTime(), element.smoothY, ntY - element:GetHeight() - fOut * 50)

    element:SetPos(-element:GetWidth() / 2, element.smoothY)
    element:SetAlpha(fIn * (1 - fOut))

    if tf >= 1 then
      element:Remove()
      table.remove(self.notifications, i)
    end

    ntY = ntY - (element:GetHeight() + 4)
  end

  self.container:Think()
  self.guiDidHover = self.container:IsGUIHovered()

  for name, tool in pairs(self.tools) do
    local selected = tool:IsSelected()
    if selected then
      tool.selectTime = Lerp(10 * FrameTime(), tool.selectTime, 1)
    else
      tool.selectTime = Lerp(10 * FrameTime(), tool.selectTime, 0)
    end

    tool:Think(selected)
  end

  self.prevKeyUseDown = keyUseDown

  if not self:GetSplash() and self.splash > 0 then
    self.splash = math.max(self.splash - 2 * FrameTime(), 0)
    self:MarkDirty()
  elseif self:GetSplash() and self.splash < 1 then
    self.splash = math.min(self.splash + 2 * FrameTime(), 1)
    self:MarkDirty()
  end
end

function ENT:GetGUICursorPos(origin, direction, guiScale)
  local intersection = util.IntersectRayWithPlane(origin, direction, self:LocalToWorld(Vector(0.03 * 15, 0, 0)), self:GetForward())

  if not intersection then return Vector(0, 0, 0), false end

  local lcl = self:WorldToLocal(intersection)

  local x = lcl.y / guiScale
  local y = -lcl.z / guiScale

  return Vector(x, y, 0), true
end

function ENT:AddNotification(text, time, type)
  if text == nil then text = "Notification"
  end
  if time == nil then time = 7
  end
  if type == nil then type = 1
  end
  local area = self:GetGUIWorkArea()
  local aWidth = area.right - area.left
  local aHeight = area.bottom - area.top

  local aRight = math.Round(area.right)
  local aLeft = math.Round(area.left)
  local aTop = math.Round(area.top)
  local aBottom = math.Round(area.bottom)

  local element = MetaSign.gui.Create("Text", self.container, 0, 0, text)
  element.alpha = 0
  element:SetWidth(aWidth * 0.5)
  element:SetPadding(4)
  element:SetWrap(true)
  element:SetTextAlignment(TEXT_ALIGN_CENTER)
  element:SetText(text)
  element:SizeToContentsY()

  local color = MetaSign.colors.notifications[type]

  element.PaintBackground = function(self, w, h)
    local padding = self.padding

    surface.SetDrawColor(color)
    MetaSign.surface.DrawRoundedRect(8, self.x, self.y, w, h, 24)
  end
  element.smoothY = aBottom + 100

  self.notifications[#self.notifications + 1] = {
    text = text,
    time = time,
    type = type,
    startTime = CurTime(),
    element = element
  }
end

function ENT:OnLimitReached()
  self:AddNotification(MetaSign.config.messages.maxObjects, 1, MetaSign.NOTIFICATION_ERROR)
end




function ENT:AddUser(user)
  net.Start("metasign_users_add")
  net.WriteEntity(self)
  net.WriteString(user)
  net.SendToServer()
end

function ENT:RemoveUser(id)
  net.Start("metasign_users_remove")
  net.WriteEntity(self)
  net.WriteString(id)
  net.SendToServer()
end

function ENT:SetUsers(users)
  self.users = users

  self.hasAccess = self:HasUserAccess(LocalPlayer())

  self.settingsDialog:SetUsers(users)
end

function ENT:DrawObject(obj, dbg)
  if dbg then
    if MetaSign.debug >= 2 then
      local bounds = obj:GetBounds()
      local size = bounds.max - bounds.min
      if size:Length() > 0 then
        surface.SetDrawColor(255, 255, 255, 50)
        surface.DrawRect(bounds.min.x, bounds.min.y, size.x, size.y)
      end
    end
  else
    obj:Render()
  end
end

function ENT:DrawObjects()
  surface.SetDrawColor(255, 255, 255)
  draw.NoTexture()

  if MetaSign.debug > 0 then for _, obj in pairs(self.objects) do
      self:DrawObject(obj, true)
    end
    if self.tempObj then
      self:DrawObject(self.tempObj, true)
    end
  end

  local hovering = {}
  for _, obj in pairs(self.objects) do
    self:DrawObject(obj)

    if obj.hovering then hovering[#hovering + 1] = obj end
  end

  if self.tempObj then
    self:DrawObject(self.tempObj)
  end

  for _, v in pairs(hovering) do
    v:RenderHover()
  end
end

function ENT:Bezier(x, a, b, c)
  local p1 = LerpVector(x, a, b)
  local p2 = LerpVector(x, b, c)

  return LerpVector(x, p1, p2)
end

function ENT:Draw()
  local mat = MetaSign.GetMaterial(self.materialId)

  if mat and self.matReady then
    render.MaterialOverrideByIndex(self.SubMaterialIndex, mat.result)

    self:DrawModel()

    render.MaterialOverrideByIndex(self.SubMaterialIndex, nil)
  else
    self:DrawModel()
  end
end

function ENT:DrawTranslucent()
  local lp = LocalPlayer()

  if convarNoGui:GetBool() then return end

  local ang = self:GetAngles()
  ang:RotateAroundAxis(self:GetRight(), 90)
  ang:RotateAroundAxis(self:GetUp(), 180)
  ang:RotateAroundAxis(self:GetForward(), -90)

  if self.editing then
    self.guiFadeTime = Lerp(10 * FrameTime(), self.guiFadeTime, 1)
  else
    self.guiFadeTime = Lerp(10 * FrameTime(), self.guiFadeTime, 0)
  end

  local f = 1 - self.guiFadeTime
  local df = self:GetGUIDistanceFade()

  if df <= 0 then return end

  self.container:SetAlpha(df)

  local tbTime = self:GetTool("brush").selectTime
  local trTime = self:GetTool("rectangle").selectTime
  local teTime = self:GetTool("ellipse").selectTime
  local tlTime = self:GetTool("line").selectTime
  local ttTime = self:GetTool("text").selectTime

  if self.hasAccess then
    self.guiEditFadeTime = Lerp(10 * FrameTime(), self.guiEditFadeTime, 1)
  else
    self.guiEditFadeTime = Lerp(10 * FrameTime(), self.guiEditFadeTime, 0)
  end

  self.btnEdit:SetAlpha(self.guiEditFadeTime)

  do
    local startX = self.btnColor.startX
    local startY = self.btnColor.startY + f * 50
    local endX = -self.btnColor:GetWidth() / 2
    local endY = -self.btnColor:GetHeight() / 2

    local time = self.btnColor.animTime

    self.btnColor:SetSize(math.Round(Lerp(time, self.btnColor.startWidth, 300) * 100) / 100, math.Round(Lerp(time, self.btnColor.startHeight, 400) * 100) / 100)

    local p = self:Bezier(time, Vector(startX, startY, 0), Vector(self.btnColor.startX, 200, 0), Vector(endX, endY, 0))

    self.btnColor:SetPos(math.Round(p.x * 100) / 100, math.Round(p.y * 100) / 100)

    self.btnColor:SetAlpha(self.guiFadeTime)
  end

  local btnColorF = (self.btnColor.animTime - 0.8) / 0.2

  self.btnColorAccept:SetPos(self.btnColor.x + self.btnColor:GetWidth() - self.btnColorAccept:GetWidth() - 10, self.btnColor.y + self.btnColor:GetHeight() - self.btnColorAccept:GetHeight() - 10)
  self.btnColorAccept:SetAlpha(self.guiFadeTime * btnColorF)

  do
    local w, h = self.btnColor:GetSize()
    local cx, cy = self.btnColor:GetCenter()

    self.color:SetSize(w - 80, w - 80)
    self.color:SetPos(cx - self.color:GetWidth() / 2, cy - h / 2 + 40)
    self.color:SetAlpha(self.guiFadeTime * btnColorF)
  end

  self.btnClear:SetPos(self.btnClear.startX, self.btnClear.startY - f * 50)
  self.btnClear:SetAlpha(self.guiFadeTime)

  self.objectList:SetPos(self.objectList.startX + f * 50, self.objectList.startY)
  self.objectList:SetAlpha(self.guiFadeTime)


  self.btnMenu:SetPos(nil, self.btnMenu.startY - f * 50)
  self.btnMenu:SetAlpha(self.guiFadeTime)





  if self.btnUndo then
    self.btnUndo:SetPos(nil, self.btnUndo.startY - f * 50)
    self.btnUndo:SetAlpha(self.guiFadeTime)
  end

  if self.btnDebug then
    self.btnDebug:SetPos(nil, self.btnDebug.startY - f * 50)
    self.btnDebug:SetAlpha(self.guiFadeTime)
  end

  self.btnToolBrush:SetPos(self.btnToolBrush.startX - f * 50 - tbTime * 25)
  self.btnToolBrush:SetAlpha(self.guiFadeTime)

  self.btnToolRectangle:SetPos(self.btnToolRectangle.startX - f * 50 - trTime * 25)
  self.btnToolRectangle:SetAlpha(self.guiFadeTime)

  self.btnToolEllipse:SetPos(self.btnToolEllipse.startX - f * 50 - teTime * 25)
  self.btnToolEllipse:SetAlpha(self.guiFadeTime)

  self.btnToolLine:SetPos(self.btnToolLine.startX - f * 50 - tlTime * 25)
  self.btnToolLine:SetAlpha(self.guiFadeTime)

  self.btnToolText:SetPos(self.btnToolText.startX - f * 50 - ttTime * 25)
  self.btnToolText:SetAlpha(self.guiFadeTime)

  self.btnToolTextEdit:SetPos(nil, self.btnToolTextEdit.startY + (1 - ttTime) * 50)
  self.btnToolTextEdit:SetAlpha(self.guiFadeTime * ttTime)

  local fs = math.max(tbTime, tlTime, ttTime)
  self.slider:SetPos(nil, self.slider.startY + (1 - fs) * 50)
  self.slider:SetAlpha(self.guiFadeTime * fs)

  local pos = self:LocalToWorld(Vector(0.03 * 15, 0, 0))
  local dot = (EyePos() - pos):Dot(self:GetForward())
  if dot > 0 then
    cam.IgnoreZ(true)
    cam.Start3D2D(pos, ang, self.guiScale)

    self.container:Paint()

    cam.End3D2D()
    cam.IgnoreZ(false)
  end
end

net.Receive("metasign_objects", function(len)
  local ent = net.ReadEntity()
  local count = net.ReadUInt(8)

  local objects = {}
  for i = 1, count do
    local obj = MetaSign.ReadNetworkedObject()
    local o = MetaSign.CreateObjectFromTable(obj)

    objects[i] = o
  end

  if not IsValid(ent) then return end

  ent:SetObjects(objects)
end)

net.Receive("metasign_objects_add", function(len)
  local ent = net.ReadEntity()
  local obj = MetaSign.ReadNetworkedObject()

  if not IsValid(ent) then return end

  local o = MetaSign.CreateObjectFromTable(obj)
  ent:AddObject(o, true)
end)

net.Receive("metasign_objects_remove", function(len)
  local ent = net.ReadEntity()
  local index = net.ReadUInt(8)

  if not IsValid(ent) then return end

  ent:RemoveObject(index, true)
end)

net.Receive("metasign_objects_clear", function(len)
  local ent = net.ReadEntity()
  if not IsValid(ent) then return end

  ent:Clear(true)
end)

net.Receive("metasign_refresh", function(len)
  local ent = net.ReadEntity()

  if not IsValid(ent) then return end

  ent:MarkDirty()
end)

net.Receive("metasign_notify", function(len)
  local ent = net.ReadEntity()
  local text = net.ReadString()
  local time = net.ReadUInt(16)
  local type = net.ReadUInt(3)

  if not IsValid(ent) then return end

  ent:AddNotification(text, time, type)
end)

net.Receive("metasign_users", function(len)
  local ent = net.ReadEntity()
  local count = net.ReadUInt(8)

  local users = {}
  for i = 1, count do
    local id = net.ReadString()
    local name = net.ReadString()

    users[#users + 1] = {
      id = id,
      name = name
    }
  end

  if not IsValid(ent) then return end

  ent:SetUsers(users)
end)

if MetaSign.debug > 0 then
  timer.Simple(0.5, function()
    for k, v in ipairs(ents.FindByClass("gsign*")) do
      if IsValid(v) then
        v:ClearGUIObjects()
        v:SetupGUI()
      end
    end
  end)
end

MetaSign.view = MetaSign.view or {
  direction = Vector(0, 0, 0),
  startDirection = Vector(0, 0, 0),
  destDirection = Vector(0, 0, 0),

  position = Vector(0, 0, 0),

  aimDirection = Vector(0, 0, 0),
  startAimDirection = Vector(0, 0, 0),

  distance = 0,
  startDistance = 0,

  startTime = 0,
  animDuration = 1,

  zoom = 60,

  enabled = false,
  showing = false,

  dragging = false,
  dragX = 0,
  dragY = 0
}

local hullSize = 5
function MetaSign.view.Start(entity)
  local lp = LocalPlayer()
  if not IsValid(lp) or not IsValid(entity) then return end

  local camData = entity:GetCameraData()

  local boxSize = entity:OBBMaxs() - entity:OBBMins()
  local center = entity:LocalToWorld(Vector(math.max(boxSize.x, hullSize), 0, 0))

  local dir = EyePos() - center
  local dist = dir:Length()
  dir:Normalize()

  local this = MetaSign.view
  this.entity = entity

  this.startTime = SysTime()

  this.startDirection = dir
  this.destDirection = ((entity:GetForward() + dir) * 0.5):GetNormalized()
  this.direction = this.destDirection
  this.angle = this.direction:Angle()

  this.startAimDirection = lp:GetAimVector()
  this.aimDirection = this.startAimDirection

  this.startDistance = dist
  this.distance = this.startDistance

  this.animDuration = 0.5

  this.zoom = camData.zoom or 60

  this.enabled = true
end

function MetaSign.view.Stop()
  local this = MetaSign.view

  this.startTime = SysTime()
  this.startDirection = this.direction
  this.startAimDirection = this.aimDirection
  this.startDistance = this.distance

  this.enabled = false
end

hook.Add("ShouldDrawLocalPlayer", "MetaSign_HideLocalPlayer", function(ply)end)

hook.Add("CalcViewModelView", "MetaSign_HideViewModel", function()
  if MetaSign.view.showing then
    return Vector(1, 1, 1) * -1000000
  end
end)

hook.Add("Think", "MetaSign_ThinkView", function()
  local view = MetaSign.view
  if not view.enabled then return end

  local mDown = input.IsMouseDown(MOUSE_RIGHT)

  if mDown and not view.dragging then
    view.dragging = true

    view.dragX, view.dragY = gui.MousePos()
  elseif not mDown and view.dragging then
    view.dragging = false
  end

  if view.dragging then
    local mx, my = gui.MousePos()
    local dx, dy = mx - view.dragX, my - view.dragY

    view.angle.y = view.angle.y - (dx * 0.5)
    view.angle.p = math.Clamp(math.NormalizeAngle(view.angle.p - dy * 0.5), -80, 80)

    view.destDirection = view.angle:Forward()

    view.dragX, view.dragY = gui.MousePos()
  end
end)

hook.Add("CalcView", "MetaSign_CalcView", function(ply, origin, angles, fov, znear, zfar)
  local data = MetaSign.view
  local time = SysTime()
  local fract = math.Clamp(math.TimeFraction(data.startTime, data.startTime + data.animDuration, time), 0, 1)

  data.showing = false
  if not data.enabled and fract >= 1 then return end

  local ent = data.entity
  if IsValid(ent) then
    local boxSize = ent:OBBMaxs() - ent:OBBMins()
    data.position = ent:LocalToWorld(Vector(math.max(boxSize.x, hullSize), 0, 0))
  else
    MetaSign.view.Stop()
    return
  end

  local t = MetaSign.easing.CubicInOut(fract, 0, 1, 1)

  data.showing = true

  data.direction = LerpVector(10 * FrameTime(), data.direction, data.destDirection):GetNormalized()

  local newAimDir = -data.direction
  local newDir = data.direction
  local newDist = data.zoom
  if not data.enabled then
    newDir = (origin - data.position)
    newAimDir = ply:GetAimVector()
    newDist = newDir:Length()

    newDir:Normalize()
  end

  local dir = LerpVector(t, data.startDirection, newDir):GetNormalized()
  data.aimDirection = LerpVector(t, data.startAimDirection, newAimDir):GetNormalized()
  data.distance = Lerp(t, data.startDistance, newDist)

  local center = data.position

  if data.enabled then
    local filter = player.GetAll()
    filter[#filter + 1] = ent

    local trace = util.TraceHull({
      start = center,
      endpos = center + dir * data.distance,
      filter = filter,
      mins = Vector(-1, -1, -1) * hullSize,
      maxs = Vector(1, 1, 1) * hullSize
    })

    if trace.Hit then
      data.distance = trace.HitPos:Distance(center)
    end
  end

  local pos = center + dir * data.distance

  local view = {}
  view.origin = pos
  view.angles = data.aimDirection:Angle()
  view.fov = fov
  view.drawviewmodel = false

  return view
end)

hook.Add("HUDShouldDraw", "MetaSign_HideGUI", function(name)
  if name == "CHudCrosshair" then
    if LocalPlayer():GetNW2Bool("MetaSign_Editing") then
      return false
    end
  end
end)
