--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign.gui = MetaSign.gui or {
  factories = {}
}

function MetaSign.gui.Create(name, parent, ...)
  local factory = MetaSign.gui.factories[name]
  if not factory then
    error("Tried to create nonexistant gui object " .. tostring(name))
  end

  local obj = factory(...)
  if parent then
    parent:AddChild(obj)
  end

  if obj.Initialize then
    obj:Initialize()
  end

  if obj.PerformLayout then
    obj:PerformLayout(obj:GetSize())
  end

  return obj
end

function MetaSign.gui.CreateContainer(entity)
  return MetaSign.gui.Create("Container", nil, entity)
end

function MetaSign.gui.Register(name, cls)
  if not name or not cls then return end

  MetaSign.gui.factories[name] = cls
end

function MetaSign.gui.Get(name)
  return MetaSign.gui.factories[name]
end


include("gui/base.lua")
include("gui/container.lua")
include("gui/button.lua")
include("gui/slider.lua")
include("gui/slidercircular.lua")
include("gui/colorpicker.lua")
include("gui/objectlist.lua")
include("gui/text.lua")
include("gui/list.lua")
include("gui/listnode.lua")
include("gui/filedialog.lua")
include("gui/textentry.lua")
include("gui/scrollbar.lua")
include("gui/panel.lua")
include("gui/dialog.lua")
include("gui/settingsdialog.lua")
