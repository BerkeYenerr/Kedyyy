--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local pon = include("entities/gsign_normal/sh_pon.lua")
local BaseGraphicsObject = include("base.lua")



local LineGraphicsObject
do
    local _class_0
    local _parent_0 = BaseGraphicsObject
    local _base_0 = {
        __name = "LineGraphicsObject",
        __base = BaseGraphicsObject.__base,
        GetBounds = function(self)
            local padding = math.sqrt(self.thickness * self.thickness * 2)

            local minX = math.min(self.x, self.endX) - padding
            local minY = math.min(self.y, self.endY) - padding
            local maxX = math.max(self.x, self.endX) + padding
            local maxY = math.max(self.y, self.endY) + padding

            self.min = Vector(minX, minY, 0)
            self.max = Vector(maxX, maxY, 0)

            return {
                min = self.min,
                max = self.max
            }
        end,
        RenderHover = function(self)
            local cx = (self.x + self.endX) / 2
            local cy = (self.y + self.endY) / 2

            local diffX = self.endX - self.x
            local diffY = self.endY - self.y
            local w = math.sqrt(diffX * diffX + diffY * diffY)
            local angle = math.deg(math.atan2(self.y - self.endY, self.endX - self.x))

            draw.NoTexture()
            surface.SetDrawColor(self.color)
            surface.DrawTexturedRectRotated(cx, cy, w, self.thickness / 2, angle)
        end,
        Render = function(self)
            local color = self.color
            if self.hovering then
                color = Color(255 - color.r, 255 - color.g, 255 - color.b)
            end

            local thickness = self.thickness

            local cx = (self.x + self.endX) / 2
            local cy = (self.y + self.endY) / 2

            local diffX = self.endX - self.x
            local diffY = self.endY - self.y
            local w = math.sqrt(diffX * diffX + diffY * diffY)
            local angle = math.deg(math.atan2(self.y - self.endY, self.endX - self.x))

            local perp = Vector(-diffY, diffX, 0):GetNormalized()

            local vertices = {}

            local x1, y1 = self.x - perp.x * thickness / 2, self.y - perp.y * thickness / 2
            local x2, y2 = self.endX - perp.x * thickness / 2, self.endY - perp.y * thickness / 2
            local x3, y3 = self.endX + perp.x * thickness / 2, self.endY + perp.y * thickness / 2
            local x4, y4 = self.x + perp.x * thickness / 2, self.y + perp.y * thickness / 2

            local u1, v1, u2, v2, u3, v3, u4, v4
            if self.uvResolver then
                u1, v1 = self.uvResolver(self, x1, y1)
                u2, v2 = self.uvResolver(self, x2, y2)
                u3, v3 = self.uvResolver(self, x3, y3)
                u4, v4 = self.uvResolver(self, x4, y4)
            end

            vertices[#vertices + 1] = {
                x = x1, y = y1, u = u1, v = v1}
            vertices[#vertices + 1] = {
                x = x2, y = y2, u = u2, v = v2}
            vertices[#vertices + 1] = {
                x = x3, y = y3, u = u3, v = v3}
            vertices[#vertices + 1] = {
                x = x4, y = y4, u = u4, v = v4}

            surface.SetDrawColor(color)
            if self.material then
                surface.SetMaterial(self.material)
            else
                draw.NoTexture()
            end

            surface.DrawPoly(vertices)
        end
    }
    _base_0.__index = _base_0
    setmetatable(_base_0, _parent_0.__index)
    _class_0 = setmetatable({
        __init = function(self, x, y, endX, endY, thickness, color)
            if color == nil then color = Color(255, 255, 255)
            end





            LineGraphicsObject.__parent.__init(self, "line")

            self.x = x
            self.y = y
            self.endX = endX
            self.endY = endY
            self.thickness = thickness
            self.color = color
        end,
        __base = _base_0,
        __name = "LineGraphicsObject",
        __parent = _parent_0,
        type = "line"
    }, {
        __index = function(cls, parent)
            local val = rawget(_base_0, parent)
            if val == nil then local parent = rawget(cls, "__parent")
                if parent then return parent[parent]
                end
            else
                return val
            end
        end,
        __call = function(cls, ...)
            local _self_0 = setmetatable({}, _base_0)
            cls.__init(_self_0, ...)
            return _self_0
        end
    })
    if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
    end
    LineGraphicsObject = _class_0
end
MetaSign.RegisterObject(LineGraphicsObject)

return LineGraphicsObject
