--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local pon = include("entities/gsign_normal/sh_pon.lua")
local BaseGraphicsObject = include("base.lua")

surface.CreateFont("MetaSign_Object_Text", {
    font = "Tahoma",
    antialias = true,
    size = 80,
    weight = 500
})


local matChalk = Material("models/metamist/chalk")

local TextGraphicsObject
do
    local _class_0
    local _parent_0 = BaseGraphicsObject
    local _base_0 = {
        __name = "TextGraphicsObject",
        __base = BaseGraphicsObject.__base,
        Render = function(self)
            local rot = self.rotation
            local fontSize = self.fontSize / 30

            local mat = Matrix()
            if MetaSign.currentMatrix then mat:Set(MetaSign.currentMatrix)end

            surface.SetFont(self.font)
            local text = self.text
            local tw, th = surface.GetTextSize(text)

            mat:Translate(Vector(self.x, self.y, 0))
            mat:Rotate(Angle(0, rot, 0))
            mat:Scale(Vector(fontSize, fontSize, 1))

            local al = self.alignment
            if al == TEXT_ALIGN_CENTER then
                mat:Translate(Vector(-tw / 2, 0, 0))
            elseif al == TEXT_ALIGN_RIGHT then
                mat:Translate(Vector(-tw, 0, 0))
            end

            mat:Translate(Vector(0, -th / 2, 0))

            cam.PushModelMatrix(mat)

            draw.DrawText(text, self.font, 0, 0, self.color, TEXT_ALIGN_LEFT)

            cam.PopModelMatrix()
        end
    }
    _base_0.__index = _base_0
    setmetatable(_base_0, _parent_0.__index)
    _class_0 = setmetatable({
        __init = function(self, text, font, x, y, fontSize, color, alignment, rotation)
            if font == nil then font = "MetaSign_Object_Text"
            end
            if color == nil then color = Color(255, 255, 255)
            end
            if alignment == nil then alignment = TEXT_ALIGN_LEFT
            end
            if rotation == nil then rotation = 0
            end





            TextGraphicsObject.__parent.__init(self, "text")

            self.text = text
            self.font = font
            self.x = x
            self.y = y
            self.fontSize = fontSize
            self.color = color
            self.alignment = alignment
            self.rotation = rotation
        end,
        __base = _base_0,
        __name = "TextGraphicsObject",
        __parent = _parent_0,
        type = "text"
    }, {
        __index = function(cls, parent)
            local val = rawget(_base_0, parent)
            if val == nil then local parent = rawget(cls, "__parent")
                if parent then return parent[parent]
                end
            else
                return val
            end
        end,
        __call = function(cls, ...)
            local _self_0 = setmetatable({}, _base_0)
            cls.__init(_self_0, ...)
            return _self_0
        end
    })
    if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
    end
    TextGraphicsObject = _class_0
end
MetaSign.RegisterObject(TextGraphicsObject)

return TextGraphicsObject
