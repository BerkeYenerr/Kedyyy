--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local pon = include("entities/gsign_normal/sh_pon.lua")
local BaseGraphicsObject = include("base.lua")



local RectangleGraphicsObject
do
  local _class_0
  local _parent_0 = BaseGraphicsObject
  local _base_0 = {
    __name = "RectangleGraphicsObject",
    __base = BaseGraphicsObject.__base,
    GetBounds = function(self)
      self.min = Vector(self.x, self.y, 0)
      self.max = Vector(self.x + self.width, self.y + self.height, 0)

      return {
        min = self.min,
        max = self.max
      }
    end,
    Serialize = function(self)
      return pon.encode({
        self.x,
        self.y,
        self.width,
        self.height
      })
    end,
    RenderHover = function(self)
      surface.SetDrawColor(self.color)
      surface.DrawRect(self.x + self.width / 4, self.y + self.height / 4, self.width / 2, self.height / 2)
    end,
    Render = function(self)
      local color = self.color
      if self.hovering then
        color = Color(255 - color.r, 255 - color.g, 255 - color.b)
      end

      surface.SetDrawColor(color)
      if self.material then
        local uStart, vStart, uEnd, vEnd
        if self.uvResolver then
          uStart, vStart = self.uvResolver(self, self.x, self.y)
          uEnd, vEnd = self.uvResolver(self, self.x + self.width, self.y + self.height)
        end

        surface.SetMaterial(self.material)
        surface.DrawTexturedRectUV(self.x, self.y, self.width, self.height, uStart, vStart, uEnd, vEnd)
      else
        surface.DrawRect(self.x, self.y, self.width, self.height)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height, color)
      if color == nil then color = Color(255, 255, 255)
      end





      RectangleGraphicsObject.__parent.__init(self, "rectangle")

      self.x = x
      self.y = y
      self.width = width
      self.height = height
      self.color = color
    end,
    __base = _base_0,
    __name = "RectangleGraphicsObject",
    __parent = _parent_0,
    type = "rectangle",
    Deserialize = function(data)
      local tbl = pon.decode(data)
      return RectangleGraphicsObject(tbl[1], tbl[2], tbl[3], tbl[4])
    end
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  RectangleGraphicsObject = _class_0
end
MetaSign.RegisterObject(RectangleGraphicsObject)

return RectangleGraphicsObject
