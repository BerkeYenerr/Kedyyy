--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local pon = include("entities/gsign_normal/sh_pon.lua")
local BaseGraphicsObject = include("base.lua")


local drawCircle = MetaSign.surface.DrawCircle

local SplineGraphicsObject
do
  local _class_0
  local _parent_0 = BaseGraphicsObject
  local _base_0 = {
    __name = "SplineGraphicsObject",
    __base = BaseGraphicsObject.__base,
    GetBounds = function(self)
      return {
        min = self.min,
        max = self.max
      }
    end,
    SetPoint = function(self, id, point)
      self.points[id] = point
      self:BuildPath()
    end,
    RemovePoint = function(self, id)
      self:SetPoint(id, nil)
    end,
    AddPoint = function(self, point)
      if self.maxPoints and #self .. points > self.maxPoints then return end

      self:SetPoint(#self.points + 1, point)
    end,
    GetPoints = function(self)
      return self.points end,
    GetPath = function(self)
      return self.path end,
    Clear = function(self)
      self.points = {}
      self:BuildPath()
    end,
    PointOnBezierCurve = function(self, p0, p1, p2, p3, t)
      local t3 = t ^ 3
      local t2 = t * t

      local f1 = -0.5 * t3 + t2 - 0.5 * t
      local f2 = 1.5 * t3 - 2.5 * t2 + 1
      local f3 = -1.5 * t3 + 2 * t2 + 0.5 * t
      local f4 = 0.5 * t3 - 0.5 * t2

      return p0.x * f1 + p1.x * f2 + p2.x * f3 + p3.x * f4, p0.y * f1 + p1.y * f2 + p2.y * f3 + p3.y * f4
    end,
    BuildPath = function(self)
      self.path = {}

      local min, max

      if #self.points > 0 then
        local p = self.points[1]
        min, max = Vector(p.pos.x, p.pos.y, p.pos.z), Vector(p.pos.x, p.pos.y, p.pos.z)
      end

      local lastX, lastY
      for i = 1, #self.points - 1 do
        local point = self.points[i]
        local pointPos = point.pos
        local next = self.points[i % #self.points + 1]
        local nextPos = next.pos

        local dist = nextPos:Distance(pointPos)

        local p0 = self.points[math.max(i - 1, 1)].pos
        local p1 = pointPos
        local p2 = self.points[i + 1].pos
        local p3 = self.points[math.min(i + 2, #self.points)].pos

        local step = 0.5
        if dist < 30 then
          local dot = (p2 - p1):GetNormalized():Dot((p3 - p1):GetNormalized())
          if dot > 0.95 then
            step = 1
          end
        end

        local it = 0
        for j = 0, 2, step do

          j = math.min(j, 1)

          local x, y = self:PointOnBezierCurve(p0, p1, p2, p3, j)

          if (not lastX or not lastY) or (math.abs(lastX - x) >= 1 or math.abs(lastY - y) >= 1) then
            if not min then min = Vector(x, y, 0)end
            if not max then max = Vector(x, y, 0)end

            if x < min.x then min.x = x end
            if y < min.y then min.y = y end

            if x > max.x then max.x = x end
            if y > max.y then max.y = y end

            self.path[#self.path + 1] = {
              x = x, y = y, u = point.u, v = point.v}
          end

          lastX, lastY = x, y

          it = it + 1

          if j == 1 then break end
        end
      end

      self.min = min or Vector(0, 0, 0)
      self.max = max or Vector(0, 0, 0)

      local padding = math.sqrt(2 * self.thickness * self.thickness) / 2
      self.min.x = self.min.x - padding
      self.min.y = self.min.y - padding
      self.max.x = self.max.x + padding
      self.max.y = self.max.y + padding
    end,
    Update = function(self)
      self:BuildPath()
    end,
    RenderHover = function(self)
      local color = self.color

      for i = 1, #self.path - 1 do
        local point = self.path[i]
        local next = self.path[i % #self.path + 1]

        surface.SetDrawColor(color)
        surface.DrawLine(next.x, next.y, point.x, point.y)
      end
    end,
    Render = function(self)
      if self.material then
        surface.SetMaterial(self.material)
      else
        draw.NoTexture()
      end

      local color = self.color
      if self.hovering then
        color = Color(255 - color.r, 255 - color.g, 255 - color.b)
      end

      surface.SetDrawColor(color)
      local thickness = self.thickness
      local vertexCount = math.ceil(math.min(6 + thickness / 10, 24))
      local capVertexCount = math.ceil(math.min(6 + thickness / 10, 24)) / 2

      if #self.points > 0 and #self.points <= 2 then
        local point = self.points[1]

        local vertices = {}
        for i = 0, 2 * math.pi, math.pi / capVertexCount do
          local cx, cy = point.pos.x + math.cos(i) * thickness / 2, point.pos.y + math.sin(i) * thickness / 2
          local cu, cv
          if self.uvResolver then
            cu, cv = self.uvResolver(self, cx, cy)
          end

          vertices[#vertices + 1] = {
            x = cx, y = cy, u = cu, v = cv}
        end

        surface.DrawPoly(vertices)
      end

      local perpStart
      local vertCount = 0
      for i = 1, #self.path - 1 do
        local entry = self.path[i]
        local nextEntry = self.path[i + 1]

        local dx = nextEntry.x - entry.x
        local dy = nextEntry.y - entry.y
        local dir = Vector(dx, dy, 0):GetNormalized()
        local perp = Vector(-dir.y, dir.x, 0)
        local perpEnd = perp

        if i < #self.path - 1 then
          local nextDir = Vector(self.path[i + 2].x - nextEntry.x, self.path[i + 2].y - nextEntry.y, 0):GetNormalized()
          local nDir = (nextDir + dir) / 2

          perpEnd = Vector(-nDir.y, nDir.x, 0):GetNormalized()
        end

        if perpStart then perp = perpStart end

        perpStart = perpEnd

        local mx = (nextEntry.x + entry.x) / 2
        local my = (nextEntry.y + entry.y) / 2
        local dist = math.sqrt(dx * dx + dy * dy)
        if dist < 1 then continue end

        local thickStart = thickness / 2
        local thickEnd = thickness / 2
        local vertices = {}

        local x1, y1 = entry.x - perp.x * thickStart, entry.y - perp.y * thickStart
        local x2, y2 = nextEntry.x - perpEnd.x * thickEnd, nextEntry.y - perpEnd.y * thickEnd
        local x3, y3 = nextEntry.x + perpEnd.x * thickEnd, nextEntry.y + perpEnd.y * thickEnd
        local x4, y4 = entry.x + perp.x * thickStart, entry.y + perp.y * thickStart

        local u1, v1, u2, v2, u3, v3, u4, v4
        if self.uvResolver then
          u1, v1 = self.uvResolver(self, x1, y1)
          u2, v2 = self.uvResolver(self, x2, y2)
          u3, v3 = self.uvResolver(self, x3, y3)
          u4, v4 = self.uvResolver(self, x4, y4)
        end

        if i == 1 then
          local angStart = math.atan2(perp.y, perp.x)

          for j = math.pi, 0, -math.pi / capVertexCount do
            local xStartCap, yStartCap = entry.x - math.cos(angStart - j) * thickStart, entry.y - math.sin(angStart - j) * thickStart
            local uStartCap, vStartCap
            if self.uvResolver then
              uStartCap, vStartCap = self.uvResolver(self, xStartCap, yStartCap)
            end

            vertices[#vertices + 1] = {
              x = xStartCap, y = yStartCap, u = uStartCap, v = vStartCap}
          end
        else
          vertices[#vertices + 1] = {
            x = x4, y = y4, u = u4, v = v4}
          vertices[#vertices + 1] = {
            x = x1, y = y1, u = u1, v = v1}
        end

        if i == #self.path - 1 then
          local angStart = math.atan2(perpEnd.y, perpEnd.x) + math.pi
          for j = math.pi, 0, -math.pi / capVertexCount do
            local xEndCap, yEndCap = nextEntry.x - math.cos(angStart - j) * thickEnd, nextEntry.y - math.sin(angStart - j) * thickEnd
            local uEndCap, vEndCap
            if self.uvResolver then
              uEndCap, vEndCap = self.uvResolver(self, xEndCap, yEndCap)
            end

            vertices[#vertices + 1] = {
              x = xEndCap, y = yEndCap, u = uEndCap, v = vEndCap}
          end
        else
          vertices[#vertices + 1] = {
            x = x2, y = y2, u = u2, v = v2}
          vertices[#vertices + 1] = {
            x = x3, y = y3, u = u3, v = v3}
        end

        surface.DrawPoly(vertices)
        vertCount = vertCount + 4
      end

      if MetaSign.debug >= 1 then
        for i = 1, #self.points - 1 do
          local point = self.points[i]
          local next = self.points[i % #self.points + 1]

          surface.SetDrawColor(0, 0, 255)
          surface.DrawLine(next.pos.x, next.pos.y, point.pos.x, point.pos.y)
          drawCircle(next.pos.x, next.pos.y, 2, 8)
          if i == 1 then
            drawCircle(point.pos.x, point.pos.y, 2, 8)
          end

          local dist = point.pos:Distance(next.pos)

          surface.SetDrawColor(0, 255, 0)
          surface.DrawLine(next.pos.x, next.pos.y, next.pos.x + next.dir.x * dist / 2, next.pos.y + next.dir.y * dist / 2)

          if i == 1 then
            surface.DrawLine(point.pos.x, point.pos.y, point.pos.x + point.dir.x * dist / 2, point.pos.y + point.dir.y * dist / 2)
          end
        end

        surface.SetDrawColor(255, 0, 0)
        for i = 1, #self.path do
          local p = self.path[i]


        end
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, thickness, color, maxPoints)


      SplineGraphicsObject.__parent.__init(self, "spline")

      self.thickness = thickness
      self.color = color or Color(255, 255, 255)
      self.maxPoints = maxPoints

      self.min = Vector(0, 0, 0)
      self.max = Vector(0, 0, 0)
      self.points = {}
      self.path = {}
    end,
    __base = _base_0,
    __name = "SplineGraphicsObject",
    __parent = _parent_0,
    type = "spline"
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  SplineGraphicsObject = _class_0
end
MetaSign.RegisterObject(SplineGraphicsObject)

return SplineGraphicsObject
