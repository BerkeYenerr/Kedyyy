--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local pon = include("entities/gsign_normal/sh_pon.lua")
local BaseGraphicsObject = include("base.lua")


local drawEllipse = MetaSign.surface.DrawEllipse

local EllipseGraphicsObject
do
  local _class_0
  local _parent_0 = BaseGraphicsObject
  local _base_0 = {
    __name = "EllipseGraphicsObject",
    __base = BaseGraphicsObject.__base,
    GetBounds = function(self)
      self.min = Vector(self.x, self.y, 0)
      self.max = Vector(self.x + self.width, self.y + self.height, 0)

      return {
        min = self.min,
        max = self.max
      }
    end,
    RenderHover = function(self)
      surface.SetDrawColor(self.color)
      drawEllipse(self.x + self.width / 2, self.y + self.height / 2, self.width / 2, self.height / 2, self.vertexCount)
    end,
    Render = function(self)
      local color = self.color
      if self.hovering then
        color = Color(255 - color.r, 255 - color.g, 255 - color.b)
      end

      surface.SetDrawColor(color)
      local vertices = {}
      local c = math.cos(0)
      local s = math.sin(0)
      for i = 0, 2 * math.pi, 2 * math.pi / self.vertexCount do
        local x = math.cos(i)
        local y = math.sin(i)

        local tempx = x * self.width / 2 * c - y * self.height * s + self.x + self.width / 2
        y = x * self.width * s + y * self.height / 2 * c + self.y + self.height / 2
        x = tempx

        local u, v
        if self.uvResolver then
          u, v = self.uvResolver(self, x, y)
        end

        vertices[#vertices + 1] = {
          x = x, y = y, u = u, v = v}
      end

      if #vertices > 0 then
        if self.material then
          surface.SetMaterial(self.material)
        else
          draw.NoTexture()
        end

        surface.DrawPoly(vertices)
      end
    end
  }
  _base_0.__index = _base_0
  setmetatable(_base_0, _parent_0.__index)
  _class_0 = setmetatable({
    __init = function(self, x, y, width, height, vertexCount, color)
      if color == nil then color = Color(255, 255, 255)
      end





      EllipseGraphicsObject.__parent.__init(self, "ellipse")

      self.x = x
      self.y = y
      self.width = width
      self.height = height
      self.vertexCount = vertexCount
      self.color = color
    end,
    __base = _base_0,
    __name = "EllipseGraphicsObject",
    __parent = _parent_0,
    type = "ellipse"
  }, {
    __index = function(cls, parent)
      local val = rawget(_base_0, parent)
      if val == nil then local parent = rawget(cls, "__parent")
        if parent then return parent[parent]
        end
      else
        return val
      end
    end,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  if _parent_0.__inherited then _parent_0.__inherited(_parent_0, _class_0)
  end
  EllipseGraphicsObject = _class_0
end
MetaSign.RegisterObject(EllipseGraphicsObject)

return EllipseGraphicsObject
