--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

local BaseGraphicsObject
do
  local _class_0
  local _base_0 = {
    __name = "BaseGraphicsObject",
    SetUVResolver = function(self, resolver)
      self.uvResolver = resolver
    end,
    SetMaterial = function(self, material)
      self.material = material
    end,
    GetBounds = function(self)
      return {
        min = Vector(0, 0, 0),
        max = Vector(0, 0, 0)
      }
    end,
    Clear = function(self) end,
    WriteNetwork = function(self)
      MetaSign.WriteNetworkedObject(self)
    end,
    Serialize = function(self) end,
    Update = function(self) end,
    RenderHover = function(self) end,
    Render = function(self) end
  }
  _base_0.__index = _base_0
  _class_0 = setmetatable({
    __init = function(self, type)
      self.type = type
    end,
    __base = _base_0,
    __name = "BaseGraphicsObject",
    type = "unknown",
    CreateEmpty = function() end,
    ReadNetwork = function()
      local tbl = MetaSign.ReadNetworkedObject(self.type)

      return MetaSign.CreateObjectFromTable(tbl)
    end,
    Deserialize = function(data) end
  }, {
    __index = _base_0,
    __call = function(cls, ...)
      local _self_0 = setmetatable({}, _base_0)
      cls.__init(_self_0, ...)
      return _self_0
    end
  })
  BaseGraphicsObject = _class_0
end

return BaseGraphicsObject
