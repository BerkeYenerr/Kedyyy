--[[
This script was written and transpiled using LAU,
a semi-superset for Lua that makes coding less like
hell and more like heaven.

If the code seems unreadable at times, that is because it was
auto-generated and beautified the best a machine can do,
which is most likely far better than any skid (also known as a monkey)
out there in the Garry's Mod community.
]]

MetaSign = MetaSign or {}
MetaSign.log = MetaSign.log or {}

MetaSign.debug = MetaSign.debug or 0

include("metasign_config.lua")

function MetaSign.log.error(...)
  MsgC(Color(255, 150, 0), "[GSigns-Error] ", ...)
  MsgC("\n")
end

function MetaSign.log.print(...)
  MsgC(Color(0, 255, 0), "[GSigns] ", Color(255, 255, 255), ...)
  MsgC("\n")
end

function MetaSign.log.debug(...)
  if MetaSign.debug == 0 then return end
  MsgC(Color(255, 150, 0), "[GSigns-D] ", Color(255, 255, 255), ...)
  MsgC("\n")
end

if SERVER then
  AddCSLuaFile("metasign_config.lua")

  if MetaSign.config.useWorkshop then
    resource.AddWorkshop("1177611143")
  else
    local function resourceAddDir(base)
      local files, directories = file.Find(base .. "/*", "GAME")

      for _, dir in pairs(directories) do
        resourceAddDir(base .. "/" .. dir)
      end
      for _, v in pairs(files) do
        MetaSign.log.debug(base .. "/" .. v)
        resource.AddSingleFile(base .. "/" .. v)
      end
    end

    resource.AddFile("resource/fonts/montserrat.ttf")

    resourceAddDir("materials/gui/metamist")
    resourceAddDir("materials/models/metamist")
    resourceAddDir("models/metamist")
  end
end

function MetaSign.SpawnFunction(ply, _, tblEnt)
  local trace = {}
  trace.start = ply:EyePos()
  trace.endpos = trace.start + ply:GetAimVector() * 150
  trace.filter = ply

  local tr = util.TraceLine(trace)

  local normal = tr.Hit and tr.HitNormal or (tr.StartPos - tr.HitPos):GetNormalized()

  local pos = tr.HitPos + normal * 0.03 * 20
  local ang = normal:Angle()
  local ent = ents.Create(tblEnt.ent)

  ent.dt = ent.dt or {}
  ent.dt.owning_ent = ply
  if ent.Setowning_ent then ent:Setowning_ent(ply)end
  ent.SID = ply.SID
  ent.allowed = tblEnt.allowed
  ent.DarkRPItem = tblEnt
  ent.frozen = tr.Hit and not IsValid(tr.Entity)

  ent:SetPos(pos)
  ent:SetAngles(ang)
  ent:Spawn()
  ent:Activate()

  local phys = ent:GetPhysicsObject()
  if IsValid(phys) then phys:Wake()end

  return ent
end

hook.Add("loadCustomDarkRPItems", "MetaSign_DarkRPItems", function()
  if not DarkRPEntities then return end

  for k, tblEnt in pairs(DarkRPEntities) do
    if string.StartWith(tblEnt.ent, "gsign") then
      if not tblEnt.spawn then
        tblEnt.spawn = MetaSign.SpawnFunction
      end
    end
  end
end)

if SERVER then
  include("metasign_version.lua")
  include("metasign_permaprops.lua")
end
